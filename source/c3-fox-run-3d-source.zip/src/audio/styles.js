// STYLES — the soundtrack as data. One style per region of the road trip north.
// Every style shares a leitmotif: the rising "fox call" pickup (sol-la-do-ish) and the
// 3-3-2 (tresillo) rhythm in its hook, so the tune feels like ONE game soundtrack that
// changes clothes as you drive from the Smokies to the Loop.
//
// Layers (L): 1 drums+bass · 2 +chords/pad · 3 +arp · 4 +lead hook · 5 +counter-melody/perc
// (key lift +2 semitones is applied by the sequencer on top of layer 5).
// Part fields: inst, from (min layer), pat {minLayer: pattern} (16 or 32 chars; . g o x X),
// p (voice params), hits [[step, len, vel, flag]], mel (see util.parseMelody).
import { parseMelody } from './util.js';

const SMOKIES = {
  id: 'smokies', name: 'Smoky Mountain Drive', bpm: 116, swing: 0.05, key: 'D', lift: 2,
  prog: ['D', 'A', 'Bm', 'G', 'D', 'A', 'G', 'A'],
  bassCenter: 40,
  parts: {
    kick:  { inst: 'kick', p: { f0: 112, f1: 44, decay: 0.42, stomp: true }, pat: { 1: 'x.......x.......', 3: 'x.......x.....x.' } },
    snare: { inst: 'clap', p: { f: 1150, decay: 0.2 }, pat: { 1: '....x.......x...' } },
    hat:   { inst: 'shaker', pat: { 1: '..x...x...x...x.', 3: 'g.x.g.x.g.x.g.xg', 5: 'ggxgggxgggxgggxg' } },
    perc:  { inst: 'wood', from: 5, p: { f: 1250 }, pat: { 5: '...x.....x....x....x.....x..x.x.' } },
    bass:  { inst: 'upright', hits: [[0, 'R', 3, 1], [4, '5L', 3, 0.8], [8, 'R', 3, 0.95], [12, '5L', 2, 0.8], [14, 'A', 2, 0.75]] },
    chords: { inst: 'strum', from: 2, n: 5, lo: 50, hi: 74,
      hits: [[0, 4, 1], [4, 2, 0.75], [6, 4, 0.6, 'U'], [10, 2, 0.5, 'U'], [12, 2, 0.8], [14, 2, 0.55, 'U']] },
    pad:   { inst: 'harmonium', from: 2, n: 3, lo: 57, hi: 72, hits: [[0, 16, 1]] },
    arp:   { inst: 'banjo', from: 3, n: 5, lo: 62, hi: 83, mode: 'idx', rate: 1,
      seq: [0, 2, 4, 1, 2, 4, 0, 3, 0, 2, 4, 1, 2, 4, 1, 4] },
    lead:  { inst: 'whistle', from: 4, gate: 0.92, mel:
      '0:F#5:3 3:F#5:3 6:E5:2 8:D5:4 12:E5:2 14:F#5:2 |' +
      '0:E5:3 3:E5:3 6:C#5:2 8:A4:6 14:B4:2 |' +
      '0:D5:3 3:D5:3 6:C#5:2 8:B4:4 12:C#5:2 14:D5:2 |' +
      '0:B4:3 3:A4:3 6:G4:2 8:A4:4 12:D5:2 14:E5:2 |' +
      '0:F#5:3 3:F#5:3 6:E5:2 8:D5:4 12:E5:2 14:F#5:2 |' +
      '0:A5:3 3:A5:3 6:G5:2 8:E5:4 12:C#5:2 14:E5:2 |' +
      '0:D5:3 3:B4:3 6:D5:2 8:G5:4 12:F#5:2 14:E5:2 |' +
      '0:E5:3 3:D5:3 6:C#5:2 8:D5:2 10:E5:6' },
    counter: { inst: 'fiddle', from: 5, lo: 57, hi: 69, rhythm: [[0, 6], [6, 6], [12, 4]] },
  },
  fill: [[8, 'clap', 0.55], [10, 'clap', 0.65], [12, 'kick', 0.9], [12, 'clap', 0.75], [13, 'clap', 0.6], [14, 'clap', 0.85], [15, 'clap', 1]],
  mix: { kick: 0.154, snare: 0.712, hat: 0.438, perc: 0.296, bass: 0.055, chords: 0.119, pad: 0.075, arp: 0.359, lead: 0.091, counter: 0.108, sparkle: 0.5, fx: 0.5 },
  pan: { hat: 0.25, perc: -0.35, chords: -0.2, arp: 0.3, counter: -0.3 },
  verb: { snare: 0.3, chords: 0.14, pad: 0.2, arp: 0.2, lead: 0.26, counter: 0.3, sparkle: 0.4, perc: 0.2 },
  title: { bpm: 100, parts: ['kick', 'hat', 'bass', 'pad', 'arp', 'lead'], lp: 5200,
    pat: { kick: 'x...............', hat: '....x.......x...' },
    mixMul: { kick: 0.55, hat: 0.7, bass: 0.6, pad: 1.3, arp: 0.62, lead: 0.72 } },
};

const FUNK = {
  id: 'funk', name: 'Riverboat Soul', bpm: 106, swing: 0.16, key: 'A', lift: 2,
  prog: ['A9', 'A9', 'D9', 'D9', 'Bm7', 'C#m7', 'D9', 'E9'],
  bassCenter: 40,
  parts: {
    kick:  { inst: 'kick', p: { f0: 140, f1: 50, decay: 0.3, click: 0.3 }, pat: { 1: 'x.....x...x.....', 3: 'x.....x...x..x..' } },
    snare: { inst: 'snare', p: { tone: 205, decay: 0.15, lp: 8000 }, pat: { 1: '....x.......x...', 2: '....x..g.g..x..g' } },
    hat:   { inst: 'hat', p: { decay: 0.035 }, pat: { 1: 'x.x.x.x.x.x.x.x.', 2: 'xgogxgogxgogxgog' } },
    ohat:  { inst: 'hat', from: 2, p: { open: true, openDecay: 0.2 }, pat: { 2: '..............x.' } },
    perc:  { inst: 'tamb', from: 5, pat: { 5: '....x.......x...' } },
    bass:  { inst: 'slap', hits: [[0, 'R', 2, 1], [3, 'O', 1, 0.8, 'pop'], [4, 'R', 1, 0.6], [6, 'R', 1, 0.9], [7, '7', 1, 0.7],
      [8, 'O', 1, 0.8, 'pop'], [10, 'R', 2, 0.95], [12, '5', 1, 0.7], [13, '7', 1, 0.6], [14, 'O', 1, 0.85, 'pop'], [15, 'R', 1, 0.6]] },
    chords: { inst: 'clav', from: 2, n: 3, lo: 62, hi: 77, hits: [[2, 1, 0.8], [5, 1, 0.6], [7, 1, 0.9], [10, 1, 0.7], [13, 1, 0.6], [15, 1, 0.8]] },
    pad:   { inst: 'ep', from: 2, n: 4, lo: 55, hi: 72, hits: [[0, 6, 0.85], [6, 10, 0.6]] },
    arp:   { inst: 'scratch', from: 3, n: 2, lo: 64, hi: 79, mode: 'dyad', pat: 'x.xg.xgxx.xg.xgx' },
    lead:  { inst: 'horns', from: 4, gate: 0.72, mel:
      '0:E5:2 2:F#5:2 4:A5:3 10:G5:1 11:A5:1 12:E5:3 |' +
      '6:C#5:1 7:D5:1 8:E5:2 10:C#5:2 12:A4:3 |' +
      '0:A4:2 2:B4:2 4:D5:3 10:C5:1 11:D5:1 12:A4:3 |' +
      '6:F#5:1 7:E5:1 8:D5:2 10:C5:2 12:A4:3 |' +
      '0:D5:3 3:D5:3 6:F#5:2 8:E5:4 12:D5:3 |' +
      '0:E5:3 3:E5:3 6:G#5:2 8:F#5:4 12:E5:3 |' +
      '0:F#5:3 3:F#5:3 6:A5:2 8:F#5:2 10:E5:2 12:D5:3 |' +
      '0:G#5:3 3:F#5:3 6:E5:2 8:D5:2 10:E5:5' },
    counter: { inst: 'ep', from: 5, lo: 60, hi: 72, rhythm: [[4, 2], [7, 3], [12, 4]] },
  },
  fill: [[8, 'tom', 0.7, { f: 210 }], [10, 'tom', 0.7, { f: 165 }], [12, 'snare', 0.6], [13, 'snare', 0.7], [14, 'tom', 0.9, { f: 120 }], [15, 'snare', 1]],
  mix: { kick: 0.165, snare: 0.402, hat: 0.481, ohat: 0.29, perc: 0.47, bass: 0.064, chords: 0.775, pad: 0.096, arp: 0.323, lead: 0.25, counter: 0.158, sparkle: 0.5, fx: 0.5 },
  pan: { hat: 0.22, ohat: 0.22, perc: -0.3, chords: 0.3, arp: -0.32, counter: -0.2, pad: -0.1 },
  verb: { snare: 0.22, chords: 0.08, pad: 0.16, arp: 0.08, lead: 0.2, counter: 0.26, sparkle: 0.4, perc: 0.15 },
};

const HOOSIER = {
  id: 'hoosier', name: 'Heartland Highway', bpm: 118, swing: 0, key: 'F', lift: 2,
  prog: ['Dm', 'Bb', 'F', 'C', 'Dm', 'Bb', 'F', 'C'],
  bassCenter: 39, echoBeats: 0.75,
  parts: {
    kick:  { inst: 'kick', p: { f0: 128, f1: 46, decay: 0.36, click: 0.2 }, pat: { 1: 'x.......x.x.....', 4: 'x...x...x...x...' } },
    snare: { inst: 'snare', p: { tone: 175, decay: 0.24, pink: true, lp: 6500, body: 0.25, noise: 1.5 }, pat: { 1: '....x.......x...' } },
    hat:   { inst: 'hat', p: { decay: 0.05, hp: 6800 }, pat: { 1: 'x.x.x.x.x.x.x.x.', 3: 'xgxgxgxgxgxgxgxg' } },
    perc:  { inst: 'tamb', from: 5, pat: { 5: '....x.......x...' } },
    bass:  { inst: 'pulse', hits: [[0, 'R', 2, 1], [2, 'R', 2, 0.7], [4, 'R', 2, 0.8], [6, 'R', 2, 0.7], [8, 'R', 2, 0.9], [10, 'R', 2, 0.7], [12, 'R', 2, 0.8], [14, 'O', 2, 0.7]] },
    chords: { inst: 'supersaw', from: 2, n: 4, lo: 55, hi: 74, hits: [[0, 16, 1]] },
    arp:   { inst: 'pluck', from: 3, n: 4, lo: 65, hi: 84, mode: 'idx', rate: 2, seq: [0, 2, 1, 2, 3, 2, 1, 2], echo: 0.5 },
    lead:  { inst: 'synthlead', from: 4, gate: 0.9, mel:
      '0:A4:2 2:C5:2 4:D5:6 10:C5:2 12:D5:2 14:F5:2 |' +
      '0:F5:4 4:D5:4 8:C5:2 10:Bb4:2 12:C5:4 |' +
      '0:A4:2 2:C5:2 4:F5:6 10:E5:2 12:F5:2 14:G5:2 |' +
      '0:G5:4 4:E5:4 8:C5:8 |' +
      '0:A4:2 2:C5:2 4:D5:6 10:C5:2 12:D5:2 14:F5:2 |' +
      '0:F5:4 4:D5:4 8:F5:2 10:G5:2 12:A5:4 |' +
      '0:A5:6 6:G5:2 8:F5:4 12:C5:4 |' +
      '0:G5:4 4:F5:2 6:E5:2 8:C5:8' },
    counter: { inst: 'strings', from: 5, lo: 60, hi: 72, rhythm: [[0, 8], [8, 8]] },
  },
  fill: [[8, 'snare', 0.5], [10, 'snare', 0.6], [12, 'tom', 0.8, { f: 185 }], [13, 'tom', 0.8, { f: 150 }], [14, 'tom', 0.9, { f: 120 }], [15, 'tom', 1, { f: 95 }]],
  mix: { kick: 0.166, snare: 0.643, hat: 0.335, perc: 0.457, bass: 0.073, chords: 0.124, arp: 0.253, lead: 0.196, counter: 0.188, sparkle: 0.5, fx: 0.5 },
  pan: { hat: 0.2, perc: -0.3, arp: -0.25, counter: 0.25 },
  verb: { snare: 0.42, chords: 0.18, arp: 0.15, lead: 0.24, counter: 0.3, sparkle: 0.4, perc: 0.2 },
};

const STEEL = {
  id: 'steel', name: 'Gary Steel', bpm: 122, swing: 0, key: 'E', lift: 2,
  prog: ['Em', 'Em', 'C', 'D', 'Em', 'Em', 'C', 'B'],
  bassCenter: 40,
  parts: {
    kick:  { inst: 'kick', p: { f0: 150, f1: 44, decay: 0.34, click: 0.35, drive: 'soft' }, pat: { 1: 'x.....x...x.....', 3: 'x..x..x...x..x..' } },
    snare: { inst: 'snare', p: { tone: 210, decay: 0.2, drive: 'hard', hp: 800, lp: 6000 }, pat: { 1: '....x.......x...' } },
    hat:   { inst: 'hat', p: { decay: 0.03, hp: 8200 }, pat: { 1: 'x.x.x.x.x.x.x.x.', 2: 'xgogxgogxgogxgog' } },
    perc:  { inst: 'metal', from: 2, p: { f: 300 }, pat: { 2: '......x.......x.', 5: '..x...x...x.x.x.' } },
    bass:  { inst: 'dist', hits: [[0, 'R', 2, 1], [2, 'R', 1, 0.6], [3, 'R', 1, 0.7], [4, 'O', 1, 0.8], [6, 'R', 1, 0.7], [7, '5', 1, 0.6],
      [8, 'R', 2, 0.9], [10, 'R', 1, 0.6], [11, 'R', 1, 0.7], [12, 'O', 1, 0.8], [14, '5', 1, 0.7], [15, 'R', 1, 0.6]] },
    chords: { inst: 'darkpad', from: 2, n: 3, lo: 52, hi: 67, hits: [[0, 16, 1]] },
    arp:   { inst: 'sqarp', from: 3, n: 5, lo: 64, hi: 88, mode: 'idx', rate: 1, seq: [0, 1, 2, 3, 4, 3, 2, 1, 0, 2, 4, 2, 3, 1, 2, 0] },
    lead:  { inst: 'squarelead', from: 4, gate: 0.85, mel:
      '0:B4:2 2:D5:2 4:E5:6 10:D5:2 12:E5:2 14:G5:2 |' +
      '0:F#5:4 4:E5:4 8:D5:2 10:B4:6 |' +
      '0:C5:2 2:E5:2 4:G5:6 10:F#5:2 12:E5:2 14:C5:2 |' +
      '0:D5:4 4:F#5:4 8:A5:4 12:F#5:4 |' +
      '0:B4:2 2:D5:2 4:E5:6 10:D5:2 12:E5:2 14:G5:2 |' +
      '0:G5:4 4:F#5:4 8:E5:2 10:D5:2 12:E5:4 |' +
      '0:E5:2 2:G5:2 4:C6:6 10:B5:2 12:G5:2 14:E5:2 |' +
      '0:F#5:4 4:D#5:4 8:B4:8' },
    counter: { inst: 'bell', from: 5, lo: 59, hi: 71, rhythm: [[0, 6], [6, 6], [12, 4]] },
  },
  fill: [[8, 'snare', 0.45], [9, 'snare', 0.4], [10, 'snare', 0.55], [11, 'snare', 0.5], [12, 'snare', 0.65], [13, 'snare', 0.7], [14, 'metal', 0.9], [15, 'snare', 1]],
  mix: { kick: 0.101, snare: 0.109, hat: 0.496, perc: 0.198, bass: 0.125, chords: 0.084, arp: 0.376, lead: 0.308, counter: 0.285, sparkle: 0.5, fx: 0.5 },
  pan: { hat: -0.2, perc: 0.35, arp: 0.25, counter: -0.3 },
  verb: { snare: 0.28, chords: 0.2, arp: 0.12, lead: 0.2, counter: 0.35, sparkle: 0.4, perc: 0.3 },
};

const HOUSE = {
  id: 'house', name: 'Chicago Jack', bpm: 124, swing: 0.04, key: 'C', lift: 2,
  prog: ['Fmaj7', 'G', 'Em7', 'Am7', 'Fmaj7', 'G', 'E7', 'Am7'],
  bassCenter: 40, pump: ['pad', 'chords', 'counter'],
  parts: {
    kick:  { inst: 'kick', p: { f0: 125, f1: 47, decay: 0.38, click: 0.25 }, pat: { 1: 'x...x...x...x...' } },
    snare: { inst: 'clap', p: { f: 1300, decay: 0.18 }, pat: { 1: '....x.......x...' } },
    ohat:  { inst: 'hat', p: { open: true, openDecay: 0.2, hp: 7200 }, pat: { 1: '..x...x...x...x.' } },
    hat:   { inst: 'hat', from: 3, p: { decay: 0.03, hp: 8600 }, pat: { 3: 'gg.ggg.ggg.ggg.g' } },
    perc:  { inst: 'shaker', from: 5, pat: { 5: 'ogxgogxgogxgogxg' } },
    bass:  { inst: 'house', hits: [[2, 'R', 2, 1], [6, 'R', 2, 0.9], [10, 'R', 2, 1], [13, 'O', 1, 0.6], [14, 'R', 2, 0.85]] },
    chords: { inst: 'piano', from: 2, n: 4, lo: 60, hi: 77, hits: [[0, 2, 1], [3, 2, 0.7], [6, 2, 0.9], [10, 2, 0.75], [13, 3, 0.85]] },
    pad:   { inst: 'strings', from: 2, n: 3, lo: 60, hi: 76, hits: [[0, 16, 1]] },
    arp:   { inst: 'acid', from: 3, mode: 'acid', seq: ['R!', '.', 'O', 'R', '.', '5', 'O!', 'R~', 'R', '.', '7', 'O', '.', 'R!', '5', 'O~'] },
    lead:  { inst: 'piano', from: 4, gate: 0.8, oct: -12, mel:
      '0:E5:2 2:G5:2 4:A5:4 8:G5:2 10:A5:2 12:C6:4 |' +
      '0:B5:3 3:A5:3 6:G5:2 8:D5:4 12:G5:4 |' +
      '0:G5:3 3:G5:3 6:E5:2 8:D5:2 10:E5:2 12:B4:4 |' +
      '0:C5:3 3:C5:3 6:D5:2 8:E5:8 |' +
      '0:E5:2 2:G5:2 4:A5:4 8:G5:2 10:A5:2 12:C6:4 |' +
      '0:B5:3 3:A5:3 6:G5:2 8:A5:2 10:B5:2 12:D6:4 |' +
      '0:B5:3 3:G#5:3 6:E5:2 8:D5:2 10:E5:2 12:G#5:4 |' +
      '0:A5:6 6:G5:2 8:E5:8' },
    counter: { inst: 'strings', from: 5, lo: 64, hi: 76, rhythm: [[0, 12], [12, 4]] },
  },
  fill: [[8, 'clap', 0.45], [10, 'clap', 0.55], [12, 'clap', 0.65], [13, 'clap', 0.72], [14, 'clap', 0.85], [15, 'clap', 1]],
  mix: { kick: 0.182, snare: 0.664, ohat: 0.345, hat: 0.823, perc: 0.318, bass: 0.068, chords: 0.201, pad: 0.098, arp: 0.07, lead: 0.276, counter: 0.212, sparkle: 0.5, fx: 0.5 },
  pan: { ohat: 0.15, hat: -0.2, perc: 0.3, arp: -0.15, counter: 0.25, pad: -0.1 },
  verb: { snare: 0.3, chords: 0.16, pad: 0.2, arp: 0.08, lead: 0.2, counter: 0.28, sparkle: 0.4, perc: 0.15 },
};

export const STYLES = { smokies: SMOKIES, funk: FUNK, hoosier: HOOSIER, steel: STEEL, house: HOUSE };
export const STYLE_ORDER = ['smokies', 'funk', 'hoosier', 'steel', 'house'];
/** THEMES[i].region -> style id */
export const REGION_STYLE = { smokies: 'smokies', bluegrass: 'funk', ohio: 'funk', hoosier: 'hoosier', steel: 'steel', chicago: 'house' };
export const PART_NAMES = ['kick', 'snare', 'hat', 'ohat', 'perc', 'bass', 'chords', 'pad', 'arp', 'lead', 'counter', 'sparkle', 'fx'];
export const DRUM_PARTS = ['kick', 'snare', 'hat', 'ohat', 'perc'];

// pre-parse melodies once
for (const id in STYLES) {
  const s = STYLES[id];
  if (s.parts.lead && s.parts.lead.mel) s.parts.lead.bars = parseMelody(s.parts.lead.mel);
}
