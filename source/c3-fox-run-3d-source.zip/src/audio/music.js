// MUSIC — a 16th-note lookahead sequencer (Chris Wilson "tale of two clocks" pattern).
// pump() schedules every step whose time falls inside [now, now + LOOKAHEAD] against the
// audio clock; nothing is ever fired from frame deltas. The same code renders offline: the
// harness replaces `nowFn` with a simulated clock and pumps in small chunks.
//
// State machine: mode 'off' | 'title' | 'run'. Layers 1..5 (+ key lift) are recomputed on bar
// boundaries and only ENTER on 4-bar phrase boundaries of the current level section.
// Level-ups are quantised to the next bar at least one beat away: riser from now, drum fill
// in the last two beats, crash + new style (region morph) + hook restart on the downbeat.
import { STYLES, PART_NAMES, DRUM_PARTS } from './styles.js';
import { parseChord, voiceChord, pcOf, VEL, rng } from './util.js';

const LOOKAHEAD = 0.12;      // seconds scheduled ahead of the audio clock
const EMPTY = Object.freeze({});
const UP = Object.freeze({ up: true });
const POP = Object.freeze({ pop: true });
const MAJOR = [0, 2, 4, 5, 7, 9, 11];
const SCALES = { steel: [0, 2, 3, 5, 7, 8, 10], funk: [0, 2, 4, 5, 7, 9, 10] };

export function createMusic(ctx, graph, I, opts = {}) {
  const rand = opts.rand || rng(7);
  const hasPan = !!ctx.createStereoPanner;

  // ---------------------------------------------------------------- per-part buses
  const bus = {};
  for (const name of PART_NAMES) {
    const inp = ctx.createGain(), pump = ctx.createGain();
    const send = ctx.createGain(), echo = ctx.createGain();
    send.gain.value = 0; echo.gain.value = 0;
    inp.connect(pump);
    let tail = pump;
    let pan = null;
    if (hasPan) { pan = ctx.createStereoPanner(); pump.connect(pan); tail = pan; }
    tail.connect(graph.music);
    pump.connect(send); send.connect(graph.verbIn);
    pump.connect(echo); echo.connect(graph.echoIn);
    bus[name] = { in: inp, pump, pan, send, echo };
  }

  const S = {
    playing: false, mode: 'off', style: null, styleId: null,
    bpm: 120, stepDur: 0.125, swing: 0,
    nextT: 0, barT: 0, step: 0, bar: 0, phraseBar: 0, sectionBar: 0,
    layers: 1, lift: 0, pending: null, justSwitched: false,
    boost: false, sparkle: false, comboHot: false,
    game: { level: 1, lap: 1, progress: 0 },
    forceLayers: null, forceLift: null,
    chord: null, nextChord: null, counterPrev: 0, acidPrev: 0,
    lateSkips: 0, steps: 0, schedMs: 0,
  };

  const M = {
    S, bus, nowFn: null, log: null,
    now() { return M.nowFn ? M.nowFn() : ctx.currentTime; },
    get beatDur() { return S.stepDur * 4; },
    get barDur() { return S.stepDur * 16; },
  };

  // ---------------------------------------------------------------- style prep (cached)
  function prep(style) {
    if (style._prepped) return style;
    const P = style.parts;
    style.scalePcs = (SCALES[style.id] || MAJOR).map(i => (i + pcOf(style.key)) % 12);
    style.chords = style.prog.map(parseChord);
    const L = style.prog.length;
    for (const name in P) {
      const p = P[name];
      if (p.hits) { // index hits by step
        p.byStep = [];
        for (const h of p.hits) (p.byStep[h[0]] = p.byStep[h[0]] || []).push(h);
      }
      if (p.n) { // voice-led voicings through the progression (twice round so bar 0 leads from bar 7)
        let prev = null; const v = [];
        for (let k = 0; k < L * 2; k++) { prev = voiceChord(style.chords[k % L], p.n, p.lo, p.hi, prev); if (k >= L) v[k - L] = prev; }
        p.voicings = v;
      }
      if (p.rhythm) { p.rByStep = []; for (const r of p.rhythm) p.rByStep[r[0]] = r; }
      if (p.lo && !p.n) { // chord-tone pools for counter melodies
        p.pools = style.chords.map(c => {
          const out = [];
          for (let m = p.lo; m <= p.hi; m++) if (c.iv.some(i => (c.root + i) % 12 === ((m % 12) + 12) % 12)) out.push(m);
          return out;
        });
      }
      if (p.bars) { // lead bars indexed by step
        p.barSteps = p.bars.map(bar => { const a = []; for (const n of bar) (a[n[0]] = a[n[0]] || []).push(n); return a; });
      }
    }
    style.patCache = {};
    style._prepped = true;
    return style;
  }
  for (const id in STYLES) prep(STYLES[id]);
  // sparkle pools per style (C6..C7)
  for (const id in STYLES) {
    const s = STYLES[id];
    s.sparklePools = s.chords.map(c => {
      const out = [];
      for (let m = 84; m <= 96; m++) if (c.iv.some(i => i < 12 && (c.root + i) % 12 === m % 12)) out.push(m);
      return out;
    });
  }

  function placeRoot(pc, centre) {
    let m = centre - 6 + ((pc - (centre - 6)) % 12 + 12) % 12;
    return m;
  }

  // apply a style's mix at time t (bar boundary)
  function applyMix(style, t, title) {
    const mul = title && style.title ? style.title.mixMul || EMPTY : EMPTY;
    for (const name of PART_NAMES) {
      const b = bus[name];
      const lvl = (style.mix[name] ?? 0.6) * (mul[name] ?? 1);
      b.in.gain.setValueAtTime(lvl, t);
      b.send.gain.setValueAtTime(style.verb[name] || 0, t);
      b.echo.gain.setValueAtTime(style.parts[name] && style.parts[name].echo || 0, t);
      if (b.pan) b.pan.pan.setValueAtTime(style.pan[name] || 0, t);
    }
    if (style.echoBeats) graph.echo.delayTime.setValueAtTime(style.echoBeats * 60 / S.bpm, t);
  }

  function loadStyle(id, t, title) {
    const style = STYLES[id] || STYLES.smokies;
    S.style = style; S.styleId = style.id;
    S.bpm = (title && style.title ? style.title.bpm : style.bpm) + (S.mode === 'run' ? Math.min(9, (S.game.lap - 1) * 3) : 0);
    S.stepDur = 60 / S.bpm / 4;
    S.swing = style.swing;
    applyMix(style, t, title);
  }

  // ---------------------------------------------------------------- layer logic
  function wantLayers() {
    if (S.forceLayers != null) return S.forceLayers;
    const g = S.game, barsIn = S.bar - S.sectionBar;
    if (g.lap > 1) return 5;
    return Math.min(5, Math.max(1, g.level + (barsIn >= 4 ? 1 : 0)));
  }
  function wantLift() {
    if (S.forceLift != null) return S.forceLift;
    const g = S.game, barsIn = S.bar - S.sectionBar;
    return (g.level >= 5 || g.lap > 1) && barsIn >= 8 ? (S.style.lift || 2) : 0;
  }

  function onBarStart(t) {
    S.barT = t;
    const P = S.pending;
    S.justSwitched = false;
    if (P && S.bar >= P.bar) {
      S.pending = null;
      loadStyle(P.styleId, t, false);
      S.phraseBar = 0; S.sectionBar = S.bar; S.lift = 0; S.justSwitched = true;
      I.crash(t, 0.6, bus.fx.in);
      I.kick(t, 0.28, bus.fx.in, { f0: 90, f1: 38, decay: 0.6 }); // sub drop under the crash
    }
    if (S.mode === 'run') {
      const barsIn = S.bar - S.sectionBar;
      const L = wantLayers();
      if (L < S.layers || (L > S.layers && (barsIn % 4 === 0 || S.forceLayers != null))) S.layers = L;
      const lf = wantLift();
      if (lf !== S.lift && (barsIn % 4 === 0 || S.forceLift != null)) S.lift = lf;
    } else if (S.mode === 'title') { S.layers = 5; S.lift = 0; }
    const prog = S.style.chords;
    S.chord = prog[S.phraseBar % prog.length];
    S.nextChord = prog[(S.phraseBar + 1) % prog.length];
  }

  function active(name) {
    const p = S.style.parts[name];
    if (!p) return false;
    if (S.mode === 'title') return S.style.title.parts.includes(name);
    if (S.mode !== 'run') return false;
    if (name === 'perc' && S.comboHot) return true;
    return (p.from || 1) <= S.layers;
  }

  function patFor(name, p) {
    if (S.mode === 'title') { const tp = S.style.title.pat[name]; if (tp) return tp; }
    const lim = Math.max(S.layers, p.from || 1, S.comboHot && name === 'perc' ? 5 : 0);
    let best = null;
    for (const k in p.pat) if (+k <= lim) best = p.pat[k];
    return best;
  }

  // ---------------------------------------------------------------- per-step players
  function note(part, t, m) { if (M.log) M.log.push({ t, part, m, bar: S.bar, step: S.step, margin: t - ctx.currentTime }); }

  function playDrums(t, st) {
    const style = S.style, P = style.parts;
    const inFill = S.pending && S.bar === S.pending.bar - 1 && st >= 8;
    for (let i = 0; i < DRUM_PARTS.length; i++) {
      const name = DRUM_PARTS[i], p = P[name];
      if (!p) continue;
      if (inFill && name !== 'kick') continue;
      if (name === 'hat' && S.boost && S.mode === 'run') { // GIG BOOST: double-time hats
        const v = (st & 3) === 0 ? 0.8 : (st & 1) ? 0.4 : 0.6;
        I.drum(p.inst === 'shaker' ? 'shaker' : 'hat', t, v, bus.hat.in, p.p);
        if (st & 1) I.drum('hat', t + S.stepDur * 0.5, 0.3, bus.hat.in, p.p);
        note('hat', t, 0);
        continue;
      }
      if (!active(name)) continue;
      const pat = patFor(name, p);
      if (!pat) continue;
      const ch = pat[(S.phraseBar * 16 + st) % pat.length];
      const v = VEL[ch];
      if (!v) continue;
      I.drum(p.inst, t, v, bus[name].in, p.p);
      note(name, t, 0);
      if (name === 'kick' && style.pump) for (const pn of style.pump) { // sidechain pump
        const g = bus[pn].pump.gain;
        g.setTargetAtTime(0.38, t, 0.006);
        g.setTargetAtTime(1, t + 0.04, 0.085);
      }
    }
    if (inFill && style.fill) for (const f of style.fill) if (f[0] === st) {
      I.drum(f[1], t, f[2] * (0.75 + 0.25 * S.pending.fillAmt), f[1] === 'kick' ? bus.kick.in : bus.snare.in, f[3] || P.snare && P.snare.p || EMPTY);
      note('fill', t, 0);
    }
  }

  function bassNote(tok) {
    const c = S.chord, root = placeRoot(c.root, S.style.bassCenter);
    switch (tok) {
      case 'O': return root + 12;
      case '5': return root + 7;
      case '5L': return root - 5;
      case '3': return root + c.third;
      case '7': return root + c.seventh;
      case 'A': { // diatonic approach tone into the next chord's root
        const nr = placeRoot(S.nextChord.root, S.style.bassCenter);
        if (nr === root) return root + 7;
        const pcs = S.style.scalePcs;
        if (nr > root) { for (let d = 1; d <= 2; d++) if (pcs.includes(((nr - d) % 12 + 12) % 12)) return nr - d; return nr - 1; }
        for (let d = 1; d <= 2; d++) if (pcs.includes((nr + d) % 12)) return nr + d; return nr + 1;
      }
      default: return root;
    }
  }

  function playBass(t, st) {
    const p = S.style.parts.bass;
    if (!p || !active('bass')) return;
    const hs = p.byStep[st];
    if (!hs) return;
    for (const h of hs) {
      const m = bassNote(h[1]) + S.lift;
      I.bass(t, m, h[2] * S.stepDur * 0.92, h[3] ?? 1, bus.bass.in, p.inst, h[4] === 'pop' ? POP : EMPTY);
      note('bass', t, m);
    }
  }

  const tmpNotes = [[], [], [], [], [], [], []];
  function lifted(v) {
    const a = tmpNotes[v.length] || [];
    a.length = v.length;
    for (let i = 0; i < v.length; i++) a[i] = v[i] + S.lift;
    return a.slice();
  }

  function playKeys(name, t, st) {
    const p = S.style.parts[name];
    if (!p || !p.byStep || !active(name)) return;
    const hs = p.byStep[st];
    if (!hs) return;
    const v = lifted(p.voicings[S.phraseBar % p.voicings.length]);
    for (const h of hs) {
      I.keys(t, v, h[1] * S.stepDur, h[2], bus[name].in, p.inst, h[3] === 'U' ? UP : EMPTY);
      note(name, t, v[0]);
    }
  }

  function playArp(t, st) {
    const p = S.style.parts.arp;
    if (!p || !active('arp')) return;
    if (p.mode === 'idx') {
      if (st % p.rate) return;
      const tones = p.voicings[S.phraseBar % p.voicings.length];
      const k = ((S.phraseBar * 16 + st) / p.rate) % p.seq.length;
      const m = tones[p.seq[k] % tones.length] + S.lift;
      I.arp(t, [m], p.rate * S.stepDur * 0.9, (st & 3) === 0 ? 0.95 : 0.7, bus.arp.in, p.inst);
      note('arp', t, m);
    } else if (p.mode === 'dyad') {
      const v = VEL[p.pat[st]];
      if (!v) return;
      I.arp(t, lifted(p.voicings[S.phraseBar % p.voicings.length]), S.stepDur * 0.7, v, bus.arp.in, p.inst);
      note('arp', t, 0);
    } else if (p.mode === 'acid') {
      const tok = p.seq[st];
      if (tok === '.') return;
      const c = S.chord, root = placeRoot(c.root, S.style.bassCenter) + 12;
      const L = tok[0];
      const m = (L === 'O' ? root + 12 : L === '5' ? root + 7 : L === '7' ? root + c.seventh : L === '3' ? root + c.third : root) + S.lift;
      const slide = tok.includes('~');
      I.arp(t, [m], S.stepDur * (slide ? 1.05 : 0.62), 0.9, bus.arp.in, 'acid',
        { accent: tok.includes('!'), from: slide ? S.acidPrev : 0, peak: 1400 });
      S.acidPrev = m;
      note('arp', t, m);
    }
  }

  function playLead(t, st) {
    const p = S.style.parts.lead;
    if (!p || !active('lead')) return;
    const bar = p.barSteps[S.phraseBar % p.barSteps.length];
    const ns = bar[st];
    if (!ns) return;
    const tv = S.mode === 'title' ? 0.8 : 1;
    for (const n of ns) {
      const m = n[1] + S.lift, dur = n[2] * S.stepDur * p.gate;
      if (p.inst === 'piano') I.keys(t, p.oct ? [m + p.oct, m] : [m], dur, n[3] * tv, bus.lead.in, 'piano', EMPTY);
      else I.lead(t, m, dur, n[3] * tv, bus.lead.in, p.inst, EMPTY);
      note('lead', t, m);
    }
  }

  function playCounter(t, st) {
    const p = S.style.parts.counter;
    if (!p || !active('counter')) return;
    const r = p.rByStep[st];
    if (!r) return;
    const pool = p.pools[S.phraseBar % p.pools.length];
    let prev = S.counterPrev || pool[pool.length >> 1];
    let best = pool[0], bd = 1e9;
    const first = st === p.rhythm[0][0];
    for (const m of pool) {
      let d = Math.abs(m - prev);
      if (!first && m === prev) d = 50;           // keep moving inside the bar
      if (d < bd) { bd = d; best = m; }
    }
    S.counterPrev = best;
    const m = best + S.lift, dur = r[1] * S.stepDur * 0.95;
    if (p.inst === 'ep' || p.inst === 'strings') I.keys(t, [m], dur, 0.9, bus.counter.in, p.inst, EMPTY);
    else I.lead(t, m, dur, 0.9, bus.counter.in, p.inst, EMPTY);
    note('counter', t, m);
  }

  function playSparkle(t, st) {
    if (!S.sparkle || S.mode !== 'run') return;
    const pr = (st & 1) ? 0.22 : 0.62;
    if (rand() > pr) return;
    const pool = S.style.sparklePools[S.phraseBar % S.style.sparklePools.length];
    const m = pool[(rand() * pool.length) | 0] + S.lift;
    I.keys(t, [m], 0.3, 0.55 + rand() * 0.35, bus.sparkle.in, 'glock', EMPTY);
    note('sparkle', t, m);
  }

  // ---------------------------------------------------------------- the clock
  function scheduleStep(silent) {
    const st = S.step;
    if (st === 0) onBarStart(S.nextT);
    if (!silent) {
      const t = S.nextT + ((st & 1) ? S.swing * S.stepDur : 0);
      try { // a voice must never be able to stall the clock
        playDrums(t, st);
        playBass(t, st);
        playKeys('pad', t, st);
        playKeys('chords', t, st);
        playArp(t, st);
        playLead(t, st);
        playCounter(t, st);
        playSparkle(t, st);
      } catch (e) { S.errors = (S.errors || 0) + 1; }
    }
    S.steps++;
    S.nextT += S.stepDur;
    if (++S.step === 16) { S.step = 0; S.bar++; S.phraseBar = (S.phraseBar + 1) % S.style.prog.length; }
  }

  M.pump = function () {
    if (!S.playing) return;
    const tn = M.now();
    const t0 = (typeof performance !== 'undefined') ? performance.now() : 0;
    if (S.nextT < tn - 0.02) { // fell behind (main-thread stall): skip, never burst late notes
      while (S.nextT < tn + 0.01) { scheduleStep(true); S.lateSkips++; }
    }
    while (S.nextT < tn + LOOKAHEAD) scheduleStep(false);
    if (t0) S.schedMs += performance.now() - t0;
  };

  /** Start a scene. mode 'title' | 'run'. */
  M.start = function (mode, styleId, t) {
    t = t ?? M.now() + 0.06;
    S.mode = mode;
    S.pending = null; S.boost = false; S.lift = 0; S.counterPrev = 0;
    loadStyle(styleId || 'smokies', t, mode === 'title');
    S.nextT = t; S.step = 0; S.bar = 0; S.phraseBar = 0; S.sectionBar = 0;
    S.layers = mode === 'title' ? 5 : wantLayers();
    for (const pn of PART_NAMES) { const g = bus[pn].pump.gain; g.cancelScheduledValues(0); g.setValueAtTime(1, t); }
    S.playing = true;
    if (mode === 'run') I.crash(t, 0.6, bus.fx.in);
  };
  M.stop = function () { S.playing = false; S.pending = null; S.mode = 'off'; };

  /** Level-up / region change: quantised to the next bar >= 1 beat away. Returns {t, bar}. */
  M.transition = function (styleId, o = {}) {
    if (!S.playing || S.mode !== 'run') return null;
    const tn = M.now();
    let B, tB;
    if (S.pending) { B = S.pending.bar; tB = S.pending.t; }
    else {
      if (S.step === 0) { B = S.bar; tB = S.nextT; }
      else { B = S.bar + 1; tB = S.nextT + (16 - S.step) * S.stepDur; }
      if (tB - tn < S.stepDur * 4) { B++; tB += 16 * S.stepDur; }
    }
    const changed = styleId !== S.styleId;
    S.pending = { styleId, bar: B, t: tB, fillAmt: changed ? 1 : 0.6 };
    const rs = Math.max(0.25, tB - tn - 0.01);
    I.riser(tn + 0.01, rs, changed ? 0.3 : 0.18, bus.fx.in, { from: 300, to: changed ? 7000 : 4500 });
    return { t: tB, bar: B, changed };
  };

  /** time of the next grid point (div in steps) at least `min` seconds away */
  M.nextGrid = function (div = 2, min = 0.02) {
    const tn = M.now();
    if (!S.playing) return tn + min;
    // steps already scheduled continue from S.nextT at S.step; walk back/forward on the grid
    let t = S.nextT - S.step * S.stepDur; // start of the current (unscheduled-from) bar
    while (t > tn + min) t -= div * S.stepDur;
    while (t < tn + min) t += div * S.stepDur;
    return t;
  };

  M.keyRoot = function () { // midi root of the current key in octave 4 (60..71), incl. lift
    const s = S.style || STYLES.smokies;
    return 60 + pcOf(s.key) + (S.lift || 0);
  };
  M.isMinor = () => !!(S.style && (S.style.id === 'steel'));
  M.setGame = function (level, lap, progress) { S.game.level = level; S.game.lap = lap; S.game.progress = progress; };

  return M;
}
