// AUDIO — public entry (CONTRACT §5). 100 % procedural WebAudio: no files, no network.
//
//   const audio = createAudio();
//   first user gesture:  audio.unlock()          (creates + resumes the AudioContext; iOS-safe)
//   screens:             audio.toTitle() / audio.toRun() / audio.toGameOver()
//   every sim event:     audio.onEvent(ev, sim)
//   every frame:         audio.update(sim, frame)  (pumps the lookahead scheduler, beds, ticks)
//   pause menu:          audio.setPaused(true|false)  (music keeps playing muffled; SFX off)
//   mute button:         audio.setMuted(bool)      (persisted in localStorage 'c3fox.muted')
//   UI buttons:          audio.click()   (also exported as a bare `click()`)
//
// Assumptions (documented per CONTRACT): gameplay events are IGNORED while the title/attract
// mode runs (sim.mode === 'ready' or before toRun()), so the attract AI never makes noise.
// 'start' implies toRun() and 'death' implies toGameOver() if main.js has not called them,
// so the audio stays correct even if the wiring misses a call. Background tabs suspend the
// context on their own (visibilitychange) in addition to whatever setPaused() main.js does.
import { createEngine, styleForTheme } from './engine.js';

const LS_KEY = 'c3fox.muted';
let lastInstance = null;
/** UI click on the most recently created audio instance (safe to call any time). */
export function click() { if (lastInstance) lastInstance.click(); }

export function createAudio() {
  const hasWin = typeof window !== 'undefined';
  const AC = hasWin && (window.AudioContext || window.webkitAudioContext);
  let ctx = null, eng = null, timer = 0;
  let muted = loadMuted(), paused = false, hidden = false;
  let scene = 'title';
  let lastSim = null, tier = 'high', runStartedAt = -1;
  const warn = { magnet: 0, x2: 0, boost: 0 };

  function loadMuted() { try { return localStorage.getItem(LS_KEY) === '1'; } catch (e) { return false; } }
  function saveMuted(b) { try { localStorage.setItem(LS_KEY, b ? '1' : '0'); } catch (e) {} }

  const wantRunning = () => !!ctx && !muted && !hidden;
  function syncState() {
    if (!ctx) return;
    try {
      if (wantRunning()) {
        if (ctx.state !== 'running') { const p = ctx.resume(); if (p && p.catch) p.catch(() => {}); }
      } else if (ctx.state === 'running') {
        setTimeout(() => {
          try { if (!wantRunning() && ctx.state === 'running') { const p = ctx.suspend(); if (p && p.catch) p.catch(() => {}); } } catch (e) {}
        }, 90); // let the mute fade finish first
      }
    } catch (e) {}
  }

  function onGesture() { // iOS 'interrupted' / autoplay-blocked recovery: any later tap resumes
    if (ctx && wantRunning() && ctx.state !== 'running') { try { const p = ctx.resume(); if (p && p.catch) p.catch(() => {}); } catch (e) {} }
  }
  function onVis() {
    hidden = typeof document !== 'undefined' && document.visibilityState === 'hidden';
    syncState();
  }
  function pump() {
    try { if (eng && ctx.state === 'running') eng.pump(); } catch (e) {}
  }

  function applyScene() {
    if (!eng || eng.scene === scene) return;
    if (scene === 'title') eng.toTitle();
    else if (scene === 'run') { runStartedAt = ctx.currentTime; eng.toRun(styleForTheme(lastSim ? lastSim.themeIdx : 0)); }
    else if (scene === 'over') eng.toGameOver();
  }

  function resetWarn() { warn.magnet = warn.x2 = warn.boost = 0; }

  const api = {
    unlock() {
      if (!AC) return false;
      try {
        if (!ctx) {
          try { ctx = new AC({ latencyHint: 'interactive' }); } catch (e) { ctx = new AC(); }
          eng = createEngine(ctx, { deferLong: true });
          eng.setMuted(muted);
          eng.setQuality(tier);
          ctx.onstatechange = () => { if (ctx.state !== 'running') syncState(); };
          if (typeof document !== 'undefined') {
            document.addEventListener('visibilitychange', onVis);
            hidden = document.visibilityState === 'hidden';
          }
          for (const n of ['pointerdown', 'touchend', 'keydown', 'mousedown']) window.addEventListener(n, onGesture, { capture: true, passive: true });
          window.addEventListener('pageshow', onVis);
          timer = setInterval(pump, 25);
          Promise.resolve().then(applyScene); // lets a same-gesture toRun() win over the default title
        }
        // iOS Safari: resume() and a 1-sample buffer must happen INSIDE the gesture
        if (ctx.state !== 'running' && !hidden) { const p = ctx.resume(); if (p && p.catch) p.catch(() => {}); }
        const b = ctx.createBuffer(1, 1, 22050), s = ctx.createBufferSource();
        s.buffer = b; s.connect(ctx.destination); s.start(0);
        if (muted) syncState();
        return true;
      } catch (e) { return false; }
    },

    onEvent(ev, sim) {
      if (!eng || !ev) return;
      if (sim) lastSim = sim;
      try {
        const type = ev.type;
        if (type === 'start') { if (scene !== 'run') api.toRun(); return; }
        if (type === 'death') { if (scene === 'run') api.toGameOver(); return; }
        if (scene !== 'run' || eng.scene !== 'run' || (sim && sim.mode === 'ready') || paused) return;
        const S = eng.sfx;
        const px = sim && sim.player ? sim.player.x : 0;
        const panOf = x => (x == null ? 0 : Math.max(-0.6, Math.min(0.6, (x - px) / 4)));
        const side = v => (typeof v === 'string' ? (v[0] === 'l' ? -1 : 1) : Math.sign(v || 0));
        switch (type) {
          case 'lane': S.lane(ev.dir || 0); break;
          case 'bump': S.bump(ev.dir || 0); break;
          case 'jump': S.jump(); break;
          case 'land': S.land(ev.impact || 5, !!ev.onRoof); break;
          case 'ramp': S.ramp(); break;
          case 'roof': S.roof(); break;
          case 'drop': S.drop(); break;
          case 'coin': S.coin(ev.kind, ev.combo || (sim && sim.combo) || 1, panOf(ev.x)); break;
          case 'tsheet': S.tsheet(ev.count, ev.shield); break;
          case 'bonus': S.bonus(); break;
          case 'combo': S.combo(ev.combo || 3); break;
          case 'comboLost': S.comboLost(); break;
          case 'nearMiss': S.nearMiss(ev.side != null ? side(ev.side) : Math.sign((ev.x || 0) - px)); break;
          case 'hop': S.hop(); break;
          case 'shieldBreak': S.shieldBreak(); break;
          case 'smash': S.smash(); break;
          case 'powerup': S.powerup(ev.kind); if (ev.kind === 'x2') eng.setSparkle(true); break;
          case 'powerWarn': S.powerTick(ev.kind, false); break;
          case 'powerEnd': S.powerEnd(ev.kind); if (ev.kind === 'x2') eng.setSparkle(false); break;
          case 'boostStart': eng.boost(true); break;
          case 'boostEnd': eng.boost(false); break;
          case 'levelUp': eng.levelUp(ev); break;
          case 'trainPass': S.trainPass(side(ev.side)); break;
          case 'hit': eng.hitStop(); break;
          default: break;
        }
      } catch (e) { /* audio must never break the game */ }
    },

    update(sim, frame) {
      if (sim) lastSim = sim;
      if (frame && frame.tier && frame.tier !== tier) { tier = frame.tier; if (eng) eng.setQuality(tier); }
      if (!eng || !sim) return;
      try {
        eng.music.setGame(sim.level || 1, sim.lap || 1, sim.levelProgress || 0);
        const inRun = scene === 'run' && eng.scene === 'run';
        const playing = inRun && sim.mode === 'play' && !paused;
        const pw = sim.power || warn;
        const M = eng.music;
        // keep the region style in sync even if a levelUp was missed (dev level select etc.)
        if (inRun && sim.mode === 'play' && M.S.playing && !M.S.pending && ctx.currentTime - runStartedAt > 0.5) {
          const want = styleForTheme(sim.themeIdx);
          if (want !== M.S.styleId) M.transition(want);
        }
        M.S.sparkle = playing && pw.x2 > 0;
        M.S.boost = playing && pw.boost > 0;
        M.S.comboHot = playing && (sim.combo || 1) >= 6;
        eng.sfx.ensureBoostLoop(playing && pw.boost > 0);
        for (const k of ['magnet', 'x2', 'boost']) { // power-up expiry ticking, accelerating
          const v = pw[k] || 0, pv = warn[k];
          if (playing && v > 0 && v < 2.02 && pv > v) {
            const step = v < 0.76 ? 0.25 : 0.5;
            if (Math.floor(v / step) !== Math.floor(pv / step)) eng.sfx.powerTick(k, v < 0.76);
          }
          warn[k] = v;
        }
        eng.sfx.bed(sim.speed || 0, playing, pw.boost > 0);
        if (ctx.state === 'running') eng.pump();
      } catch (e) {}
    },

    setMuted(b) {
      muted = !!b; saveMuted(muted);
      if (eng) { eng.setMuted(muted); syncState(); }
    },
    get muted() { return muted; },

    setPaused(b) {
      b = !!b;
      if (b === paused) return;
      paused = b;
      if (eng) { try { eng.muffle(paused); } catch (e) {} }
    },

    toTitle() { scene = 'title'; resetWarn(); applyScene(); },
    toRun() {
      if (scene === 'run' && eng && eng.scene === 'run' && ctx.currentTime - runStartedAt < 0.3) return; // double call guard
      scene = 'run'; resetWarn();
      if (eng) { eng.scene = 'off'; applyScene(); }
    },
    toGameOver() { if (scene === 'over') return; scene = 'over'; applyScene(); },

    click() {
      if (!ctx) api.unlock(); // clicks come from gestures: a free chance to unlock
      try { if (eng && !muted && ctx.state === 'running') eng.sfx.click(); } catch (e) {}
    },

    // ---- extras (dev / quality) ----
    setQuality(t) { tier = t; if (eng) eng.setQuality(t); },
    get context() { return ctx; },
    get engine() { return eng; },
    get scene() { return scene; },
    dispose() {
      try {
        clearInterval(timer);
        if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', onVis);
        if (hasWin) for (const n of ['pointerdown', 'touchend', 'keydown', 'mousedown']) window.removeEventListener(n, onGesture, { capture: true });
        if (ctx) ctx.close();
      } catch (e) {}
      ctx = null; eng = null;
    },
  };
  lastInstance = api;
  return api;
}
