// SFX — short, punchy, cheap. Every effect is a handful of fresh source nodes feeding a
// POOLED output channel (persistent Gain -> StereoPanner -> sfx bus, round-robin), with
// per-effect rate limits / voice caps and ±3 % random pitch so repeats don't fatigue.
// Tonal effects (coins, chimes, fanfares) are pitched from the music's current key.
// Continuous beds (wind/road, boost jet) are owned here too and driven from update().
import { mtof, clamp, noiseBuffer, autoFree } from './util.js';

export function createSfx(ctx, graph, I, music, rand = Math.random) {
  const P = I._prims;
  const { osc, gain, filt, noise, perc, sweep } = P;
  const hasPan = !!ctx.createStereoPanner;
  const now = () => music.now();
  const jit = (a = 0.03) => 1 + (rand() * 2 - 1) * a;

  // ---------------------------------------------------------------- levels
  // Per-effect output gain, set from measurements (tools/audio-render.py --only sfx) so that
  // frequent effects peak around -16..-11 dBFS, rewards around -10..-6, big moments -6..-3,
  // all above a music bed that sits near -16.5 LUFS.
  const LV = {
    coin: 1.35, tsheet: 0.62, bonus: 0.8, combo: 1.25, comboLost: 1.5, jump: 3.6, land: 0.72, lane: 6.5,
    bump: 0.48, ramp: 1, roof: 1, drop: 4.2, nearMiss: 1.6, hop: 1.6, shieldBreak: 0.75, smash: 0.65,
    powerup: 1.05, tick: 1.75, powerEnd: 1.5, boostStart: 0.95, boostEnd: 2.6, trainPass: 0.66,
    levelUp: 0.72, hit: 0.42, gameOver: 0.42, click: 0.8,
  };

  // ---------------------------------------------------------------- pooled channels
  // Persistent Gain -> StereoPanner chains; each trigger takes an IDLE channel (so changing
  // its gain/pan never touches another effect's tail), falling back to the oldest one.
  const POOL = 16, chans = [];
  for (let i = 0; i < POOL; i++) {
    const g = ctx.createGain();
    let tail = g, pn = null;
    if (hasPan) { pn = ctx.createStereoPanner(); g.connect(pn); tail = pn; }
    tail.connect(graph.sfx);
    chans.push({ in: g, pan: pn, busy: 0 });
  }
  let ci = 0;
  function chan(t, pan = 0, lv = 1, dur = 0.5) {
    let c = null, oldest = chans[0];
    for (let k = 0; k < POOL; k++) {
      const cand = chans[(ci + k) % POOL];
      if (cand.busy <= t) { c = cand; ci = (ci + k + 1) % POOL; break; }
      if (cand.busy < oldest.busy) oldest = cand;
    }
    if (!c) c = oldest;
    c.busy = t + dur;
    c.in.gain.cancelScheduledValues(t); c.in.gain.setValueAtTime(lv, t);
    if (c.pan) { c.pan.pan.cancelScheduledValues(t); c.pan.pan.setValueAtTime(clamp(pan, -1, 1), t); }
    return c;
  }
  const verbSend = ctx.createGain(); verbSend.gain.value = 1; verbSend.connect(graph.verbIn);

  const last = {};
  function gate(name, gap, t) { if (last[name] != null && t - last[name] < gap) return false; last[name] = t; return true; }
  const live = {};
  function cap(name, n, t, dur) { // voice cap per effect family
    const a = live[name] || (live[name] = []);
    for (let i = a.length - 1; i >= 0; i--) if (a[i] <= t) a.splice(i, 1);
    if (a.length >= n) return false;
    a.push(t + dur); return true;
  }

  // ---------------------------------------------------------------- building blocks
  function tone(t, type, f, a, dec, v, out, f2) {
    const o = osc(type, f, t), g = gain();
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + a + dec);
    perc(g.gain, t, v, a, dec);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + a + dec + 0.02); autoFree(o, [g]);
    return o;
  }
  function nburst(t, kind, ftype, f0, f1, q, a, dec, v, out) {
    const n = noise(t, a + dec + 0.03, kind), f = filt(ftype, f0, q), g = gain();
    if (f1 && f1 !== f0) sweep(f.frequency, t, f0, f1, a + dec);
    perc(g.gain, t, v, a, dec);
    n.connect(f); f.connect(g); g.connect(out); autoFree(n, [f, g]);
  }
  function bell(t, m, v, dec, out, ratio = 2.0, idx = 1.2) { // FM bell
    const f = mtof(m), c = osc('sine', f, t), mo = osc('sine', f * ratio, t), mg = gain(), g = gain();
    mg.gain.setValueAtTime(f * idx, t); mg.gain.exponentialRampToValueAtTime(f * 0.02, t + dec);
    mo.connect(mg); mg.connect(c.frequency); c.connect(g); g.connect(out);
    perc(g.gain, t, v, 0.001, dec);
    c.start(t); mo.start(t); c.stop(t + dec + 0.02); mo.stop(t + dec + 0.02);
    autoFree(c, [g, mg]);
  }
  const key = () => music.keyRoot();              // octave-4 root of the current key
  const LADDER = [0, 2, 4, 5, 7, 9, 11, 12, 14];  // combo climbs the major scale (tops out at E6-ish: no 2-5 kHz fundamentals)

  const S = {};

  // ---------------------------------------------------------------- pickups
  S.coin = function (kind = 'xm', combo = 1, pan = 0) {
    const t = now();
    if (!gate('coin', 0.03, t) || !cap('coin', 5, t, 0.3)) return;
    const m = key() + 12 + LADDER[clamp((combo | 0) - 1, 0, 8)];
    const j = jit(0.006), out = chan(t, pan, LV.coin, 0.35).in;
    if (kind === 'tab') { // glassy tablet: bright bell partials
      tone(t, 'sine', mtof(m) * j, 0.001, 0.28, 0.2, out);
      tone(t, 'sine', mtof(m + 12) * 1.004 * j, 0.001, 0.1, 0.035, out);
      tone(t + 0.035, 'sine', mtof(m + 7) * j, 0.001, 0.22, 0.12, out);
    } else if (kind === 'watch') { // soft wooden marimba blip
      tone(t, 'sine', mtof(m) * j, 0.001, 0.16, 0.24, out);
      tone(t, 'sine', mtof(m) * 4 * j, 0.0005, 0.02, 0.022, out);
      tone(t, 'triangle', mtof(m - 12) * j, 0.001, 0.07, 0.08, out);
    } else { // XM gold: classic two-step "ching"
      const w = P.pw('softsq');
      const o1 = osc(w, mtof(m) * j, t), o2 = osc(w, mtof(m + 5) * j, t + 0.055);
      const lp = filt('lowpass', 3000), g1 = gain(), g2 = gain();
      perc(g1.gain, t, 0.13, 0.001, 0.06);
      perc(g2.gain, t + 0.055, 0.14, 0.001, 0.26);
      o1.connect(g1); o2.connect(g2); g1.connect(lp); g2.connect(lp); lp.connect(out);
      o1.start(t); o1.stop(t + 0.08); o2.start(t + 0.055); o2.stop(t + 0.33);
      autoFree(o2, [g1, g2, lp]);
      tone(t + 0.055, 'sine', mtof(m + 12) * j, 0.001, 0.09, 0.02, out);
    }
  };

  S.tsheet = function (count = 1, shield = 1) {
    const t = now(), out = chan(t, 0, LV.tsheet, 1.2).in, r = key() + 12;
    [7, 12, 16].forEach((d, i) => bell(t + i * 0.045, r + d, 0.13, 0.55, out, 2.0, 0.9));
    bell(t + 0.135, r + 19, 0.07, 0.8, verbSend, 2.0, 0.6);
    // shield "whum" swell
    const o = osc('sine', 170, t), g = gain();
    o.frequency.exponentialRampToValueAtTime(340, t + 0.3);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.16 + 0.03 * shield, t + 0.08);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.42);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.45); autoFree(o, [g]);
  };

  S.bonus = function () { // +$100: brass arpeggio + sparkle + register ding
    const t = music.nextGrid(1, 0.015), out = chan(t, 0, LV.bonus, 1.4).in, r = key();
    const sd = Math.min(0.075, music.S.stepDur * 0.6);
    [0, 4, 7, 12].forEach((d, i) => I.lead(t + i * sd, r + d + 12, sd * 0.9, 0.55, out, 'horns', { bright: 3000 }));
    I.lead(t + 4 * sd, r + 16, 0.36, 0.45, out, 'horns', { bright: 2800 });
    I.lead(t + 4 * sd, r + 12, 0.36, 0.4, out, 'horns', { bright: 2400 });
    for (let i = 0; i < 5; i++) bell(t + 4 * sd + i * 0.05, r + 12 + [0, 4, 7, 12, 16][i], 0.05, 0.4, verbSend, 2.0, 0.5);
    nburst(t + 4 * sd, 'white', 'bandpass', 3200, 3200, 2, 0.001, 0.03, 0.08, out);
    duck(0.6, 0.55);
  };

  S.combo = function (n = 3) {
    const t = now(), out = chan(t, 0, LV.combo, 1.1).in, r = key() + 12;
    const seq = n >= 9 ? [0, 4, 7, 12, 16] : n >= 6 ? [0, 4, 7, 12] : [0, 4, 7];
    seq.forEach((d, i) => bell(t + i * 0.05, r + d, 0.12, 0.35, out, 3.0, 0.5));
    if (n >= 9) {
      nburst(t, 'white', 'bandpass', 1200, 6000, 2, 0.2, 0.15, 0.05, out);
      bell(t + 0.25, r + 19, 0.05, 0.9, verbSend, 2.0, 0.4);
    }
  };

  S.comboLost = function () {
    const t = now(); if (!gate('comboLost', 0.4, t)) return;
    const out = chan(t, 0, LV.comboLost, 0.3).in, lp = filt('lowpass', 1300), j = jit();
    const o = osc('triangle', 520 * j, t), g = gain();
    o.frequency.exponentialRampToValueAtTime(250 * j, t + 0.26);
    perc(g.gain, t, 0.12, 0.005, 0.26);
    o.connect(g); g.connect(lp); lp.connect(out); o.start(t); o.stop(t + 0.3); autoFree(o, [g, lp]);
  };

  // ---------------------------------------------------------------- movement
  S.jump = function () {
    const t = now(); if (!gate('jump', 0.06, t)) return;
    const out = chan(t, 0, LV.jump, 0.25).in, j = jit();
    nburst(t, 'pink', 'bandpass', 520 * j, 2300 * j, 1.3, 0.02, 0.17, 0.2, out);
    tone(t, 'sine', 300 * j, 0.004, 0.07, 0.06, out, 470 * j);
  };

  S.land = function (impact = 5, onRoof = false) {
    const t = now(); if (!gate('land', 0.06, t)) return;
    const out = chan(t, 0, LV.land, 0.3).in, j = jit(), k = clamp(impact / 8, 0.35, 1);
    tone(t, 'sine', 120 * j, 0.002, 0.13, 0.42 * k, out, 52 * j);
    nburst(t, 'brown', 'lowpass', 520, 300, 0.8, 0.001, 0.07, 0.3 * k, out);
    nburst(t, 'white', 'bandpass', 1600 * j, 900, 1.0, 0.002, 0.06, 0.05 * k, out);
    if (onRoof) { I.metal(t, 0.55 * k, out, { f: 205 * j }); tone(t, 'triangle', 410 * j, 0.001, 0.2, 0.05, out); }
  };

  S.lane = function (dir = 1) {
    const t = now(); if (!gate('lane', 0.035, t)) return;
    const c = chan(t, 0, LV.lane, 0.2), j = jit();
    if (c.pan) { c.pan.pan.setValueAtTime(-0.15 * dir, t); c.pan.pan.linearRampToValueAtTime(0.7 * dir, t + 0.11); }
    nburst(t, 'pink', 'bandpass', 800 * j, 2400 * j, 1.5, 0.012, 0.1, 0.16, c.in);
  };

  S.bump = function (dir = 1) {
    const t = now(); if (!gate('bump', 0.1, t)) return;
    const out = chan(t, 0.5 * dir, LV.bump, 0.5).in, j = jit();
    tone(t, 'sine', 98 * j, 0.002, 0.2, 0.55, out, 55 * j);
    nburst(t, 'brown', 'lowpass', 700, 250, 0.8, 0.001, 0.12, 0.35, out);
    I.metal(t, 0.3, out, { f: 150 * j });
    // wobble: vibrato'd tone that dies away (the "boing" of the bounce-back)
    const o = osc('triangle', 175 * j, t), g = gain(), l = osc('sine', 13, t), lg = gain();
    lg.gain.setValueAtTime(30, t); lg.gain.exponentialRampToValueAtTime(2, t + 0.4);
    l.connect(lg); lg.connect(o.frequency);
    perc(g.gain, t, 0.12, 0.01, 0.4);
    o.connect(g); g.connect(out); o.start(t); l.start(t); o.stop(t + 0.45); l.stop(t + 0.45);
    autoFree(o, [g]); autoFree(l, [lg]);
  };

  S.ramp = function () {
    const t = now(); if (!gate('ramp', 0.3, t)) return;
    const out = chan(t, 0, LV.ramp, 0.55).in, j = jit();
    const o = osc('sawtooth', 70 * j, t), lp = filt('lowpass', 420, 2), g = gain();
    o.frequency.exponentialRampToValueAtTime(165 * j, t + 0.42);
    sweep(lp.frequency, t, 300, 900, 0.42);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.14, t + 0.12);
    g.gain.linearRampToValueAtTime(0.0, t + 0.46);
    o.connect(lp); lp.connect(g); g.connect(out); o.start(t); o.stop(t + 0.5); autoFree(o, [lp, g]);
    nburst(t, 'brown', 'lowpass', 260, 420, 0.7, 0.05, 0.35, 0.22, out);
  };

  S.roof = function () {
    const t = now(); if (!gate('roof', 0.2, t)) return;
    I.metal(t, 0.38, chan(t, 0, LV.roof, 0.4).in, { f: 240 * jit() });
  };

  S.drop = function () {
    const t = now(); if (!gate('drop', 0.2, t)) return;
    nburst(t, 'pink', 'bandpass', 1900 * jit(), 480, 1.2, 0.02, 0.2, 0.1, chan(t, 0, LV.drop, 0.3).in);
  };

  S.nearMiss = function (side = 0) {
    const t = now(); if (!gate('nearMiss', 0.08, t)) return;
    const c = chan(t, 0.2 * side, LV.nearMiss, 0.5), j = jit();
    if (c.pan) c.pan.pan.linearRampToValueAtTime(0.85 * side, t + 0.18);
    nburst(t, 'pink', 'bandpass', 420 * j, 1900 * j, 1.1, 0.05, 0.16, 0.24, c.in);
    bell(t + 0.07, key() + 19, 0.09, 0.45, c.in, 3.0, 0.4);
  };

  S.hop = function () {
    const t = now(); if (!gate('hop', 0.08, t)) return;
    const out = chan(t, 0, LV.hop, 0.25).in, r = key() + 12;
    tone(t, 'triangle', mtof(r + 7) * jit(0.006), 0.002, 0.05, 0.1, out);
    tone(t + 0.05, 'triangle', mtof(r + 12) * jit(0.006), 0.002, 0.12, 0.1, out);
  };

  // ---------------------------------------------------------------- impacts
  S.shieldBreak = function () {
    const t = now(), out = chan(t, 0, LV.shieldBreak, 0.9).in;
    for (let i = 0; i < 9; i++) { // glass shards: inharmonic high partials, staggered
      const f = 1900 + rand() * 4200, dt = rand() * 0.03, dec = 0.05 + rand() * 0.28;
      tone(t + dt, 'sine', f, 0.0005, dec, 0.035 + rand() * 0.03, out);
    }
    nburst(t, 'white', 'highpass', 3200, 3200, 0.7, 0.001, 0.14, 0.16, out);
    tone(t, 'sine', 150, 0.002, 0.22, 0.4, out, 58);
    tone(t + 0.02, 'triangle', 620, 0.003, 0.3, 0.07, out, 300);
    bell(t + 0.01, key() + 18, 0.05, 0.7, verbSend, 1.41, 0.8);
  };

  S.smash = function () {
    const t = now(); if (!gate('smash', 0.05, t)) return;
    const out = chan(t, 0, LV.smash, 0.45).in, j = jit();
    const n = noise(t, 0.4, 'white'), lp = filt('lowpass', 3000, 1.2), sh = P.shaper(P.DRIVE.hard), g = gain();
    sweep(lp.frequency, t, 3200 * j, 280, 0.3);
    perc(g.gain, t, 0.24, 0.002, 0.3);
    n.connect(lp); lp.connect(sh); sh.connect(g); g.connect(out); autoFree(n, [lp, sh, g]);
    tone(t, 'sine', 80 * j, 0.002, 0.28, 0.5, out, 38);
    for (let i = 0; i < 5; i++) nburst(t + rand() * 0.14, 'white', 'bandpass', 700 + rand() * 2200, 0, 3, 0.0005, 0.018, 0.12, out);
  };

  S.hit = function () { // fatal impact + descending sting
    const t = now(), out = chan(t, 0, LV.hit, 1.5).in;
    tone(t, 'sine', 95, 0.002, 0.55, 0.42, out, 30);
    nburst(t, 'brown', 'lowpass', 1100, 200, 0.8, 0.002, 0.45, 0.32, out);
    S.smash();
    nburst(t, 'white', 'highpass', 3500, 3500, 0.7, 0.002, 0.5, 0.05, out);
    const r = key() + 12, sd = 0.1;
    [12, 7, 3].forEach((d, i) => I.lead(t + 0.12 + i * sd, r + d - 12, sd * 0.85, 0.55, out, 'horns', { bright: 1500 }));
    const tl = t + 0.12 + 3 * sd;
    const o = osc('square', mtof(r - 12), tl), o2 = osc('sawtooth', mtof(r - 12) * 1.004, tl), lp = filt('lowpass', 1200, 1), g = gain();
    o.frequency.setValueAtTime(mtof(r - 12), tl + 0.15); o.frequency.exponentialRampToValueAtTime(mtof(r - 14), tl + 0.8);
    o2.frequency.setValueAtTime(mtof(r - 12) * 1.004, tl + 0.15); o2.frequency.exponentialRampToValueAtTime(mtof(r - 14), tl + 0.8);
    g.gain.setValueAtTime(0, tl); g.gain.linearRampToValueAtTime(0.09, tl + 0.02);
    g.gain.setTargetAtTime(0, tl + 0.45, 0.14);
    o.connect(lp); o2.connect(lp); lp.connect(g); g.connect(out);
    o.start(tl); o2.start(tl); o.stop(tl + 1.3); o2.stop(tl + 1.3); autoFree(o, [lp, g]);
  };

  // ---------------------------------------------------------------- power-ups
  S.powerup = function (kind) {
    const t = now(), out = chan(t, 0, LV.powerup, 1.0).in, r = key() + 12;
    if (kind === 'magnet') { // rising magnetic "vwoop"
      const o = osc('sine', 260, t), l = osc('sine', 17, t), lg = gain(), g = gain(), o2 = osc('triangle', 520, t), g2 = gain();
      o.frequency.exponentialRampToValueAtTime(900, t + 0.36);
      o2.frequency.exponentialRampToValueAtTime(1800, t + 0.36);
      lg.gain.setValueAtTime(40, t); lg.gain.linearRampToValueAtTime(90, t + 0.36);
      l.connect(lg); lg.connect(o.frequency);
      perc(g.gain, t, 0.2, 0.05, 0.4); perc(g2.gain, t, 0.04, 0.05, 0.3);
      o.connect(g); o2.connect(g2); g.connect(out); g2.connect(out);
      o.start(t); o2.start(t); l.start(t); o.stop(t + 0.48); o2.stop(t + 0.4); l.stop(t + 0.48);
      autoFree(o, [g]); autoFree(o2, [g2]); autoFree(l, [lg]);
      bell(t + 0.3, r + 12, 0.06, 0.5, verbSend, 2, 0.5);
    } else if (kind === 'x2') { // cash register ka-ching + coin jingle
      nburst(t, 'white', 'bandpass', 2600, 2600, 2.5, 0.001, 0.025, 0.2, out);
      nburst(t + 0.06, 'white', 'bandpass', 1800, 1800, 2.5, 0.001, 0.02, 0.14, out);
      bell(t + 0.08, r + 7, 0.13, 0.9, out, 2.0, 1.0);
      bell(t + 0.08, r + 12, 0.1, 0.9, out, 2.0, 1.0);
      for (let i = 0; i < 5; i++) tone(t + 0.12 + i * 0.035, 'sine', mtof(r + 12 + [0, 4, 7, 12, 16][i]), 0.001, 0.08, 0.05, out);
    } else { // boost pickup: quick rising charge
      [0, 7, 12, 19].forEach((d, i) => I.arp(t + i * 0.04, [r + d], 0.06, 0.9, out, 'sqarp'));
      I.riser(t, 0.3, 0.12, out, { from: 600, to: 5000 });
    }
    duck(0.55, 0.35);
  };

  S.powerTick = function (kind, urgent) {
    const t = now(); if (!gate('tick' + kind, 0.15, t)) return;
    const out = chan(t, 0, LV.tick, 0.1).in;
    const f = (kind === 'boost' ? 1350 : kind === 'x2' ? 1600 : 1200) * (urgent ? 1.19 : 1);
    tone(t, 'sine', f, 0.001, 0.045, 0.1, out);
    nburst(t, 'white', 'highpass', 5000, 5000, 0.7, 0.0005, 0.01, 0.05, out);
  };

  S.powerEnd = function (kind) {
    const t = now(); if (!gate('powerEnd' + kind, 0.3, t)) return;
    const out = chan(t, 0, LV.powerEnd, 0.4).in, r = key() + 12;
    tone(t, 'triangle', mtof(r + 12), 0.003, 0.12, 0.09, out);
    tone(t + 0.1, 'triangle', mtof(r + 7), 0.003, 0.22, 0.09, out);
  };

  // ---------------------------------------------------------------- boost jet
  let boostLoop = null;
  S.boostStart = function () {
    const t = now(), out = chan(t, 0, LV.boostStart, 0.9).in;
    const n = noise(t, 0.9, 'pink'), lp = filt('lowpass', 400, 1.2), g = gain();
    sweep(lp.frequency, t, 380, 3400, 0.5);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(0.42, t + 0.12); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.85);
    n.connect(lp); lp.connect(g); g.connect(out); autoFree(n, [lp, g]);
    tone(t, 'sine', 70, 0.004, 0.6, 0.45, out, 34);
    loopOn(true, t);
  };
  S.boostEnd = function () {
    const t = now(), out = chan(t, 0, LV.boostEnd, 0.6).in;
    nburst(t, 'pink', 'bandpass', 3000, 260, 1.1, 0.02, 0.55, 0.22, out);
    tone(t, 'sawtooth', 110, 0.01, 0.5, 0.05, out, 50);
    loopOn(false, t);
  };
  function loopOn(on, t) {
    if (on) {
      if (boostLoop) { boostLoop.g.gain.cancelScheduledValues(t); boostLoop.g.gain.setTargetAtTime(0.13, t, 0.12); return; }
      const n = ctx.createBufferSource(); n.buffer = noiseBuffer(ctx, 'pinkL'); n.loop = true;
      const bp = filt('bandpass', 750, 0.7), lp = filt('lowpass', 2200), g = gain(0);
      const lfo = osc('sine', 0.9, t), lg = gain(220);
      lfo.connect(lg); lg.connect(bp.frequency);
      const hum = osc('sawtooth', 55, t), hl = filt('lowpass', 240, 1), hg = gain(0.5);
      hum.connect(hl); hl.connect(hg); hg.connect(g);
      n.connect(bp); bp.connect(lp); lp.connect(g); g.connect(graph.amb);
      g.gain.setValueAtTime(0, t); g.gain.setTargetAtTime(0.13, t + 0.15, 0.15);
      n.start(t); lfo.start(t); hum.start(t);
      boostLoop = { n, lfo, hum, g, nodes: [bp, lp, lg, hl, hg, g] };
    } else if (boostLoop) {
      const L = boostLoop; boostLoop = null;
      L.g.gain.cancelScheduledValues(t); L.g.gain.setTargetAtTime(0, t, 0.12);
      const end = t + 0.8;
      L.n.stop(end); L.lfo.stop(end); L.hum.stop(end);
      autoFree(L.n, L.nodes);
    }
  }
  S.boostActive = () => !!boostLoop;
  S.ensureBoostLoop = function (on) { if (on !== !!boostLoop) loopOn(on, now()); };

  // ---------------------------------------------------------------- traffic
  S.trainPass = function (side = 1) {
    const t = now(); if (!gate('trainPass', 0.15, t)) return;
    const c = chan(t, 0.15 * side, LV.trainPass, 1.0), out = c.in;
    if (c.pan) { c.pan.pan.setValueAtTime(0.15 * side, t); c.pan.pan.linearRampToValueAtTime(0.9 * side, t + 0.55); }
    // air whoosh swelling as it passes
    const n = noise(t, 1.0, 'pink'), bp = filt('bandpass', 350, 0.9), g = gain();
    bp.frequency.setValueAtTime(320, t); bp.frequency.exponentialRampToValueAtTime(1500, t + 0.42); bp.frequency.exponentialRampToValueAtTime(380, t + 0.95);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.34, t + 0.42); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.95);
    n.connect(bp); bp.connect(g); g.connect(out); autoFree(n, [bp, g]);
    if (!gate('horn', 2.6, t)) return;
    // air horn chord with doppler drop through the pass
    const lp = filt('lowpass', 1500, 0.8), hg = gain();
    hg.gain.setValueAtTime(0.0001, t); hg.gain.exponentialRampToValueAtTime(0.1, t + 0.18);
    hg.gain.setValueAtTime(0.1, t + 0.4); hg.gain.exponentialRampToValueAtTime(0.0001, t + 0.95);
    sweep(lp.frequency, t, 1700, 700, 0.95);
    const srcs = [];
    for (const f of [311, 370, 466]) {
      const o = osc('sawtooth', f * 1.055, t);
      o.frequency.setValueAtTime(f * 1.055, t + 0.3);
      o.frequency.exponentialRampToValueAtTime(f * 0.945, t + 0.52);
      o.connect(lp); o.start(t); o.stop(t + 1.0); srcs.push(o);
    }
    lp.connect(hg); hg.connect(out); autoFree(srcs[0], [lp, hg]);
  };

  // ---------------------------------------------------------------- level up
  S.levelUp = function () { // fanfare on the next 8th, in the current key
    const t = music.nextGrid(2, 0.02), out = chan(t, 0, LV.levelUp, 1.8).in, r = key();
    const sd = clamp(music.S.stepDur, 0.1, 0.15);
    for (let i = 0; i < 3; i++) I.lead(t + i * sd, r + 7, sd * 0.8, 0.5, out, 'horns', { bright: 2800 });
    const tl = t + 3 * sd;
    I.lead(tl, r + 12, sd * 4, 0.55, out, 'horns', { bright: 3000 });
    I.lead(tl, r + 7, sd * 4, 0.42, out, 'horns', { bright: 2400 });
    I.lead(tl, r + 4, sd * 4, 0.4, out, 'horns', { bright: 2200 });
    for (let i = 0; i < 6; i++) bell(tl + i * 0.04, r + 12 + [0, 4, 7, 12, 16, 19][i], 0.05, 0.5, verbSend, 2, 0.5);
    I.crash(tl, 0.3, out, { decay: 1.1 });
    duckAt(t, 0.6, 3 * sd + sd * 4 + 0.15);
  };

  S.gameOverSting = function () { // gentle minor-iv -> I "amen", then quiet
    const t = now() + 0.05, out = chan(t, 0, LV.gameOver, 2.6).in, r = key();
    const iv = [r + 5, r + 8, r + 12], I1 = [r, r + 4, r + 7]; // minor iv -> I (plagal)
    I.keys(t, iv, 0.7, 0.5, out, 'ep');
    I.keys(t, iv, 0.8, 0.35, out, 'strings');
    I.keys(t + 0.75, I1, 1.1, 0.5, out, 'ep');
    I.keys(t + 0.75, I1, 1.2, 0.35, out, 'strings');
    I.bass(t, r - 24 + 5, 0.7, 0.12, out, 'house');
    I.bass(t + 0.75, r - 24, 1.1, 0.12, out, 'house');
    bell(t + 0.75, r + 12, 0.05, 1.0, verbSend, 2, 0.4);
  };

  S.click = function () {
    const t = now();
    const g = gain(), o = osc('sine', 1450 * jit(0.02), t);
    perc(g.gain, t, 0.12 * LV.click, 0.0008, 0.018);
    o.connect(g); g.connect(graph.ui); o.start(t); o.stop(t + 0.03); autoFree(o, [g]);
    nburst(t, 'white', 'highpass', 4500, 4500, 0.7, 0.0005, 0.006, 0.05, graph.ui);
  };

  // ---------------------------------------------------------------- music ducking
  function duck(depth, dur) { duckAt(now(), depth, dur); }
  function duckAt(t, depth, dur) {
    const g = graph.duck.gain;
    g.cancelScheduledValues(t);
    g.setTargetAtTime(depth, t, 0.02);
    g.setTargetAtTime(1, t + dur, 0.18);
  }
  S.duck = duck;

  // ---------------------------------------------------------------- road / wind bed
  let bed = null;
  function ensureBed() {
    if (bed) return bed;
    const t = now();
    const w = ctx.createBufferSource(); w.buffer = noiseBuffer(ctx, 'pinkL'); w.loop = true;
    const whp = filt('highpass', 180, 0.6), wlp = filt('lowpass', 900, 0.5), wg = gain(0);
    const r = ctx.createBufferSource(); r.buffer = noiseBuffer(ctx, 'brownL'); r.loop = true;
    const rlp = filt('lowpass', 150, 0.8), rg = gain(0);
    w.connect(whp); whp.connect(wlp); wlp.connect(wg); wg.connect(graph.amb);
    r.connect(rlp); rlp.connect(rg); rg.connect(graph.amb);
    w.start(t, 0.3); r.start(t, 3.1);
    bed = { wg, rg, wlp, wv: -1, rv: -1, f: -1 };
    return bed;
  }
  /** speed m/s; on = whether the bed should sound at all */
  S.bed = function (speed, on, boost) {
    if (!on && !bed) return;
    const b = ensureBed(), t = now();
    const k = on ? clamp((speed - 10) / 20, 0, 1) : 0;
    const wv = on ? 0.03 + 0.05 * k + (boost ? 0.04 : 0) : 0;
    const rv = on ? 0.1 + 0.08 * k : 0;
    const f = 600 + 900 * k + (boost ? 900 : 0);
    // only touch the automation timeline when something actually changed (called per frame)
    if (Math.abs(wv - b.wv) > 0.002) { b.wv = wv; b.wg.gain.setTargetAtTime(wv, t, 0.25); }
    if (Math.abs(rv - b.rv) > 0.002) { b.rv = rv; b.rg.gain.setTargetAtTime(rv, t, 0.25); }
    if (Math.abs(f - b.f) > 25) { b.f = f; b.wlp.frequency.setTargetAtTime(f, t, 0.3); }
  };

  return S;
}
