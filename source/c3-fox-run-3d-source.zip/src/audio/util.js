// AUDIO UTIL — pitch maths, seeded PRNG, chord parsing / voicing, shared noise buffers,
// PeriodicWave tables and waveshaper curves. Everything here is context-agnostic or takes
// the (realtime OR offline) AudioContext explicitly so the same code renders offline.

export const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const dbToGain = db => Math.pow(10, db / 20);
export const TAU = Math.PI * 2;

/** mulberry32 — deterministic so offline renders are reproducible. */
export function rng(seed = 1) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---------------------------------------------------------------- notes & chords
const PC = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
export function pcOf(name) {
  const m = /^([A-G])([#b]?)/.exec(name);
  if (!m) return 0;
  return (PC[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0) + 12) % 12;
}
/** 'F#5' -> 78 */
export function noteNum(s) {
  const m = /^([A-G])([#b]?)(-?\d)$/.exec(s);
  if (!m) return 60;
  return 12 * (+m[3] + 1) + PC[m[1]] + (m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0);
}

const QUAL = {
  '': [0, 4, 7], m: [0, 3, 7], '7': [0, 4, 7, 10], maj7: [0, 4, 7, 11], m7: [0, 3, 7, 10],
  '9': [0, 4, 7, 10, 14], m9: [0, 3, 7, 10, 14], maj9: [0, 4, 7, 11, 14], sus4: [0, 5, 7],
  sus2: [0, 2, 7], '6': [0, 4, 7, 9], m6: [0, 3, 7, 9], add9: [0, 4, 7, 14], '7sus4': [0, 5, 7, 10],
};
const chordCache = new Map();
/** 'C#m7' -> { sym, root: pc, iv: intervals, third, fifth, seventh } */
export function parseChord(sym) {
  let c = chordCache.get(sym);
  if (c) return c;
  const m = /^([A-G][#b]?)(.*)$/.exec(sym);
  const root = pcOf(m[1]);
  const iv = QUAL[m[2]] || QUAL[''];
  const third = iv.includes(3) ? 3 : iv.includes(4) ? 4 : iv[1];
  const seventh = iv.includes(10) ? 10 : iv.includes(11) ? 11 : 12;
  c = { sym, root, iv, third, fifth: 7, seventh };
  chordCache.set(sym, c);
  return c;
}

/** Candidate close voicings of chord `c` (n notes) whose notes lie inside [lo, hi];
 *  returns the one closest to `prev` (voice leading) or to the range centre. */
export function voiceChord(c, n, lo, hi, prev) {
  let pcs = c.iv.map(i => (c.root + i) % 12);
  // drop the fifth first, then the root, when the chord has more tones than voices
  if (pcs.length > n && pcs.length >= 4) pcs = pcs.filter((p, i) => c.iv[i] !== 7);
  if (pcs.length > n) pcs = pcs.slice(1);
  let best = null, bestD = 1e9;
  const centre = (lo + hi) / 2;
  for (let inv = 0; inv < pcs.length; inv++) {
    for (let base = lo - 12; base <= hi; base++) {
      if ((base % 12 + 12) % 12 !== pcs[inv]) continue;
      const v = [base];
      let k = inv;
      while (v.length < n) {
        k = (k + 1) % pcs.length;
        let nx = v[v.length - 1] + 1;
        while ((nx % 12 + 12) % 12 !== pcs[k]) nx++;
        v.push(nx);
      }
      if (v[0] < lo || v[v.length - 1] > hi) continue;
      let d = 0;
      if (prev && prev.length) for (let i = 0; i < n; i++) d += Math.abs(v[i] - prev[Math.min(i, prev.length - 1)]);
      else d = Math.abs((v[0] + v[n - 1]) / 2 - centre) * n;
      if (d < bestD) { bestD = d; best = v; }
    }
  }
  if (!best) { // range too tight: stack from lo
    best = [];
    let x = lo;
    for (let i = 0; i < n; i++) { while ((x % 12 + 12) % 12 !== pcs[i % pcs.length]) x++; best.push(x); x++; }
  }
  return best;
}

/** Lead / melody strings:  "0:F#5:3 3:F#5:3 6:E5:2 | 0:E5:4 ..."  one '|' per bar.
 *  -> array of bars, each [[step, midi, len, vel], ...]  ("pos:note:len[:vel]") */
export function parseMelody(src) {
  return src.split('|').map(bar => bar.trim().split(/\s+/).filter(Boolean).map(tok => {
    const [p, n, l, v] = tok.split(':');
    return [+p, noteNum(n), +l, v ? +v : 1];
  }));
}

/** Drum pattern char -> velocity */
export const VEL = { '.': 0, g: 0.28, o: 0.55, x: 0.8, X: 1 };

// ---------------------------------------------------------------- per-context caches
const CTX_CACHE = new WeakMap();
function cacheFor(ctx) {
  let c = CTX_CACHE.get(ctx);
  if (!c) { c = {}; CTX_CACHE.set(ctx, c); }
  return c;
}

/** Mono noise buffers: 'white', 'pink', 'brown' (2 s) and 'pinkL', 'brownL' (7 s, for
 *  continuous beds so the loop never sounds periodic) — generated once per context. */
export function noiseBuffer(ctx, name = 'white') {
  const c = cacheFor(ctx);
  if (c[name]) return c[name];
  const long = name.endsWith('L'), kind = long ? name.slice(0, -1) : name;
  const len = Math.floor(ctx.sampleRate * (long ? 7 : 2));
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const d = buf.getChannelData(0);
  const r = rng((kind === 'white' ? 11 : kind === 'pink' ? 23 : 37) + (long ? 5 : 0));
  if (kind === 'white') for (let i = 0; i < len; i++) d[i] = r() * 2 - 1;
  else if (kind === 'pink') {
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < len; i++) {
      const w = r() * 2 - 1;
      b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759;
      b2 = 0.96900 * b2 + w * 0.1538520; b3 = 0.86650 * b3 + w * 0.3104856;
      b4 = 0.55000 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.0168980;
      d[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11; b6 = w * 0.115926;
    }
  } else {
    let last = 0;
    for (let i = 0; i < len; i++) { last = (last + 0.02 * (r() * 2 - 1)) / 1.02; d[i] = last * 3.5; }
  }
  // crossfade the loop seam so looping sources don't click
  const fade = 256;
  for (let i = 0; i < fade; i++) { const k = i / fade; d[i] = d[i] * k + d[len - fade + i] * (1 - k); }
  c[name] = buf;
  return buf;
}

/** PeriodicWave from a harmonic amplitude function; cached per context by name. */
export function wave(ctx, name) {
  const c = cacheFor(ctx);
  c.waves = c.waves || {};
  if (c.waves[name]) return c.waves[name];
  const fn = WAVES[name];
  const N = 40;
  const real = new Float32Array(N + 1), imag = new Float32Array(N + 1);
  for (let k = 1; k <= N; k++) imag[k] = fn(k);
  const w = ctx.createPeriodicWave(real, imag);
  c.waves[name] = w;
  return w;
}
const WAVES = {
  // plucked strings: pluck position notches (sin(k*pi*p)) + spectral tilt
  banjo: k => Math.abs(Math.sin(k * Math.PI / 5.3)) / Math.pow(k, 0.8) * (k > 24 ? 0.3 : 1),
  guitar: k => Math.abs(Math.sin(k * Math.PI / 6.4)) / Math.pow(k, 1.15),
  clav: k => Math.abs(Math.sin(k * Math.PI / 11)) / Math.pow(k, 0.7) * (k > 20 ? 0.4 : 1),
  piano: k => [0, 1, 0.62, 0.34, 0.26, 0.14, 0.1, 0.07, 0.05, 0.035, 0.025][k] || 0.02 / k,
  organ: k => ({ 1: 1, 2: 0.72, 3: 0.4, 4: 0.34, 6: 0.16, 8: 0.12, 10: 0.04 })[k] || 0,
  softsq: k => (k % 2 ? 1 / Math.pow(k, 1.35) : 0.05 / k),
  horn: k => 1 / Math.pow(k, 1.05) * (k > 16 ? 0.25 : 1),
  reed: k => (k % 2 ? 1 / k : 0.35 / k) * (k > 12 ? 0.3 : 1),
};

/** tanh saturation curve normalised so ±1 -> ±1 (gentle glue at drive ~1.2) */
export function satCurve(drive = 1.2, n = 2048) {
  const c = new Float32Array(n), k = Math.tanh(drive);
  for (let i = 0; i < n; i++) { const x = i / (n - 1) * 2 - 1; c[i] = Math.tanh(drive * x) / k; }
  return c;
}
/** Hard ceiling soft-clipper: linear up to `knee`, then smoothly approaches `ceil`.
 *  The table spans a VIRTUAL input of ±`range`; feed it through a gain of 1/range first.
 *  WaveShaper output can never exceed the curve's max, so this is a true peak guard. */
export function clipCurve(ceil = 0.955, knee = 0.7, range = 1.6, n = 4096) {
  const c = new Float32Array(n), span = ceil - knee;
  for (let i = 0; i < n; i++) {
    const x = ((i / (n - 1)) * 2 - 1) * range;
    const a = Math.abs(x);
    const y = a <= knee ? a : knee + span * Math.tanh((a - knee) / span);
    c[i] = Math.sign(x) * y;
  }
  return c;
}
/** Asymmetric-ish drive for gritty parts. */
export function driveCurve(amount = 3, n = 1024) {
  const c = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = i / (n - 1) * 2 - 1;
    c[i] = Math.tanh(amount * x + 0.15 * x * x) / Math.tanh(amount);
  }
  return c;
}

/** Procedural stereo reverb impulse response (no files): decaying noise with HF damping. */
export function reverbIR(ctx, seconds = 1.6, decay = 3.2, damp = 0.35, channels = 2) {
  const sr = ctx.sampleRate, len = Math.floor(sr * seconds);
  const buf = ctx.createBuffer(channels, len, sr);
  for (let ch = 0; ch < channels; ch++) {
    const d = buf.getChannelData(ch), r = rng(101 + ch * 17);
    let lp = 0;
    for (let i = 0; i < len; i++) {
      const t = i / len;
      const env = Math.pow(1 - t, decay) * (i < sr * 0.004 ? i / (sr * 0.004) : 1);
      const a = 0.05 + damp * 2 * Math.pow(t, 0.6);         // one-pole LP: brighter early, darker tail
      lp = a * lp + (1 - a) * (r() * 2 - 1);
      d[i] = lp * env * Math.sqrt((1 + a) / (1 - a)) * (1 - 0.4 * t);
    }
  }
  // normalise energy so the send level means something
  let e = 0;
  for (let ch = 0; ch < channels; ch++) { const d = buf.getChannelData(ch); for (let i = 0; i < len; i++) e += d[i] * d[i]; }
  const g = 1 / Math.sqrt(e / channels) * 0.9;
  for (let ch = 0; ch < channels; ch++) { const d = buf.getChannelData(ch); for (let i = 0; i < len; i++) d[i] *= g; }
  return buf;
}

/** Disconnect `nodes` when source `src` ends (keeps long sessions leak-free on Safari). */
export function autoFree(src, nodes) {
  src.onended = () => { for (let i = 0; i < nodes.length; i++) { try { nodes[i].disconnect(); } catch (e) {} } };
}
