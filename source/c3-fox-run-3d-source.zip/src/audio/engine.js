// ENGINE — graph + instruments + sequencer + SFX bound to ONE context, which may be a live
// AudioContext or an OfflineAudioContext (tools/audio-render.py renders the very same code).
// Scene-level musical moves (title, run, level-up morph, boost colour, tape-stop on death,
// game-over sting, pause muffle) live here so they are testable offline.
import { createGraph } from './graph.js';
import { createInstruments } from './instruments.js';
import { createMusic } from './music.js';
import { createSfx } from './sfx.js';
import { REGION_STYLE, STYLES } from './styles.js';
import { THEMES } from '../data/themes.js';
import { rng, wave, noiseBuffer } from './util.js';

export function styleForTheme(idx) {
  const th = THEMES[((idx | 0) % THEMES.length + THEMES.length) % THEMES.length];
  return REGION_STYLE[th && th.region] || 'smokies';
}

export function createEngine(ctx, opts = {}) {
  // pre-warm lookup tables so the first coin / first region change never hitches the frame
  for (const w of ['banjo', 'guitar', 'clav', 'piano', 'softsq', 'horn']) wave(ctx, w);
  for (const n of ['white', 'pink', 'brown']) noiseBuffer(ctx, n);
  const longBeds = () => { try { noiseBuffer(ctx, 'pinkL'); noiseBuffer(ctx, 'brownL'); } catch (e) {} };
  if (opts.deferLong && typeof setTimeout === 'function') setTimeout(longBeds, 250); else longBeds();
  const graph = createGraph(ctx, opts);
  const I = createInstruments(ctx, rng(opts.seed || 1234));
  const music = createMusic(ctx, graph, I, { rand: rng((opts.seed || 1234) + 7) });
  const sfx = createSfx(ctx, graph, I, music, rng((opts.seed || 1234) + 13));
  const now = () => music.now();

  const E = { ctx, graph, I, music, sfx, scene: 'off', stopAt: 0, muffled: false };

  function ramp(param, v, t, tc) { param.cancelScheduledValues(t); param.setTargetAtTime(v, t, tc); }
  function lpTo(f, t, time) {
    const p = graph.musicLP.frequency;
    p.cancelScheduledValues(t);
    p.setValueAtTime(Math.max(40, p.value), t);
    p.exponentialRampToValueAtTime(f, t + time);
  }

  E.pump = function () {
    if (E.stopAt && now() >= E.stopAt) { E.stopAt = 0; music.stop(); }
    music.pump();
  };

  E.toTitle = function () {
    const t = now();
    E.scene = 'title'; E.stopAt = 0;
    graph.musicVol.gain.cancelScheduledValues(t);
    graph.musicVol.gain.setValueAtTime(0, t);
    graph.musicVol.gain.linearRampToValueAtTime(1, t + 1.4);
    lpTo(STYLES.smokies.title.lp || 5200, t, 0.05);
    music.start('title', 'smokies', t + 0.05);
    sfx.bed(0, false);
    sfx.ensureBoostLoop(false);
  };

  E.toRun = function (styleId = 'smokies') {
    const t = now();
    E.scene = 'run'; E.stopAt = 0;
    graph.musicVol.gain.cancelScheduledValues(t);
    graph.musicVol.gain.setTargetAtTime(1, t, 0.03);
    lpTo(18000, t, 0.25);
    graph.verbRet.gain.cancelScheduledValues(t); graph.verbRet.gain.setTargetAtTime(0.55, t, 0.05);
    music.S.sparkle = false; music.S.boost = false; music.S.comboHot = false;
    music.start('run', styleId, t + 0.06);
  };

  /** fatal hit: stop the band like pulling the tape — filter closes and fades over ~0.7 s */
  E.hitStop = function () {
    const t = now();
    lpTo(160, t, 0.55);
    ramp(graph.musicVol.gain, 0.0001, t + 0.1, 0.18);
    E.stopAt = t + 0.75;
    sfx.ensureBoostLoop(false);
    sfx.hit();
  };

  E.toGameOver = function () {
    const t = now();
    const wasRun = E.scene === 'run';
    E.scene = 'over';
    music.stop(); E.stopAt = 0;
    ramp(graph.musicVol.gain, 0.0001, t, 0.05);
    sfx.ensureBoostLoop(false);
    sfx.bed(0, false);
    if (wasRun || opts.forceSting) sfx.gameOverSting();
  };

  E.levelUp = function (ev) {
    if (E.scene !== 'run') return null;
    const id = styleForTheme(ev && ev.themeIdx != null ? ev.themeIdx : 0);
    sfx.levelUp();
    return music.transition(id);
  };

  E.boost = function (on) {
    const t = now();
    music.S.boost = !!on;
    if (on) {
      lpTo(650, t, 0.02);
      graph.musicLP.frequency.exponentialRampToValueAtTime(18000, t + 0.95);
      I.riser(t, 0.9, 0.3, music.bus.fx.in, { from: 400, to: 9000, q: 1.2 });
      sfx.boostStart();
    } else {
      lpTo(2400, t, 0.05);
      graph.musicLP.frequency.exponentialRampToValueAtTime(18000, t + 0.7);
      sfx.boostEnd();
    }
  };

  E.setSparkle = function (on) { music.S.sparkle = !!on; };

  /** pause button: keep the band playing but muffled under the menu */
  E.muffle = function (on) {
    const t = now();
    E.muffled = !!on;
    if (on) {
      lpTo(620, t, 0.25);
      ramp(graph.musicVol.gain, 0.5, t, 0.08);
      ramp(graph.sfxVol.gain, 0, t, 0.03);
      ramp(graph.verbRet.gain, 0.2, t, 0.1);
      sfx.bed(0, false);
      sfx.ensureBoostLoop(false);
    } else {
      lpTo(E.scene === 'title' ? (STYLES.smokies.title.lp || 5200) : 18000, t, 0.3);
      ramp(graph.musicVol.gain, E.scene === 'over' ? 0.0001 : 1, t, 0.08);
      ramp(graph.sfxVol.gain, 1, t, 0.03);
      ramp(graph.verbRet.gain, 0.55, t, 0.1);
    }
  };

  E.setMuted = function (m) {
    const t = ctx.currentTime;
    ramp(graph.out.gain, m ? 0 : 1, t, 0.02);
  };

  E.setQuality = function (tier) { graph.setQuality(tier); };

  return E;
}
