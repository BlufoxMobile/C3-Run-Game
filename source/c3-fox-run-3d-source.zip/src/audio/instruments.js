// INSTRUMENTS — every sound is synthesised from oscillators, PeriodicWaves, filtered noise
// and gain envelopes. Each voice is scheduled at an absolute context time `t`, so the same
// calls work in realtime (lookahead scheduler) and in an OfflineAudioContext.
// Voices create short-lived source nodes and free their chain on `ended`.
//
//   const I = createInstruments(ctx, rand);
//   I.kick(t, vel, outNode, params)   I.bass(t, midi, dur, vel, out, kind, params)
//   I.keys(t, midis[], dur, vel, out, kind, params)   I.lead(t, midi, dur, vel, out, kind, params)
import { mtof, noiseBuffer, wave, autoFree, driveCurve } from './util.js';

export const PERF = { noSweep: false, noVibrato: false, noFilters: false }; // profiling switches (dev only)

export function createInstruments(ctx, rand = Math.random) {
  const stats = { nodes: 0 };
  const DRIVE = { soft: driveCurve(1.8), hard: driveCurve(3.2) };

  const osc = (type, f, t) => {
    const o = ctx.createOscillator();
    if (typeof type === 'string') o.type = type; else o.setPeriodicWave(type);
    o.frequency.setValueAtTime(f, t);
    stats.nodes++;
    return o;
  };
  const gain = (v = 0) => { const g = ctx.createGain(); g.gain.value = v; stats.nodes++; return g; };
  const filt = (type, f, q = 0.707) => {
    const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; b.Q.value = q; stats.nodes++; return b;
  };
  const noise = (t, dur, kind = 'white') => {
    const s = ctx.createBufferSource(); s.buffer = noiseBuffer(ctx, kind); s.loop = true;
    s.start(t, rand() * 1.8); s.stop(t + dur); stats.nodes++;
    return s;
  };
  const shaper = curve => { const w = ctx.createWaveShaper(); w.curve = curve; stats.nodes++; return w; };
  const pw = name => wave(ctx, name);

  // --- envelopes -----------------------------------------------------------------------
  function perc(p, t, peak, a, dec) {
    p.setValueAtTime(0, t);
    p.linearRampToValueAtTime(peak, t + a);
    p.exponentialRampToValueAtTime(0.0001, t + a + dec);
    return t + a + dec + 0.01;
  }
  /** attack a, decay time-constant d to sustain s, release time-constant r after dur -> stop time */
  function adsr(p, t, peak, a, d, s, dur, r) {
    p.setValueAtTime(0, t);
    p.linearRampToValueAtTime(peak, t + a);
    p.setTargetAtTime(peak * s, t + a, d);
    const tr = t + Math.max(dur, a + 0.001);
    p.setTargetAtTime(0, tr, r);
    return tr + r * 6;
  }
  function sweep(p, t, from, to, time) {
    if (PERF.noSweep) { p.value = to; return; }
    p.setValueAtTime(from, t);
    p.exponentialRampToValueAtTime(to, t + time);
  }
  function vibrato(t, f, depth, rate, delay, oscs, end) {
    if (PERF.noVibrato) return;
    const l = osc('sine', rate, t), lg = gain(0);
    lg.gain.setValueAtTime(0, t);
    lg.gain.linearRampToValueAtTime(0, t + delay);
    lg.gain.linearRampToValueAtTime(f * depth, t + delay + 0.25);
    l.connect(lg);
    for (const o of oscs) lg.connect(o.frequency);
    l.start(t); l.stop(end);
    autoFree(l, [lg]);
  }

  // ======================================================================= DRUMS
  function kick(t, v, out, p = {}) {
    const f0 = p.f0 || 150, f1 = p.f1 || 48, dec = p.decay || 0.4;
    const o = osc('sine', f0 * 2.4, t);
    o.frequency.exponentialRampToValueAtTime(f0, t + 0.01);
    o.frequency.exponentialRampToValueAtTime(f1, t + (p.pd || 0.11));
    const g = gain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(v, t + 0.002);
    g.gain.exponentialRampToValueAtTime(v * 0.55, t + dec * 0.3);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dec);
    let last = g;
    o.connect(g);
    if (p.drive) { const sh = shaper(DRIVE[p.drive] || DRIVE.soft); g.connect(sh); last = sh; }
    last.connect(out);
    o.start(t); o.stop(t + dec + 0.02);
    autoFree(o, last === g ? [g] : [g, last]);
    if (p.stomp) { // wooden-floor stomp: low noise thump
      const n = noise(t, 0.12, 'brown'), lp = filt('lowpass', 520, 0.9), ng = gain();
      perc(ng.gain, t, v * 0.9, 0.002, 0.09);
      n.connect(lp); lp.connect(ng); ng.connect(out); autoFree(n, [lp, ng]);
    }
    if (p.click) {
      const n = noise(t, 0.02), hp = filt('highpass', 2200), ng = gain();
      perc(ng.gain, t, v * p.click, 0.0005, 0.012);
      n.connect(hp); hp.connect(ng); ng.connect(out); autoFree(n, [hp, ng]);
    }
  }

  function snare(t, v, out, p = {}) {
    const tone = p.tone || 190, dec = p.decay || 0.17;
    const b = osc('triangle', tone, t);
    b.frequency.exponentialRampToValueAtTime(tone * 0.78, t + 0.06);
    const bg = gain(); perc(bg.gain, t, v * (p.body ?? 0.35), 0.001, 0.09);
    b.connect(bg); bg.connect(out); b.start(t); b.stop(t + 0.12); autoFree(b, [bg]);
    const n = noise(t, dec + 0.05, p.pink ? 'pink' : 'white');
    const hp = filt('highpass', p.hp || 1000), lp = filt('lowpass', p.lp || 7000), ng = gain();
    perc(ng.gain, t, v * (p.noise ?? 1.0), 0.001, dec);
    n.connect(hp); hp.connect(lp); lp.connect(ng);
    let last = ng;
    if (p.drive) { const sh = shaper(DRIVE[p.drive]); ng.connect(sh); last = sh; }
    last.connect(out);
    autoFree(n, last === ng ? [hp, lp, ng] : [hp, lp, ng, last]);
  }

  function clap(t, v, out, p = {}) {
    const dec = p.decay || 0.16;
    const n = noise(t, 0.06 + dec), bp = filt('bandpass', p.f || 1250, 1.2), hp = filt('highpass', 600), g = gain();
    const q = g.gain;
    q.setValueAtTime(0, t);
    for (let i = 0; i < 3; i++) {
      const tt = t + i * 0.0105;
      q.setValueAtTime(v * 0.85, tt);
      q.exponentialRampToValueAtTime(v * 0.12, tt + 0.0095);
    }
    q.setValueAtTime(v, t + 0.032);
    q.exponentialRampToValueAtTime(0.0001, t + 0.032 + dec);
    n.connect(hp); hp.connect(bp); bp.connect(g); g.connect(out);
    autoFree(n, [hp, bp, g]);
  }

  function hat(t, v, out, p = {}) {
    const open = !!p.open, dec = open ? (p.openDecay || 0.26) : (p.decay || 0.042);
    const n = noise(t, dec + 0.03), hp = filt('highpass', p.hp || 7200, 0.9), g = gain();
    let last = hp;
    if (p.bp) { const bp = filt('bandpass', p.bp, 0.8); hp.connect(bp); last = bp; }
    perc(g.gain, t, v * (open ? 0.42 : 0.5), 0.001, dec);
    n.connect(hp); last.connect(g); g.connect(out);
    autoFree(n, last === hp ? [hp, g] : [hp, last, g]);
  }

  function shaker(t, v, out, p = {}) {
    const n = noise(t, 0.11), bp = filt('bandpass', p.f || 6200, 1.3), g = gain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(v * 0.55, t + (p.a || 0.014));
    g.gain.exponentialRampToValueAtTime(0.0001, t + (p.a || 0.014) + (p.decay || 0.07));
    n.connect(bp); bp.connect(g); g.connect(out);
    autoFree(n, [bp, g]);
  }

  function tamb(t, v, out) {
    shaker(t, v * 0.8, out, { f: 8200, a: 0.003, decay: 0.12 });
    const f = 5200 + rand() * 600, o = osc('sine', f, t), g = gain();
    perc(g.gain, t, v * 0.05, 0.001, 0.09);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.12); autoFree(o, [g]);
  }

  function wood(t, v, out, p = {}) {
    const f = p.f || 1150;
    const o = osc('sine', f, t), o2 = osc('sine', f * 1.58, t), g = gain(), g2 = gain();
    perc(g.gain, t, v * 0.45, 0.0008, 0.055);
    perc(g2.gain, t, v * 0.15, 0.0008, 0.03);
    o.connect(g); o2.connect(g2); g.connect(out); g2.connect(out);
    o.start(t); o2.start(t); o.stop(t + 0.08); o2.stop(t + 0.08);
    autoFree(o, [g]); autoFree(o2, [g2]);
  }

  function metal(t, v, out, p = {}) {
    const f = (p.f || 320) * (0.97 + rand() * 0.06);
    const R = [1, 1.47, 2.09, 2.76], A = [0.42, 0.3, 0.2, 0.12], D = [0.34, 0.2, 0.13, 0.08];
    const g = gain(1), lp = filt('lowpass', 4200);
    for (let i = 0; i < 4; i++) {
      const o = osc(i === 0 ? 'triangle' : 'sine', f * R[i], t), pg = gain();
      perc(pg.gain, t, v * A[i], 0.001, D[i]);
      o.connect(pg); pg.connect(g); o.start(t); o.stop(t + D[i] + 0.03); autoFree(o, [pg]);
    }
    g.connect(lp); lp.connect(out);
    const n = noise(t, 0.03), hp = filt('highpass', 3000), ng = gain();
    perc(ng.gain, t, v * 0.25, 0.0005, 0.018);
    n.connect(hp); hp.connect(ng); ng.connect(out);
    autoFree(n, [hp, ng, g, lp]);
  }

  function tom(t, v, out, p = {}) {
    const f = p.f || 140;
    const o = osc('sine', f * 1.3, t);
    o.frequency.exponentialRampToValueAtTime(f, t + 0.02);
    o.frequency.exponentialRampToValueAtTime(f * 0.62, t + 0.3);
    const g = gain(); perc(g.gain, t, v * 0.8, 0.002, 0.3);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + 0.34); autoFree(o, [g]);
    const n = noise(t, 0.05), lp = filt('lowpass', 2400), ng = gain();
    perc(ng.gain, t, v * 0.18, 0.001, 0.04);
    n.connect(lp); lp.connect(ng); ng.connect(out); autoFree(n, [lp, ng]);
  }

  function crash(t, v, out, p = {}) {
    const dec = p.decay || 1.7;
    const n = noise(t, dec + 0.05), hp = filt('highpass', p.hp || 4800, 0.8), lp = filt('lowpass', 11000), g = gain();
    perc(g.gain, t, v * 0.36, 0.002, dec);
    n.connect(hp); hp.connect(lp); lp.connect(g); g.connect(out);
    autoFree(n, [hp, lp, g]);
  }

  const DRUM = { kick, snare, clap, hat, shaker, tamb, wood, metal, tom, crash };
  function drum(name, t, v, out, p) { (DRUM[name] || hat)(t, v, out, p || {}); }

  // ======================================================================= BASS
  function bass(t, m, dur, v, out, kind, p = {}) {
    const f = mtof(m);
    const g = gain();
    const chain = [g];
    let end;
    if (kind === 'upright') {
      const o1 = osc('triangle', f, t), o2 = osc('sine', f, t), og = gain(0.9);
      const lp = filt('lowpass', 1800, 1.1);
      sweep(lp.frequency, t, 2400, 480, 0.14);
      o1.connect(lp); o2.connect(og); og.connect(lp); lp.connect(g);
      end = adsr(g.gain, t, v, 0.004, 0.11, 0.42, dur, 0.035);
      o1.start(t); o2.start(t); o1.stop(end); o2.stop(end);
      chain.push(lp, og); autoFree(o1, chain); autoFree(o2, []);
      const n = noise(t, 0.03, 'brown'), nl = filt('lowpass', 380), ng = gain();
      perc(ng.gain, t, v * 0.35, 0.001, 0.02);
      n.connect(nl); nl.connect(ng); ng.connect(out); autoFree(n, [nl, ng]);
    } else if (kind === 'slap') {
      const o1 = osc('sawtooth', f, t), o2 = osc('sine', f, t), og = gain(0.8);
      const lp = filt('lowpass', 3000, 3.2);
      sweep(lp.frequency, t, p.pop ? 5200 : 3200, p.pop ? 900 : 460, p.pop ? 0.12 : 0.085);
      o1.connect(lp); o2.connect(og); og.connect(g); lp.connect(g);
      end = adsr(g.gain, t, v * (p.pop ? 0.75 : 1), 0.002, 0.09, 0.5, dur, 0.03);
      o1.start(t); o2.start(t); o1.stop(end); o2.stop(end);
      chain.push(lp, og); autoFree(o1, chain); autoFree(o2, []);
    } else if (kind === 'pulse') {
      const o1 = osc('sawtooth', f, t), o2 = osc('square', f, t), og = gain(0.5);
      o2.detune.value = 7;
      const lp = filt('lowpass', 900, 1.6);
      sweep(lp.frequency, t, 1700, 720, 0.11);
      o1.connect(lp); o2.connect(og); og.connect(lp); lp.connect(g);
      end = adsr(g.gain, t, v * 0.8, 0.004, 0.1, 0.7, dur * 0.88, 0.02);
      o1.start(t); o2.start(t); o1.stop(end); o2.stop(end);
      chain.push(lp, og); autoFree(o1, chain); autoFree(o2, []);
    } else if (kind === 'dist') {
      const o1 = osc('sawtooth', f, t), o2 = osc('sawtooth', f * 1.006, t);
      const lp = filt('lowpass', 2000, 4.5);
      sweep(lp.frequency, t, 2600, 380, 0.11);
      const sh = shaper(DRIVE.hard), post = filt('lowpass', 3200, 0.7);
      o1.connect(lp); o2.connect(lp); lp.connect(sh); sh.connect(post); post.connect(g);
      end = adsr(g.gain, t, v * 0.55, 0.003, 0.08, 0.6, dur * 0.9, 0.02);
      o1.start(t); o2.start(t); o1.stop(end); o2.stop(end);
      chain.push(lp, sh, post); autoFree(o1, chain); autoFree(o2, []);
    } else if (kind === 'acid') {
      const o = osc('sawtooth', p.from ? mtof(p.from) : f, t);
      if (p.from) o.frequency.exponentialRampToValueAtTime(f, t + 0.055);
      const lp = filt('lowpass', 300, p.q || 7);
      const peak = p.accent ? (p.peak || 1500) : (p.peak || 1500) * 0.55;
      lp.frequency.setValueAtTime(260, t);
      lp.frequency.linearRampToValueAtTime(peak, t + 0.006);
      lp.frequency.setTargetAtTime(280, t + 0.006, p.accent ? 0.11 : 0.07);
      const post = filt('lowpass', 2600, 0.5);
      o.connect(lp); lp.connect(post); post.connect(g);
      end = adsr(g.gain, t, v * (p.accent ? 0.62 : 0.45), 0.003, 0.1, 0.75, dur, 0.018);
      o.start(t); o.stop(end);
      chain.push(lp, post); autoFree(o, chain);
    } else { // 'house' — round sine + a little saw bite
      const o1 = osc('sine', f, t), o2 = osc('sawtooth', f, t), og = gain(0.28);
      const lp = filt('lowpass', 900, 1.2);
      sweep(lp.frequency, t, 1400, 620, 0.12);
      o2.connect(og); og.connect(lp); o1.connect(g); lp.connect(g);
      end = adsr(g.gain, t, v * 0.9, 0.004, 0.14, 0.75, dur, 0.025);
      o1.start(t); o2.start(t); o1.stop(end); o2.stop(end);
      chain.push(lp, og); autoFree(o1, chain); autoFree(o2, []);
    }
    g.connect(out);
  }

  // ======================================================================= KEYS / CHORDS
  function glock(t, ms, v, out) { // sparkle bells, each note randomly panned
    const end = t + 0.6;
    for (const m of ms) {
      const f = mtof(m), o = osc('sine', f, t), o2 = osc('sine', f * 4, t), og = gain(), og2 = gain();
      perc(og.gain, t, v * 0.22, 0.001, 0.45);
      perc(og2.gain, t, v * 0.03, 0.001, 0.08);
      o.connect(og); o2.connect(og2);
      if (ctx.createStereoPanner) {
        const pn = ctx.createStereoPanner(); pn.pan.value = (rand() * 2 - 1) * 0.7;
        og.connect(pn); og2.connect(pn); pn.connect(out); autoFree(o, [og, og2, pn]);
      } else { og.connect(out); og2.connect(out); autoFree(o, [og, og2]); }
      o.start(t); o2.start(t); o.stop(end); o2.stop(t + 0.1);
    }
  }

  function keys(t, ms, dur, v, out, kind, p = {}) {
    if (kind === 'glock') { glock(t, ms, v, out); return; }
    const g = gain();
    const chain = [g];
    const srcs = [];
    let end;
    if (kind === 'strum') {
      const lp = filt('lowpass', 3000, 0.8);
      sweep(lp.frequency, t, p.up ? 3600 : 3200, 1000, 0.32);
      const order = p.up ? ms.slice(-3).reverse() : ms;
      const peak = v * (p.up ? 0.2 : 0.26);
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(peak, t + 0.004);
      g.gain.setTargetAtTime(peak * 0.3, t + 0.004, 0.13);
      g.gain.setTargetAtTime(0, t + dur, 0.06);
      end = t + dur + 0.4;
      order.forEach((m, i) => {
        const o = osc(pw('guitar'), mtof(m), t + i * 0.012);
        o.connect(lp); o.start(t + i * 0.012); o.stop(end); srcs.push(o);
      });
      lp.connect(g); chain.push(lp);
    } else if (kind === 'harmonium' || kind === 'strings' || kind === 'darkpad' || kind === 'supersaw') {
      const cfg = {
        harmonium: { det: [-7, 7], lp: 1500, q: 0.6, a: 0.16, r: 0.14, lvl: 0.12 },
        strings: { det: [-9, 9], lp: 2100, q: 0.5, a: 0.3, r: 0.3, lvl: 0.1 },
        darkpad: { det: [-10, 10], lp: 780, q: 1.5, a: 0.28, r: 0.35, lvl: 0.16 },
        supersaw: { det: [-13, 11], lp: 1900, q: 0.9, a: 0.05, r: 0.16, lvl: 0.1 },
      }[kind];
      const lp = filt('lowpass', cfg.lp, cfg.q);
      if (kind === 'supersaw') sweep(lp.frequency, t, 850, cfg.lp, 0.3);
      if (kind === 'darkpad') { lp.frequency.setValueAtTime(420, t); lp.frequency.linearRampToValueAtTime(cfg.lp, t + dur * 0.5); lp.frequency.linearRampToValueAtTime(520, t + dur); }
      end = adsr(g.gain, t, v * cfg.lvl, cfg.a, 0.5, 0.9, dur, cfg.r);
      for (const m of ms) for (const d of cfg.det) {
        const o = osc('sawtooth', mtof(m), t); o.detune.value = d;
        o.connect(lp); o.start(t); o.stop(end); srcs.push(o);
      }
      lp.connect(g); chain.push(lp);
    } else if (kind === 'clav') {
      const hp = filt('highpass', 240), lp = filt('lowpass', 3000, 1.5);
      sweep(lp.frequency, t, 3400, 1100, 0.09);
      end = perc(g.gain, t, v * 0.2, 0.001, Math.min(0.22, dur + 0.06));
      for (const m of ms) { const o = osc(pw('clav'), mtof(m), t); o.connect(hp); o.start(t); o.stop(end); srcs.push(o); }
      hp.connect(lp); lp.connect(g); chain.push(hp, lp);
    } else if (kind === 'ep') { // FM electric piano
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(v * 0.2, t + 0.004);
      g.gain.setTargetAtTime(v * 0.07, t + 0.004, 0.35);
      g.gain.setTargetAtTime(0, t + dur, 0.09);
      end = t + dur + 0.6;
      for (const m of ms) {
        const f = mtof(m), c = osc('sine', f, t), mo = osc('sine', f, t), mg = gain();
        mg.gain.setValueAtTime(f * 1.3, t);
        mg.gain.exponentialRampToValueAtTime(f * 0.12, t + 0.35);
        mo.connect(mg); mg.connect(c.frequency); c.connect(g);
        c.start(t); mo.start(t); c.stop(end); mo.stop(end); srcs.push(c); autoFree(mo, [mg]);
      }
    } else if (kind === 'piano') { // M1-style house piano
      const lp = filt('lowpass', 5000, 0.6);
      sweep(lp.frequency, t, p.bright || 5200, 1300, 0.4);
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(v * 0.2, t + 0.002);
      g.gain.setTargetAtTime(v * 0.075, t + 0.002, 0.09);
      g.gain.setTargetAtTime(0.0, t + dur, 0.07);
      end = t + dur + 0.45;
      for (const m of ms) { const o = osc(pw('piano'), mtof(m), t); o.connect(lp); o.start(t); o.stop(end); srcs.push(o); }
      lp.connect(g); chain.push(lp);
      const nz = noise(t, 0.02), nl = filt('bandpass', 2400, 0.8), ng = gain();
      perc(ng.gain, t, v * 0.05, 0.0005, 0.012);
      nz.connect(nl); nl.connect(ng); ng.connect(out); autoFree(nz, [nl, ng]);
    }
    g.connect(out);
    if (srcs.length) { autoFree(srcs[0], chain); }
  }

  // ======================================================================= LEADS
  function lead(t, m, dur, v, out, kind, p = {}) {
    const f = mtof(m);
    const g = gain();
    const chain = [g];
    let end, srcs = [];
    if (kind === 'whistle') {
      const o1 = osc('sine', f * 0.985, t), o2 = osc('triangle', f * 0.985, t), og = gain(0.22);
      o1.frequency.exponentialRampToValueAtTime(f, t + 0.035);
      o2.frequency.exponentialRampToValueAtTime(f, t + 0.035);
      const lp = filt('lowpass', 4200);
      o1.connect(lp); o2.connect(og); og.connect(lp); lp.connect(g);
      end = adsr(g.gain, t, v * 0.42, 0.022, 0.2, 0.82, dur, 0.05);
      vibrato(t, f, 0.0065, 5.6, 0.14, [o1, o2], end);
      srcs = [o1, o2]; chain.push(lp, og);
    } else if (kind === 'fiddle') {
      const o1 = osc('sawtooth', f, t), lp = filt('lowpass', 2300, 0.8), bp = filt('peaking', 1200, 1.2);
      bp.gain.value = 4;
      o1.connect(lp); lp.connect(bp); bp.connect(g);
      end = adsr(g.gain, t, v * 0.22, 0.09, 0.3, 0.85, dur, 0.1);
      vibrato(t, f, 0.006, 6.1, 0.2, [o1], end);
      srcs = [o1]; chain.push(lp, bp);
    } else if (kind === 'horns') {
      const o1 = osc('sawtooth', f, t), o2 = osc('sawtooth', f, t), o3 = osc(pw('horn'), f / 2, t), o3g = gain(0.35);
      o1.detune.value = -8; o2.detune.value = 8;
      const lp = filt('lowpass', 1800, 1.1);
      lp.frequency.setValueAtTime(650, t);
      lp.frequency.exponentialRampToValueAtTime(p.bright || 2700, t + 0.035);
      lp.frequency.exponentialRampToValueAtTime((p.bright || 2700) * 0.68, t + 0.22);
      o1.connect(lp); o2.connect(lp); o3.connect(o3g); o3g.connect(lp); lp.connect(g);
      end = adsr(g.gain, t, v * 0.2, 0.014, 0.15, 0.78, dur, 0.045);
      srcs = [o1, o2, o3]; chain.push(lp, o3g);
    } else if (kind === 'synthlead') {
      const o1 = osc('sawtooth', f, t), o2 = osc(pw('softsq'), f, t), o2g = gain(0.7);
      o2.detune.value = 6;
      const lp = filt('lowpass', 2300, 1.3);
      lp.frequency.setValueAtTime(1300, t);
      lp.frequency.exponentialRampToValueAtTime(3100, t + 0.03);
      lp.frequency.exponentialRampToValueAtTime(2200, t + 0.25);
      o1.connect(lp); o2.connect(o2g); o2g.connect(lp); lp.connect(g);
      end = adsr(g.gain, t, v * 0.2, 0.012, 0.2, 0.8, dur, 0.1);
      vibrato(t, f, 0.005, 5.2, 0.22, [o1, o2], end);
      srcs = [o1, o2]; chain.push(lp, o2g);
    } else if (kind === 'squarelead') {
      const o1 = osc('square', f, t), o2 = osc('square', f, t);
      o2.detune.value = 10;
      const lp = filt('lowpass', 2100, 1.4), sh = shaper(DRIVE.soft);
      o1.connect(lp); o2.connect(lp); lp.connect(sh); sh.connect(g);
      end = adsr(g.gain, t, v * 0.13, 0.006, 0.15, 0.75, dur, 0.07);
      vibrato(t, f, 0.004, 5.8, 0.25, [o1, o2], end);
      srcs = [o1, o2]; chain.push(lp, sh);
    } else if (kind === 'bell') { // soft FM bell
      const c = osc('sine', f, t), mo = osc('sine', f * 3.5, t), mg = gain();
      mg.gain.setValueAtTime(f * 1.6, t);
      mg.gain.exponentialRampToValueAtTime(f * 0.05, t + 0.9);
      mo.connect(mg); mg.connect(c.frequency); c.connect(g);
      end = perc(g.gain, t, v * 0.2, 0.002, Math.max(0.6, dur * 1.2));
      srcs = [c, mo]; chain.push(mg);
    } else if (kind === 'piano' || kind === 'ep' || kind === 'strings' || kind === 'strum') {
      keys(t, p.octave ? [m, m + 12] : [m], dur, v, out, kind, p);
      return;
    } else { // 'pluck' fallback
      const o = osc(pw('softsq'), f, t), lp = filt('lowpass', 3000);
      sweep(lp.frequency, t, 3200, 900, 0.14);
      o.connect(lp); lp.connect(g);
      end = perc(g.gain, t, v * 0.3, 0.002, 0.3);
      srcs = [o]; chain.push(lp);
    }
    g.connect(out);
    for (const s of srcs) { s.start(t); s.stop(end); }
    autoFree(srcs[0], chain);
  }

  // ======================================================================= ARPS
  function arp(t, ms, dur, v, out, kind, p = {}) {
    if (kind === 'acid') { bass(t, ms[0], dur, v, out, 'acid', p); return; }
    const g = gain(), chain = [g], srcs = [];
    let end;
    if (kind === 'banjo') {
      const lp = filt('lowpass', 3000, 1.4);
      sweep(lp.frequency, t, 6200, 1500, 0.1);
      end = perc(g.gain, t, v * 0.3, 0.0012, 0.3);
      for (const m of ms) { const o = osc(pw('banjo'), mtof(m), t); o.connect(lp); srcs.push(o); }
      lp.connect(g); chain.push(lp);
    } else if (kind === 'scratch') { // muted funk guitar
      const bp = filt('bandpass', 900, 2.2);
      sweep(bp.frequency, t, 600, 1900, 0.05);
      end = perc(g.gain, t, v * 0.9, 0.001, 0.06);
      for (const m of ms) { const o = osc('sawtooth', mtof(m), t); o.connect(bp); srcs.push(o); }
      bp.connect(g); chain.push(bp);
    } else if (kind === 'sqarp') {
      const lp = filt('lowpass', 2000, 3);
      sweep(lp.frequency, t, 2700, 560, 0.1);
      end = perc(g.gain, t, v * 0.16, 0.001, 0.17);
      for (const m of ms) { const o = osc('square', mtof(m), t); o.connect(lp); srcs.push(o); }
      lp.connect(g); chain.push(lp);
    } else { // 'pluck'
      const lp = filt('lowpass', 2800, 1);
      sweep(lp.frequency, t, 3300, 820, 0.15);
      end = perc(g.gain, t, v * 0.26, 0.0015, 0.26);
      for (const m of ms) { const o = osc(pw('softsq'), mtof(m), t); o.connect(lp); srcs.push(o); }
      lp.connect(g); chain.push(lp);
    }
    g.connect(out);
    for (const s of srcs) { s.start(t); s.stop(end); }
    autoFree(srcs[0], chain);
  }

  // ======================================================================= FX
  function riser(t, dur, v, out, p = {}) {
    const n = noise(t, dur + 0.1), bp = filt('bandpass', 400, p.q || 1.6), g = gain();
    bp.frequency.setValueAtTime(p.from || 350, t);
    bp.frequency.exponentialRampToValueAtTime(p.to || 6000, t + dur);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(v, t + dur);
    g.gain.linearRampToValueAtTime(0, t + dur + 0.06);
    n.connect(bp); bp.connect(g); g.connect(out);
    autoFree(n, [bp, g]);
  }
  function downlifter(t, dur, v, out, p = {}) {
    const n = noise(t, dur + 0.05), bp = filt('bandpass', 4000, 1.2), g = gain();
    sweep(bp.frequency, t, p.from || 5000, p.to || 260, dur);
    perc(g.gain, t, v, 0.01, dur);
    n.connect(bp); bp.connect(g); g.connect(out);
    autoFree(n, [bp, g]);
  }

  return { stats, drum, kick, snare, clap, hat, shaker, tamb, wood, metal, tom, crash, bass, keys, lead, arp, riser, downlifter,
    _prims: { osc, gain, filt, noise, shaper, perc, adsr, sweep, vibrato, pw, DRIVE } };
}
