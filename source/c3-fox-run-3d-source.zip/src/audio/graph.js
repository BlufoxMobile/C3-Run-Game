// AUDIO GRAPH — the fixed mixing topology. Works on an AudioContext or OfflineAudioContext.
//
//   music parts ─┬─> music ─> sat (tanh glue) ─> musicLP (sweepable) ─> duck ─> musicVol ─> glue comp ─┐
//                └─> verbIn ─> Convolver (procedural IR) ─> verbRet ───────────────────────┤
//   (arp) ──────────> echoIn ─> Delay ⟲ (fb+LP) ─> music                                  │
//   sfx voices ─────> sfx ─> sfxVol ────────────────────────────────────────────────────────┤
//   wind / boost loop ─> amb ───────────────────────────────────────────────────────────────┤
//   ui click ───────> ui ───────────────────────────────────────────────────────────────────┤
//                                                                                          v
//   master ─> limiter ─> (1/1.6) ─> soft-clip ceiling (-0.54 dBFS) ─> out (mute) ─> dest
import { satCurve, clipCurve, reverbIR } from './util.js';

// SFX no longer pass the glue compressor (and its automatic makeup gain): this trim keeps
// their measured levels identical to the calibrated ones.
const SFX_TRIM = 1.45;

export function createGraph(ctx, opts = {}) {
  const dest = opts.destination || ctx.destination;
  const G = (v = 1) => { const g = ctx.createGain(); g.gain.value = v; return g; };

  const master = G(1);
  const comp = ctx.createDynamicsCompressor();
  comp.threshold.value = -16; comp.knee.value = 8; comp.ratio.value = 2.5;
  comp.attack.value = 0.006; comp.release.value = 0.2;
  const limiter = ctx.createDynamicsCompressor();
  limiter.threshold.value = -4; limiter.knee.value = 0; limiter.ratio.value = 20;
  limiter.attack.value = 0.001; limiter.release.value = 0.09;
  const clipPre = G(1 / 1.6);
  const clip = ctx.createWaveShaper(); clip.curve = clipCurve(0.94, 0.72, 1.6);
  const out = G(1);
  master.connect(limiter); limiter.connect(clipPre); clipPre.connect(clip);
  clip.connect(out); out.connect(dest);

  // music chain
  const music = G(1);
  const sat = ctx.createWaveShaper(); sat.curve = satCurve(1.15); sat.oversample = 'none'; // gentle glue: aliasing is inaudible, 2x cost ~2 % CPU
  const satIn = G(0.9);
  const musicLP = ctx.createBiquadFilter(); musicLP.type = 'lowpass'; musicLP.frequency.value = 18000; musicLP.Q.value = 0.6;
  const duck = G(1);
  const musicVol = G(1);
  // the glue compressor sits on the MUSIC bus only: SFX skip its 6 ms look-ahead (lower latency)
  music.connect(satIn); satIn.connect(sat); sat.connect(musicLP); musicLP.connect(duck); duck.connect(musicVol);
  musicVol.connect(comp); comp.connect(master);

  // reverb (one shared send for music + a few SFX). MONO convolution (half the CPU of a
  // stereo IR) widened with a 13 ms Haas delay on the right channel.
  const mono = n => { n.channelCount = 1; n.channelCountMode = 'explicit'; n.channelInterpretation = 'speakers'; return n; };
  const verbIn = mono(G(1));
  const verbHP = mono(ctx.createBiquadFilter()); verbHP.type = 'highpass'; verbHP.frequency.value = 220;
  const verb = mono(ctx.createConvolver()); verb.normalize = false; verb.buffer = reverbIR(ctx, opts.irSeconds || 1.6, 3.0, 0.36, 1);
  const haas = ctx.createDelay(0.05); haas.delayTime.value = 0.013;
  const merge = ctx.createChannelMerger(2);
  const verbRet = G(0.55);
  verbIn.connect(verbHP); verbHP.connect(verb);
  verb.connect(merge, 0, 0); verb.connect(haas); haas.connect(merge, 0, 1);
  merge.connect(verbRet); verbRet.connect(master);

  // tempo echo (dotted eighth by default) for arps
  const echoIn = G(1);
  const echo = ctx.createDelay(2.0); echo.delayTime.value = 0.39;
  const echoFB = G(0.36);
  const echoLP = ctx.createBiquadFilter(); echoLP.type = 'lowpass'; echoLP.frequency.value = 2600;
  const echoOut = G(0.55);
  echoIn.connect(echo); echo.connect(echoLP); echoLP.connect(echoFB); echoFB.connect(echo);
  echoLP.connect(echoOut); echoOut.connect(music);

  const sfx = G(SFX_TRIM), sfxVol = G(1);
  sfx.connect(sfxVol); sfxVol.connect(master);
  const amb = G(1); amb.connect(master);
  const ui = G(1); ui.connect(master);

  const graph = {
    ctx, master, comp, limiter, clip, out, music, sat, musicLP, duck, musicVol,
    verbIn, verb, verbRet, echoIn, echo, echoFB, sfx, sfxVol, amb, ui,
    quality: 'high',
    setQuality(tier) {
      if (tier === graph.quality) return;
      graph.quality = tier;
      try {
        verbHP.disconnect();
        if (tier !== 'low') verbHP.connect(verb); // low tier: no reverb at all
      } catch (e) {}
    },
  };
  return graph;
}
