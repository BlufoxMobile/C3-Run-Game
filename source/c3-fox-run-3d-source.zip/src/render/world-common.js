// WORLD — shared helpers: world uniforms, deterministic hashing, bent-material factory,
// the scrolling instance Pool, and the inverse-ACES GLSL used by unlit painted layers.
// Owned by the WORLD agent.
import * as THREE from 'three';
import { applyBend } from '../core/bend.js';

/** dist is fed to shaders modulo this (every periodic spacing in the world divides it). */
export const SCROLL_MOD = 960;

/** Uniforms shared by every world material (same objects, so one write updates all). */
export const WU = {
  uTime: { value: 0 },
  uScroll: { value: 0 },          // sim.dist mod SCROLL_MOD  -> track s of a vertex = uScroll - worldZ
  uWind: { value: 1 },
  uNearFade: { value: 2.2 },
  uCamHigh: { value: 0 },        // 0 on the road, 1 when the camera rides high (roof / GIG BOOST): overheads dissolve early
  uCamPos: { value: new THREE.Vector3() },
};

// ------------------------------------------------------------------ hashing / rng
/** Deterministic 0..1 hash of a track position (1/8 m resolution) + salt. */
export function hs(s, salt = 0) {
  let h = (Math.round(s * 8) * 374761393 + salt * 668265263) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
/** Seeded PRNG (mulberry32) -> function returning 0..1. */
export function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const smooth = t => t * t * (3 - 2 * t);

// ------------------------------------------------------------------ materials
let keyN = 0;
/** Wrap a built-in material with an optional shader patch and the curved-world bend.
 *  `patch(shader, material)` runs in onBeforeCompile. Each patched material gets a unique
 *  program cache key (applyBend alone would make every patched material share one). */
export function bentMat(mat, patch, key) {
  if (patch) {
    const k = 'world:' + (key || 'p' + (++keyN));
    mat.onBeforeCompile = (sh) => patch(sh, mat);
    mat.customProgramCacheKey = () => k;
  }
  return applyBend(mat);
}

/** String-surgery helper for onBeforeCompile. */
export function patchShader(sh, o) {
  if (o.uniforms) Object.assign(sh.uniforms, o.uniforms);
  let vs = sh.vertexShader, fs = sh.fragmentShader;
  if (o.vPars) vs = vs.replace('#include <common>', '#include <common>\n' + o.vPars);
  if (o.vBegin) vs = vs.replace('#include <begin_vertex>', '#include <begin_vertex>\n' + o.vBegin);
  if (o.vProject) vs = vs.replace('#include <project_vertex>', o.vProject);
  if (o.vEnd) vs = vs.replace(/}\s*$/, o.vEnd + '\n}');
  if (o.fPars) fs = fs.replace('#include <common>', '#include <common>\n' + o.fPars);
  if (o.fMap) fs = fs.replace('#include <map_fragment>', o.fMap);
  if (o.fColor) fs = fs.replace('#include <color_fragment>', '#include <color_fragment>\n' + o.fColor);
  if (o.fAlpha) fs = fs.replace('#include <alphatest_fragment>', o.fAlpha);
  if (o.fRough) fs = fs.replace('#include <roughnessmap_fragment>', o.fRough);
  if (o.fEmissive) fs = fs.replace('#include <emissivemap_fragment>', '#include <emissivemap_fragment>\n' + o.fEmissive);
  if (o.fOut) fs = fs.replace('#include <opaque_fragment>', '#include <opaque_fragment>\n' + o.fOut);
  sh.vertexShader = vs; sh.fragmentShader = fs;
}

/** Overhead structures (gantries, overpasses, truss, L): fragments dither away when they are
 *  (a) within uNearFade of the camera, or (b) on the camera's flight path — in its height band,
 *  ahead of it and laterally in front of it (a camera riding up with the fox on a truck roof or
 *  in GIG BOOST flies through clean holes instead of clipping). Ordered (Bayer) dither. */
export const NEAR_FADE_VPARS = 'varying vec3 vOW;';
export const NEAR_FADE_VBEGIN = `
#ifdef USE_INSTANCING
vOW = (modelMatrix * instanceMatrix * vec4(transformed, 1.0)).xyz;
#else
vOW = (modelMatrix * vec4(transformed, 1.0)).xyz;
#endif`;
export const NEAR_FADE_PARS = `uniform float uNearFade; uniform float uCamHigh; uniform vec3 uCamPos; varying vec3 vOW;
float nfBayer2(vec2 a) { a = floor(a); return fract(dot(a, vec2(0.5, a.y * 0.75))); }
float nfBayer4(vec2 a) { return nfBayer2(0.5 * a) * 0.25 + nfBayer2(a); }`;
export const NEAR_FADE_GLSL = /* glsl */`
{
  float nfD = length(vViewPosition);
  float nfA = clamp((nfD - 0.6) / max(uNearFade - 0.6, 0.01), 0.0, 1.0);
  float nfDy = vOW.y - uCamPos.y;
  float nfBand = smoothstep(0.5, 0.15, nfDy) * smoothstep(-1.5, -0.9, nfDy);
  float nfAhead = 1.0 - smoothstep(4.0, 16.0, uCamPos.z - vOW.z);
  float nfLat = 1.0 - smoothstep(4.5, 7.5, abs(vOW.x - uCamPos.x));
  nfA = min(nfA, 1.0 - nfBand * nfAhead * nfLat);
  // riding high (truck roof / GIG BOOST): anything overhead dissolves well BEFORE the camera
  // reaches it, so a level sign can never fill the screen (Jeff's #1 complaint)
  float nfFly = uCamHigh * smoothstep(3.6, 4.6, vOW.y) * (1.0 - smoothstep(26.0, 46.0, uCamPos.z - vOW.z));
  nfA = min(nfA, 1.0 - nfFly);
  if (nfBayer4(gl_FragCoord.xy) >= nfA) discard;
}`;
/** Uniforms for NEAR_FADE_*; spread into a patch's uniforms. */
export const nearFadeUniforms = () => ({ uNearFade: WU.uNearFade, uCamHigh: WU.uCamHigh, uCamPos: WU.uCamPos });

/** GLSL: inverse of three's ACESFilmicToneMapping (so unlit painted layers display as painted).
 *  Needs uniform float uInvTM (1 = ACES active) and uniform float uTMExp (exposure). */
export const INV_ACES_GLSL = /* glsl */`
uniform float uInvTM;
uniform float uTMExp;
float invRRT(float y) {
  y = clamp(y, 0.0, 0.985);
  // solve y = (v(v+a)-b)/(v(c v+d)+e) for v
  float a = 0.0245786, b = 0.000090537, c = 0.983729, d = 0.4329510, e = 0.238081;
  float A = 1.0 - y * c, B = a - y * d, Cc = -b - y * e;
  return (-B + sqrt(max(B * B - 4.0 * A * Cc, 0.0))) / (2.0 * A);
}
vec3 invACES(vec3 c, float cap) {
  if (uInvTM < 0.5) return c / max(uTMExp, 0.001);
  const mat3 outInv = mat3( 0.643038, 0.059269, 0.005962,  0.311187, 0.931436, 0.063929,  0.045775, 0.009295, 0.930118 );
  const mat3 inInv  = mat3( 1.764741, -0.147028, -0.036337,  -0.675778, 1.160252, -0.162436,  -0.088963, -0.013224, 1.198773 );
  vec3 y = outInv * clamp(c, 0.0, 1.0);
  vec3 v = vec3(invRRT(y.r), invRRT(y.g), invRRT(y.b));
  vec3 x = inInv * v;
  return clamp(x * 0.6 / max(uTMExp, 0.001), 0.0, cap);
}`;

// ------------------------------------------------------------------ scrolling instance pool
const _m = new THREE.Matrix4();
/** An InstancedMesh whose instances live at track positions s. Each frame sync(dist) writes
 *  render z = z0 - (s - dist) straight into the matrices and recycles anything behind. */
export class Pool {
  constructor(geo, mat, cap, opts = {}) {
    this.cap = cap;
    this.attrs = {};
    for (const [k, size] of Object.entries(opts.attrs || {})) {
      const a = new THREE.InstancedBufferAttribute(new Float32Array(cap * size), size);
      a.setUsage(THREE.DynamicDrawUsage);
      geo.setAttribute(k, a); this.attrs[k] = a;
    }
    const m = this.mesh = new THREE.InstancedMesh(geo, mat, cap);
    m.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    if (opts.color) {
      m.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(cap * 3).fill(1), 3);
      m.instanceColor.setUsage(THREE.DynamicDrawUsage);
    }
    m.count = 0; m.frustumCulled = false; m.visible = false;
    if (opts.name) m.name = opts.name;
    if (opts.order !== undefined) m.renderOrder = opts.order;
    this.s = new Float64Array(cap);
    this.z0 = new Float32Array(cap);
    this.len = new Float32Array(cap);
    this.data = new Array(cap).fill(null);
    this.n = 0;
    this.dirty = true;
  }
  /** Add one instance. ry = yaw, sx/sy/sz scale. Returns index or -1 when full. */
  add(s, x, y, z0 = 0, ry = 0, sx = 1, sy = 1, sz = 1, len = 0) {
    if (this.n >= this.cap) return -1;
    const i = this.n++;
    this.setTransform(i, x, y, z0, ry, sx, sy, sz);
    this.s[i] = s; this.z0[i] = z0; this.len[i] = len; this.data[i] = null;
    this.dirty = true;
    return i;
  }
  setTransform(i, x, y, z0, ry, sx, sy, sz) {
    const a = this.mesh.instanceMatrix.array, o = i * 16;
    const c = Math.cos(ry), sn = Math.sin(ry);
    a[o] = c * sx; a[o + 1] = 0; a[o + 2] = -sn * sx; a[o + 3] = 0;
    a[o + 4] = 0; a[o + 5] = sy; a[o + 6] = 0; a[o + 7] = 0;
    a[o + 8] = sn * sz; a[o + 9] = 0; a[o + 10] = c * sz; a[o + 11] = 0;
    a[o + 12] = x; a[o + 13] = y; a[o + 14] = z0; a[o + 15] = 1;
    this.z0[i] = z0;
  }
  setMatrix(i, m4) { m4.toArray(this.mesh.instanceMatrix.array, i * 16); }
  attr(name, i, a, b, c, d) {
    const at = this.attrs[name], o = i * at.itemSize, arr = at.array;
    arr[o] = a; if (at.itemSize > 1) arr[o + 1] = b; if (at.itemSize > 2) arr[o + 2] = c; if (at.itemSize > 3) arr[o + 3] = d;
  }
  color(i, r, g, b) {
    const arr = this.mesh.instanceColor.array; arr[i * 3] = r; arr[i * 3 + 1] = g; arr[i * 3 + 2] = b;
  }
  colorC(i, col, k = 1) { this.color(i, col.r * k, col.g * k, col.b * k); }
  _copy(from, to) {
    const a = this.mesh.instanceMatrix.array;
    for (let k = 0; k < 16; k++) a[to * 16 + k] = a[from * 16 + k];
    if (this.mesh.instanceColor) {
      const c = this.mesh.instanceColor.array;
      c[to * 3] = c[from * 3]; c[to * 3 + 1] = c[from * 3 + 1]; c[to * 3 + 2] = c[from * 3 + 2];
    }
    for (const k in this.attrs) {
      const at = this.attrs[k], n = at.itemSize, arr = at.array;
      for (let q = 0; q < n; q++) arr[to * n + q] = arr[from * n + q];
    }
    this.s[to] = this.s[from]; this.z0[to] = this.z0[from]; this.len[to] = this.len[from]; this.data[to] = this.data[from];
  }
  remove(i) {
    const j = --this.n;
    if (i !== j) this._copy(j, i);
    this.data[j] = null;
    this.dirty = true;
  }
  clear() { this.n = 0; this.data.fill(null); this.dirty = true; this.mesh.count = 0; this.mesh.visible = false; }
  /** Recycle everything that is `behind` metres behind the player. */
  cull(dist, behind) {
    for (let i = 0; i < this.n;) {
      if (this.s[i] + this.len[i] < dist - behind) this.remove(i);
      else i++;
    }
  }
  /** Recycle behind the player, then position everything for this frame. */
  sync(dist, behind) {
    this.cull(dist, behind);
    const a = this.mesh.instanceMatrix.array;
    for (let i = 0; i < this.n; i++) a[i * 16 + 14] = this.z0[i] - (this.s[i] - dist);
    this.mesh.count = this.n;
    this.mesh.visible = this.n > 0;
    if (this.n > 0) {
      const im = this.mesh.instanceMatrix;
      im.clearUpdateRanges(); im.addUpdateRange(0, this.n * 16); im.needsUpdate = true;
      if (this.dirty) {
        const ic = this.mesh.instanceColor;
        if (ic) { ic.clearUpdateRanges(); ic.addUpdateRange(0, this.n * 3); ic.needsUpdate = true; }
        for (const k in this.attrs) { const at = this.attrs[k]; at.clearUpdateRanges(); at.addUpdateRange(0, this.n * at.itemSize); at.needsUpdate = true; }
        this.dirty = false;
      }
    }
  }
}

// ------------------------------------------------------------------ geometry helpers
/** Merge an array of BufferGeometries (position/normal/uv[/color]) into one non-indexed-safe geometry. */
export function mergeGeos(list) {
  const geos = list.map(g => (g.index ? g.toNonIndexed() : g));
  let n = 0; for (const g of geos) n += g.attributes.position.count;
  const hasCol = geos.some(g => g.attributes.color);
  const pos = new Float32Array(n * 3), nor = new Float32Array(n * 3), uv = new Float32Array(n * 2);
  const col = hasCol ? new Float32Array(n * 3) : null;
  let o = 0;
  for (const g of geos) {
    const c = g.attributes.position.count;
    pos.set(g.attributes.position.array, o * 3);
    if (g.attributes.normal) nor.set(g.attributes.normal.array, o * 3);
    if (g.attributes.uv) uv.set(g.attributes.uv.array, o * 2);
    if (col) {
      if (g.attributes.color) col.set(g.attributes.color.array, o * 3);
      else col.fill(1, o * 3, (o + c) * 3);
    }
    o += c;
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  out.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  out.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  if (col) out.setAttribute('color', new THREE.BufferAttribute(col, 3));
  return out;
}
/** Box from min/max corners, optional vertex colour. */
export function boxGeo(x0, y0, z0, x1, y1, z1, color, segZ = 1) {
  const g = new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0, 1, 1, segZ);
  g.translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
  if (color) paint(g, color);
  return g;
}
/** Paint a geometry with a flat vertex colour (THREE.Color or hex string). */
export function paint(g, color) {
  const c = color.isColor ? color : new THREE.Color(color);
  const n = g.attributes.position.count, arr = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { arr[i * 3] = c.r; arr[i * 3 + 1] = c.g; arr[i * 3 + 2] = c.b; }
  g.setAttribute('color', new THREE.BufferAttribute(arr, 3));
  return g;
}
/** A beam (box) between two points with a square cross-section of size w. */
export function beamGeo(a, b, w, color) {
  const dir = new THREE.Vector3().subVectors(b, a), len = dir.length();
  const g = new THREE.BoxGeometry(w, w, len);
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir.normalize());
  g.applyQuaternion(q);
  g.translate((a.x + b.x) / 2, (a.y + b.y) / 2, (a.z + b.z) / 2);
  if (color) paint(g, color);
  return g;
}
