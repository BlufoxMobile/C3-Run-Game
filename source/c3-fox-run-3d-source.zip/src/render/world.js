// WORLD — the environment the fox runs through: a road trip north from the Smokies to the
// Chicago Loop across 12 stages (src/data/themes.js), dawn -> night.
//
//   const world = createWorld(ctx);
//   world.setTheme(idx, instant)       // title screen / tests (instant also respawns content)
//   world.onEvent(ev, sim)             // 'levelUp' -> 3 s sky/fog/light crossfade + gantry gleam
//   world.update(sim, frame)           // every frame, after sim.step and event dispatch
//   world.setQuality('high'|'med'|'low')
//   world.sunDir   THREE.Vector3  unit direction TO the visible sun (or moon at night)
//   world.keyDir   THREE.Vector3  unit direction TO the key light used for shading
//   world.fogColor THREE.Color    the fog / horizon colour (linear working space, as designed)
//
// Structure (all world-*.js files are WORLD-agent helpers):
//   world-sky.js     sky dome (painted panorama sky/NN_* when it loads, procedural fallback)
//                    + far landform cards that ride the curved-world crest
//   world-ground.js  one bent ground mesh: asphalt, markings, rumble strips, shoulders, fields,
//                    second carriageway, light pools, level checker line, water zones + water
//   world-props.js   spawner + instanced props (sprites, lights, rails, buildings, corn, ...)
//   world-signs.js   level gantry, guide gantries, overpasses, mile signs
//   world-life.js    birds, mist, fireflies, traffic, the L, neon
//
// ASSUMPTIONS (see report): the sky panoramas are 21:9 with the painted horizon ~63.5 % down;
// they map to 150 deg of azimuth, mirrored beyond. setTheme(idx) drives the sky; update()
// follows sim.themeIdx (a mismatch crossfades, a non-level-up jump is applied instantly).
import * as THREE from 'three';
import { BEND } from '../core/bend.js';
import { THEMES } from '../data/themes.js';
import { WU, SCROLL_MOD, lerp, clamp, smooth } from './world-common.js';
import { createSky, createCard, KIND_ID } from './world-sky.js';
import { createGround } from './world-ground.js';
import { createProps, LOOKS } from './world-props.js';
import { createSigns } from './world-signs.js';
import { createLife } from './world-life.js';

const D2R = Math.PI / 180;
const TOD = {
  dawn:     { el: -1.5, sunAmt: 0.0, glow: 0.65, rays: 0.0, keyI: 2.2, hemiI: 1.8, stars: 0.35, fogN: 16, fogF: 185, tint: [0.84, 0.9, 1.0], night: 0.15, cloud: 0.55 },
  sunrise:  { el: 5.0,  sunAmt: 1.0, glow: 1.0,  rays: 0.9, keyI: 2.5, hemiI: 1.35, stars: 0.0,  fogN: 26, fogF: 220, tint: [1.0, 0.95, 0.88], night: 0.0, cloud: 0.6 },
  day:      { el: 48,   sunAmt: 1.0, glow: 0.3,  rays: 0.4, keyI: 2.9, hemiI: 1.55, stars: 0.0,  fogN: 40, fogF: 260, tint: [1, 1, 1], night: 0.0, cloud: 0.75 },
  golden:   { el: 8.0,  sunAmt: 1.0, glow: 1.0,  rays: 1.0, keyI: 2.7, hemiI: 1.35, stars: 0.0,  fogN: 30, fogF: 235, tint: [1.0, 0.95, 0.84], night: 0.0, cloud: 0.6 },
  dusk:     { el: 1.2,  sunAmt: 0.9, glow: 1.05, rays: 0.25, keyI: 1.8, hemiI: 1.15, stars: 0.5, fogN: 26, fogF: 215, tint: [0.86, 0.78, 0.86], night: 0.5, cloud: 0.5 },
  bluehour: { el: -9,   sunAmt: 0.0, glow: 0.22, rays: 0.0, keyI: 1.2, hemiI: 1.05, stars: 1.0,  fogN: 24, fogF: 205, tint: [0.4, 0.46, 0.66], night: 1.0, cloud: 0.45 },
  night:    { el: -20,  sunAmt: 0.0, glow: 0.0,  rays: 0.0, keyI: 0.75, hemiI: 0.85, stars: 1.0, fogN: 26, fogF: 215, tint: [0.34, 0.38, 0.56], night: 1.0, cloud: 0.2 },
};
const OVERRIDE = {
  0: { cloud: 0.35 },
  8: { sunAmt: 0.0, el: -4, night: 0.9, glow: 0.55, stars: 0.8, tint: [0.56, 0.44, 0.46] },
  9: { cloud: 0.5 },
  11: { cloud: 0.0 },
};
const CARD = {           // visible metres above the crest at the card's depth
  ridge: [62, 34], hills: [34, 20], plateau: [44, 26], flat: [9, 5], city: [46, 30], stacks: [52, 24],
};
const HERO = {
  0: { key: 'sprites/bg_smokies', w: 560, lift: -6, amt: 0.95 },
  1: { key: 'sprites/bg_smokies', w: 520, lift: -8, amt: 0.8 },
  9: { key: 'sprites/bg_chicago', w: 150, lift: -6, amt: 0.9, x: -70 },
  10: { key: 'sprites/bg_chicago', w: 330, lift: -10, amt: 1.0 },
};

// painted horizon (fraction of image height from the top) of each sky panorama — from the ART
// agent's assets/sky/sky.json; 0.635 when unknown.
// fog colour per painting = the sky just above its horizon (precomputed in assets/sky/sky.json;
// sampling it at runtime with getImageData forced a GPU readback + full decode = a visible hitch)
const SKY_FOG = ["#91a2c4", "#ddaa86", "#a7d8f1", "#b0defa", "#c8b898", "#c9eafa", "#f7d388", "#ec836c", "#a23e37", "#5d73bd", "#745473", "#c2826b"];
const SKY_HORIZON = [0.62, 0.57, 0.64, 0.60, 0.67, 0.67, 0.70, 0.65, 0.68, 0.63, 0.65, 0.88];

const C = (h) => new THREE.Color(h);
function mixC(a, b, t) { return a.clone().lerp(b, t); }

/** Build the static visual description of a stage. Colours are linear (THREE.Color). */
function buildVis(i) {
  const th = THEMES[i];
  const tod = Object.assign({}, TOD[th.tod] || TOD.day, OVERRIDE[i] || {});
  const L = LOOKS[i];
  const v = { idx: i, night: tod.night };
  v.top = C(th.skyT); v.mid = C(th.skyM); v.bot = C(th.skyB);
  v.fog = v.bot.clone();
  if (th.haze) v.fog.lerp(v.mid, 0.12);
  v.fogNear = tod.fogN * (th.fog ? 0.7 : 1) * (th.haze ? 0.75 : 1);
  v.fogFar = tod.fogF * (th.fog ? 0.85 : 1) * (th.haze ? 0.8 : 1);
  v.haze = th.haze ? 0.5 : th.fog ? 0.4 : 0.1;
  const az = (th.keyDir || 1) * (tod.el > 20 ? 34 : 21) * D2R, el = tod.el * D2R;
  v.sunDir = new THREE.Vector3(Math.sin(az) * Math.cos(el), Math.sin(el), -Math.cos(az) * Math.cos(el)).normalize();
  v.sunCol = C(th.sun || th.key);
  v.glowCol = mixC(C(th.sun || th.key), C(th.skyB), 0.35);
  v.sunAmt = tod.sunAmt * (th.sun ? 1 : 0.5); v.glow = tod.glow; v.rays = th.rays ? tod.rays : 0;
  v.cloudCol = C(th.clouds || th.skyM); v.cloudAmt = th.clouds ? tod.cloud : 0;
  v.stars = th.stars ? tod.stars : 0;
  v.moonAmt = th.moon ? 1 : 0;
  const maz = -(th.keyDir || 1) * 18 * D2R, mel = 20 * D2R;
  v.moonDir = new THREE.Vector3(Math.sin(maz) * Math.cos(mel), Math.sin(mel), -Math.cos(maz) * Math.cos(mel)).normalize();
  // lights
  v.hemiSky = mixC(C(th.amb), C(th.skyM), 0.35);
  v.hemiGround = C(th.grB).lerp(C('#5a5a5a'), 0.5).multiplyScalar(0.8);
  v.hemiI = tod.hemiI * (0.85 + th.ambA * 0.8);
  v.keyCol = C(th.key);
  v.keyI = tod.keyI * (0.8 + th.keyA * 0.6);
  const low = tod.el < 15;
  v.keyDir = new THREE.Vector3((th.keyDir || 1) * (low ? 0.85 : 0.5), low ? 0.62 : 1.0, 0.42).normalize();
  v.spriteTint = new THREE.Color().setRGB(...tod.tint);
  v.glass = mixC(v.mid, v.bot, 0.5).multiplyScalar(0.85);
  v.mistCol = mixC(v.bot, C('#ffffff'), 0.35);
  v.birdCol = mixC(C('#1b2030'), v.bot, 0.25);
  v.birds = th.birds ? 1 : 0;
  v.fireflies = th.fireflies ? 1 : 0;
  v.wind = (th.wind || 0.8);
  // ground
  v.grass = C(th.grB); v.grass2 = C(th.grT);
  v.road = C(th.rdB).lerp(C('#6d7078'), 0.3).multiplyScalar(0.8);
  v.verge = L.city ? C('#8b8d92') : mixC(C(th.rdB), C('#b0a184'), 0.55);
  if (L.city) { v.grass = C('#3a3d44'); v.grass2 = C('#2c2f36'); }
  if (L.bld && !L.city && (i === 8 || i === 10)) { v.grass.lerp(C('#3b3e3c'), 0.35); }
  v.lampCol = L.lights === 'white' ? new THREE.Color(0.75, 0.86, 1.0) : new THREE.Color(1.0, 0.62, 0.3);
  v.poolCol = L.lights === 'white' ? new THREE.Color(0.75, 0.86, 1.0) : new THREE.Color(1.0, 0.58, 0.22);
  v.style = new THREE.Vector4(L.city ? 1 : 0, L.road2 ? 1 : 0, L.mow || 0, th.shimmer ? 1 : 0);
  v.fx = new THREE.Vector4(L.lights && v.night > 0.3 ? 1 : 0, (i === 9 || i === 11) ? 0.7 : i === 10 ? 0.4 : 0, i === 9 ? 1 : 0, 0);
  v.skyHaze = mixC(v.bot, v.mid, 0.3);
  // water
  v.waterDeep = mixC(C(th.skyT), C('#0b3a4a'), 0.5).multiplyScalar(0.8);
  v.waterSky = mixC(v.bot, v.mid, 0.4);
  v.glint = v.night > 0.5 ? new THREE.Color(1.2, 1.15, 1.0) : C(th.sun || '#fff4dc').multiplyScalar(1.6);
  // landform cards
  const fk = th.fark, mk = th.midk;
  v.far = { kind: KIND_ID[fk] ?? 0, scale: (CARD[fk] || CARD.hills)[0], col: C(th.far), haze: mixC(v.bot, C(th.far), 0.25), rim: mixC(v.glowCol, v.bot, 0.3).multiplyScalar(tod.glow * 0.6) };
  v.midL = { kind: KIND_ID[mk] ?? 1, scale: (CARD[mk] || CARD.hills)[1], col: C(th.mid), haze: mixC(v.bot, C(th.mid), 0.5), rim: v.far.rim.clone().multiplyScalar(0.6) };
  if (fk === 'city' && i < 9) v.far.scale = 26;
  v.hero = HERO[i] || null;
  v.sky = th.sky;
  return v;
}
const VIS = THEMES.map((t, i) => buildVis(i));

// ---------------------------------------------------------------- JS mirror of the GLSL inverse ACES
function invRRT(y) {
  y = Math.min(Math.max(y, 0), 0.985);
  const a = 0.0245786, b = 0.000090537, c = 0.983729, d = 0.4329510, e = 0.238081;
  const A = 1 - y * c, B = a - y * d, Cc = -b - y * e;
  return (-B + Math.sqrt(Math.max(B * B - 4 * A * Cc, 0))) / (2 * A);
}
function invACES(col, out, exposure = 1, cap = 1.35) {
  const r = col.r, g = col.g, b = col.b;
  const yr = 0.643038 * r + 0.311187 * g + 0.045775 * b;
  const yg = 0.059269 * r + 0.931436 * g + 0.009295 * b;
  const yb = 0.005962 * r + 0.063929 * g + 0.930118 * b;
  const vr = invRRT(yr), vg = invRRT(yg), vb = invRRT(yb);
  const xr = 1.764741 * vr - 0.675778 * vg - 0.088963 * vb;
  const xg = -0.147028 * vr + 1.160252 * vg - 0.013224 * vb;
  const xb = -0.036337 * vr - 0.162436 * vg + 1.198773 * vb;
  const k = 0.6 / Math.max(exposure, 0.001);
  out.setRGB(clamp(xr * k, 0, cap), clamp(xg * k, 0, cap), clamp(xb * k, 0, cap));
  return out;
}

export function createWorld(ctx) {
  const { scene, camera, renderer, assets } = ctx;
  const root = new THREE.Group(); root.name = 'world';
  scene.add(root);

  // ---- lights & fog
  const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 1.2);
  const key = new THREE.DirectionalLight(0xffffff, 2.4);
  key.target.position.set(0, 0, 0);
  const sunLight = new THREE.DirectionalLight(0xffffff, 0);   // low sun / moon ahead: road glare + rim light
  scene.add(hemi, key, key.target, sunLight, sunLight.target);
  scene.fog = new THREE.Fog(0x888888, 30, 220);
  scene.background = null;

  // ---- track info shared with the spawners
  const track = {
    level: 1, lap: 1, levelStart: 0, nextLevelAt: 1e9, themeIdx: 0, nextThemeIdx: 1,
    themeAt(s) { return s >= this.nextLevelAt ? this.nextThemeIdx : this.themeIdx; },
    levelAt(s) {
      return s >= this.nextLevelAt
        ? { level: this.level + 1, start: this.nextLevelAt, end: null, theme: this.nextThemeIdx }
        : { level: this.level, start: this.levelStart, end: this.nextLevelAt, theme: this.themeIdx };
    },
  };
  const env = { track, visFor: i => VIS[i], themes: THEMES };

  // ---- subsystems
  const sky = createSky(renderer);
  scene.add(sky.mesh);
  const cardFar = createCard('world-card-far', 238, 1300, 260, 60, 1.7, sky.black);
  const cardMid = createCard('world-card-mid', 212, 1200, 160, 30, 4.3, sky.black);
  root.add(cardFar.mesh, cardMid.mesh);
  const ground = createGround(ctx);
  root.add(ground.mesh, ground.water);
  const props = createProps(ctx, root, env);
  const zoneU = [ground.U.uZone0.value, ground.U.uZone1.value];
  const signs = createSigns(ctx, root, env, props);
  const life = createLife(ctx, root, env, props);

  // ---- hero sprite textures
  const heroTex = {};
  for (const k of ['sprites/bg_smokies', 'sprites/bg_chicago']) {
    const t = assets.getTexture(k, { mipmaps: true });
    if (t) heroTex[k] = t;
  }
  const heroAspect = k => { const m = assets.SPRITE_META[k.replace('sprites/', '')]; return m ? m.w / m.h : 4; };

  // ---- sky panoramas (loaded lazily, current + next only)
  const pano = {};            // idx -> { tex, fog: Color } | 'loading' | 'none'
  let panosOn = true;
  function wantPano(i) {
    if (pano[i]) return;
    if (!panosOn) { pano[i] = 'none'; return; }
    const k = THEMES[i].sky;
    if (!k || !assets.hasAsset(k)) { pano[i] = 'none'; return; }
    pano[i] = 'loading';
    assets.getImage(k).then(img => {
      if (pano[i] !== 'loading') return;           // disabled / pruned meanwhile
      if (!img) { pano[i] = 'none'; return; }
      const t = new THREE.Texture(img);
      t.colorSpace = THREE.SRGBColorSpace; t.generateMipmaps = false;
      t.minFilter = THREE.LinearFilter; t.magFilter = THREE.LinearFilter;
      t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; t.needsUpdate = true;
      const fog = SKY_FOG[i] ? new THREE.Color().setStyle(SKY_FOG[i], THREE.SRGBColorSpace) : null;
      try { renderer.initTexture(t); } catch (e) { /* upload now, not mid-crossfade */ }
      pano[i] = { tex: t, fog };
    });
  }
  function panoOf(i) { const p = pano[i]; return p && p.tex ? p : null; }
  function prunePanos(a, b, c) {        // keep at most the fading-from, current and next skies on the GPU
    for (const k in pano) {
      const p = pano[k], i = +k;
      if (p && p.tex && i !== a && i !== b && i !== c) { p.tex.dispose(); delete pano[k]; }
    }
  }

  // ---- theme / crossfade state
  const cur = {             // interpolated visual state used by sky / lights / fog
    top: new THREE.Color(), mid: new THREE.Color(), bot: new THREE.Color(), fog: new THREE.Color(),
    sunDir: new THREE.Vector3(), sunCol: new THREE.Color(), glowCol: new THREE.Color(), cloudCol: new THREE.Color(),
    moonDir: new THREE.Vector3(), hemiSky: new THREE.Color(), hemiGround: new THREE.Color(), keyCol: new THREE.Color(),
    keyDir: new THREE.Vector3(), glass: new THREE.Color(), skyHaze: new THREE.Color(), birdCol: new THREE.Color(),
    waterDeep: new THREE.Color(), waterSky: new THREE.Color(), glint: new THREE.Color(),
    sunAmt: 0, glow: 0, rays: 0, cloudAmt: 0, stars: 0, moonAmt: 0, hemiI: 1, keyI: 1, fogNear: 30, fogFar: 200,
    haze: 0, night: 0, birds: 0, fireflies: 0, wind: 1,
  };
  const COLS = ['top', 'mid', 'bot', 'fog', 'sunCol', 'glowCol', 'cloudCol', 'hemiSky', 'hemiGround', 'keyCol', 'glass', 'skyHaze', 'birdCol', 'waterDeep', 'waterSky', 'glint'];
  const VECS = ['sunDir', 'moonDir', 'keyDir'];
  const NUMS = ['sunAmt', 'glow', 'rays', 'cloudAmt', 'stars', 'moonAmt', 'hemiI', 'keyI', 'fogNear', 'fogFar', 'haze', 'night', 'birds', 'fireflies', 'wind'];
  function copyVis(dst, src) {
    for (const k of COLS) dst[k].copy(src[k]);
    for (const k of VECS) dst[k].copy(src[k]);
    for (const k of NUMS) dst[k] = src[k];
  }
  const from = {}; for (const k of COLS) from[k] = new THREE.Color(); for (const k of VECS) from[k] = new THREE.Vector3();
  let skyIdx = -1, fromIdx = -1, fadeT = 1, FADE = 3.0;
  let pendingFlush = true;
  let lastDist = null, lastNext = null, lastNextTheme = null;

  function startFade(idx) {
    if (idx === skyIdx) return;
    copyVis(from, cur);
    fromIdx = skyIdx; skyIdx = idx; fadeT = 0;
    wantPano(idx);
  }
  function setTheme(idx, instant = true) {
    idx = ((idx % 12) + 12) % 12;
    if (instant) {
      skyIdx = idx; fromIdx = idx; fadeT = 1;
      copyVis(cur, VIS[idx]);
      wantPano(idx);
      pendingFlush = true;
    } else startFade(idx);
  }

  // ---- crest (curved-world horizon) measurement
  const _v = new THREE.Vector3(), _w = new THREE.Vector3(), _q = new THREE.Quaternion();
  function bentView(x, y, z, out) {
    out.set(x, y, z).applyMatrix4(camera.matrixWorldInverse);
    const u = BEND.uniforms, d = Math.max(0, -out.z - u.uBendStart.value);
    out.y -= u.uBendY.value * d * d; out.x += u.uBendX.value * d * d;
    return out;
  }
  function ndcY(view) { return _w.copy(view).applyMatrix4(camera.projectionMatrix).y; }
  let crestNdc = 0, crestElev = 0;
  function measureCrest() {
    const cx = camera.position.x, cz = camera.position.z;
    let best = -1e9, bestD = 60;
    for (let d = 10; d <= 176; d += 6) {
      bentView(cx, 0, cz - d, _v);
      if (_v.z >= -0.1) continue;
      const y = ndcY(_v);
      if (y > best) { best = y; bestD = d; }
    }
    crestNdc = best;
    bentView(cx, 0, cz - bestD, _v);
    _v.normalize();
    camera.getWorldQuaternion(_q);
    _v.applyQuaternion(_q);
    crestElev = Math.asin(clamp(_v.y, -1, 1));
  }
  function cardBaseY(depth, target) {
    const cx = camera.position.x, cz = camera.position.z - depth;
    const y0 = 0, y1 = 60;
    const n0 = ndcY(bentView(cx, y0, cz, _v)), n1 = ndcY(bentView(cx, y1, cz, _v));
    let y = y0 + (target - n0) / Math.max(n1 - n0, 1e-6) * (y1 - y0);
    const n2 = ndcY(bentView(cx, y, cz, _v));
    const slope = (n1 - n0) / (y1 - y0);
    y += (target - n2) / Math.max(slope, 1e-6);
    return y;
  }

  // ---- quality
  let tier = ctx.tier || 'high';
  function setQuality(t) {
    tier = t;
    const dens = t === 'low' ? 0.45 : t === 'med' ? 0.72 : 1;
    props.setDensity(dens); life.setDensity(dens); life.setExtras(t !== 'low');
    const oct = t === 'low' ? 2 : t === 'med' ? 3 : 4;
    if (sky.mat.defines.CLOUD_OCT !== oct) { sky.mat.defines.CLOUD_OCT = oct; sky.mat.needsUpdate = true; }
  }
  setQuality(tier);

  // ---- post-processing detection (fog colour must be pre-inverted when an OutputPass tone-maps later)
  let postMode = false;
  sky.mesh.onBeforeRender = (r) => { postMode = r.getRenderTarget() !== null; };

  // ---- public objects
  const sunDir = new THREE.Vector3(0, 0.3, -1).normalize();
  const keyDirOut = new THREE.Vector3(0.5, 1, 0.4).normalize();
  const fogColor = new THREE.Color();
  const tmpC = new THREE.Color(), _c2 = new THREE.Color();

  function applyGroundSlot(slot, v) {
    const U = ground.U;
    U['uGrass' + slot].value.copy(v.grass); U['uGrass2' + slot].value.copy(v.grass2);
    U['uRoad' + slot].value.copy(v.road); U['uVerge' + slot].value.copy(v.verge);
    U['uPoolCol' + slot].value.copy(v.poolCol);
    U['uStyle' + slot].value.copy(v.style); U['uFx' + slot].value.copy(v.fx);
  }
  function applyCardSlot(card, slot, v, layer) {
    const L = layer === 'far' ? v.far : v.midL, U = card.U;
    U['uKind' + slot].value = L.kind;
    U['uCol' + slot].value.copy(L.col); U['uHaze' + slot].value.copy(L.haze); U['uRim' + slot].value.copy(L.rim);
    U['uNight' + slot].value = v.night;
    // cards are the fallback for a missing painted panorama (the paintings carry their own landforms)
    const hasPano = !!panoOf(v.idx);
    const amt = hasPano ? 0 : 1;
    U['uAmt' + slot].value = amt;
    const hr = U['uHeroRect' + slot].value;
    if (layer === 'far' && v.hero && heroTex[v.hero.key] && !hasPano) {
      const w = v.hero.w, h = w / heroAspect(v.hero.key);
      hr.set((v.hero.x || 0) - w / 2, w, h, v.hero.amt);
      U['tHero' + slot].value = heroTex[v.hero.key];
      U.uScale.value = L.scale;
    } else hr.w = 0;
    return L.scale;
  }

  // ---------------------------------------------------------------- update
  function update(sim, frame) {
    const dt = Math.min(frame && frame.dt || 1 / 60, 0.1);
    const time = frame && frame.time !== undefined ? frame.time : (WU.uTime.value + dt);
    const dist = sim.dist;
    camera.updateMatrixWorld();

    // track info
    const nextAt = Number.isFinite(sim.nextLevelAt) ? sim.nextLevelAt : dist + 1e6;
    const themeNow = ((sim.themeIdx | 0) % 12 + 12) % 12;
    const themeNext = Number.isFinite(sim.nextThemeIdx) ? ((sim.nextThemeIdx | 0) % 12 + 12) % 12 : (themeNow + 1) % 12;
    track.level = sim.level || 1; track.lap = sim.lap || 1; track.levelStart = sim.levelStart || 0;
    track.nextLevelAt = nextAt; track.themeIdx = themeNow; track.nextThemeIdx = themeNext;

    // jumps / theme changes
    let flush = pendingFlush;
    if (lastDist !== null && (dist < lastDist - 0.5 || dist > lastDist + 250)) flush = true;
    if (themeNow !== skyIdx) {
      const natural = lastNext !== null && dist >= lastNext - 1 && themeNow === lastNextTheme;
      if (natural && !flush) startFade(themeNow);
      else { setTheme(themeNow, true); flush = true; }
    }
    if (flush) {
      pendingFlush = false;
      props.flush(dist); signs.flush(dist); life.flush(dist);
    }
    lastDist = dist; lastNext = nextAt; lastNextTheme = themeNext;

    // crossfade
    if (fadeT < 1) {
      fadeT = Math.min(1, fadeT + dt / FADE);
      const t = smooth(fadeT), to = VIS[skyIdx];
      for (const k of COLS) cur[k].copy(from[k]).lerp(to[k], t);
      for (const k of VECS) cur[k].copy(from[k]).lerp(to[k], t).normalize();
      for (const k of NUMS) cur[k] = lerp(from[k] ?? to[k], to[k], t);
      if (fadeT >= 1) fromIdx = skyIdx;
    }
    for (const k of NUMS) if (from[k] === undefined) from[k] = cur[k];
    wantPano(skyIdx); wantPano(themeNext);
    prunePanos(skyIdx, fromIdx, themeNext);

    // shared uniforms
    WU.uTime.value = time;
    WU.uScroll.value = ((dist % SCROLL_MOD) + SCROLL_MOD) % SCROLL_MOD;
    WU.uWind.value = cur.wind;

    // lights
    hemi.color.copy(cur.hemiSky); hemi.groundColor.copy(cur.hemiGround); hemi.intensity = cur.hemiI;
    key.color.copy(cur.keyCol); key.intensity = cur.keyI;
    key.position.copy(cur.keyDir).multiplyScalar(80).add(camera.position); key.target.position.copy(camera.position);
    key.target.updateMatrixWorld();
    sunDir.copy(cur.moonAmt > 0.5 && cur.sunAmt < 0.1 ? cur.moonDir : cur.sunDir);
    {
      const low = clamp(1 - (cur.sunDir.y - 0.05) / 0.3, 0, 1);
      const moon = cur.moonAmt * (1 - cur.sunAmt);
      sunLight.color.copy(cur.sunCol).lerp(_c2.setRGB(0.55, 0.65, 1.0), moon);
      sunLight.intensity = cur.sunAmt * low * 1.6 + moon * 0.35;
      sunLight.position.copy(sunDir).multiplyScalar(80).add(camera.position);
      sunLight.position.y = Math.max(sunLight.position.y, camera.position.y + 6);
      sunLight.target.position.copy(camera.position); sunLight.target.updateMatrixWorld();
    }
    keyDirOut.copy(cur.keyDir);

    // tone-mapping awareness
    const aces = renderer.toneMapping === THREE.ACESFilmicToneMapping ? 1 : 0;
    const exp = renderer.toneMappingExposure || 1;
    sky.U.uInvTM.value = aces; sky.U.uTMExp.value = exp;
    cardFar.U.uInvTM.value = cardMid.U.uInvTM.value = aces;
    cardFar.U.uTMExp.value = cardMid.U.uTMExp.value = exp;

    // horizon / crest
    measureCrest();
    const pA = panoOf(fromIdx), pB = panoOf(skyIdx);
    const U = sky.U;
    U.uTop.value.copy(cur.top); U.uMid.value.copy(cur.mid); U.uBot.value.copy(cur.bot);
    U.uSunCol.value.copy(cur.sunCol); U.uGlowCol.value.copy(cur.glowCol); U.uCloudCol.value.copy(cur.cloudCol);
    U.uSunDir.value.copy(cur.sunDir);
    U.uSunR.value.crossVectors(cur.sunDir, _w.set(0, 1, 0)).normalize();
    U.uSunU.value.crossVectors(U.uSunR.value, cur.sunDir).normalize();
    U.uMoonDir.value.copy(cur.moonDir);
    U.uSunAmt.value = cur.sunAmt; U.uGlow.value = cur.glow; U.uRays.value = cur.rays;
    U.uCloudAmt.value = cur.cloudAmt; U.uStars.value = cur.stars; U.uMoonAmt.value = cur.moonAmt;
    U.uTime.value = time; U.uCloudShift.value = -(dist * 0.0009) % 1000; U.uHaze.value = cur.haze;
    U.uHorizon.value = crestElev - 0.004;
    const mixT = fadeT < 1 ? smooth(fadeT) : 1;
    U.tPanoA.value = pA ? pA.tex : sky.black; U.uPanoA.value = pA ? 1 : 0;
    U.tPanoB.value = pB ? pB.tex : sky.black; U.uPanoB.value = pB ? 1 : 0;
    U.uPanoVA.value = 1 - (SKY_HORIZON[fromIdx >= 0 ? fromIdx : skyIdx] || 0.635);
    U.uPanoVB.value = 1 - (SKY_HORIZON[skyIdx] || 0.635);
    U.uMix.value = mixT;
    sky.mesh.position.copy(camera.position);

    // fog colour: painted-sky horizon when a panorama is up, else the gradient bottom
    fogColor.copy(cur.fog);
    const fa = pA && pA.fog ? tmpC.copy(pA.fog) : null;
    if (pB && pB.fog) fogColor.lerp(pB.fog, mixT * 0.85);
    if (fa && mixT < 1) fogColor.lerp(fa, (1 - mixT) * 0.85);
    if (postMode && aces) invACES(fogColor, scene.fog.color, exp, 1.35); else scene.fog.color.copy(fogColor);
    scene.fog.near = cur.fogNear; scene.fog.far = cur.fogFar;
    U.uBot.value.lerp(fogColor, 0.6);

    // far cards: slot A = from theme, B = to theme
    const vA = VIS[fromIdx >= 0 ? fromIdx : skyIdx], vB = VIS[skyIdx];
    for (let ci = 0; ci < 2; ci++) {
      const card = ci ? cardMid : cardFar, layer = ci ? 'mid' : 'far';
      const sA = applyCardSlot(card, 'A', vA, layer), sB = applyCardSlot(card, 'B', vB, layer);
      card.U.uScale.value = lerp(sA, sB, mixT);
      card.U.uMix.value = fromIdx === skyIdx ? 0 : mixT;
      if (fromIdx === skyIdx) { applyCardSlot(card, 'A', vB, layer); }
      card.U.uTime.value = time;
      const baseY = cardBaseY(card.depth, crestNdc) - (layer === 'far' ? 4 : 2.5);
      card.mesh.position.set(camera.position.x, baseY, camera.position.z - card.depth);
      card.mesh.visible = card.U.uAmtA.value > 0 || card.U.uAmtB.value > 0 || card.U.uHeroRectA.value.w > 0 || card.U.uHeroRectB.value.w > 0;
    }

    // ground: A = level we're in, B = beyond sim.nextLevelAt
    applyGroundSlot('A', VIS[themeNow]); applyGroundSlot('B', VIS[themeNext]);
    const splitZ = Math.max(-(nextAt - dist), -5000);
    ground.U.uSplitZ.value = splitZ;
    ground.U.uLevelZ.value = splitZ;
    ground.U.uLevelGlow.value = 0.6 + 0.4 * Math.sin(time * 6) + VIS[themeNext].night * 0.5;
    ground.U.uSkyHaze.value.copy(cur.skyHaze);
    // water zones
    let nz = 0;
    zoneU[0].set(0, 0, 0, 0); zoneU[1].set(0, 0, 0, 0);
    for (const z of props.zones) {
      if (nz >= 2 || z.s1 < dist - 40 || z.s0 > dist + 200) continue;
      zoneU[nz++].set(-(z.s0 - dist), -(z.s1 - dist), z.type === 'river' ? 1 : 2, z.seed);
    }
    ground.water.visible = nz > 0;
    const W = ground.WU;
    W.uWDeep.value.copy(cur.waterDeep); W.uWSky.value.copy(cur.waterSky); W.uWGlint.value.copy(cur.glint);
    const gdir = cur.moonAmt > 0.5 && cur.sunAmt < 0.1 ? cur.moonDir : cur.sunDir;
    W.uSunAz.value.set(gdir.x, gdir.z);
    W.uGlintAmt.value = cur.night > 0.5 ? (cur.moonAmt > 0.5 ? 0.8 : 0.4) : 1.0;

    // spawners + systems
    props.setVisual(cur);
    const spFar = props.farCur();
    life.cullAll(dist);
    props.update(dist, dt, time);
    // signs + life spawn on the same far steps
    const farNow = props.farCur();
    for (let s = lastSignS === null ? spFar : lastSignS; s < farNow; s += 2) { signs.step(s, dist); life.step(s, dist); }
    lastSignS = farNow;
    signs.update(sim, dist, dt, cur);
    life.update(sim, dist, dt, time, cur, camera);
    WU.uNearFade.value = 2.4;
    WU.uCamPos.value.copy(camera.position);
    { const py = sim && sim.player ? sim.player.y : 0; const hi = Math.min(1, Math.max(0, (py - 1.9) / 1.0)); WU.uCamHigh.value += (hi - WU.uCamHigh.value) * Math.min(1, dt * 6); }
  }
  let lastSignS = null;
  const origFlush = props.flush;
  props.flush = (d) => { origFlush(d); lastSignS = null; };

  function onEvent(ev, sim) {
    if (!ev) return;
    if (ev.type === 'levelUp') {
      if (typeof ev.themeIdx === 'number') startFade(ev.themeIdx);
      signs.onLevelUp();
    }
  }

  const world = {
    update, onEvent, setQuality, setTheme,
    sunDir, keyDir: keyDirOut, fogColor,
    root, sky, ground, props, signs, life, cards: [cardFar, cardMid],
    get tier() { return tier; },
    get crest() { return { ndc: crestNdc, elev: crestElev }; },
    get skyTheme() { return skyIdx; },
    /** Debug / low-memory: disable the painted panoramas (procedural sky + landform cards instead). */
    setPanoramas(on) {
      panosOn = !!on;
      for (const k in pano) { const p = pano[k]; if (p && p.tex) p.tex.dispose(); delete pano[k]; }
    },
    get panoStatus() { const o = {}; for (const k in pano) o[k] = typeof pano[k] === 'string' ? pano[k] : 'ready'; return o; },
  };
  setTheme(0, true);
  return world;
}
