// WORLD — the ground: one static bent mesh (x ±160 m, z +24..-172 m) whose shader draws the
// 3-lane asphalt (canvas grain texture), dashed lane lines, edge lines, red/white rumble strips,
// shoulders / sidewalks, a second carriageway, grass & fields, sodium light pools, the glowing
// level line, heat shimmer — everything scrolls by track s (uScroll - z), so motion is seamless.
// Theme A (current level) / B (beyond sim.nextLevelAt) are blended at uSplitZ.
// Water zones discard the terrain so the water plane below shows (river crossing, lakeshore).
// Owned by the WORLD agent.
import * as THREE from 'three';
import { WU, bentMat, patchShader } from './world-common.js';
import { asphaltTexture, groundTexture } from './world-tex.js';

const COMMON_GLSL = /* glsl */`
float gh11(float p) { return fract(sin(p * 127.1) * 43758.5453); }
float gn11(float x) { float i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(gh11(i), gh11(i + 1.0), f); }
float sqw(float x, float duty, float w) {
  w = max(w, 1e-4);
  float x0 = x - 0.5 * w, x1 = x + 0.5 * w;
  float i0 = floor(x0) * duty + min(fract(x0), duty);
  float i1 = floor(x1) * duty + min(fract(x1), duty);
  return clamp((i1 - i0) / w, 0.0, 1.0);
}
float band(float x, float c, float hw, float fw) { return clamp((hw - abs(x - c)) / max(fw, 1e-4) + 0.5, 0.0, 1.0); }
// water zone: x=zNear, y=zFar (render z), z=type (1 river both sides, 2 lake right), w=seed
float zoneW(vec4 zn, float X, float S, float Z) {
  if (zn.z < 0.5) return 0.0;
  float wob = (gn11(X * 0.09 + zn.w) - 0.5) * 7.0;
  float inside = step(zn.y + wob, Z) * step(Z, zn.x + wob);
  if (zn.z < 1.5) return inside * step(6.25, abs(X));
  return inside * step(13.0 + sin(S * 0.05) * 1.6 + sin(S * 0.13 + 1.0) * 0.7, X);
}
float zoneBank(vec4 zn, float X, float S, float Z) {   // 0..1 near a shoreline (for mud / sand)
  if (zn.z < 0.5) return 0.0;
  float wob = (gn11(X * 0.09 + zn.w) - 0.5) * 7.0;
  if (zn.z < 1.5) {
    float dz = min(abs(Z - (zn.x + wob)), abs(Z - (zn.y + wob)));
    float inside = step(zn.y + wob - 9.0, Z) * step(Z, zn.x + wob + 9.0);
    return inside * (1.0 - smoothstep(2.0, 9.0, dz)) * step(6.25, abs(X));
  }
  float inside = step(zn.y, Z) * step(Z, zn.x);
  float edge = 13.0 + sin(S * 0.05) * 1.6 + sin(S * 0.13 + 1.0) * 0.7;
  return inside * smoothstep(edge - 4.5, edge - 0.5, X);
}
`;

export function createGround(ctx) {
  const tAsph = asphaltTexture(), tGround = groundTexture();
  const V3 = () => ({ value: new THREE.Color() });
  const V4 = () => ({ value: new THREE.Vector4() });
  const U = {
    tAsph: { value: tAsph }, tGround: { value: tGround },
    uSplitZ: { value: -9999 },
    uGrassA: V3(), uGrassB: V3(), uGrass2A: V3(), uGrass2B: V3(), uRoadA: V3(), uRoadB: V3(),
    uVergeA: V3(), uVergeB: V3(), uPoolColA: V3(), uPoolColB: V3(), uLevelCol: { value: new THREE.Color('#2f9bff') }, uSkyHaze: V3(),
    uStyleA: V4(), uStyleB: V4(), uFxA: V4(), uFxB: V4(), uZone0: V4(), uZone1: V4(),
    uPoolP: { value: 32 }, uLevelZ: { value: -9999 }, uLevelGlow: { value: 1 },
    uTime: WU.uTime, uScroll: WU.uScroll,
  };
  const mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9, metalness: 0.0 });
  bentMat(mat, sh => patchShader(sh, {
    uniforms: U,
    vPars: 'uniform float uScroll;\nvarying vec3 vG;',
    vBegin: 'vG = vec3(position.x, uScroll - position.z, position.z);',
    fPars: `
uniform sampler2D tAsph, tGround;
uniform float uSplitZ, uPoolP, uLevelZ, uLevelGlow, uTime;
uniform vec3 uGrassA, uGrassB, uGrass2A, uGrass2B, uRoadA, uRoadB, uVergeA, uVergeB, uPoolColA, uPoolColB, uLevelCol, uSkyHaze;
uniform vec4 uStyleA, uStyleB, uFxA, uFxB, uZone0, uZone1;
varying vec3 vG;
${COMMON_GLSL}`,
    fMap: /* glsl */`
float X = vG.x, S = vG.y, Z = vG.z;
float ax = abs(X);
float fwx = fwidth(X), fws = fwidth(S);
float tB = clamp((uSplitZ - Z) / 5.0 + 0.5, 0.0, 1.0);
vec3 grassC = mix(uGrassA, uGrassB, tB), grass2 = mix(uGrass2A, uGrass2B, tB);
vec3 roadC = mix(uRoadA, uRoadB, tB), verge = mix(uVergeA, uVergeB, tB), poolC = mix(uPoolColA, uPoolColB, tB);
vec4 sty = mix(uStyleA, uStyleB, tB), fx = mix(uFxA, uFxB, tB);
if (zoneW(uZone0, X, S, Z) + zoneW(uZone1, X, S, Z) > 0.5) discard;
vec3 gt = texture2D(tGround, vec2(X, S) / 4.5).rgb;
vec3 gm = texture2D(tGround, vec2(X * 0.9 + 3.0, S) / 43.0).rgb;
// ---- terrain: two grass tones, blade detail, macro blotches, mow stripes
vec3 col = mix(grass2, grassC, smoothstep(0.2, 0.8, gm.g)) * (0.78 + 0.44 * gt.r);
col *= 1.0 + sty.z * 0.08 * (sqw(X / 4.0, 0.5, fwx / 4.0) * 2.0 - 1.0);
float gRough = 0.96;
// shoreline mud / beach sand
float bank = max(zoneBank(uZone0, X, S, Z), zoneBank(uZone1, X, S, Z));
col = mix(col, mix(vec3(0.16, 0.12, 0.08), vec3(0.62, 0.52, 0.36), fx.z) * (0.8 + 0.3 * gt.b), bank);
// ---- second carriageway (left, x -21.5..-13.5)
if (sty.y > 0.0) {
  float r2 = sty.y * band(X, -17.5, 4.0, fwx);
  vec3 road2 = roadC * texture2D(tAsph, vec2((X + 17.5) / 8.6 + 0.5, S / 16.0 + 0.37)).rgb;
  float d2 = band(X, -17.5, 0.07, fwx) * sqw(S / 9.0, 0.36, fws / 9.0);
  float e2 = band(X, -21.1, 0.08, fwx);
  float y2 = band(X, -13.9, 0.08, fwx);
  road2 = mix(road2, vec3(0.8), max(d2, e2) * 0.9);
  road2 = mix(road2, vec3(0.85, 0.6, 0.08), y2 * 0.9);
  float sh2 = sty.y * (band(X, -17.5, 4.8, fwx) - band(X, -17.5, 4.0, fwx));
  col = mix(col, verge * (0.7 + 0.4 * gt.b), sh2);
  col = mix(col, road2, r2);
}
// ---- shoulder (gravel) or city sidewalk
float inRiver = max(step(0.5, uZone0.z) * step(uZone0.z, 1.5) * step(uZone0.y - 12.0, Z) * step(Z, uZone0.x + 12.0),
                    step(0.5, uZone1.z) * step(uZone1.z, 1.5) * step(uZone1.y - 12.0, Z) * step(Z, uZone1.x + 12.0));
float sh = smoothstep(4.88, 4.96, ax) * (1.0 - smoothstep(5.6, 6.2 + gt.b * 0.6, ax));
col = mix(col, verge * (0.72 + 0.45 * gt.b), sh * (1.0 - sty.x));
if (sty.x > 0.0) {
  float sw = sty.x * smoothstep(4.88, 4.96, ax) * (1.0 - smoothstep(10.4, 10.6, ax));
  float jS = sqw(S / 1.8 + 0.5, 0.04, fws / 1.8), jX = sqw((ax - 4.95) / 1.8, 0.04, fwx / 1.8);
  vec3 slab = verge * (0.82 + 0.22 * gt.b) * (1.0 - 0.28 * max(jS, jX));
  slab = mix(slab, verge * 1.25, band(ax, 5.05, 0.12, fwx));             // curb top
  col = mix(col, slab, sw);
}
// bridge deck edge over the river
col = mix(col, verge * 1.1 * (0.8 + 0.2 * gt.b), inRiver * smoothstep(4.9, 5.0, ax) * step(ax, 6.3));
// ---- rumble strips 4.30..4.92 (red / white blocks, the old game's signature)
float rum = band(ax, 4.61, 0.31, fwx);
float rw = sqw(S / 2.4, 0.5, fws / 2.4);
vec3 rumC = mix(vec3(0.60, 0.045, 0.035), vec3(0.86, 0.86, 0.84), rw);
// ---- asphalt + markings
float onRoad = 1.0 - smoothstep(4.3 - fwx, 4.3 + fwx, ax);
vec3 asp = texture2D(tAsph, vec2(X / 8.6 + 0.5, S / 16.0)).rgb;
vec3 road = roadC * asp;
float dash = sqw(S / 9.0, 0.36, fws / 9.0);
float lane = band(ax, 1.3, 0.075, fwx) * dash;
float edge = band(ax, 4.02, 0.085, fwx);
float mark = max(lane, edge);
road = mix(road, vec3(0.88, 0.88, 0.84) * (0.8 + 0.2 * asp.r), mark * 0.93);
// level line: a painted checker band (Blufox blue / white) 1.6 m deep
float lz = Z - uLevelZ;
float chk = step(abs(lz + 0.8), 0.8) * onRoad;
float ck = mod(floor(X / 0.8) + floor((lz + 0.8) / 0.8), 2.0);
road = mix(road, mix(vec3(0.02, 0.18, 0.62), vec3(0.9), ck), chk * 0.92);
col = mix(col, rumC * (0.86 + 0.14 * asp.r), rum);
col = mix(col, road, onRoad);
// heat shimmer mirage near the crest
if (sty.w > 0.0) {
  float mir = sty.w * onRoad * smoothstep(-24.0, -52.0, Z);
  float wob = 0.5 + 0.5 * sin(S * 0.7 + uTime * 5.0 + X * 1.7) * sin(S * 0.23 - uTime * 3.1);
  col = mix(col, uSkyHaze, mir * (0.25 + 0.3 * wob));
}
gRough = mix(gRough, mix(0.8, 0.34, fx.y) - mark * 0.1, onRoad);
diffuseColor.rgb = col;
// light pools (street lights at s = n*P right side, n*P + P/2 left side)
vec3 gEmis = vec3(0.0);
if (fx.x > 0.0) {
  float P = uPoolP;
  float dR = (fract(S / P) - 0.5) * P, dL = (fract(S / P + 0.5) - 0.5) * P;
  float pR = exp(-dR * dR / 26.0) * exp(-(X - 3.6) * (X - 3.6) / 9.0);
  float pL = exp(-dL * dL / 26.0) * exp(-(X + 3.6) * (X + 3.6) / 9.0);
  float streak = fx.y * (exp(-dR * dR / 260.0) * exp(-(X - 3.4) * (X - 3.4) / 2.5) + exp(-dL * dL / 260.0) * exp(-(X + 3.4) * (X + 3.4) / 2.5));
  gEmis += poolC * col * (pR + pL) * fx.x * 4.0 + poolC * streak * fx.x * 0.12 * onRoad;
}
float lvl = exp(-lz * lz / 0.05) * (1.0 - smoothstep(4.6, 5.2, ax));
gEmis += uLevelCol * uLevelGlow * (lvl * 2.6 + exp(-lz * lz / 5.0) * 0.12 * onRoad);
`,
    fRough: 'float roughnessFactor = gRough;',
    fEmissive: 'totalEmissiveRadiance += gEmis;',
  }), 'ground');

  // grid: dense x near the road, 2 m rows along z
  const xs = [-160, -120, -90, -68, -52, -40, -31, -24, -21.5, -19.5, -17.5, -15.5, -13.5, -11, -8.5, -6.3, -5, -4.3, -2.6, -1.3, 0,
    1.3, 2.6, 4.3, 5, 6.3, 8.5, 11, 13.5, 16, 19, 24, 31, 40, 52, 68, 90, 120, 160];
  const zs = []; for (let z = 24; z >= -174; z -= 2) zs.push(z);
  const geo = gridGeo(xs, zs, 0);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false; mesh.name = 'world-ground';
  mesh.renderOrder = -10;

  // ---------------------------------------------------------------- water plane
  const WUx = {
    uWDeep: { value: new THREE.Color() }, uWSky: { value: new THREE.Color() }, uWGlint: { value: new THREE.Color() },
    uSunAz: { value: new THREE.Vector2(0, -1) }, uGlintAmt: { value: 1 },
    uZone0: U.uZone0, uZone1: U.uZone1,
    uTime: WU.uTime, uScroll: WU.uScroll,
  };
  const wmat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.22, metalness: 0.0 });
  bentMat(wmat, sh => patchShader(sh, {
    uniforms: WUx,
    vPars: 'uniform float uScroll;\nvarying vec3 vG;',
    vBegin: 'vG = vec3(position.x, uScroll - position.z, position.z);',
    fPars: `
uniform vec3 uWDeep, uWSky, uWGlint;
uniform vec2 uSunAz;
uniform float uGlintAmt, uTime;
uniform vec4 uZone0, uZone1;
varying vec3 vG;
${COMMON_GLSL}
float wn(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  float a = gh11(i.x + i.y * 57.0), b = gh11(i.x + 1.0 + i.y * 57.0), c = gh11(i.x + (i.y + 1.0) * 57.0), d = gh11(i.x + 1.0 + (i.y + 1.0) * 57.0);
  return mix(mix(a, b, f.x), mix(c, d, f.x), f.y); }`,
    fMap: /* glsl */`
float X = vG.x, S = vG.y, Z = vG.z;
float w1 = wn(vec2(X * 0.35 + uTime * 0.25, S * 0.9 - uTime * 0.6));
float w2 = wn(vec2(X * 1.1 - uTime * 0.4, S * 2.3 + uTime * 0.9));
float ripple = w1 * 0.6 + w2 * 0.4;
vec3 V = normalize(vViewPosition);
float fres = pow(1.0 - clamp(abs(V.y) * 0.0 + 0.0, 0.0, 1.0), 1.0);
float dist = length(vViewPosition);
float graze = smoothstep(10.0, 90.0, dist);
vec3 wc = mix(uWDeep, uWSky, 0.35 + 0.5 * graze);
wc *= 0.85 + 0.3 * ripple;
// foam at the shore / bridge piers
float edgeR = max(zoneBank(uZone0, X, S, Z), zoneBank(uZone1, X, S, Z));
diffuseColor.rgb = wc;
// glint path toward the sun / moon azimuth
vec2 hd = normalize(vec2(X, -Z + 8.0));
float path = pow(max(dot(hd, normalize(vec2(uSunAz.x, -uSunAz.y))), 0.0), 18.0);
float spark = smoothstep(0.78, 0.95, w2 * 0.5 + w1 * 0.5) * (0.35 + path * 1.6) * graze;
vec3 gEmis = uWGlint * spark * uGlintAmt + uWGlint * path * (0.12 + 0.22 * ripple) * uGlintAmt * graze;
`,
    fEmissive: 'totalEmissiveRadiance += gEmis;',
  }), 'water');
  const wgeo = gridGeo([-160, -60, -30, -14, -6, 0, 6, 14, 30, 60, 160], zs, -0.5);
  const water = new THREE.Mesh(wgeo, wmat);
  water.frustumCulled = false; water.visible = false; water.name = 'world-water';
  water.renderOrder = -11;

  return { mesh, mat, U, water, WU: WUx };
}

function gridGeo(xs, zs, y) {
  const nx = xs.length, nz = zs.length;
  const pos = new Float32Array(nx * nz * 3), nor = new Float32Array(nx * nz * 3), uv = new Float32Array(nx * nz * 2);
  for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {
    const k = j * nx + i;
    pos[k * 3] = xs[i]; pos[k * 3 + 1] = y; pos[k * 3 + 2] = zs[j];
    nor[k * 3 + 1] = 1;
    uv[k * 2] = i / (nx - 1); uv[k * 2 + 1] = j / (nz - 1);
  }
  const idx = [];
  for (let j = 0; j < nz - 1; j++) for (let i = 0; i < nx - 1; i++) {
    const a = j * nx + i, b = a + 1, c = a + nx, d = c + 1;
    idx.push(a, b, c, b, d, c);
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('normal', new THREE.BufferAttribute(nor, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex(idx);
  return g;
}
