// ACTORS · the hero fox. Painted sprite billboard (feet at z = 0) brought to life with
// run-rate-synced frames, lane lean + skew, squash & stretch, bob, blob shadow, afterimage
// ghosts, invulnerability blink, stumble wobble, death knock-back, and the power-up looks:
// purple fresnel SHIELD bubble + pips, MAGNET swirl, 2X gold sparkles, GIG BOOST cyan energy.
import * as THREE from 'three';
import { FOX_H } from '../core/constants.js';
import { Atlas, SpriteBatch, createSpriteMaterial, loadSheet } from './actors-sprites.js';
import { TAU, clamp, lerp, smooth, hash } from './actors-common.js';
import { BEND_GLSL_PARS, BEND_GLSL_APPLY } from '../core/bend.js';

const RUN_KEY = 'sprites/player_run', HIT_KEY = 'sprites/player_hit';
const JUMP_KEY = 'sprites/fox_jump_back', BOOST_KEY = 'sprites/fox_boost_back';
const HIST = 40;

function auraMaterial(kind) {
  return new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uAmt: { value: 0 }, uFlash: { value: 0 },
      uA: { value: new THREE.Color() }, uB: { value: new THREE.Color() } },
    defines: { [kind]: 1 },
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    vertexShader: /* glsl */`
      ${BEND_GLSL_PARS}
      varying vec3 vN; varying vec3 vV; varying vec3 vP;
      void main() {
        vP = position;
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vN = normalize(normalMatrix * normal);
        vV = -mvPosition.xyz;
        ${BEND_GLSL_APPLY}
        gl_Position = projectionMatrix * mvPosition;
      }`,
    fragmentShader: /* glsl */`
      uniform float uTime; uniform float uAmt; uniform float uFlash;
      uniform vec3 uA; uniform vec3 uB;
      varying vec3 vN; varying vec3 vV; varying vec3 vP;
      void main() {
        float ndv = abs(dot(normalize(vN), normalize(vV)));
        float rim = pow(1.0 - ndv, 2.4);
        vec3 col; float a;
      #ifdef SHIELD
        // hex-ish cells + rising scan bands; strength pips are separate meshes
        vec2 q = vec2(atan(vP.z, vP.x) * 3.0, vP.y * 5.2);
        vec2 r = abs(fract(q + vec2(0.5 * floor(q.y), 0.0)) - 0.5);
        float cell = smoothstep(0.42, 0.49, max(r.x, r.y));
        float band = pow(0.5 + 0.5 * sin(vP.y * 9.0 - uTime * 3.4), 8.0);
        float rim3 = pow(1.0 - ndv, 3.2);
        a = uAmt * (rim3 * 0.9 + cell * rim * 0.25 + band * rim * 0.3) + uFlash * (0.3 + rim);
        col = mix(uA, uB, rim3) * a;
      #endif
      #ifdef MAGNET
        float ang = atan(vP.z, vP.x);
        float s = fract(ang / 6.2831853 * 2.0 + vP.y * 0.45 - uTime * 1.1);
        float l1 = 1.0 - smoothstep(0.0, 0.035, abs(s - 0.25));
        float l2 = 1.0 - smoothstep(0.0, 0.035, abs(s - 0.75));
        float fadeY = smoothstep(-0.05, 0.3, vP.y) * (1.0 - smoothstep(1.2, 2.0, vP.y));
        a = uAmt * fadeY * (0.35 + 0.65 * rim);
        col = (uA * l1 + uB * l2) * a * 1.3 + (uA + uB) * 0.04 * rim * a;
      #endif
      #ifdef BOOST
        float flow = 0.5 + 0.5 * sin(vP.y * 7.0 + uTime * 16.0 + vP.x * 3.0);
        float r3 = pow(1.0 - ndv, 3.0);
        a = uAmt * r3 * (0.5 + 0.5 * flow) * 0.55;
        col = mix(uA, uB, r3 * flow) * a;
      #endif
        gl_FragColor = vec4(col, 1.0);
      }`,
  });
}

export function createFox(ctx, S) {
  const { THREE: _T, scene, assets } = ctx;
  const env = S.env;
  const atlas = new Atlas(2048);
  const mat = createSpriteMaterial({ mode: 'lit', alphaTest: 0.32, edge: true });
  mat.uniforms.uGlowLo.value = 0.94;
  const body = new SpriteBatch(mat, 1, 'fox');
  body.mesh.renderOrder = -2;
  const ghostMat = createSpriteMaterial({ mode: 'ghost' });
  const ghosts = new SpriteBatch(ghostMat, 10, 'foxGhosts');
  ghosts.mesh.renderOrder = -1;
  atlas.onChange(tex => {
    mat.uniforms.map.value = tex; ghostMat.uniforms.map.value = tex;
    mat.uniforms.uTexel.value.set(0.7 / atlas.W, 0.7 / atlas.H);   // thinner outline than the monsters'
  });
  scene.add(body.mesh, ghosts.mesh);

  // ---- sheets
  const sheets = { run: [], hit: [], jump: [], boost: [] };
  const pxPerM = { run: 0, hit: 0, jump: 0, boost: 0 };
  const runCell = { h: 512, units: 2.4 };
  function scaleFor(name, frames) {
    if (!frames.length) return;
    const contentMax = Math.max(...frames.map(f => f.by1 - f.by0));
    if (name === 'run') { pxPerM.run = contentMax / FOX_H; runCell.h = frames[0].cellH; runCell.units = frames[0].unitsHigh || 2.4; }
    else if (frames[0].unitsHigh && pxPerM.run) pxPerM[name] = pxPerM.run * (frames[0].cellH / frames[0].unitsHigh) / (runCell.h / runCell.units);
    else pxPerM[name] = contentMax / (FOX_H * (name === 'jump' ? 0.92 : 0.95));
  }
  const ready = loadSheet(assets, RUN_KEY, atlas).then(f => { sheets.run = f; scaleFor('run', f); });
  // the hit strip + the ART agent's chase-cam poses (used only if they exist and load), in sequence
  ready
    .then(() => loadSheet(assets, HIT_KEY, atlas, { pick: [1, 2, 3] })).then(f => { sheets.hit = f; scaleFor('hit', f); })
    .then(() => loadSheet(assets, JUMP_KEY, atlas)).then(f => { sheets.jump = f; scaleFor('jump', f); })
    .then(() => loadSheet(assets, BOOST_KEY, atlas)).then(f => { sheets.boost = f; scaleFor('boost', f); })
    .catch(e => console.warn('[actors] fox sheets', e && e.message))
    .then(() => atlas.seal());

  // ---- auras
  const auraGroup = new THREE.Group(); auraGroup.name = 'actors.foxAuras';
  scene.add(auraGroup);
  const sphere = new THREE.IcosahedronGeometry(1, 4);
  const shieldMat = auraMaterial('SHIELD');
  shieldMat.uniforms.uA.value.setRGB(0.55, 0.3, 1.6); shieldMat.uniforms.uB.value.setRGB(1.4, 1.0, 2.6);
  const shield = new THREE.Mesh(sphere, shieldMat); shield.renderOrder = 3; shield.visible = false; auraGroup.add(shield);
  const pipGeo = new THREE.OctahedronGeometry(0.12, 0);
  const pipMat = S.bend(new THREE.MeshBasicMaterial({ color: new THREE.Color(0.75, 0.35, 1.9) }));
  const pips = new THREE.InstancedMesh(pipGeo, pipMat, 3); pips.frustumCulled = false; pips.count = 0; auraGroup.add(pips);
  const cyl = new THREE.CylinderGeometry(1, 1, 2.2, 32, 6, true); cyl.translate(0, 1.1, 0);
  const magMat = auraMaterial('MAGNET');
  magMat.uniforms.uA.value.setRGB(2.2, 0.25, 0.3); magMat.uniforms.uB.value.setRGB(0.3, 0.7, 2.6);
  const magnet = new THREE.Mesh(cyl, magMat); magnet.renderOrder = 3; magnet.visible = false; auraGroup.add(magnet);
  const boostMat = auraMaterial('BOOST');
  boostMat.uniforms.uA.value.setRGB(0.1, 1.2, 2.0); boostMat.uniforms.uB.value.setRGB(1.2, 2.6, 3.0);
  const boostShell = new THREE.Mesh(sphere, boostMat); boostShell.renderOrder = 3; boostShell.visible = false; auraGroup.add(boostShell);

  // ---- state
  const st = {
    runPhase: 0, sq: 0, sqV: 0, bumpT: 0, bumpDir: 0, deathT: -1, hitY: 0, hitX: 0,
    flashT: 0, flashCol: new THREE.Color(1, 1, 1), shieldFlash: 0, shieldPop: 0,
    trail: 0, boostK: 0, magK: 0, x2K: 0, shieldK: 0, lastDist: 0, airT: 0,
    hist: Array.from({ length: HIST }, () => ({ x: 0, y: 0, f: null, w: 1, h: 1, roll: 0, shear: 0, pitch: 0 })), hi: 0,
  };
  let quality = { ghosts: 6, sparkles: 22 };
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _s = new THREE.Vector3(), _p = new THREE.Vector3();
  const pos = new THREE.Vector3();          // fox feet (render space) for other modules / FX

  function reset() {
    st.deathT = -1; st.sq = st.sqV = 0; st.bumpT = 0; st.flashT = 0; st.trail = 0; st.shieldPop = 0;
    for (const h of st.hist) h.f = null;
  }

  const ppmOf = name => pxPerM[name] || pxPerM.run || 290;

  function onEvent(ev, sim) {
    switch (ev.type) {
      case 'start': reset(); break;
      case 'jump': st.sqV += 5.2; st.trail = Math.max(st.trail, 0.5); break;
      case 'land': st.sqV -= clamp(3.2 + (ev.impact || 5) * 0.28, 3, 6.5); break;
      case 'bump': st.bumpT = 0.55; st.bumpDir = ev.dir || 0; st.flashT = 0.2; st.flashCol.setRGB(1, 0.35, 0.3); break;
      case 'lane': st.trail = 1; break;
      case 'powerup': { const P = ctx.POWERUPS && ctx.POWERUPS[ev.kind]; st.flashT = 0.32; st.flashCol.set(P ? P.c : '#ffffff'); break; }
      case 'tsheet': st.shieldFlash = 1; st.flashT = 0.25; st.flashCol.setRGB(0.8, 0.6, 1); break;
      case 'shieldBreak': st.shieldPop = 1; st.flashT = 0.3; st.flashCol.setRGB(0.85, 0.7, 1); break;
      case 'boostStart': st.flashT = 0.35; st.flashCol.setRGB(0.5, 0.95, 1); break;
      case 'hit': if (st.deathT < 0) { st.deathT = 0; st.hitY = sim.player.y; st.hitX = sim.player.x; } break;
    }
  }

  function update(sim, frame) {
    const dt = Math.min(frame.dt, 0.05), t = frame.time;
    const p = sim.player, cam = frame.camera;
    if (sim.dist < st.lastDist - 1) reset();
    st.lastDist = sim.dist;
    const dying = sim.mode === 'dying' || sim.mode === 'over' || p.anim === 'hit';
    if (dying && st.deathT < 0) { st.deathT = 0; st.hitY = p.y; st.hitX = p.x; }
    if (!dying && st.deathT >= 0 && sim.mode === 'play') st.deathT = -1;

    const boosting = sim.power.boost > 0 && !dying;
    st.boostK += ((boosting ? 1 : 0) - st.boostK) * (1 - Math.exp(-dt * 6));
    st.magK += ((sim.power.magnet > 0 && !dying ? 1 : 0) - st.magK) * (1 - Math.exp(-dt * 5));
    st.x2K += ((sim.power.x2 > 0 && !dying ? 1 : 0) - st.x2K) * (1 - Math.exp(-dt * 5));

    // squash & stretch spring (+ airborne stretch from vertical speed)
    const air = !p.grounded && !dying;
    st.airT = air ? st.airT + dt : 0;
    const airTarget = air && !boosting ? clamp(p.vy * 0.018, -0.07, 0.12) : 0;
    st.sqV += (-(st.sq - airTarget) * 170 - st.sqV * 13) * dt;
    st.sq = clamp(st.sq + st.sqV * dt, -0.32, 0.3);
    st.bumpT = Math.max(0, st.bumpT - dt);
    st.flashT = Math.max(0, st.flashT - dt);
    st.shieldFlash = Math.max(0, st.shieldFlash - dt * 1.6);
    st.shieldPop = Math.max(0, st.shieldPop - dt * 2.6);

    // ---------- pick the frame
    let name = 'run', f = null, pitch = -0.05, roll = 0, shear = 0, px = p.x, py = p.y, pz = 0;
    const run = sheets.run;
    if (dying && st.deathT >= 0) {
      st.deathT += dt;
      const d = st.deathT;
      const hit = sheets.hit;
      if (hit.length) { name = 'hit'; f = hit[d < 0.13 ? 0 : d < 0.42 ? Math.min(1, hit.length - 1) : hit.length - 1]; }
      else if (run.length) f = run[2];
      const k = clamp(d / 0.62, 0, 1);
      pz = 1.05 * (1 - (1 - k) * (1 - k));
      const ground = p.surfaceY || 0;
      py = lerp(st.hitY, ground, k) + (d < 0.62 ? Math.sin(Math.PI * k) * 0.95 : 0);
      px = st.hitX + (st.hitX > 0.5 ? 0.25 : st.hitX < -0.5 ? -0.25 : 0) * k;
      roll = d < 0.62 ? Math.sin(k * Math.PI) * 0.35 * (st.hitX >= 0 ? 1 : -1) : 0;
      pitch = 0;
    } else if (run.length) {
      const fps = clamp(14 * (sim.speed || 16) / 16, 10, 24);
      st.runPhase = (st.runPhase + dt * fps) % 6;
      if (boosting && sheets.boost.length) { name = 'boost'; f = sheets.boost[Math.floor(t * 10) % sheets.boost.length]; pitch = -0.04; }
      else if (boosting) { f = sheets.jump.length ? (name = 'jump', sheets.jump[0]) : run[2]; pitch = -0.38; }
      else if (air && sheets.jump.length) { name = 'jump'; const n = sheets.jump.length; f = sheets.jump[n > 1 ? clamp(Math.floor((0.5 - p.vy / 14) * n), 0, n - 1) : 0]; }
      else if (air) { f = run[p.vy > 0 ? 2 : 3]; }
      else f = run[Math.floor(st.runPhase) % run.length];
      roll = -p.lean * 0.21;
      shear = p.lean * 0.11;
      px += p.lean * 0.06;
      if (!air && !boosting) py += Math.pow(Math.abs(Math.sin(st.runPhase / 6 * TAU)), 1.6) * 0.045;   // run bob, 2 steps per cycle
      if (boosting) { py += Math.sin(t * 5.2) * 0.08; roll += Math.sin(t * 2.3) * 0.05; }
      const wob = Math.max(st.bumpT / 0.55, p.stumbleT > 0 ? Math.min(1, p.stumbleT / 0.6) : 0);
      if (wob > 0) { roll += Math.sin(t * 30) * 0.16 * wob; px += Math.sin(t * 23) * 0.06 * wob - st.bumpDir * 0.18 * wob * wob; }
    }

    // ---------- draw
    body.begin(); ghosts.begin();
    let alpha = 1, flash = 0;
    if (sim.invuln > 0 && !dying) { const b = Math.sin(t * 38) > 0; alpha = b ? 1 : 0.42; flash = b ? 0.2 : 0.45; }
    let tr = 0, tg = 0, tb = 0, ta = 0;
    if (st.flashT > 0) { const k = st.flashT / 0.45; tr = st.flashCol.r; tg = st.flashCol.g; tb = st.flashCol.b; ta = Math.min(0.55, k * 0.9); }
    if (dying && st.deathT < 0.16) { tr = 1; tg = 0.2; tb = 0.15; ta = 0.75 * (1 - st.deathT / 0.16); flash = 0.35 * (1 - st.deathT / 0.16); }
    if (boosting) { tr = 0.5; tg = 0.95; tb = 1.0; ta = Math.max(ta, 0.3 * st.boostK); }
    const yaw = Math.atan2(cam.position.x - px, cam.position.z - pz);
    let w = 1, h = 1;
    if (f) {
      const ppm = ppmOf(name);
      w = f.w / ppm * (1 - st.sq * 0.55); h = f.h / ppm * (1 + st.sq);
      // thin cool outline so the hero pops off busy scenery (stronger at night)
      body.edgeColor(0.55, 0.8, 1.0);
      body.push(f, px, py, pz, w, h, yaw, pitch, roll, shear, alpha, flash, 0.25, 0.14 + 0.24 * env.night, tr, tg, tb, ta);
    }
    pos.set(px, py, pz);

    // ghost trail (history ring)
    const hs = st.hist[st.hi]; st.hi = (st.hi + 1) % HIST;
    hs.x = px; hs.y = py; hs.f = f; hs.w = w; hs.h = h; hs.roll = roll; hs.shear = shear; hs.pitch = pitch; hs.name = name;
    const laneActive = p.laneT < 1 ? 1 : Math.min(1, Math.abs(p.lean) * 1.4);
    st.trail = Math.max(st.trail - dt * 4.5, laneActive, st.boostK);
    if (st.trail > 0.02 && !dying && f) {
      const n = quality.ghosts;
      const boostCol = st.boostK;
      for (let i = 1; i <= n; i++) {
        const back = boosting ? i * 3 : i;
        const g = st.hist[(st.hi - 1 - back + HIST * 4) % HIST];
        if (!g.f) continue;
        const k = 1 - i / (n + 1);
        const a = st.trail * k * (0.34 - 0.12 * boostCol);
        const cr = lerp(0.35, 0.25, boostCol), cg = lerp(0.62, 1.0, boostCol), cb = lerp(1.25, 1.35, boostCol);
        const gold = st.x2K * (1 - boostCol);
        ghosts.push(g.f, g.x, g.y - (boosting ? i * 0.05 : 0), -0.06 - i * 0.05, g.w * (1 + i * 0.015), g.h, yaw, g.pitch, g.roll, g.shear,
          a, 0, 0, 0, lerp(cr, 1.3, gold), lerp(cg, 0.95, gold), lerp(cb, 0.3, gold), 1);
      }
    }
    body.end(); ghosts.end();

    // sprite lighting from the theme
    const u = mat.uniforms;
    u.uLight.value.copy(env.spriteLight).multiplyScalar(1.06);
    u.uRim.value.copy(env.rim).multiplyScalar(1.0);
    u.uRimOff.value.set(env.keySide * 3.2 / atlas.W, 1.2 / Math.max(1, atlas.H));

    // ---------- shadow on whatever is under the fox
    const surf = dying ? (p.surfaceY || 0) : (p.surfaceY || 0);
    const hgt = Math.max(0, py - surf);
    const sk = 1 - clamp(hgt / 5.5, 0, 0.72);
    S.shadows.push(px, surf, pz + 0.05, 1.25 * sk, 0.9 * sk, 0, 0, 0, 0, 0.62 * (1 - clamp(hgt / 7, 0, 0.75)), 'blob', 0.03);
    if (st.deathT > 0.5) S.shadows.push(px, surf, pz - 0.2, 2.2, 1.2, 0, 0, 0, 0, 0.45, 'blob', 0.035);

    // ---------- auras
    const cx = px, cy = py + 0.92, cz = pz;
    // shield
    const sh = dying ? 0 : sim.shield;
    const shieldTarget = sh > 0 ? 0.3 + 0.1 * sh : 0;
    st.shieldK += (shieldTarget - st.shieldK) * (1 - Math.exp(-dt * (dying ? 16 : 6)));
    const pop = st.shieldPop;
    shield.visible = st.shieldK > 0.01 || pop > 0 || st.shieldFlash > 0;
    if (shield.visible) {
      const r = 1.0 * (1 + (1 - pop) * pop * 1.8) * (1 + 0.02 * Math.sin(t * 4));
      shield.position.set(cx, cy, cz); shield.scale.set(r * 0.9, r * 1.08, r * 0.9);
      shieldMat.uniforms.uTime.value = t;
      shieldMat.uniforms.uAmt.value = st.shieldK * (0.55 + 0.15 * Math.sin(t * 3)) * (boosting ? 0.4 : 1);
      shieldMat.uniforms.uFlash.value = st.shieldFlash * 0.7 + pop * 1.4;
    }
    pips.count = sh;
    for (let i = 0; i < sh; i++) {
      const a = t * 2.2 + i * TAU / Math.max(1, sh);
      _p.set(cx + Math.cos(a) * 0.5, py + h * 0.98 + 0.28 + Math.sin(t * 3 + i) * 0.04, cz + Math.sin(a) * 0.5);
      _q.setFromAxisAngle(_s.set(0, 1, 0), t * 3 + i);
      _m.compose(_p, _q, _s.set(1, 1.5, 1).multiplyScalar(1 + st.shieldFlash * 0.6));
      pips.setMatrixAt(i, _m);
    }
    if (sh) pips.instanceMatrix.needsUpdate = true;
    // magnet swirl
    magnet.visible = st.magK > 0.01;
    if (magnet.visible) {
      magnet.position.set(cx, py - 0.05, cz); magnet.scale.set(0.95, 1, 0.95);
      magMat.uniforms.uTime.value = t; magMat.uniforms.uAmt.value = st.magK * (0.8 + 0.2 * Math.sin(t * 7));
    }
    // boost shell + glow + jet
    boostShell.visible = st.boostK > 0.01;
    if (boostShell.visible) {
      boostShell.position.set(cx, cy, cz + 0.1); boostShell.scale.set(0.95, 1.15, 1.5);
      boostMat.uniforms.uTime.value = t; boostMat.uniforms.uAmt.value = st.boostK;
    }
    const G = S.glows;
    if (st.boostK > 0.01) {
      const k = st.boostK;
      G.push(cx, cy, cz - 0.3, 2.6, 0.1, 0.7, 1.3, 0.22 * k, 'glow');
      // jet flames under the sneakers (the boost sprite paints its own jets; these add bloom + flicker)
      for (let i = 0; i < 2; i++) {
        const fl = 0.75 + 0.25 * Math.sin(t * 40 + i * 2.1);
        G.push(cx + (i ? 0.16 : -0.16), py - 0.05, cz - 0.05, 0.55 * fl, 0.6, 1.6, 2.2, 0.7 * k, 'glow');
      }
      // faint contrails streaming back toward the camera from each sneaker
      for (let i = 0; i < 2; i++) S.additive.push(cx + (i ? 0.17 : -0.17), py - 0.1, cz + 2.6, 0.26, 5.0, 0, 0.15 * k, 0.7 * k, 1.0 * k, 1, 'trail', 0);
    }
    if (st.x2K > 0.01) {
      const n = quality.sparkles, k = st.x2K;
      for (let i = 0; i < n; i++) {
        const ph = (t * 0.55 + hash(i) ) % 1;
        const a = hash(i + 7) * TAU + t * (1.2 + hash(i + 3));
        const r = 0.55 + 0.3 * hash(i + 11);
        const tw = 0.5 + 0.5 * Math.sin(t * 9 + i * 1.7);
        G.push(cx + Math.cos(a) * r, py + ph * 2.2, cz + Math.sin(a) * r, 0.16 + 0.22 * tw, 2.6, 1.9, 0.5, k * (1 - ph) * (0.5 + 0.5 * tw), 'star');
      }
      S.additive.push(cx, surf, cz, 1.9, 1.9, 0, 0.9 * k, 0.6 * k, 0.1 * k, 1, 'glow', 0.04);
    }
    if (st.magK > 0.01) {
      for (let i = 0; i < 8; i++) {
        const a = t * 3.2 + i * TAU / 8;
        const red = i % 2 === 0;
        G.push(cx + Math.cos(a) * 0.98, py + 0.2 + ((t * 0.9 + i * 0.37) % 1) * 1.9, cz + Math.sin(a) * 0.98, 0.22,
          red ? 2.4 : 0.4, red ? 0.4 : 0.9, red ? 0.4 : 2.6, 0.8 * st.magK, 'star');
      }
    }
    if (st.shieldFlash > 0 || pop > 0) G.push(cx, cy, cz, 2.8 + pop * 2, 0.8, 0.5, 1.6, 0.5 * Math.max(st.shieldFlash, pop), 'ring');
  }

  function setQuality(tier) {
    quality = tier === 'low' ? { ghosts: 2, sparkles: 8 } : tier === 'med' ? { ghosts: 4, sparkles: 14 } : { ghosts: 6, sparkles: 22 };
  }

  return { update, onEvent, setQuality, pos, sheets, ready, atlas, body, get state() { return st; } };
}
