// WORLD — overhead highway furniture: the LEVEL GANTRY at sim.nextLevelAt ("NOW ENTERING" /
// next stage name / "<region> · LEVEL n", Interstate-green reflective panel with a Blufox-blue
// level tab, lit at night, gleams as you pass under it), plain sign gantries and overpasses for
// rhythm, and roadside mile signs counting down to Chicago. Panel bottom edge is 5.7 m, so it
// never hides the lanes. Owned by the WORLD agent.
import * as THREE from 'three';
import { THEMES } from '../data/themes.js';
import { WU, bentMat, patchShader, mergeGeos, boxGeo, beamGeo, lerp, hs, NEAR_FADE_GLSL, NEAR_FADE_PARS, NEAR_FADE_VPARS, NEAR_FADE_VBEGIN, nearFadeUniforms } from './world-common.js';
import { makeCanvas, canvasTex } from './world-tex.js';
import { LOOKS, BEHIND } from './world-props.js';

const FONT = `'Avenir Next Condensed','Roboto Condensed','sans-serif-condensed','Arial Narrow','Helvetica Neue',Helvetica,Arial,'DejaVu Sans Condensed',sans-serif`;
const SHIELDS = ['40', '75', '75', '75', '64', '65', '65', '65', '90', '41', '94', 'C3'];
const CITIES = [['KNOXVILLE', 0], ['LEXINGTON', 150], ['LOUISVILLE', 240], ['INDIANAPOLIS', 330], ['GARY', 410], ['CHICAGO', 530]];
const TOTAL_MI = 530;
export const milesToChicago = (level, frac = 0) => Math.max(0, Math.round(TOTAL_MI * (1 - (((level - 1) % 12) + frac) / 12)));

const PANEL_W = 13.0, PANEL_H = 5.6, PANEL_Y0 = 6.7;     // tab bottom 6.7 m (clears a boosting fox), main panel 7.9..12.3
const TEX_W = 2048, TEX_H = Math.round(TEX_W * PANEL_H / PANEL_W);
const MAIN_FR = 4.4 / 5.6;

// ---------------------------------------------------------------- drawing helpers
function rr(g, x, y, w, h, r) {
  g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath();
}
function fitFont(g, txt, size, maxW, weight = 700) {
  // text width scales linearly with font size: measure once, scale, done (the old 4 px
  // step-down loop re-parsed the font dozens of times and hitched every gantry spawn)
  g.font = `${weight} ${size}px ${FONT}`;
  const w = g.measureText(txt).width;
  if (w <= maxW) return size;
  const s = Math.max(20, Math.floor(size * maxW / w));
  g.font = `${weight} ${s}px ${FONT}`;
  return s;
}
function spaced(g, txt, cx, y, sp) {
  const chars = [...txt]; const ws = chars.map(c => g.measureText(c).width);
  const tot = ws.reduce((a, b) => a + b, 0) + sp * (chars.length - 1);
  let x = cx - tot / 2; g.textAlign = 'left';
  chars.forEach((c, i) => { g.fillText(c, x, y); x += ws[i] + sp; });
  g.textAlign = 'center';
}
function greenPanel(g, x, y, w, h, r) {
  const gr = g.createLinearGradient(0, y, 0, y + h);
  gr.addColorStop(0, '#12824c'); gr.addColorStop(0.5, '#0c6e3f'); gr.addColorStop(1, '#095c34');
  rr(g, x, y, w, h, r); g.fillStyle = gr; g.fill();
  // retroreflective micro-prism sparkle
  g.save(); rr(g, x, y, w, h, r); g.clip();
  const R = (a => () => (a = (a * 16807) % 2147483647) / 2147483647)(12345);
  g.fillStyle = 'rgba(255,255,255,0.035)';
  for (let i = 0; i < w * h / 90; i++) g.fillRect(x + R() * w, y + R() * h, 2, 2);
  const sh = g.createLinearGradient(x, y, x + w, y + h);
  sh.addColorStop(0, 'rgba(255,255,255,0.10)'); sh.addColorStop(0.35, 'rgba(255,255,255,0)'); sh.addColorStop(1, 'rgba(0,0,0,0.10)');
  g.fillStyle = sh; g.fillRect(x, y, w, h);
  g.restore();
  const b = Math.max(8, h * 0.022);
  rr(g, x + b * 1.6, y + b * 1.6, w - b * 3.2, h - b * 3.2, r * 0.7); g.lineWidth = b; g.strokeStyle = '#f4f6f2'; g.stroke();
}
function shield(g, cx, cy, h, label) {
  const w = h * 0.92;
  const x0 = cx - w / 2, y0 = cy - h / 2;
  const path = () => {
    g.beginPath();
    g.moveTo(x0, y0 + h * 0.08);
    g.quadraticCurveTo(x0 + w * 0.25, y0 - h * 0.04, x0 + w * 0.5, y0 + h * 0.06);
    g.quadraticCurveTo(x0 + w * 0.75, y0 - h * 0.04, x0 + w, y0 + h * 0.08);
    g.lineTo(x0 + w, y0 + h * 0.5);
    g.quadraticCurveTo(x0 + w, y0 + h * 0.86, x0 + w * 0.5, y0 + h);
    g.quadraticCurveTo(x0, y0 + h * 0.86, x0, y0 + h * 0.5);
    g.closePath();
  };
  if (label === 'C3') {       // Blufox badge for the Loop
    rr(g, x0, y0 + h * 0.05, w, h * 0.9, h * 0.16); g.fillStyle = '#1565d8'; g.fill();
    g.lineWidth = h * 0.05; g.strokeStyle = '#fff'; g.stroke();
    g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = `800 ${h * 0.5}px ${FONT}`; g.fillText('C³', cx, cy + h * 0.03);
    return;
  }
  if (label === '41') {       // US route shield (Lake Shore Drive)
    path(); g.fillStyle = '#fff'; g.fill(); g.lineWidth = h * 0.045; g.strokeStyle = '#111'; g.stroke();
    g.fillStyle = '#111'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = `800 ${h * 0.5}px ${FONT}`; g.fillText('41', cx, cy + h * 0.06);
    return;
  }
  path(); g.fillStyle = '#1a3f9c'; g.fill();
  g.save(); path(); g.clip(); g.fillStyle = '#c8202c'; g.fillRect(x0, y0 - 10, w, h * 0.3 + 10);
  g.fillStyle = '#fff'; g.fillRect(x0, y0 + h * 0.3, w, h * 0.025); g.restore();
  path(); g.lineWidth = h * 0.045; g.strokeStyle = '#fff'; g.stroke();
  g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = `700 ${h * 0.1}px ${FONT}`; g.fillText('INTERSTATE', cx, y0 + h * 0.18);
  g.font = `800 ${h * 0.46}px ${FONT}`; g.fillText(label, cx, cy + h * 0.14);
}

/** The level sign: NOW ENTERING / NAME / REGION + blue LEVEL tab. */
export function drawLevelSign(c, info) {
  const g = c.getContext('2d'), W = c.width, H = c.height;
  g.clearRect(0, 0, W, H);
  const mainH = Math.round(H * MAIN_FR);
  // tab first (behind the main panel's bottom edge)
  const tabTxt = (info.lap > 1 ? `LAP ${info.lap} · ` : '') + `LEVEL ${info.level}`;
  g.font = `800 ${H * 0.15}px ${FONT}`;
  const tw = Math.min(W * 0.62, Math.max(W * 0.3, g.measureText(tabTxt).width + H * 0.36));
  const tx = W / 2 - tw / 2;
  const tg = g.createLinearGradient(0, mainH - 20, 0, H);
  tg.addColorStop(0, '#1d74ec'); tg.addColorStop(1, '#0d4fb4');
  rr(g, tx, mainH - 30, tw, H - mainH + 24, 26); g.fillStyle = tg; g.fill();
  rr(g, tx + 14, mainH - 16, tw - 28, H - mainH - 4, 18); g.lineWidth = 10; g.strokeStyle = '#fff'; g.stroke();
  g.fillStyle = '#fff'; g.textAlign = 'center'; g.textBaseline = 'middle';
  fitFont(g, tabTxt, H * 0.15, tw - 70, 800);
  g.fillText(tabTxt, W / 2, mainH + (H - mainH) * 0.44);
  // main panel
  greenPanel(g, 6, 6, W - 12, mainH - 12, 40);
  const shH = mainH * 0.62, shX = 70 + shH * 0.46;
  shield(g, shX, mainH * 0.5, shH, info.shield);
  const cx = W / 2 + shH * 0.34, maxW = W - shX * 2 - 40;
  g.fillStyle = '#f4f6f2'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = `700 ${mainH * 0.12}px ${FONT}`;
  spaced(g, 'NOW ENTERING', cx, mainH * 0.2, mainH * 0.03);
  fitFont(g, info.name, mainH * 0.36, maxW, 800);
  g.fillText(info.name, cx, mainH * 0.52);
  fitFont(g, info.region, mainH * 0.14, maxW, 700);
  g.fillText(info.region, cx, mainH * 0.8);
}

function drawMileSign(c, rows) {
  const g = c.getContext('2d'), W = c.width, H = c.height;
  g.clearRect(0, 0, W, H);
  greenPanel(g, 4, 4, W - 8, H - 8, 26);
  g.fillStyle = '#f4f6f2'; g.textBaseline = 'middle';
  rows.forEach(([name, mi], k) => {
    const y = H * (rows.length === 1 ? 0.5 : 0.31 + k * 0.4);
    g.font = `700 ${H * 0.25}px ${FONT}`; g.textAlign = 'left';
    const nameMax = W * 0.62;
    fitFont(g, name, H * 0.25, nameMax, 700); g.fillText(name, W * 0.08, y);
    g.font = `800 ${H * 0.27}px ${FONT}`; g.textAlign = 'right';
    g.fillText(String(mi), W * 0.92, y);
  });
}

function drawGuideSign(c, v) {
  const g = c.getContext('2d'), W = c.width, H = c.height;
  g.clearRect(0, 0, W, H);
  if (v.blue) {
    const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#1d74ec'); gr.addColorStop(1, '#0d4fb4');
    rr(g, 4, 4, W - 8, H - 8, 26); g.fillStyle = gr; g.fill();
    rr(g, 20, 20, W - 40, H - 40, 18); g.lineWidth = 9; g.strokeStyle = '#fff'; g.stroke();
  } else greenPanel(g, 4, 4, W - 8, H - 8, 26);
  g.fillStyle = '#f4f6f2'; g.textAlign = 'center'; g.textBaseline = 'middle';
  let cx = W / 2;
  if (v.shield) { shield(g, H * 0.5, H * 0.46, H * 0.62, v.shield); cx = W / 2 + H * 0.3; }
  fitFont(g, v.top, H * 0.26, W - H * 1.2, 800); g.fillText(v.top, cx, H * 0.33);
  fitFont(g, v.bot, H * 0.2, W - H * 1.2, 700); g.fillText(v.bot, cx, H * 0.66);
  if (v.arrow) {
    g.font = `800 ${H * 0.2}px ${FONT}`; g.fillText('↓   ↓', cx, H * 0.86);
  }
}
const GUIDES = [
  [{ shield: '40', top: 'KNOXVILLE', bot: 'NORTH  I-75', arrow: 1 }, { blue: 1, top: 'BLUFOX MOBILE', bot: 'NEXT EXIT →' }],
  [{ shield: '75', top: 'LEXINGTON', bot: 'CINCINNATI', arrow: 1 }, { blue: 1, top: 'C³ · SALES', bot: 'EXIT 41 · 1 MI' }],
  [{ shield: '75', top: 'LEXINGTON', bot: 'NORTH', arrow: 1 }, { blue: 1, top: 'BLUFOX MOBILE', bot: 'GAS · FOOD · 5G' }],
  [{ shield: '64', top: 'LOUISVILLE', bot: 'WEST', arrow: 1 }, { blue: 1, top: 'BLUFOX MOBILE', bot: 'NEXT RIGHT' }],
  [{ shield: '65', top: 'INDIANAPOLIS', bot: 'NORTH', arrow: 1 }, { blue: 1, top: 'C³ STORE', bot: 'EXIT 137 · 2 MI' }],
  [{ shield: '65', top: 'INDIANAPOLIS', bot: 'NORTH', arrow: 1 }, { blue: 1, top: 'BLUFOX MOBILE', bot: 'NEXT EXIT →' }],
  [{ shield: '65', top: 'GARY', bot: 'CHICAGO', arrow: 1 }, { blue: 1, top: 'BLUFOX MOBILE', bot: 'EXIT 201' }],
  [{ shield: '65', top: 'GARY', bot: 'CHICAGO', arrow: 1 }, { blue: 1, top: 'C³ · SALES', bot: 'OPEN LATE' }],
  [{ shield: '90', top: 'CHICAGO', bot: 'SKYWAY  ·  TOLL', arrow: 1 }, { blue: 1, top: 'BLUFOX MOBILE', bot: 'EXIT 17 · 1 MI' }],
  [{ shield: '41', top: 'LAKE SHORE DR', bot: 'DOWNTOWN', arrow: 1 }, { blue: 1, top: 'NAVY PIER', bot: 'NEXT RIGHT' }],
  [{ shield: '94', top: 'CHICAGO LOOP', bot: 'EXIT 51', arrow: 1 }, { blue: 1, top: 'BLUFOX MOBILE', bot: 'STATE ST ·  LEFT' }],
  [{ shield: 'C3', top: 'STATE ST', bot: 'THE LOOP', arrow: 0 }, { blue: 1, top: 'BLUFOX MOBILE', bot: 'FLAGSHIP · 1 BLK' }],
];

// ---------------------------------------------------------------- geometry
function gantryFrameGeo(span = 7.7) {
  const g = [], st = '#aab3bb', st2 = '#8d969f';
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  for (const sx of [-1, 1]) {
    const x = sx * span;
    g.push(boxGeo(x - 0.9, -0.2, -1.1, x + 0.9, 0.7, 1.1, '#a7a39a'));        // footing
    for (const z of [-0.45, 0.45]) g.push(boxGeo(x - 0.16, 0.7, z - 0.16, x + 0.16, 12.7, z + 0.16, st));
    for (let k = 0; k < 8; k++) {
      const y0 = 0.9 + k * 1.45, y1 = y0 + 1.45;
      g.push(beamGeo(V(x, y0, k % 2 ? -0.45 : 0.45), V(x, y1, k % 2 ? 0.45 : -0.45), 0.09, st2));
    }
  }
  // box truss beam
  for (const y of [11.4, 12.6]) for (const z of [-0.45, 0.45]) g.push(boxGeo(-span - 0.3, y - 0.12, z - 0.12, span + 0.3, y + 0.12, z + 0.12, st));
  for (let k = 0; k < 12; k++) {
    const x0 = -span + k * (2 * span / 12), x1 = x0 + 2 * span / 12;
    for (const z of [-0.45, 0.45]) g.push(beamGeo(V(x0, 11.4, z), V(x1, 12.6, z), 0.08, st2));
    g.push(beamGeo(V(x0, 12.6, -0.45), V(x1, 12.6, 0.45), 0.07, st2));
  }
  // panel backing + catwalk
  g.push(boxGeo(-6.5, 7.9, 0.52, 6.5, 12.3, 0.6, '#7d858c'));
  // sign lights on arms above the panel (glow at night)
  for (const x of [-4.4, 0, 4.4]) {
    g.push(boxGeo(x - 0.05, 12.5, 0.4, x + 0.05, 12.62, 1.6, '#6f777e'));
    g.push(boxGeo(x - 0.4, 12.36, 1.45, x + 0.4, 12.5, 1.8, new THREE.Color(3.5, 3.4, 3.0)));
  }
  // amber beacons on the legs
  for (const sx of [-1, 1]) g.push(boxGeo(sx * span - 0.2, 12.8, -0.2, sx * span + 0.2, 13.1, 0.2, new THREE.Color(5, 2.2, 0.3)));
  return mergeGeos(g);
}
function mileSignGeo() {
  const g = [];
  for (const x of [-1.6, 1.6]) g.push(boxGeo(x - 0.08, 0, -0.08, x + 0.08, 4.6, 0.08, '#8b939a'));
  g.push(boxGeo(-2.7, 2.2, -0.07, 2.7, 4.6, -0.02, '#7d858c'));
  return mergeGeos(g);
}

// ---------------------------------------------------------------- system
export function createSigns(ctx, root, env, props) {
  const T = env.track;
  const glowK = { value: 1 };
  const frameMat = bentMat(new THREE.MeshLambertMaterial({ vertexColors: true }), sh => patchShader(sh, {
    uniforms: { uGlowK: glowK, ...nearFadeUniforms() },
    vPars: NEAR_FADE_VPARS, vBegin: NEAR_FADE_VBEGIN,
    fPars: 'uniform float uGlowK;\n' + NEAR_FADE_PARS,
    fColor: `vec3 pGlow = max(vColor.rgb - 1.0, 0.0);\ndiffuseColor.rgb = min(diffuseColor.rgb, vec3(1.0));\n` + NEAR_FADE_GLSL,
    fEmissive: 'totalEmissiveRadiance += pGlow * uGlowK;',
  }), 'gantryFrame');
  const frameGeo = gantryFrameGeo();
  const mileGeo = mileSignGeo();

  function panelMaterial(tex) {
    const U = { uFlash: { value: -1 }, uNightE: { value: 0 }, ...nearFadeUniforms() };
    const m = bentMat(new THREE.MeshLambertMaterial({ map: tex, alphaTest: 0.5, emissiveMap: tex, emissive: 0xffffff }), sh => patchShader(sh, {
      uniforms: U,
      vPars: NEAR_FADE_VPARS, vBegin: NEAR_FADE_VBEGIN,
      fPars: 'uniform float uFlash, uNightE;\n' + NEAR_FADE_PARS,
      fEmissive: /* glsl */`
{
  float lum = dot(totalEmissiveRadiance, vec3(0.3, 0.55, 0.15));
  totalEmissiveRadiance *= uNightE;
  totalEmissiveRadiance += vec3(0.02, 0.05, 0.03) * uNightE;
  // gleam sweeping across the panel
  float band = vMapUv.x * 1.4 - vMapUv.y * 0.35 - uFlash;
  float gleam = exp(-band * band * 90.0) * step(-0.5, uFlash);
  totalEmissiveRadiance += vec3(1.2, 1.25, 1.3) * gleam * (0.4 + lum);
}`,
      fColor: NEAR_FADE_GLSL,
    }), 'panel');
    m.userData.U = U;
    return m;
  }

  // ---- gantry objects (pooled, individual meshes)
  const gantries = [];
  function makeGantry(kind) {
    const grp = new THREE.Group(); grp.name = 'world-gantry-' + kind;
    const frame = new THREE.Mesh(frameGeo, frameMat); frame.frustumCulled = false; frame.name = 'world-gantry-frame';
    grp.add(frame);
    let c, tex, panel;
    if (kind === 'level') {
      c = makeCanvas(TEX_W, TEX_H); tex = canvasTex(c, { aniso: 16 });
      const pg = new THREE.PlaneGeometry(PANEL_W, PANEL_H); pg.translate(0, PANEL_Y0 + PANEL_H / 2, 0.64);
      panel = new THREE.Mesh(pg, panelMaterial(tex));
    } else {
      c = makeCanvas(1024, 540); tex = canvasTex(c, { aniso: 16 });
      const pg = new THREE.PlaneGeometry(6.3, 6.3 * 540 / 1024); pg.translate(0, 10.1, 0.64);
      panel = new THREE.Mesh(pg, panelMaterial(tex));
      const c2 = makeCanvas(1024, 540), tex2 = canvasTex(c2, { aniso: 16 });
      const pg2 = new THREE.PlaneGeometry(5.9, 5.9 * 540 / 1024); pg2.translate(0, 10.25, 0.64);
      const panel2 = new THREE.Mesh(pg2, panelMaterial(tex2));
      panel2.frustumCulled = false; panel2.name = 'world-gantry-panel2'; grp.add(panel2);
      grp.userData.c2 = c2; grp.userData.tex2 = tex2; grp.userData.panel2 = panel2;
    }
    panel.frustumCulled = false; panel.name = 'world-gantry-panel'; grp.add(panel);
    grp.visible = false;
    root.add(grp);
    const o = { kind, grp, c, tex, panel, s: -1e9, used: false, key: '' };
    gantries.push(o);
    return o;
  }
  for (let i = 0; i < 2; i++) makeGantry('level');
  for (let i = 0; i < 2; i++) makeGantry('plain');

  function takeGantry(kind, dist) {
    for (const o of gantries) if (o.kind === kind && (!o.used || o.s < dist - BEHIND - 4)) return o;
    return null;
  }
  const levelSignKey = (lv, ti, lap) => `${lv}|${ti}|${lap}`;
  function placeLevelGantry(s, level, ti, lap, dist) {
    const key = levelSignKey(level, ti, lap) + '@' + s;
    if (gantries.some(o => o.used && o.key === key)) return;
    const o = takeGantry('level', dist); if (!o) return;
    const th = THEMES[ti];
    drawLevelSign(o.c, { name: th.name, region: th.reg, level, lap, shield: SHIELDS[ti] });
    o.tex.needsUpdate = true;
    o.s = s; o.used = true; o.key = key; o.level = level; o.grp.visible = true;
    o.panel.material.userData.U.uFlash.value = -1;
  }
  function placePlainGantry(s, ti, dist) {
    const o = takeGantry('plain', dist); if (!o) return false;
    const v = GUIDES[ti] || GUIDES[0];
    drawGuideSign(o.c, v[0]); o.tex.needsUpdate = true;
    drawGuideSign(o.grp.userData.c2, v[1]); o.grp.userData.tex2.needsUpdate = true;
    o.panel.position.x = -3.2; o.grp.userData.panel2.position.x = 3.3;
    o.s = s; o.used = true; o.key = 'plain@' + s; o.grp.visible = true;
    return true;
  }

  // ---- mile signs (individual meshes, 2 alive)
  const miles = [];
  for (let i = 0; i < 2; i++) {
    const grp = new THREE.Group(); grp.name = 'world-milesign';
    const post = new THREE.Mesh(mileGeo, frameMat); post.frustumCulled = false; post.name = 'world-mile-post'; grp.add(post);
    const c = makeCanvas(1024, 456), tex = canvasTex(c, { aniso: 16 });
    const pg = new THREE.PlaneGeometry(5.4, 5.4 * 456 / 1024); pg.translate(0, 2.2 + 5.4 * 456 / 1024 / 2, 0);
    const panel = new THREE.Mesh(pg, panelMaterial(tex)); panel.frustumCulled = false; panel.name = 'world-gantry-panel'; grp.add(panel);
    grp.visible = false; root.add(grp);
    miles.push({ grp, c, tex, panel, s: -1e9, used: false, key: '' });
  }
  function placeMileSign(s, level, frac, dist) {
    const key = 'mi' + level;
    if (miles.some(m => m.used && m.key === key)) return;
    const o = miles.find(m => !m.used || m.s < dist - BEHIND - 4); if (!o) return;
    const stage = (level - 1) % 12;
    const p = TOTAL_MI * (stage + frac) / 12;
    const next = CITIES.find(([, m]) => m > p + 3);
    const rows = [];
    if (next && next[0] !== 'CHICAGO') rows.push([next[0], Math.round(next[1] - p)]);
    rows.push(['CHICAGO', Math.max(1, Math.round(TOTAL_MI - p))]);
    drawMileSign(o.c, rows); o.tex.needsUpdate = true;
    o.s = s; o.used = true; o.key = key; o.grp.visible = true;
  }

  // ---------------------------------------------------------------- spawning (called by the far cursor)
  let nextOverS = 0;
  const mileDone = new Set();
  function step(s, dist) {
    const lv = T.levelAt(s), ti = lv.theme, L = LOOKS[ti];
    // one mile sign per level (not downtown)
    if (ti !== 11 && !mileDone.has(lv.level)) {
      const len = lv.end ? lv.end - lv.start : 400;
      const at = lv.start + Math.min(170, len * 0.42);
      if (s >= at && s < at + 2.01) {
        mileDone.add(lv.level);
        if (!(props.zoneAt(s) && props.zoneAt(s).type === 'river')) placeMileSign(s, lv.level, (s - lv.start) / len, dist);
      }
    }
    // overheads for rhythm
    if (s >= nextOverS) {
      const over = L.over;
      const nearLevel = Math.abs(s - T.nextLevelAt) < 70 || Math.abs(s - lv.start) < 60 || props.zoneAt(s + 20) || props.zoneAt(s - 20);
      if (!over || nearLevel) { nextOverS = s + 40; return; }
      const [kind, every] = over;
      if (kind === 'overpass') {
        const i = props.P.over.add(s, 0, 0, 0, 0, 1, 1, 1, 6);
        if (i >= 0) props.P.over.attr('aGlow', i, 0);
      } else placePlainGantry(s, ti, dist);
      nextOverS = s + every * lerp(0.8, 1.2, hs(s, 901));
    }
  }

  // ---------------------------------------------------------------- per frame
  let flashT = -1, lastLevelKey = '';
  function update(sim, dist, dt, vis) {
    // the level gantry at the next level boundary (and a welcome one at the start of level 1)
    const nl = T.level + 1, lap = 1 + Math.floor((nl - 1) / 12);
    if (T.nextLevelAt - dist < 600) placeLevelGantry(T.nextLevelAt, nl, T.nextThemeIdx, lap, dist);
    if (T.level === 1 && dist < 60) placeLevelGantry(T.levelStart + 70, 1, T.themeIdx, T.lap, dist);
    // gleam as the player approaches the sign (starts ~1.6 s out)
    for (const o of gantries) {
      if (!o.used) continue;
      o.grp.position.z = -(o.s - dist);
      if (o.s < dist - BEHIND - 30) { o.used = false; o.grp.visible = false; continue; }
      if (o.kind === 'level') {
        const U = o.panel.material.userData.U;
        const sp = Math.max(sim.speed || 0, 10), tt = (dist - (o.s - sp * 1.6)) / (sp * 1.6);
        U.uFlash.value = tt > 0 && tt < 1.6 ? -0.4 + tt * 1.6 : -1;
        U.uNightE.value = 0.06 + vis.night * 1.25;
      } else {
        o.panel.material.userData.U.uNightE.value = 0.05 + vis.night * 1.1;
        o.grp.userData.panel2.material.userData.U.uNightE.value = 0.05 + vis.night * 1.1;
      }
    }
    for (const m of miles) {
      if (!m.used) continue;
      m.grp.position.set(8.6, 0, -(m.s - dist));
      m.panel.material.userData.U.uNightE.value = 0.05 + vis.night * 1.0;
      if (m.s < dist - BEHIND - 10) { m.used = false; m.grp.visible = false; }
    }
    // level-up flare: the gantry's sign lights and beacons blaze for ~0.8 s as you pass under
    let flare = 0;
    if (flashT >= 0) { flashT += dt; flare = Math.max(0, 1 - flashT / 0.8); if (flashT > 0.8) flashT = -1; }
    glowK.value = 0.15 + vis.night * 1.6 + flare * 5;
  }

  return {
    step, update,
    flush(dist) {
      for (const o of gantries) { o.used = false; o.grp.visible = false; o.key = ''; }
      for (const m of miles) { m.used = false; m.grp.visible = false; m.key = ''; }
      mileDone.clear();
      nextOverS = dist + 150;
    },
    onLevelUp() { flashT = 0; },
    gantries, miles,
  };
}
