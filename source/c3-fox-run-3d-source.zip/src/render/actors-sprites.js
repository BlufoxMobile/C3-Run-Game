// ACTORS · painted-sprite pipeline (owned by the ACTORS agent).
//
// The painted strips in assets/sprites/ were sliced imperfectly: pieces of one figure
// landed in the neighbouring cell (a hand, a tail tip, a claw) and every cell carries
// stray slivers along its edges. Shown raw, those slivers flicker at the fox's side.
// So every sheet is CLEANED at load time on a 2D canvas:
//   1. cells are copied into padded buffers,
//   2. known misplaced fragments are moved back to their owner (SHEET_FIXES, measured
//      offline from the shipped webps; skipped automatically if a sheet's size changes),
//   3. connected components: keep the figure, drop edge slivers / foreign fragments,
//   4. trim, bleed colour into transparent texels (no dark fringes when filtered),
//   5. pack into a shared DataTexture atlas (shelf packer) with per-frame UV rects.
// Unknown sheets (e.g. the ART agent's new fox_jump_back) get steps 1 and 3-5.
//
// SpriteBatch = one InstancedMesh (one draw call) of camera-facing quads that all sample
// one atlas, with per-instance frame rect / alpha / flash / tint, through a small custom
// shader that bends with the world, fogs, and relights the painted art for each theme
// (ambient tint, key-light rim, contact darkening, emissive boost of hot pixels).
import * as THREE from 'three';
import { BEND_GLSL_PARS, BEND_GLSL_APPLY } from '../core/bend.js';

const A_MIN = 16;          // alpha that counts as "solid" for connectivity
const PAD = 6;             // transparent border around every packed frame

// [srcCell, x0, x1, y0, y1, dstCell, dx, dy] in source pixels, cell-local. Only pixels that
// are NOT part of the source cell's main figure are moved.
export const SHEET_FIXES = {
  'sprites/player_run': { w: 1926, h: 512, ops: [
    [1, 0, 54, 150, 250, 0, 276, -4], [1, 0, 22, 0, 135, 0, 276, -4],
    [2, 16, 41, 190, 270, 1, 234, -21], [3, 66, 91, 320, 368, 2, 200, 22],
    [3, 309, 316, 175, 240, 4, -245, 0], [4, 290, 321, 170, 250, 5, -254, 52]] },
  'sprites/mon_falloff': { w: 2048, h: 315, ops: [[1, 0, 26, 130, 270, 0, 512, 32]] },
};

// ------------------------------------------------------------------ connected components
// 8-connected labelling of alpha > A_MIN. Returns { lab:Int32Array, n, size[], bb[] }.
function label(alpha, w, h) {
  const lab = new Int32Array(w * h);
  const stack = new Int32Array(w * h);
  const size = [0], bb = [null];
  let n = 0;
  for (let i = 0; i < w * h; i++) {
    if (lab[i] || alpha[i] <= A_MIN) continue;
    n++;
    let sp = 0, cnt = 0, x0 = w, x1 = -1, y0 = h, y1 = -1;
    stack[sp++] = i; lab[i] = n;
    while (sp) {
      const p = stack[--sp];
      const x = p % w, y = (p / w) | 0;
      cnt++;
      if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
      for (let dy = -1; dy <= 1; dy++) {
        const yy = y + dy; if (yy < 0 || yy >= h) continue;
        for (let dx = -1; dx <= 1; dx++) {
          const xx = x + dx; if (xx < 0 || xx >= w) continue;
          const q = yy * w + xx;
          if (!lab[q] && alpha[q] > A_MIN) { lab[q] = n; stack[sp++] = q; }
        }
      }
    }
    size.push(cnt); bb.push([x0, y0, x1, y1]);
  }
  return { lab, n, size, bb };
}

function mainOf(L) { let m = 0, best = -1; for (let k = 1; k <= L.n; k++) if (L.size[k] > best) { best = L.size[k]; m = k; } return m; }

/** Cut a horizontal strip into cleaned, trimmed, colour-bled frames.
 *  opts: { key, frames, scale=1, pick:[cell indices]|null, meta }
 *  returns [{ w, h, data:Uint8ClampedArray (RGBA straight alpha, top row first),
 *             ax, ay (anchor px in frame), bx0, by0, bx1, by1 (content bbox px), cellH }] */
export async function processStrip(img, opts) {
  const yieldNow = () => new Promise(r => setTimeout(r, 0));   // keep the loading bar / attract mode smooth
  const frames = opts.frames || 1;
  const scale = opts.scale || 1;
  const sw = img.naturalWidth || img.width, sh = img.naturalHeight || img.height;
  const W = Math.max(1, Math.round(sw * scale)), H = Math.max(1, Math.round(sh * scale));
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const g = cv.getContext('2d', { willReadFrequently: true });
  g.drawImage(img, 0, 0, W, H);
  const src = g.getImageData(0, 0, W, H).data;
  const padX = Math.round(64 * scale) + 8;
  const cells = [];
  for (let i = 0; i < frames; i++) {
    const cx0 = Math.round(i * W / frames), cx1 = Math.round((i + 1) * W / frames);
    const cw = cx1 - cx0, bw = cw + padX * 2;
    const buf = new Uint8ClampedArray(bw * H * 4);
    for (let y = 0; y < H; y++) {
      const so = (y * W + cx0) * 4, dof = (y * bw + padX) * 4;
      buf.set(src.subarray(so, so + cw * 4), dof);
    }
    cells.push({ cx0, cw, bw, buf, L: null });
  }
  const alphaOf = c => { const a = new Uint8Array(c.bw * H); for (let i = 0, j = 3; i < a.length; i++, j += 4) a[i] = c.buf[j]; return a; };
  // 2. move known fragments home
  const fix = SHEET_FIXES[opts.key];
  if (fix && fix.w === sw && fix.h === sh) {
    const need = new Set(fix.ops.map(o => o[0]));
    for (const ci of need) if (cells[ci]) { await yieldNow(); cells[ci].L = label(alphaOf(cells[ci]), cells[ci].bw, H); }
    for (const [sc, x0, x1, y0, y1, dc, dx, dy] of fix.ops) {
      const S = cells[sc], D = cells[dc]; if (!S || !D) continue;
      const main = mainOf(S.L);
      const X0 = Math.round(x0 * scale), X1 = Math.round(x1 * scale), Y0 = Math.round(y0 * scale), Y1 = Math.round(y1 * scale);
      const DX = Math.round(dx * scale), DY = Math.round(dy * scale);
      for (let y = Math.max(0, Y0); y < Math.min(H, Y1); y++) {
        const ty = y + DY; if (ty < 0 || ty >= H) continue;
        for (let x = X0; x < X1; x++) {
          const sx = x + padX, si = y * S.bw + sx;
          if (sx < 0 || sx >= S.bw) continue;
          const a = S.buf[si * 4 + 3];
          if (!a || S.L.lab[si] === main) continue;
          const tx = x + DX + padX; if (tx < 0 || tx >= D.bw) continue;
          const di = (ty * D.bw + tx) * 4;
          if (D.buf[di + 3] >= a) continue;
          D.buf[di] = S.buf[si * 4]; D.buf[di + 1] = S.buf[si * 4 + 1]; D.buf[di + 2] = S.buf[si * 4 + 2]; D.buf[di + 3] = a;
        }
      }
    }
  }
  // 3-5 per picked cell
  const pick = opts.pick || cells.map((_, i) => i);
  const meta = opts.meta || {};
  const out = [];
  for (const ci of pick) {
    const c = cells[ci]; if (!c) continue;
    await yieldNow();
    const bw = c.bw, buf = c.buf;
    const alpha = alphaOf(c);
    const L = label(alpha, bw, H);
    const main = mainOf(L);
    if (!main) continue;
    const mb = L.bb[main], ms = L.size[main];
    const keep = new Uint8Array(L.n + 1);
    const edgeL = padX + 1, edgeR = padX + c.cw - 2;
    for (let k = 1; k <= L.n; k++) {
      const b = L.bb[k];
      const inside = b[0] >= mb[0] && b[2] <= mb[2] && b[1] >= mb[1] && b[3] <= mb[3];
      const touches = b[0] <= edgeL || b[2] >= edgeR;
      keep[k] = (k === main || L.size[k] >= ms * 0.25 || (inside && !touches && L.size[k] >= 40)) ? 1 : 0;
    }
    // clear rejected pixels; faint (unlabelled) pixels survive only next to kept ones
    for (let y = 0; y < H; y++) for (let x = 0; x < bw; x++) {
      const i = y * bw + x, a = alpha[i];
      if (!a) continue;
      const l = L.lab[i];
      let ok;
      if (l) ok = keep[l];
      else {
        ok = 0;
        for (let dy = -2; dy <= 2 && !ok; dy++) { const yy = y + dy; if (yy < 0 || yy >= H) continue;
          for (let dx = -2; dx <= 2; dx++) { const xx = x + dx; if (xx < 0 || xx >= bw) continue;
            const l2 = L.lab[yy * bw + xx]; if (l2 && keep[l2]) { ok = 1; break; } } }
      }
      if (!ok) { buf[i * 4 + 3] = 0; alpha[i] = 0; }
    }
    // content bbox
    let x0 = bw, x1 = -1, y0 = H, y1 = -1;
    for (let y = 0; y < H; y++) for (let x = 0; x < bw; x++) if (alpha[y * bw + x] > 8) {
      if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y;
    }
    if (x1 < 0) continue;
    const fx0 = Math.max(0, x0 - PAD), fy0 = Math.max(0, y0 - PAD);
    const fx1 = Math.min(bw - 1, x1 + PAD), fy1 = Math.min(H - 1, y1 + PAD);
    const fw = fx1 - fx0 + 1, fh = fy1 - fy0 + 1;
    const data = new Uint8ClampedArray(fw * fh * 4);
    for (let y = 0; y < fh; y++) data.set(buf.subarray(((y + fy0) * bw + fx0) * 4, ((y + fy0) * bw + fx0 + fw) * 4), y * fw * 4);
    bleed(data, fw, fh);
    const ax = meta.ax != null ? meta.ax * c.cw + padX - fx0 : ((x0 + x1) / 2 - fx0);
    const ay = meta.ay != null ? meta.ay * H - fy0 : (y1 + 1 - fy0);
    out.push({ w: fw, h: fh, data, ax, ay, bx0: x0 - fx0, by0: y0 - fy0, bx1: x1 - fx0 + 1, by1: y1 - fy0 + 1, cellH: H, cell: ci });
  }
  return out;
}

// Spread edge colours into transparent texels so bilinear/mip filtering never pulls in black.
function bleed(d, w, h) {
  const n = w * h;
  const filled = new Uint8Array(n);
  let sr = 0, sg = 0, sb = 0, sc = 0;
  for (let i = 0; i < n; i++) if (d[i * 4 + 3] > 0) { filled[i] = 1; if (d[i * 4 + 3] > 200) { sr += d[i * 4]; sg += d[i * 4 + 1]; sb += d[i * 4 + 2]; sc++; } }
  let front = [];
  for (let i = 0; i < n; i++) if (!filled[i]) {
    const x = i % w, y = (i / w) | 0;
    if ((x > 0 && filled[i - 1]) || (x < w - 1 && filled[i + 1]) || (y > 0 && filled[i - w]) || (y < h - 1 && filled[i + w])) front.push(i);
  }
  for (let pass = 0; pass < 6 && front.length; pass++) {
    const next = [], done = [];
    for (const i of front) {
      if (filled[i]) continue;
      const x = i % w, y = (i / w) | 0;
      let r = 0, g = 0, b = 0, c = 0;
      const nb = [x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1];
      for (const q of nb) if (q >= 0 && filled[q]) { r += d[q * 4]; g += d[q * 4 + 1]; b += d[q * 4 + 2]; c++; }
      if (!c) continue;
      d[i * 4] = r / c; d[i * 4 + 1] = g / c; d[i * 4 + 2] = b / c;
      done.push(i);
      for (const q of nb) if (q >= 0 && !filled[q]) next.push(q);
    }
    for (const i of done) filled[i] = 1;
    front = next;
  }
  if (sc) { sr /= sc; sg /= sc; sb /= sc; }
  for (let i = 0; i < n; i++) if (!filled[i]) { d[i * 4] = sr; d[i * 4 + 1] = sg; d[i * 4 + 2] = sb; }
}

// ------------------------------------------------------------------ atlas
/** Shelf-packed RGBA atlas. add(frames) → frames get .rect = [u0,v0,u1,v1] after build(). */
export class Atlas {
  constructor(width = 2048) {
    this.W = width; this.H = 0; this.frames = []; this.tex = null; this.listeners = [];
  }
  add(frames) { for (const f of frames) this.frames.push(f); return frames; }
  /** Drop the CPU copies of the frames once every sheet is packed (the texture keeps its data). */
  seal() { this.sealed = true; for (const f of this.frames) f.data = null; }
  onChange(fn) { this.listeners.push(fn); if (this.tex) fn(this.tex); }
  build() {
    if (this.sealed) return this.tex;
    const W = this.W;
    const order = this.frames.slice().sort((a, b) => b.h - a.h);
    let x = 0, y = 0, rowH = 0;
    for (const f of order) {
      const fw = f.w + 2, fh = f.h + 2;
      if (x + fw > W) { x = 0; y += rowH; rowH = 0; }
      f.px = x + 1; f.py = y + 1;
      x += fw; rowH = Math.max(rowH, fh);
    }
    const H = Math.max(16, Math.ceil((y + rowH) / 64) * 64);
    const data = new Uint8Array(W * H * 4);
    for (const f of this.frames) {
      for (let r = 0; r < f.h; r++) {
        const dstRow = H - 1 - (f.py + r);              // flip: image top row -> v = 1
        data.set(f.data.subarray(r * f.w * 4, (r + 1) * f.w * 4), (dstRow * W + f.px) * 4);
      }
      f.rect = [f.px / W, 1 - (f.py + f.h) / H, (f.px + f.w) / W, 1 - f.py / H];
      f.texel = [1 / W, 1 / H];
    }
    let tex = this.tex;
    if (!tex || tex.image.width !== W || tex.image.height !== H) {
      if (tex) tex.dispose();
      tex = new THREE.DataTexture(data, W, H, THREE.RGBAFormat, THREE.UnsignedByteType);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.generateMipmaps = true;
      tex.minFilter = THREE.LinearMipmapLinearFilter;
      tex.magFilter = THREE.LinearFilter;
      tex.anisotropy = 4;
      this.tex = tex;
    } else tex.image.data = data;
    tex.needsUpdate = true;
    this.H = H;
    for (const fn of this.listeners) fn(tex);
    return tex;
  }
}

// ------------------------------------------------------------------ material
/** mode: 'lit' (painted characters), 'ghost' (additive afterimage), 'flat' (unlit, e.g. name tags) */
export function createSpriteMaterial({ mode = 'lit', alphaTest = 0.34, edge = false, fogK = 1 } = {}) {
  const uniforms = THREE.UniformsUtils.merge([THREE.UniformsLib.fog, {
    map: { value: null },
    uLight: { value: new THREE.Color(1, 1, 1) },
    uRim: { value: new THREE.Color(0, 0, 0) },
    uRimOff: { value: new THREE.Vector2(0.0015, 0.0015) },
    uEdge: { value: new THREE.Color(0, 0, 0) },
    uTexel: { value: new THREE.Vector2(1 / 2048, 1 / 2048) },
    uAlphaTest: { value: alphaTest },
    uGlowLo: { value: 0.72 },
    uFogK: { value: fogK },
  }]);
  const defines = {};
  if (mode === 'ghost') defines.GHOST = 1;
  if (mode === 'flat') defines.FLAT = 1;
  if (edge) defines.EDGE = 1;
  const m = new THREE.ShaderMaterial({
    uniforms, defines, fog: true, transparent: true,
    depthWrite: mode === 'lit', depthTest: true, side: THREE.DoubleSide,
    blending: mode === 'ghost' ? THREE.AdditiveBlending : THREE.NormalBlending,
    vertexShader: /* glsl */`
      #include <common>
      #include <fog_pars_vertex>
      ${BEND_GLSL_PARS}
      attribute vec4 aRect;
      attribute vec4 aParams;
      attribute vec4 aTint;
      attribute vec4 aExtra;
      varying vec4 vExtra;
      varying vec2 vUv;
      varying vec2 vLocal;
      varying vec4 vParams;
      varying vec4 vTint;
      void main() {
        vUv = vec2(mix(aRect.x, aRect.z, uv.x), mix(aRect.y, aRect.w, uv.y));
        vLocal = uv;
        vParams = aParams;
        vTint = aTint;
        vExtra = aExtra;
        vec4 mvPosition = modelViewMatrix * instanceMatrix * vec4(position, 1.0);
        ${BEND_GLSL_APPLY}
        gl_Position = projectionMatrix * mvPosition;
        #include <fog_vertex>
      }`,
    fragmentShader: /* glsl */`
      #include <common>
      #include <fog_pars_fragment>
      uniform sampler2D map;
      uniform vec3 uLight;
      uniform vec3 uRim;
      uniform vec2 uRimOff;
      uniform vec3 uEdge;
      uniform vec2 uTexel;
      uniform float uAlphaTest;
      uniform float uGlowLo;
      uniform float uFogK;
      varying vec2 vUv;
      varying vec2 vLocal;
      varying vec4 vParams;   // x alpha, y white flash, z hot-pixel glow, w edge glow
      varying vec4 vTint;     // rgb colour, a mix (ghost: rgb = colour)
      varying vec4 vExtra;    // rgb edge-light colour (per instance)
      void main() {
        vec4 t = texture2D(map, vUv);
      #ifdef GHOST
        float ga = t.a * vParams.x;
        if (ga < 0.02) discard;
        gl_FragColor = vec4(vTint.rgb * ga, ga);
      #else
        float a = t.a * vParams.x;
        if (t.a < uAlphaTest || a < 0.01) discard;
        vec3 col = t.rgb;
        #ifdef FLAT
          vec3 lit = col;
        #else
          vec3 lit = col * uLight;
          lit *= mix(0.66, 1.0, smoothstep(0.0, 0.16, vLocal.y));          // contact darkening
          float aL = texture2D(map, vUv + uRimOff).a;                       // rim toward the key light
          lit += uRim * (1.0 - aL) * smoothstep(0.3, 0.95, t.a);
          #ifdef EDGE
            vec2 o = uTexel * 3.5;
            float mn = min(min(texture2D(map, vUv + vec2(o.x, 0.0)).a, texture2D(map, vUv - vec2(o.x, 0.0)).a),
                           min(texture2D(map, vUv + vec2(0.0, o.y)).a, texture2D(map, vUv - vec2(0.0, o.y)).a));
            lit += (uEdge + vExtra.rgb) * (1.0 - mn) * vParams.w;
          #endif
          float hot = max(col.r, max(col.g, col.b));
          lit += col * smoothstep(uGlowLo, 1.0, hot) * vParams.z;          // eyes / lava / neon bloom
        #endif
        // tint / flash amounts are perceptual (squared: blending happens in linear light)
        lit = mix(lit, vTint.rgb, vTint.a * vTint.a);
        lit = mix(lit, vec3(1.0), vParams.y * vParams.y);
        gl_FragColor = vec4(lit, a);
      #endif
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        #ifdef USE_FOG
          #ifdef FOG_EXP2
            float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
          #else
            float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
          #endif
          fogFactor *= uFogK;
          #ifdef GHOST
            gl_FragColor.rgb *= 1.0 - fogFactor;
          #else
            gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
          #endif
        #endif
      }`,
  });
  return m;
}

// ------------------------------------------------------------------ batch
const _R = new THREE.Matrix4(), _L = new THREE.Matrix4(), _E = new THREE.Euler(0, 0, 0, 'YXZ');

/** One InstancedMesh of quads (x ∈ [-.5,.5], y ∈ [0,1]) with per-instance frame/params/tint. */
export class SpriteBatch {
  constructor(material, capacity, name = 'sprites') {
    const geo = new THREE.PlaneGeometry(1, 1, 1, 2);
    geo.translate(0, 0.5, 0);
    this.rect = new THREE.InstancedBufferAttribute(new Float32Array(capacity * 4), 4).setUsage(THREE.DynamicDrawUsage);
    this.params = new THREE.InstancedBufferAttribute(new Float32Array(capacity * 4), 4).setUsage(THREE.DynamicDrawUsage);
    this.tint = new THREE.InstancedBufferAttribute(new Float32Array(capacity * 4), 4).setUsage(THREE.DynamicDrawUsage);
    this.extra = new THREE.InstancedBufferAttribute(new Float32Array(capacity * 4), 4).setUsage(THREE.DynamicDrawUsage);
    geo.setAttribute('aExtra', this.extra);
    geo.setAttribute('aRect', this.rect);
    geo.setAttribute('aParams', this.params);
    geo.setAttribute('aTint', this.tint);
    this.mesh = new THREE.InstancedMesh(geo, material, capacity);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.frustumCulled = false;
    this.mesh.name = 'actors.' + name;
    this.mesh.count = 0;
    this.cap = capacity; this.n = 0; this.material = material;
    this._er = this._eg = this._eb = 0;
  }
  begin() { this.n = 0; }
  /** Edge-light colour for the following push() calls (monsters' signature rim). */
  edgeColor(r, g, b) { this._er = r; this._eg = g; this._eb = b; }
  /** frame: packed frame (rect, w, h, ax, ay). size in metres of the whole frame quad. */
  push(frame, px, py, pz, w, h, yaw, pitch, roll, shear, alpha, flash, glow, edge, tr, tg, tb, ta) {
    if (this.n >= this.cap || !frame || !frame.rect) return -1;
    const i = this.n++;
    // anchor in quad units: x relative to centre, y relative to bottom
    const ax = frame.ax / frame.w - 0.5, ay = 1 - frame.ay / frame.h;
    const e = _L.elements;
    // L = shear · scale · translate(-anchor)
    e[0] = w; e[4] = shear * h; e[8] = 0; e[12] = -w * ax - shear * h * ay;
    e[1] = 0; e[5] = h;         e[9] = 0; e[13] = -h * ay;
    e[2] = 0; e[6] = 0;         e[10] = 1; e[14] = 0;
    e[3] = 0; e[7] = 0;         e[11] = 0; e[15] = 1;
    _E.set(pitch, yaw, roll, 'YXZ');
    _R.makeRotationFromEuler(_E);
    _R.elements[12] = px; _R.elements[13] = py; _R.elements[14] = pz;
    _R.multiply(_L);
    _R.toArray(this.mesh.instanceMatrix.array, i * 16);
    const r = frame.rect, ra = this.rect.array;
    ra[i * 4] = r[0]; ra[i * 4 + 1] = r[1]; ra[i * 4 + 2] = r[2]; ra[i * 4 + 3] = r[3];
    const pa = this.params.array;
    pa[i * 4] = alpha; pa[i * 4 + 1] = flash; pa[i * 4 + 2] = glow; pa[i * 4 + 3] = edge;
    const ta2 = this.tint.array;
    ta2[i * 4] = tr; ta2[i * 4 + 1] = tg; ta2[i * 4 + 2] = tb; ta2[i * 4 + 3] = ta;
    const xa = this.extra.array;
    xa[i * 4] = this._er; xa[i * 4 + 1] = this._eg; xa[i * 4 + 2] = this._eb; xa[i * 4 + 3] = 0;
    return i;
  }
  end() {
    this.mesh.count = this.n;
    if (this.n) {
      this.mesh.instanceMatrix.clearUpdateRanges(); this.mesh.instanceMatrix.addUpdateRange(0, this.n * 16); this.mesh.instanceMatrix.needsUpdate = true;
      for (const at of [this.rect, this.params, this.tint, this.extra]) { at.clearUpdateRanges(); at.addUpdateRange(0, this.n * 4); at.needsUpdate = true; }
    }
    this.mesh.visible = this.n > 0;
  }
}

/** Fetch + clean + pack a sheet into an atlas once its image arrives. Returns a Promise of frames (or []). */
export function loadSheet(assets, key, atlas, opts = {}) {
  if (!assets.hasAsset(key)) return Promise.resolve([]);
  const name = key.replace('sprites/', '');
  const meta = (assets.SPRITE_META && assets.SPRITE_META[name]) || null;
  return assets.getImage(key).then(async img => {
    if (!img) return [];
    let frames = meta && meta.frames;
    if (!frames) {
      const asp = (img.naturalWidth || img.width) / (img.naturalHeight || img.height);
      frames = opts.frames || (asp > 1.45 ? Math.max(1, Math.round(asp / 0.8)) : 1);
    }
    let out = [];
    try {
      const t0 = performance.now();
      out = await processStrip(img, { key, frames, scale: opts.scale || 1, pick: opts.pick || null,
        meta: meta && opts.useMetaAnchor !== false ? { ax: meta.ax, ay: meta.ay } : {} });
      for (const f of out) { f.key = key; f.unitsHigh = meta ? meta.unitsHigh : null; f.frameCount = frames; f.scale = opts.scale || 1; }
      atlas.add(out);
      atlas.build();
      if (typeof __DEV__ !== 'undefined' && __DEV__) console.info(`[actors] ${key}: ${out.length} frames cleaned in ${Math.round(performance.now() - t0)} ms`);
    } catch (err) {
      console.warn('[actors] sprite processing failed for', key, err && err.message);
      out = [];
    }
    return out;
  });
}
