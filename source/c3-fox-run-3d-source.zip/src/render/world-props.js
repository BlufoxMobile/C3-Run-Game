// WORLD — roadside props and the spawner. Everything lives at a track position s in a
// recycled InstancedMesh Pool; content spawned at s belongs to the theme of the level s falls in
// (past sim.nextLevelAt -> sim.nextThemeIdx), so the next region appears beyond the gantry.
//   * painted sprites (pine, tree, barn, walkup, flag, ad billboards, bush, hay) = ONE instanced
//     camera-facing billboard draw (atlas), with wind sway
//   * procedural low-poly: street lights (+lamp heads +halos), delineators, guard rails, board
//     fences, chain-link, telephone poles, buildings with procedural lit windows, corn (swaying
//     clumps + canopy tiles), wind turbines (spinning rotors, blinking aviation lights), smoke
//     stacks (GPU-animated smoke), steel truss bridge, overpasses
// Owned by the WORLD agent.
import * as THREE from 'three';
import { WU, Pool, bentMat, patchShader, hs, lerp, mergeGeos, boxGeo, beamGeo, paint, NEAR_FADE_GLSL, NEAR_FADE_PARS, NEAR_FADE_VPARS, NEAR_FADE_VBEGIN, nearFadeUniforms } from './world-common.js';
import { createSpriteAtlas, glowTexture, puffTexture, cornTexture, chainTexture } from './world-tex.js';

export const STEP = 2;
const SIDES = [-1, 1];
export const NEAR_AHEAD = 112;
export const FAR_AHEAD = 178;
export const BEHIND = 16;

// ---------------------------------------------------------------- per-stage dressing
// trees: [kind, xMin, xMax, meanSpacingPerSide, hMin, hMax]
export const LOOKS = [
  { // 0 SMOKY DAWN — pine forest mountain road, rock-grey guard rail, mist
    rail: 'guard', delin: true, ads: 330, over: ['overpass', 330],
    trees: [['pine', 7.4, 15, 2.8, 7, 11], ['pine', 15, 46, 1.35, 9, 17], ['tree', 9, 30, 18, 6, 8], ['bush', 6.4, 9, 8, 1.1, 1.8]] },
  { // 1 TENNESSEE SUNRISE — foothills, mixed woods, flags, telephone line
    rail: 'guard', delin: true, flags: 150, tele: true, over: ['overpass', 320],
    trees: [['pine', 7.8, 18, 5.5, 7, 11], ['tree', 8.5, 20, 6.5, 6, 9], ['pine', 18, 50, 2.6, 9, 15], ['tree', 18, 50, 3.4, 8, 12], ['bush', 6.4, 9, 9, 1.1, 1.8]] },
  { // 2 CUMBERLAND PLATEAU — bright high road, sign gantries
    rail: 'guard', delin: true, ads: 240, over: ['gantry', 300],
    trees: [['pine', 8, 20, 4.6, 7, 12], ['tree', 9, 24, 8, 6, 9], ['pine', 20, 50, 2.2, 9, 15], ['bush', 6.4, 10, 8, 1.1, 1.7]] },
  { // 3 KENTUCKY BLUEGRASS — white board fences, barns, hay, lone trees
    rail: 'wood', ads: 360, barns: 120, hay: 16, tele: true, over: ['overpass', 360], mow: 1,
    trees: [['tree', 12, 48, 10, 7, 11], ['tree', 48, 80, 9, 9, 13], ['bush', 7, 12, 22, 1.2, 1.8]] },
  { // 4 LOUISVILLE HAZE — suburban approach, lights, low buildings, traffic
    rail: 'guard', lights: 'cobra', ads: 150, flags: 210, over: ['gantry', 260], road2: true,
    bld: { x: [17, 48], every: 24, h: [6, 16], d: [12, 26], w: [10, 22], styles: [2, 1, 2, 3] },
    trees: [['tree', 8.5, 16, 8, 6, 9], ['tree', 16, 40, 6, 8, 12], ['bush', 6.6, 10, 10, 1.1, 1.7]] },
  { // 5 OHIO RIVER — riverbank woods then the truss bridge over the water
    rail: 'guard', delin: true, flags: 240, ads: 320, water: 'river',
    trees: [['tree', 8, 18, 5, 7, 10], ['tree', 18, 50, 2.8, 9, 13], ['pine', 14, 50, 6, 9, 14], ['bush', 6.4, 10, 9, 1.1, 1.8]] },
  { // 6 INDIANA CORN — corn to the horizon, barns, telephone line
    corn: true, delin: true, barns: 130, tele: true, ads: 340, over: ['overpass', 420],
    trees: [['tree', 60, 90, 30, 9, 12]] },
  { // 7 HOOSIER DUSK — corn + wind farm at dusk, fireflies
    corn: true, delin: true, barns: 210, tele: true, turbines: 58, over: ['overpass', 420],
    trees: [['tree', 60, 90, 40, 9, 12]] },
  { // 8 GARY STEEL — mills, stacks, chain-link, sodium lights
    rail: 'chain', lights: 'sodium', ads: 280, stacks: 42, road2: true, over: ['gantry', 260],
    bld: { x: [15, 52], every: 26, h: [8, 24], d: [22, 46], w: [14, 34], styles: [3, 3, 3, 2] },
    trees: [['bush', 7, 12, 14, 1.1, 1.6], ['tree', 12, 20, 30, 6, 8]] },
  { // 9 LAKESHORE — Lake Michigan on the right, park + skyline on the left
    lights: 'white', ads: 300, flags: 200, road2: true, water: 'lake',
    trees: [['tree', 8.5, 13, 6, 6, 9], ['tree', 24, 44, 4, 8, 12], ['bush', 6.6, 12, 9, 1.1, 1.7]] },
  { // 10 CHICAGO SKYLINE — expressway into the city, mid-rises, walk-ups
    rail: 'guard', lights: 'sodium', ads: 220, road2: true, over: ['overpass', 250], walkups: 15,
    bld: { x: [24, 70], every: 17, h: [14, 64], d: [14, 30], w: [12, 26], styles: [0, 1, 2, 0, 1] },
    trees: [['tree', 8.5, 12, 22, 6, 8]] },
  { // 11 THE LOOP — canyon of lit towers, neon, the L overhead
    lights: 'sodium', city: true, loop: true,
    bld: { x: [11.3, 11.3], every: 0, h: [26, 120], d: [16, 34], w: [18, 30], styles: [0, 1, 2, 0, 1, 0] },
    trees: [] },
];

// ---------------------------------------------------------------- shared GLSL
export const BB_VPARS = /* glsl */`
attribute vec4 aUV;
attribute vec4 aP;
uniform float uTime, uWind;
`;
export const BB_PROJECT = /* glsl */`
vec4 bbC = modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
float bbW = length(instanceMatrix[0].xyz), bbH = length(instanceMatrix[1].xyz);
vec3 camR = normalize(vec3(viewMatrix[0][0], 0.0, viewMatrix[2][0]));
float yy = position.y;
float sw = aP.y * uWind * (sin(uTime * 1.5 + aP.z) * 0.7 + sin(uTime * 2.7 + aP.z * 1.7) * 0.3) * yy * yy;
vec3 wp = bbC.xyz + camR * ((position.x - aP.x) * bbW + sw * bbH) + vec3(0.0, yy * bbH, 0.0);
vec4 mvPosition = viewMatrix * vec4(wp, 1.0);
gl_Position = projectionMatrix * mvPosition;
#ifdef USE_MAP
vMapUv = aUV.xy + vec2(mix(uv.x, 1.0 - uv.x, step(aP.w, 0.0)), uv.y) * aUV.zw;
#endif
`;

const PROP_PATCH = (extra = {}) => sh => patchShader(sh, {
  uniforms: { uGlowK: extra.glowK, ...nearFadeUniforms() },
  vPars: 'attribute float aGlow;\nvarying float vGlow;\n' + NEAR_FADE_VPARS,
  vBegin: 'vGlow = aGlow;\n' + NEAR_FADE_VBEGIN,
  fPars: 'uniform float uGlowK;\n' + NEAR_FADE_PARS + '\nvarying float vGlow;',
  fColor: `vec3 pGlow = max(vColor.rgb - 1.0, 0.0);\ndiffuseColor.rgb = min(diffuseColor.rgb, vec3(1.0));` + (extra.nearFade ? '\n' + NEAR_FADE_GLSL : ''),
  fEmissive: 'totalEmissiveRadiance += pGlow * (0.12 + vGlow) * uGlowK;',
});

// ---------------------------------------------------------------- geometry builders
const GALV = new THREE.Color('#aeb6be');
const RED = new THREE.Color(1, 0.08, 0.05), SODIUM = new THREE.Color(1.0, 0.55, 0.18), COOLW = new THREE.Color(0.8, 0.9, 1.0), WARMW = new THREE.Color(1.0, 0.85, 0.6);

function streetLightGeo() {
  const g = [];
  g.push(boxGeo(-0.13, 0, -0.13, 0.13, 9.0, 0.13, '#5a6068'));             // pole
  g.push(boxGeo(-0.3, 0, -0.3, 0.3, 0.5, 0.3, '#7a7f86'));                // base
  g.push(beamGeo(new THREE.Vector3(0, 8.7, 0), new THREE.Vector3(-2.3, 9.05, 0), 0.12, '#5a6068')); // arm
  return mergeGeos(g);
}
function lampHeadGeo() {  // at the arm end, local origin = pole base
  return mergeGeos([boxGeo(-2.85, 8.86, -0.24, -1.95, 9.1, 0.24, '#3a3e44'), boxGeo(-2.75, 8.8, -0.18, -2.05, 8.87, 0.18, '#ffffff')]);
}
function delineatorGeo() {
  return mergeGeos([boxGeo(-0.05, 0, -0.05, 0.05, 1.05, 0.05, '#e8e8e8'), boxGeo(-0.06, 0.78, 0.045, 0.06, 0.95, 0.06, new THREE.Color(6, 4.2, 1.2))]);
}
function guardRailGeo() {  // 4 m segment centred on z=0, road side is -x (rotate PI for the left side)
  const g = [];
  g.push(boxGeo(-0.06, 0.52, -2.02, 0.03, 0.86, 2.02, GALV));
  g.push(boxGeo(-0.09, 0.63, -2.02, -0.05, 0.75, 2.02, '#8f979f'));
  g.push(boxGeo(0.03, 0, -0.08, 0.18, 0.8, 0.08, '#6c737b'));
  g.push(boxGeo(-0.07, 0.8, -0.05, -0.04, 0.84, 0.05, new THREE.Color(5, 5, 4.5)));      // reflector
  return mergeGeos(g);
}
function woodFenceGeo() {  // 4 m, white 4-board horse fence
  const g = [], c = '#eceae4';
  for (const y of [0.3, 0.62, 0.94, 1.26]) g.push(boxGeo(-0.04, y, -2.02, 0.02, y + 0.16, 2.02, c));
  for (const z of [-1, 1]) g.push(boxGeo(0.02, 0, z - 0.1, 0.2, 1.5, z + 0.1, '#d9d6cf'));
  return mergeGeos(g);
}
function chainPostGeo() {  // 4 m: posts + top rail (the mesh is a separate alpha pool)
  const g = [];
  g.push(boxGeo(-0.05, 0, -0.05, 0.05, 2.3, 0.05, '#8a9199'));
  g.push(boxGeo(-0.035, 2.18, -2.02, 0.035, 2.25, 2.02, '#8a9199'));
  g.push(boxGeo(-0.02, 2.3, -2.0, 0.02, 2.55, 2.0, '#5c6268'));   // barbed strand
  return mergeGeos(g);
}
function telePoleGeo() {
  const g = [], wood = '#6b5039';
  g.push(boxGeo(-0.14, 0, -0.14, 0.14, 10.5, 0.14, wood));
  g.push(boxGeo(-1.3, 9.6, -0.09, 1.3, 9.8, 0.09, wood));
  g.push(boxGeo(-0.9, 8.9, -0.08, 0.9, 9.05, 0.08, wood));
  for (const x of [-1.15, -0.4, 0.4, 1.15]) g.push(boxGeo(x - 0.05, 9.8, -0.05, x + 0.05, 9.98, 0.05, '#c9d2c8'));
  g.push(boxGeo(-0.3, 7.6, 0.12, 0.3, 8.3, 0.5, '#7d8286'));     // transformer can
  return mergeGeos(g);
}
function wireGeo() {       // sagging wires between two telephone poles 40 m apart (z -20..20)
  const segs = 10, g = [];
  for (const [x, y] of [[-1.15, 9.95], [-0.4, 9.95], [0.4, 9.95], [1.15, 9.95], [-0.8, 9.0]]) {
    for (let i = 0; i < segs; i++) {
      const t0 = i / segs, t1 = (i + 1) / segs;
      const z0 = -20 + 40 * t0, z1 = -20 + 40 * t1;
      const y0 = y - 0.9 * 4 * t0 * (1 - t0), y1 = y - 0.9 * 4 * t1 * (1 - t1);
      g.push(beamGeo(new THREE.Vector3(x, y0, z0), new THREE.Vector3(x, y1, z1), 0.035, '#1f2326'));
    }
  }
  return mergeGeos(g);
}
function turbineTowerGeo() {
  const g = [];
  const tower = new THREE.CylinderGeometry(0.55, 1.15, 36, 10, 4); tower.translate(0, 18, 0); paint(tower, '#eef1f3'); g.push(tower);
  g.push(boxGeo(-1.1, 35.4, -3.6, 1.1, 37.4, 1.4, '#e4e8ea'));
  const hub = new THREE.SphereGeometry(0.9, 10, 8); hub.scale(1, 1, 1.4); hub.translate(0, 36.4, 1.9); paint(hub, '#f4f6f7'); g.push(hub);
  return mergeGeos(g);
}
function rotorGeo() {      // centred on the hub, in the XY plane
  const g = [];
  for (let k = 0; k < 3; k++) {
    const b = new THREE.BufferGeometry();
    const shape = new THREE.Shape();
    shape.moveTo(-0.35, 0.8); shape.lineTo(0.55, 0.8); shape.lineTo(0.35, 7); shape.lineTo(0.12, 17.5); shape.lineTo(-0.1, 17.5); shape.lineTo(-0.35, 6);
    const sg = new THREE.ExtrudeGeometry(shape, { depth: 0.18, bevelEnabled: false });
    sg.rotateZ(k * Math.PI * 2 / 3);
    paint(sg, '#f2f4f5');
    g.push(sg);
    b.dispose();
  }
  return mergeGeos(g);
}
function stackGeo() {
  const g = [];
  const c = new THREE.CylinderGeometry(1.6, 2.4, 52, 14, 1); c.translate(0, 26, 0); paint(c, '#8b8580'); g.push(c);
  for (const [y, col] of [[40, '#c43b2e'], [44, '#e9e4dc'], [48, '#c43b2e']]) {
    const b = new THREE.CylinderGeometry(1.75, 1.8, 3.6, 14, 1); b.translate(0, y, 0); paint(b, col); g.push(b);
  }
  const top = new THREE.CylinderGeometry(1.9, 1.9, 0.8, 14, 1); top.translate(0, 52, 0); paint(top, '#3c3a38'); g.push(top);
  g.push(boxGeo(-0.2, 49.9, 1.85, 0.2, 50.3, 2.0, new THREE.Color(8, 0.6, 0.4)));   // aviation light
  return mergeGeos(g);
}
function trussPanelGeo() { // 12 m, centred z=0, both sides + overhead bracing
  const g = [], col = '#3f6b78', col2 = '#355a66';
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  for (const sx of [-1, 1]) {
    const x = sx * 6.25;
    g.push(boxGeo(x - 0.22, -0.7, -6.02, x + 0.22, 0.75, 6.02, col2));            // bottom chord + deck fascia
    g.push(boxGeo(x - 0.2, 10.4, -6.02, x + 0.2, 10.9, 6.02, col));                   // top chord
    g.push(boxGeo(x - 0.18, 0.75, -6.2, x + 0.18, 10.4, -5.84, col));                // vertical
    g.push(beamGeo(V(x, 0.75, -6), V(x, 10.4, 0), 0.3, col));                        // Warren diagonals
    g.push(beamGeo(V(x, 10.4, 0), V(x, 0.75, 6), 0.3, col));
    g.push(boxGeo(x - sx * 0.55 - 0.18, 0, -6.02, x - sx * 0.55 + 0.18, 0.85, 6.02, '#9a9fa4')); // parapet
  }
  g.push(boxGeo(-6.25, 10.45, -6.18, 6.25, 10.85, -5.86, col));                       // cross beam
  g.push(beamGeo(V(-6.2, 10.65, -6), V(6.2, 10.65, 6), 0.22, col2));                  // X bracing
  g.push(beamGeo(V(6.2, 10.65, -6), V(-6.2, 10.65, 6), 0.22, col2));
  g.push(boxGeo(-6.4, -3.5, -1.0, -5.6, -0.7, 1.0, '#8e8a84'));                    // piers into the river
  g.push(boxGeo(5.6, -3.5, -1.0, 6.4, -0.7, 1.0, '#8e8a84'));
  return mergeGeos(g);
}
function overpassGeo() {   // concrete overpass carrying a county road, bottom at 7.4 m
  const g = [], con = '#b7b3aa', con2 = '#9d9990';
  g.push(boxGeo(-44, 7.4, -5, 44, 8.7, 5, con));
  g.push(boxGeo(-44, 8.7, 4.4, 44, 9.6, 5, con2));
  g.push(boxGeo(-44, 8.7, -5, 44, 9.6, -4.4, con2));
  g.push(boxGeo(-44, 7.3, 4.9, 44, 7.45, 5.05, '#6f6b64'));
  for (const x of [-7.6, 7.6]) {
    for (const z of [-2.6, 2.6]) g.push(boxGeo(x - 0.55, 0, z - 0.55, x + 0.55, 7.4, z + 0.55, con2));
    g.push(boxGeo(x - 0.8, 6.6, -4, x + 0.8, 7.4, 4, con));
  }
  // embankments
  for (const sx of [-1, 1]) {
    const e = new THREE.BoxGeometry(1, 1, 1);
    const p = e.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const lx = p.getX(i) + 0.5, ly = p.getY(i) + 0.5, lz = p.getZ(i);
      const x = sx * (26 + lx * 22), top = 8.7 * (1 - lx), y = ly * top;
      p.setXYZ(i, x, y, lz * 14);
    }
    e.computeVertexNormals();
    paint(e, '#6f7d4e');
    g.push(e);
  }
  return mergeGeos(g);
}
function prismGeoBox() { const b = new THREE.BoxGeometry(1, 1, 1, 1, 1, 6); b.translate(0, 0.5, 0); return b; }

// ---------------------------------------------------------------- the props system
export function createProps(ctx, root, env) {
  const { assets } = ctx;
  const atlas = createSpriteAtlas(assets);
  const glowK = { value: 0 };
  const P = {};         // pools
  const T = env.track;  // shared track info (theme / level lookups), owned by world.js

  // ---- billboards (one draw for all painted sprites)
  const bbMat = bentMat(new THREE.MeshBasicMaterial({ map: atlas.tex, alphaTest: 0.42, transparent: false, fog: true }),
    sh => patchShader(sh, { uniforms: { uTime: WU.uTime, uWind: WU.uWind }, vPars: BB_VPARS, vProject: BB_PROJECT }), 'bb');
  const bbGeo = new THREE.PlaneGeometry(1, 1); bbGeo.translate(0.5, 0.5, 0);
  P.bb = new Pool(bbGeo, bbMat, 1100, { attrs: { aUV: 4, aP: 4 }, color: true, name: 'world-billboards' });

  // ---- generic vertex-coloured props (Lambert + glowing vertex colours > 1)
  const propMat = bentMat(new THREE.MeshLambertMaterial({ vertexColors: true }), PROP_PATCH({ glowK }), 'prop');
  const overMat = bentMat(new THREE.MeshLambertMaterial({ vertexColors: true }), PROP_PATCH({ glowK, nearFade: true }), 'propOver');
  const mk = (name, geo, cap, mat = propMat, extra = {}) => (P[name] = new Pool(geo, mat, cap, { attrs: { aGlow: 1, ...(extra.attrs || {}) }, color: extra.color, name: 'world-' + name }));
  mk('pole', streetLightGeo(), 26);
  mk('delin', delineatorGeo(), 40);
  mk('rail', guardRailGeo(), 120);
  mk('wood', woodFenceGeo(), 150);
  mk('chainP', chainPostGeo(), 120);
  mk('tele', telePoleGeo(), 10);
  mk('wire', wireGeo(), 10);
  mk('turb', turbineTowerGeo(), 16);
  mk('rotor', rotorGeo(), 16);
  mk('stack', stackGeo(), 14);
  mk('truss', trussPanelGeo(), 24, overMat);
  mk('over', overpassGeo(), 3, overMat);

  // lamp heads: basic material, HDR instance colour when lit
  const lampMat = bentMat(new THREE.MeshBasicMaterial({ vertexColors: true }), null);
  P.lamp = new Pool(lampHeadGeo(), lampMat, 26, { color: true, name: 'world-lamps' });

  // chain-link mesh (alpha)
  const chainTex = chainTexture(); chainTex.repeat.set(4 / 0.35, 2.2 / 0.35);
  const chainMat = bentMat(new THREE.MeshLambertMaterial({ map: chainTex, alphaTest: 0.35, side: THREE.DoubleSide, color: '#9aa2aa' }), null);
  const chainGeo = new THREE.PlaneGeometry(4, 2.2); chainGeo.rotateY(Math.PI / 2); chainGeo.translate(0, 1.1, 0);
  P.chain = new Pool(chainGeo, chainMat, 120, { name: 'world-chainlink' });

  // ---- glow halos (additive camera-facing), shared by lamps, flares, beacons
  const glowTex = glowTexture();
  const haloMat = bentMat(new THREE.MeshBasicMaterial({ map: glowTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }),
    sh => patchShader(sh, {
      uniforms: { uTime: WU.uTime, uWind: WU.uWind },
      vPars: BB_VPARS + 'varying float vBlink;',
      vProject: BB_PROJECT.replace('float sw =', 'vBlink = aP.y > 0.0 ? step(0.55, fract(uTime * aP.y + aP.z)) : 1.0;\nfloat sw = 0.0 *'),
      fPars: 'varying float vBlink;',
      fColor: 'diffuseColor.rgb *= vBlink; diffuseColor.a *= vBlink;',
    }), 'halo');
  P.halo = new Pool(bbGeo.clone(), haloMat, 160, { attrs: { aUV: 4, aP: 4 }, color: true, name: 'world-halos', order: 5 });

  // ---- buildings with procedural windows
  const bldU = { uGlass: { value: new THREE.Color('#5b7896') }, uNightK: { value: 1 }, uGlowK: glowK };
  const bldMat = bentMat(new THREE.MeshLambertMaterial({ color: 0xffffff }), sh => patchShader(sh, {
    uniforms: bldU,
    vPars: 'attribute vec4 aW;\nvarying vec4 vW;\nvarying vec3 vFac;',
    vBegin: `
vec3 bsc = vec3(length(instanceMatrix[0].xyz), length(instanceMatrix[1].xyz), length(instanceMatrix[2].xyz));
float isSide = step(0.5, abs(normal.x));
vFac = vec3(mix((position.x + 0.5) * bsc.x, (position.z + 0.5) * bsc.z, isSide), position.y * bsc.y, step(0.5, abs(normal.y)));
vW = aW;`,
    fPars: `
uniform vec3 uGlass; uniform float uNightK, uGlowK;
varying vec4 vW; varying vec3 vFac;
float bh(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
vec3 bWinE = vec3(0.0);`,
    fColor: /* glsl */`
{
  float st = vW.x;
  vec2 cell = st < 0.5 ? vec2(2.5, 3.6) : st < 1.5 ? vec2(3.1, 3.4) : st < 2.5 ? vec2(3.3, 3.8) : st < 3.5 ? vec2(3.2, 6.0) : vec2(99.0);
  vec2 lo = st < 0.5 ? vec2(0.07, 0.1) : st < 1.5 ? vec2(0.27, 0.24) : st < 2.5 ? vec2(0.05, 0.38) : vec2(0.12, 0.66);
  vec2 hi = st < 0.5 ? vec2(0.93, 0.92) : st < 1.5 ? vec2(0.73, 0.86) : st < 2.5 ? vec2(0.95, 0.8) : vec2(0.88, 0.8);
  vec2 g = vFac.xy / cell;
  vec2 fw = fwidth(g);
  vec2 id = floor(g), f = fract(g);
  vec2 wa = smoothstep(lo - fw, lo + fw, f) * (1.0 - smoothstep(hi - fw, hi + fw, f));
  float win = wa.x * wa.y;
  float far = smoothstep(0.18, 0.55, max(fw.x, fw.y));
  float avgW = (hi.x - lo.x) * (hi.y - lo.y);
  win = mix(win, avgW, far);
  float h = bh(id + floor(vW.z + 0.5) * 17.0);
  float lit = mix(step(h, vW.y), vW.y, far);
  float roof = vFac.z;
  float gf = st < 2.5 ? step(vFac.y, 4.3) : 0.0;
  if (st > 3.5 || roof > 0.5) { win = 0.0; lit = 0.0; gf = 0.0; }
  vec3 wall = diffuseColor.rgb;
  // brick / panel texture
  if (st > 0.5 && st < 1.5) wall *= 0.9 + 0.1 * step(0.5, fract(vFac.y / 0.3 + step(0.5, fract(vFac.x / 0.9)) * 0.5));
  if (st > 2.5 && st < 3.5) {
    float rib = fract(vFac.x / 0.7);
    wall *= 0.8 + 0.2 * smoothstep(0.1, 0.5, rib) * (1.0 - smoothstep(0.5, 0.9, rib));
    wall *= mix(0.55, 1.0, step(1.4, vFac.y));
    wall *= 1.0 - 0.18 * step(0.5, fract(h * 9.0)) * step(fract(vFac.y / 7.0), 0.08);
  }
  if (st < 0.5) wall *= 0.9 + 0.1 * step(0.08, fract(vFac.x / cell.x));
  vec3 glass = uGlass * (0.62 + 0.55 * fract(h * 13.7));
  vec3 c = mix(wall, glass, win);
  c = mix(c, vec3(0.05, 0.055, 0.06), gf * step(0.3, fract(vFac.x / 4.0)) * step(0.6, vFac.y) * step(vFac.y, 3.6));  // storefront glass
  if (roof > 0.5) c = wall * 0.55;
  diffuseColor.rgb = c;
  vec3 wc = fract(h * 7.1) < 0.6 ? vec3(1.0, 0.5, 0.16) : fract(h * 7.1) < 0.86 ? vec3(1.0, 0.7, 0.32) : vec3(0.5, 0.66, 1.0);
  wc *= 0.45 + 0.75 * fract(h * 31.7);
  float glow = vW.w * uNightK;
  float sf = gf * step(0.3, fract(vFac.x / 4.0)) * step(0.6, vFac.y) * step(vFac.y, 3.6) * step(0.12, fract(vFac.x / 1.3));
  bWinE = wc * lit * win * glow * 1.05 + mix(vec3(1.0, 0.55, 0.25), vec3(0.6, 0.8, 1.0), step(0.6, fract(h * 3.3))) * sf * glow * 0.65 * step(0.35, fract(h * 5.1));
}`,
    fEmissive: 'totalEmissiveRadiance += bWinE;',
  }), 'bld');
  P.bld = new Pool(prismGeoBox(), bldMat, 190, { attrs: { aW: 4 }, color: true, name: 'world-buildings' });

  // ---- corn
  const cornTex = cornTexture();
  const cornMat = bentMat(new THREE.MeshLambertMaterial({ map: cornTex, alphaTest: 0.45, side: THREE.DoubleSide }), sh => patchShader(sh, {
    uniforms: { uTime: WU.uTime, uWind: WU.uWind, uScroll: WU.uScroll },
    vPars: 'uniform float uTime, uWind, uScroll;',
    vBegin: `{
  vec3 ip = instanceMatrix[3].xyz;
  float s = uScroll - ip.z;
  float wave = sin(uTime * 2.1 - s * 0.32 + ip.x * 0.15) * 0.6 + sin(uTime * 3.3 + s * 0.9) * 0.4;
  transformed.x += wave * 0.16 * uWind * position.y * position.y / 5.0;
  transformed.z += wave * 0.08 * uWind * position.y * position.y / 5.0;
}`,
  }), 'corn');
  const cornGeo = mergeGeos([0, 1, 2].map(k => { const p = new THREE.PlaneGeometry(1.5, 2.6); p.translate(0, 1.3, 0); p.rotateY(k * Math.PI / 3 + 0.3); return p; }));
  P.corn = new Pool(cornGeo, cornMat, 2200, { color: true, name: 'world-corn' });
  const canopyMat = bentMat(new THREE.MeshLambertMaterial({ color: 0xffffff }), sh => patchShader(sh, {
    uniforms: { uTime: WU.uTime, uWind: WU.uWind, uScroll: WU.uScroll, uCornA: { value: new THREE.Color('#7a9a2e') }, uCornB: { value: new THREE.Color('#e0c060') } },
    vPars: 'uniform float uTime, uWind, uScroll;\nvarying vec2 vCW;',
    vBegin: `{
  vec4 wpC = instanceMatrix * vec4(position, 1.0);
  float s = uScroll - wpC.z;
  vCW = vec2(wpC.x, s);
  transformed.y += (sin(uTime * 1.9 - s * 0.21 + wpC.x * 0.05) * 0.5 + 0.5) * 0.28 * uWind;
}`,
    fPars: `uniform vec3 uCornA, uCornB; uniform float uTime, uWind;\nvarying vec2 vCW;
float ch(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
float cn(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(ch(i), ch(i + vec2(1, 0)), f.x), mix(ch(i + vec2(0, 1)), ch(i + vec2(1, 1)), f.x), f.y); }`,
    fMap: /* glsl */`{
  float X = vCW.x, S = vCW.y;
  float fwr = fwidth(X / 0.76);
  float row = fract(X / 0.76);
  float gap = mix(smoothstep(0.0, 0.3, row) * (1.0 - smoothstep(0.7, 1.0, row)), 0.62, smoothstep(0.15, 0.5, fwr));
  float fw2 = fwidth(S * 1.6);
  float leaf = mix(cn(vec2(X * 3.1, S * 1.6)), 0.5, smoothstep(0.3, 1.0, fw2)) * 0.6 + cn(vec2(X * 0.4, S * 0.25)) * 0.4;
  float tassel = smoothstep(0.66, 0.86, mix(cn(vec2(X * 6.0 + 3.0, S * 5.0)), 0.45, smoothstep(0.3, 1.0, fw2 * 3.0)));
  float gust = sin(uTime * 1.9 - S * 0.21 + X * 0.05) * 0.5 + 0.5;
  vec3 c = mix(uCornA * 0.28, uCornA * 1.05, gap * (0.45 + 0.75 * leaf));
  c = mix(c, uCornB, tassel * 0.6 * gap);
  c *= 0.9 + gust * 0.22 * uWind;
  diffuseColor.rgb *= c;
}`,
  }), 'canopy');
  const canGeo = new THREE.PlaneGeometry(80, 12, 12, 6); canGeo.rotateX(-Math.PI / 2); canGeo.translate(11.8 + 40, 2.25, 0);
  P.canopy = new Pool(canGeo, canopyMat, 40, { name: 'world-canopy' });

  // ---- smoke puffs (GPU animated, rising from stack tops)
  const puffMat = bentMat(new THREE.MeshBasicMaterial({ map: puffTexture(), transparent: true, depthWrite: false, fog: false, color: '#54474c' }), sh => patchShader(sh, {
    uniforms: { uTime: WU.uTime, uWind: WU.uWind },
    vPars: BB_VPARS + 'varying float vAge;',
    vProject: /* glsl */`
float age = fract(uTime * 0.055 + aP.z);
vAge = age;
vec4 bbC = modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0);
float bbW = length(instanceMatrix[0].xyz) * (1.0 + age * 3.2);
vec3 camR = normalize(vec3(viewMatrix[0][0], 0.0, viewMatrix[2][0]));
vec3 wp = bbC.xyz + vec3(age * age * 26.0 * uWind + sin(aP.z * 40.0) * 2.0, age * 30.0, -age * 6.0);
wp += camR * (position.x - 0.5) * bbW + vec3(0.0, (position.y - 0.5) * bbW, 0.0);
vec4 mvPosition = viewMatrix * vec4(wp, 1.0);
gl_Position = projectionMatrix * mvPosition;
#ifdef USE_MAP
vMapUv = uv;
#endif`,
    fPars: 'varying float vAge;',
    fColor: 'diffuseColor.a *= smoothstep(0.0, 0.08, vAge) * (1.0 - smoothstep(0.55, 1.0, vAge)); diffuseColor.rgb *= 1.0 + (1.0 - vAge) * 0.35;',
  }), 'puff');
  P.puff = new Pool(bbGeo.clone(), puffMat, 140, { attrs: { aUV: 4, aP: 4 }, name: 'world-smoke', order: 4 });

  for (const k in P) root.add(P[k].mesh);

  // ---------------------------------------------------------------- spawn state
  let density = 1;
  const seq = { L: {}, R: {} };
  let nearCur = 0, farCur = 0;
  const zones = [];      // { level, type, s0, s1, seed, clamped }

  function flush(dist) {
    for (const k in P) P[k].clear();
    nearCur = farCur = Math.floor((dist - BEHIND) / STEP) * STEP;
    seq.L = {}; seq.R = {};
    zones.length = 0;
  }

  // ---- item helpers
  const tint = new THREE.Color();
  function bb(name, s, x, h, sway = 0, tintK = 1) {
    const r = atlas.rects[name]; if (!r) return -1;
    const flip = hs(s, x * 3 + 7) < 0.5 && name !== 'scen_barn' && !name.startsWith('ad') && name !== 'scen_walkup' ? -1 : 1;
    const i = P.bb.add(s, x, 0, 0, 0, h * r.aspect, h, 1, 0);
    if (i < 0) return i;
    P.bb.attr('aUV', i, r.u0, r.v0, r.du, r.dv);
    P.bb.attr('aP', i, flip < 0 ? 1 - r.ax : r.ax, sway, hs(s, 91) * 6.28, flip);
    const ti = T.themeAt(s), vis = env.visFor(ti);
    const v = 0.9 + hs(s, x) * 0.2;
    tint.copy(vis.spriteTint).multiplyScalar(v * tintK);
    if (LOOKS[ti].lights && vis.night > 0.3) {           // warm up sprites standing near a street light
      const side = x > 0 ? 1 : -1, off = side > 0 ? 0 : 16;
      const ds = ((s - off) % 32 + 32) % 32, d = Math.min(ds, 32 - ds), dx = Math.abs(x) - 5;
      const k = Math.exp(-d * d / 60) * Math.exp(-dx * dx / 40) * 1.4;
      tint.r += vis.lampCol.r * k * 0.6; tint.g += vis.lampCol.g * k * 0.6; tint.b += vis.lampCol.b * k * 0.6;
    }
    P.bb.colorC(i, tint);
    return i;
  }
  function halo(s, x, y, size, col, k = 1, blink = 0, z0 = 0) {
    const i = P.halo.add(s, x, y - size / 2, z0, 0, size, size, 1, 0);
    if (i < 0) return i;
    const r = { u0: 0, v0: 0, du: 1, dv: 1 };
    P.halo.attr('aUV', i, r.u0, r.v0, r.du, r.dv);
    P.halo.attr('aP', i, 0.5, blink, hs(s, x) * (blink ? 0 : 1), 1);
    P.halo.color(i, col.r * k, col.g * k, col.b * k);
    return i;
  }
  function glowOf(s) { return env.visFor(T.themeAt(s)).night; }

  // ---- zones (water)
  function zoneAt(s) {
    for (const z of zones) if (s >= z.s0 && s <= z.s1) return z;
    return null;
  }
  function ensureZone(s, ti) {
    const L = LOOKS[ti];
    if (!L.water) return;
    const lv = T.levelAt(s);
    for (let k = 0; k < zones.length; k++) if (zones[k].level === lv.level) return;
    const len = lv.end ? lv.end - lv.start : 420;
    let s0, s1;
    if (L.water === 'river') { s0 = lv.start + Math.min(110, len * 0.22); s1 = s0 + Math.min(300, Math.max(150, len * 0.62)); }
    else { s0 = lv.start + 6; s1 = lv.end ? lv.end + 30 : lv.start + 5000; }
    if (lv.end && L.water === 'river') s1 = Math.min(s1, lv.end - 40);
    zones.push({ level: lv.level, type: L.water, s0, s1, seed: (lv.level * 7.13) % 10, clamped: !!lv.end });
  }
  function updateZones(dist) {
    for (const z of zones) {
      if (!z.clamped && z.level === T.level) {
        z.clamped = true;
        if (z.type === 'lake') z.s1 = T.nextLevelAt + 30;
        else z.s1 = Math.min(z.s1, T.nextLevelAt - 40);
      }
    }
    for (let i = zones.length - 1; i >= 0; i--) if (zones[i].s1 < dist - 60) zones.splice(i, 1);
  }
  function blocked(s, x) {   // is (s, x) on water?
    const z = zoneAt(s);
    if (!z) return false;
    if (z.type === 'river') return Math.abs(x) > 6.0;
    return x > 11.5;
  }

  // ---------------------------------------------------------------- per-step dressing
  function stepFar(s) {
    const ti = T.themeAt(s), L = LOOKS[ti];
    ensureZone(s, ti);
    const night = glowOf(s);
    // trees & bushes
    for (const [kind, x0, x1, every, h0, h1] of L.trees) {
      const want = STEP / every * (kind === 'bush' ? 1 : density);
      for (const side of SIDES) {
        let n = Math.floor(want); if (hs(s, side * 13 + x0 * 7) < want - n) n++;
        for (let k = 0; k < n; k++) {
          const r1 = hs(s + k * 0.37, side * 5 + x0), r2 = hs(s + k * 0.51, side * 9 + x1), r3 = hs(s + k * 0.73, side * 3 + h0);
          const x = side * lerp(x0, x1, r1), ss = s + r2 * STEP;
          if (blocked(ss, x)) continue;
          if (L.loop || (L.water === 'lake' && side > 0 && Math.abs(x) > 11)) continue;
          const name = kind === 'pine' ? 'scen_pine' : kind === 'tree' ? 'scen_tree' : 'bush';
          const h = lerp(h0, h1, r3);
          bb(name, ss, x, h, kind === 'bush' ? 0.02 : 0.035, 1);
        }
      }
    }
    // barns
    if (L.barns && hs(s, 301) < STEP / L.barns) {
      const side = hs(s, 302) < 0.5 ? -1 : 1, x = side * lerp(20, 36, hs(s, 303));
      if (!blocked(s, x)) bb('scen_barn', s, x, lerp(9, 12, hs(s, 304)), 0, 1);
    }
    // walk-ups (painted)
    if (L.walkups && hs(s, 311) < STEP / L.walkups * density) {
      const side = hs(s, 312) < 0.5 ? -1 : 1, x = side * lerp(12, 17, hs(s, 313));
      bb('scen_walkup', s, x, lerp(15, 19, hs(s, 314)), 0, 1);
    }
    // ad billboards
    if (L.ads && hs(s, 321) < STEP / L.ads) {
      const side = hs(s, 322) < 0.6 ? 1 : -1, x = side * lerp(11, 15, hs(s, 323));
      if (!blocked(s, x)) bb('ad' + Math.floor(hs(s, 324) * atlas.ads), s, x, 8.5, 0, 1.05);
    }
    // buildings
    if (L.bld) placeBuildings(s, L, night);
    // turbines
    if (L.turbines && hs(s, 331) < STEP / L.turbines * Math.max(0.6, density)) {
      const side = hs(s, 332) < 0.5 ? -1 : 1, x = side * lerp(34, 130, hs(s, 333));
      const sc = lerp(0.85, 1.25, hs(s, 334));
      const i = P.turb.add(s, x, 0, 0, 0, sc, sc, sc, 3);
      if (i >= 0) {
        P.turb.attr('aGlow', i, night);
        const j = P.rotor.add(s, x, 36.4 * sc, 2.1 * sc, 0, sc, sc, sc, 3);
        if (j >= 0) { P.rotor.data[j] = { ph: hs(s, 335) * 6.28, sp: lerp(0.9, 1.4, hs(s, 336)), sc, x, y: 36.4 * sc, z0: 2.1 * sc }; P.rotor.attr('aGlow', j, 0); }
        halo(s, x, 37.6 * sc, 7, RED, 1.6, 0.8, 0);
      }
    }
    // smoke stacks
    if (L.stacks && hs(s, 341) < STEP / L.stacks) {
      const side = hs(s, 342) < 0.5 ? -1 : 1, x = side * lerp(28, 100, hs(s, 343));
      const sc = lerp(0.8, 1.2, hs(s, 344));
      const i = P.stack.add(s, x, 0, 0, 0, sc, sc, sc, 3);
      if (i >= 0) {
        P.stack.attr('aGlow', i, 1);
        halo(s, x, 50.1 * sc, 6, RED, 1.6, 0.7, 2);
        const n = Math.round(10 * Math.max(0.5, density));
        for (let k = 0; k < n; k++) {
          const j = P.puff.add(s, x, 52.5 * sc, 0, 0, 6 * sc, 6 * sc, 1, 60);
          if (j < 0) break;
          P.puff.attr('aUV', j, 0, 0, 1, 1);
          P.puff.attr('aP', j, 0.5, 0, k / n, 1);
        }
        // flare stack every other
        
      }
    }
    // truss bridge over the river
    const z = zoneAt(s + 14) || zoneAt(s - 14);
    if (z && z.type === 'river' && s % 12 === 0 && s >= z.s0 - 14 && s <= z.s1 + 14) {
      P.truss.add(s, 0, 0, 0, 0, 1, 1, 1, 7);
    }
    // street lights (right side at s = n*32, left side at n*32 + 16)
    if (L.lights) {
      for (const side of SIDES) {
        if (((s - (side > 0 ? 0 : 16)) % 32 + 32) % 32 !== 0) continue;
        if (L.water === 'lake' && side > 0 && blocked(s, 7)) { /* poles still stand on the promenade */ }
        const x = side * 6.75;
        const i = P.pole.add(s, x, 0, 0, side > 0 ? 0 : Math.PI, 1, 1, 1, 1);
        if (i < 0) continue;
        P.pole.attr('aGlow', i, 0);
        const j = P.lamp.add(s, x, 0, 0, side > 0 ? 0 : Math.PI, 1, 1, 1, 1);
        const on = night > 0.3;
        const lc = L.lights === 'sodium' ? SODIUM : L.lights === 'white' ? COOLW : WARMW;
        if (j >= 0) P.lamp.color(j, on ? lc.r * 6 : 0.55, on ? lc.g * 6 : 0.57, on ? lc.b * 6 : 0.6);
        if (on) halo(s, x - side * 2.4, 8.85, 5.5, lc, 0.9, 0, 0);
      }
    }
    // telephone line (right side)
    if (L.tele && ((s - 20) % 40 + 40) % 40 === 0) {
      const x = 10.5;
      if (!blocked(s, x)) {
        const i = P.tele.add(s, x, 0, 0, 0, 1, 1, 1, 1);
        if (i >= 0) P.tele.attr('aGlow', i, 0);
        const j = P.wire.add(s + 20, x, 0, 0, 0, 1, 1, 1, 20);
        if (j >= 0) P.wire.attr('aGlow', j, 0);
      }
    }
    // flags
    if (L.flags && hs(s, 351) < STEP / L.flags) {
      const side = hs(s, 352) < 0.5 ? -1 : 1;
      if (!blocked(s, side * 8)) bb('scen_flag', s, side * lerp(7.6, 9.5, hs(s, 353)), 6.5, 0.05, 1);
    }
    // hay bales
    if (L.hay && hs(s, 361) < STEP / L.hay * density) {
      const side = hs(s, 362) < 0.5 ? -1 : 1;
      bb('hay', s, side * lerp(10, 40, hs(s, 363)), 1.5, 0, 1);
    }
  }

  function placeBuildings(s, L, night) {
    const B = L.bld;
    for (const side of SIDES) {
      const key = side < 0 ? 'L' : 'R';
      if (L.loop) {
        // continuous canyon: next building starts where the previous ended (+ alley)
        const q = seq[key];
        if (q.bld === undefined || q.bld < s - 40) q.bld = s;
        while (q.bld < s + STEP) {
          const d = lerp(B.d[0], B.d[1], hs(q.bld, side * 3 + 1));
          const w = lerp(B.w[0], B.w[1], hs(q.bld, side * 3 + 2));
          const tall = hs(q.bld, side * 3 + 3);
          const h = lerp(B.h[0], B.h[1], tall * tall);
          const st = B.styles[Math.floor(hs(q.bld, side * 3 + 4) * B.styles.length)];
          const sc = q.bld + d / 2;
          const xc = side * (B.x[0] + w / 2);
          addBuilding(sc, xc, w, h, d, st, night, side);
          if (h > 70 && hs(q.bld, 77) < 0.6) {            // antenna + beacon
            const i = P.bld.add(sc, xc, h, 0, 0, 0.6, h * 0.22, 0.6, d / 2);
            if (i >= 0) { P.bld.attr('aW', i, 4, 0, 0, 0); P.bld.color(i, 0.35, 0.36, 0.38); }
            halo(sc, xc, h * 1.22, 5, RED, 1.8, 0.6, 0);
          }
          if (env.neon && hs(q.bld, 78) < 0.85) env.neon(sc + d * 0.35, side * (B.x[0] - 0.35), q.bld);
          if (env.neon && hs(q.bld, 79) < 0.45 && d > 22) env.neon(sc - d * 0.3, side * (B.x[0] - 0.35), q.bld + 3);
          q.bld += d + lerp(2.5, 7, hs(q.bld, side * 3 + 5));
        }
        continue;
      }
      if (hs(s, side * 71 + 400) > STEP / B.every * density) continue;
      const w = lerp(B.w[0], B.w[1], hs(s, side * 3 + 11));
      const d = lerp(B.d[0], B.d[1], hs(s, side * 3 + 12));
      const r = hs(s, side * 3 + 13);
      const h = lerp(B.h[0], B.h[1], r * r);
      const x = side * (lerp(B.x[0], B.x[1], hs(s, side * 3 + 14)) + w / 2);
      if (blocked(s, x)) continue;
      const st = B.styles[Math.floor(hs(s, side * 3 + 15) * B.styles.length)];
      addBuilding(s, x, w, h, d, st, night, side);
    }
  }
  const PALETTE = {
    0: ['#4b5b70', '#58677a', '#3d4a5c', '#6a7688'],          // glass towers (mullion colour)
    1: ['#8a4a36', '#9b5a3f', '#7a3f30', '#a8765a', '#6d4a3a'], // brick
    2: ['#b9b4aa', '#a7a39b', '#c7c1b4', '#8f9296'],          // concrete / limestone
    3: ['#6f757b', '#7d6a5b', '#5d6660', '#8a8f93'],          // corrugated industrial
  };
  const cTmp = new THREE.Color();
  function addBuilding(s, x, w, h, d, st, night, side) {
    const i = P.bld.add(s, x, 0, 0, 0, w, h, d, d / 2);
    if (i < 0) return;
    const pal = PALETTE[st] || PALETTE[2];
    cTmp.set(pal[Math.floor(hs(s, x) * pal.length)]);
    P.bld.colorC(i, cTmp);
    const lit = night > 0.3 ? lerp(0.22, 0.5, hs(s, x + 1)) : 0.04;
    P.bld.attr('aW', i, st, st === 3 ? lit * 0.45 : lit, Math.floor(hs(s, x + 2) * 50), night);
    if (st === 3) {                        // industrial roof stacks + vents
      for (let k = 0; k < 2; k++) {
        if (hs(s, x + 5 + k) < 0.45) continue;
        const sh = lerp(6, 16, hs(s, x + 7 + k));
        const j = P.bld.add(s, x + (hs(s, x + 9 + k) - 0.5) * w * 0.7, h, (hs(s, x + 11 + k) - 0.5) * d * 0.5, 0, 1.4, sh, 1.4, d / 2);
        if (j >= 0) { P.bld.attr('aW', j, 4, 0, 0, 0); P.bld.color(j, 0.3, 0.26, 0.24); }
      }
    }
    // rooftop box / water tank
    if (h < 60 && hs(s, x + 3) < 0.55) {
      const j = P.bld.add(s, x + (hs(s, x + 4) - 0.5) * w * 0.4, h, 0, 0, Math.min(w * 0.35, 5), 2.6, Math.min(d * 0.3, 5), d / 2);
      if (j >= 0) { P.bld.attr('aW', j, 4, 0, 0, 0); P.bld.color(j, 0.42, 0.34, 0.28); }
    }
  }

  function stepNear(s) {
    const ti = T.themeAt(s), L = LOOKS[ti];
    ensureZone(s, ti);
    const night = glowOf(s);
    const z = zoneAt(s);
    const onBridge = z && z.type === 'river';
    // rails
    if (!onBridge) {
      if (L.rail === 'guard' && s % 4 === 0) {
        for (const side of SIDES) {
          if (L.water === 'lake' && side > 0 && z) continue;
          const i = P.rail.add(s + 2, side * 5.95, 0, 0, side > 0 ? 0 : Math.PI, 1, 1, 1, 2);
          if (i >= 0) P.rail.attr('aGlow', i, night);
        }
      } else if (L.rail === 'wood' && s % 4 === 0) {
        for (const side of SIDES) {
          const i = P.wood.add(s + 2, side * 6.4, 0, 0, side > 0 ? 0 : Math.PI, 1, 1, 1, 2);
          if (i >= 0) P.wood.attr('aGlow', i, 0);
        }
      } else if (L.rail === 'chain' && s % 4 === 0) {
        for (const side of SIDES) {
          const i = P.chainP.add(s + 2, side * 6.5, 0, 0, side > 0 ? 0 : Math.PI, 1, 1, 1, 2);
          if (i >= 0) P.chainP.attr('aGlow', i, 0);
          P.chain.add(s + 2, side * 6.5, 0, 0, 0, 1, 1, 1, 2);
        }
      }
    }
    // delineators
    if (L.delin && !L.rail && s % 16 === 8) {
      for (const side of SIDES) {
        const i = P.delin.add(s, side * 6.0, 0, 0, 0, 1, 1, 1, 0);
        if (i >= 0) P.delin.attr('aGlow', i, night);
      }
    }
    // corn: swaying clumps along the field edge + canopy tiles
    if (L.corn) {
      const rows = density < 0.6 ? 4 : density < 0.9 ? 6 : 8;
      for (const side of SIDES) {
        for (let r = 0; r < rows; r++) {
          const x0 = 6.2 + r * 0.85;
          const n = 1 + (hs(s, r * 11 + side) < 0.45 ? 1 : 0);
          for (let k = 0; k < n; k++) {
            const ss = s + k + hs(s + k, r * 7 + side) * 0.9;
            const hh = lerp(0.95, 1.2, hs(ss, 17 + r)) * (r === 0 ? 0.9 : 1);
            const i = P.corn.add(ss, side * (x0 + hs(ss, r + 3) * 0.35), 0, 0, hs(ss, 23) * 6.28, 1, hh, 1, 1);
            if (i >= 0) { const v = 0.8 + hs(ss, 29) * 0.35; P.corn.color(i, v, v * 0.98, v * 0.9); }
          }
        }
        if (s % 12 === 0) P.canopy.add(s + 6, 0, 0, 0, side > 0 ? 0 : Math.PI, 1, 1, 1, 6);
      }
    }
  }

  // ---------------------------------------------------------------- per frame
  const rotM = new THREE.Matrix4(), rotS = new THREE.Matrix4();
  function cullAll(dist) { for (const k in P) P[k].cull(dist, k === 'puff' ? BEHIND + 60 : BEHIND); }
  function update(dist, dt, time) {
    updateZones(dist);
    cullAll(dist);
    while (farCur < dist + FAR_AHEAD) { stepFar(farCur); farCur += STEP; }
    while (nearCur < dist + NEAR_AHEAD) { stepNear(nearCur); nearCur += STEP; }
    for (const k in P) P[k].sync(dist, k === 'puff' ? BEHIND + 60 : BEHIND);
    // spinning rotors: rebuild their matrices
    const R = P.rotor, a = R.mesh.instanceMatrix.array;
    for (let i = 0; i < R.n; i++) {
      const d = R.data[i]; if (!d) continue;
      const ang = d.ph + time * d.sp * WU.uWind.value;
      rotM.makeRotationZ(ang); rotS.makeScale(d.sc, d.sc, d.sc); rotM.multiply(rotS);
      rotM.setPosition(d.x, d.y, d.z0 - (R.s[i] - dist));
      rotM.toArray(a, i * 16);
    }
  }

  return {
    P, atlas, zones, flush, update, cullAll, bb, halo, blocked, zoneAt,
    setDensity(k) { density = k; },
    setVisual(vis) {
      glowK.value = 1.0 + vis.night * 3.0;
      bldU.uGlass.value.copy(vis.glass);
      bldU.uNightK.value = 1;
    },
    farCur() { return farCur; },
  };
}
