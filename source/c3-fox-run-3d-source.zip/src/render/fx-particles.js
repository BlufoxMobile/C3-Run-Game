// GPU PARTICLE POOL — one InstancedBufferGeometry of quads = ONE draw call per pool.
//
// Particles are stateless on the GPU: the CPU writes a particle's birth parameters once
// into a ring buffer (only the dirty range is uploaded), and the vertex shader evaluates
// the closed-form ballistic motion with linear drag at (uTime - birth). No per-frame CPU
// work per particle, no allocation.
//
// Per particle:
//   aP0   origin: anchor 0 world  -> (x, y, s)   track distance, scrolls with sim.dist
//                 anchor 1 fox    -> (x, y, z)   render space, does NOT scroll
//                 anchor 2 camera -> (dx, dy, dz) offset from cameraPosition (speed lines)
//   aV0   initial velocity (render axes, m/s)
//   aT    birth, life, size0, size1
//   aCol  linear HDR rgb (values > ~1.3 bloom on 'high'), alpha
//   aPhys gravity (m/s², negative = down), drag (1/s), spin (rad/s), floor y
//   aMode shape, orient, anchor, stretch
// shapes: 0 glow · 1 star sparkle · 2 ring · 3 confetti rect · 4 soft puff · 5 streak · 6 shard
// orient: 0 billboard (spins) · 1 velocity-stretched · 2 flat on the ground (XZ) · 3 tumbling flutter
// The bend (BEND_GLSL_*) is applied to every quad, like every other material in the scene.
import * as THREE from 'three';
import { BEND, BEND_GLSL_PARS, BEND_GLSL_APPLY } from '../core/bend.js';

const VERT = /* glsl */`
${BEND_GLSL_PARS}
uniform float uTime;
uniform float uDist;
uniform float uScroll;
uniform float uPx;       // view-space metres per pixel at depth 1 (2 tan(fov/2) / bufferHeight)
attribute vec3 aP0;
attribute vec3 aV0;
attribute vec4 aT;
attribute vec4 aCol;
attribute vec4 aPhys;
attribute vec4 aMode;
varying vec2 vUv;
varying vec4 vCol;
varying float vShape;
varying float vLife;
varying float vShade;
void main() {
  float age = uTime - aT.x;
  if (age < 0.0 || age >= aT.y) { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); vCol = vec4(0.0); return; }
  float u = age / aT.y;
  float k = max(aPhys.y, 0.0001);
  float e = exp(-k * age);
  vec3 vt = vec3(0.0, aPhys.x / k, 0.0);
  vec3 disp = vt * age + (aV0 - vt) * (1.0 - e) / k;
  vec3 vel = vt + (aV0 - vt) * e;
  vec3 wp;
  if (aMode.z < 0.5) { wp = vec3(aP0.x, aP0.y, uDist - aP0.z); vel.z += uScroll; }
  else if (aMode.z < 1.5) { wp = aP0; }
  else { wp = cameraPosition + aP0; }
  wp += disp;
  if (wp.y < aPhys.w) { wp.y = aPhys.w; vel.y = 0.0; }
  float size = mix(aT.z, aT.w, u);
  vec2 c = position.xy;
  vShade = 1.0;
  float energy = 1.0;
  vec4 mvPosition;
  if (aMode.y > 1.5 && aMode.y < 2.5) {
    float ang = aPhys.z * age;
    float cs = cos(ang), sn = sin(ang);
    vec2 r = vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs) * size;
    mvPosition = viewMatrix * vec4(wp + vec3(r.x, 0.0, r.y), 1.0);
  } else {
    mvPosition = viewMatrix * vec4(wp, 1.0);
    if (aMode.y > 0.5 && aMode.y < 1.5) {
      vec3 vv = mat3(viewMatrix) * vel;
      vec3 p2 = mvPosition.xyz + vv * 0.02;
      vec2 s1 = mvPosition.xy / max(-mvPosition.z, 0.05);
      vec2 s2 = p2.xy / max(-p2.z, 0.05);
      vec2 d = s2 - s1;
      float dl = length(d);
      vec2 dir = dl > 1e-6 ? d / dl : vec2(0.0, 1.0);
      vec2 perp = vec2(-dir.y, dir.x);
      float len = size + length(vv) * aMode.w;
      // never thinner than ~1.6 px: widen and dim instead (keeps distant streaks visible, no shimmer)
      float across = max(size, -mvPosition.z * uPx * 1.6);
      energy = size / across;
      mvPosition.xy += dir * (c.y - 0.5) * len + perp * c.x * across;
    } else {
      float ang = aPhys.z * age + aT.x * 7.31;
      float cs = cos(ang), sn = sin(ang);
      vec2 cc = c;
      if (aMode.y > 2.5) { float f = cos(aPhys.z * 1.7 * age + aT.x * 13.0); cc.x *= f; vShade = 0.55 + 0.45 * abs(f); }
      float sz = max(size, -mvPosition.z * uPx * 2.5);
      energy = (size * size) / (sz * sz);
      mvPosition.xy += vec2(cc.x * cs - cc.y * sn, cc.x * sn + cc.y * cs) * sz;
    }
  }
  ${BEND_GLSL_APPLY}
  gl_Position = projectionMatrix * mvPosition;
  vUv = c + 0.5;
  vCol = vec4(aCol.rgb, aCol.a * energy);
  vShape = aMode.x;
  vLife = u;
}
`;

const FRAG = /* glsl */`
varying vec2 vUv;
varying vec4 vCol;
varying float vShape;
varying float vLife;
varying float vShade;
void main() {
  vec2 p = vUv * 2.0 - 1.0;
  float r2 = dot(p, p);
  float a = 0.0;
  float s = vShape;
  if (s < 0.5) {                       // glow
    a = exp(-r2 * 4.5);
  } else if (s < 1.5) {                // 4-point star sparkle
    float core = exp(-r2 * 14.0);
    float sx = exp(-abs(p.y) * 22.0) * max(0.0, 1.0 - abs(p.x));
    float sy = exp(-abs(p.x) * 22.0) * max(0.0, 1.0 - abs(p.y));
    a = core + (sx + sy) * 0.9;
  } else if (s < 2.5) {                // ring (thins as it expands)
    float r = sqrt(r2);
    float w = mix(0.26, 0.06, vLife);
    a = smoothstep(1.0 - w - 0.08, 1.0 - w, r) * (1.0 - smoothstep(0.93, 1.0, r));
  } else if (s < 3.5) {                // confetti / chip
    a = step(abs(p.x), 0.92) * step(abs(p.y), 0.55);
  } else if (s < 4.5) {                // soft puff
    a = (1.0 - smoothstep(0.15, 1.0, sqrt(r2))) * 0.85;
  } else if (s < 5.5) {                // streak (head at +y)
    a = exp(-p.x * p.x * 5.0) * smoothstep(-1.0, 0.7, p.y) * (1.0 - smoothstep(0.8, 1.0, p.y));
  } else {                             // shard (triangle, bright edge)
    float tri = step(abs(p.x), (1.0 - p.y) * 0.5) * step(-1.0, p.y);
    float edge = smoothstep(0.34, 0.5, abs(p.x) / max(0.001, (1.0 - p.y)));
    a = tri * (0.55 + 0.45 * edge);
  }
  float fade = smoothstep(0.0, 0.05, vLife) * (1.0 - smoothstep(0.62, 1.0, vLife));
  float alpha = a * vCol.a * fade;
#ifdef FX_ADDITIVE
  gl_FragColor = vec4(vCol.rgb * alpha * vShade, 1.0);
#else
  if (alpha < 0.02) discard;
  gl_FragColor = vec4(vCol.rgb * vShade, alpha);
#endif
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}
`;

/** Reusable emit record — fill the fields, call pool.emit(P). */
export function makeP() {
  return { shape: 0, orient: 0, anchor: 1, x: 0, y: 0, z: 0, vx: 0, vy: 0, vz: 0, life: 0.5, s0: 0.2, s1: 0.0,
    r: 1, g: 1, b: 1, a: 1, grav: 0, drag: 0, spin: 0, floor: -100, stretch: 0 };
}

export function createParticlePool(count, additive, name) {
  const geo = new THREE.InstancedBufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-0.5, -0.5, 0, 0.5, -0.5, 0, 0.5, 0.5, 0, -0.5, 0.5, 0]), 3));
  geo.setIndex([0, 1, 2, 0, 2, 3]);
  const mk = (n) => {
    const a = new THREE.InstancedBufferAttribute(new Float32Array(count * n), n);
    a.setUsage(THREE.DynamicDrawUsage);
    return a;
  };
  const A = { aP0: mk(3), aV0: mk(3), aT: mk(4), aCol: mk(4), aPhys: mk(4), aMode: mk(4) };
  for (const k in A) {
    geo.setAttribute(k, A[k]);
    A[k].userData = { full: false };
    A[k].onUpload(function () { this.userData.full = false; });
  }
  const fullUpload = a => { a.clearUpdateRanges(); a.userData.full = true; a.needsUpdate = true; };
  // everything starts dead
  for (let i = 0; i < count; i++) { A.aT.array[i * 4] = -1e6; A.aT.array[i * 4 + 1] = 0; }
  geo.instanceCount = count;
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);

  const uniforms = {
    uTime: { value: 0 }, uDist: { value: 0 }, uScroll: { value: 0 }, uPx: { value: 0.002 },
    uBendY: BEND.uniforms.uBendY, uBendX: BEND.uniforms.uBendX, uBendStart: BEND.uniforms.uBendStart,
  };
  const mat = new THREE.ShaderMaterial({
    name: 'fx-' + name, uniforms, vertexShader: VERT, fragmentShader: FRAG,
    transparent: true, depthWrite: false, depthTest: true, side: THREE.DoubleSide,   // stretched quads can flip winding
    blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    defines: additive ? { FX_ADDITIVE: 1 } : {},
    fog: false,
  });
  mat.userData.__bent = true;     // bend is built into the shader
  const mesh = new THREE.Mesh(geo, mat);
  mesh.name = 'fx-' + name;
  mesh.frustumCulled = false;
  mesh.renderOrder = additive ? 20 : 19;

  let head = 0, lo = Infinity, hi = -1;
  const pool = {
    mesh, uniforms, count, time: 0,
    emit(P) {
      const i = head;
      head = (head + 1) % count;
      if (i < lo) lo = i; if (i > hi) hi = i;
      let o = i * 3;
      A.aP0.array[o] = P.x; A.aP0.array[o + 1] = P.y; A.aP0.array[o + 2] = P.z;
      A.aV0.array[o] = P.vx; A.aV0.array[o + 1] = P.vy; A.aV0.array[o + 2] = P.vz;
      o = i * 4;
      const t = A.aT.array; t[o] = pool.time; t[o + 1] = P.life; t[o + 2] = P.s0; t[o + 3] = P.s1;
      const c = A.aCol.array; c[o] = P.r; c[o + 1] = P.g; c[o + 2] = P.b; c[o + 3] = P.a;
      const ph = A.aPhys.array; ph[o] = P.grav; ph[o + 1] = P.drag; ph[o + 2] = P.spin; ph[o + 3] = P.floor;
      const m = A.aMode.array; m[o] = P.shape; m[o + 1] = P.orient; m[o + 2] = P.anchor; m[o + 3] = P.stretch;
      return i;
    },
    /** upload only what changed since last frame, then set the clock uniforms */
    commit(dist, scroll, px) {
      // Ranges ACCUMULATE until three uploads them (it merges + clears them on upload), so
      // several update() calls per rendered frame (app.advance, catch-up steps) lose nothing.
      if (hi >= 0) {
        for (const k in A) {
          const a = A[k], n = a.itemSize;
          if (a.userData.full) { /* a full upload is already queued */ }
          else if (a.updateRanges.length >= 24) fullUpload(a);
          else a.addUpdateRange(lo * n, (hi - lo + 1) * n);
          a.needsUpdate = true;
        }
      }
      lo = Infinity; hi = -1;
      uniforms.uTime.value = pool.time;
      uniforms.uDist.value = dist;
      uniforms.uScroll.value = scroll;
      if (px > 0) uniforms.uPx.value = px;
    },
    /** keep float precision: shift every birth time when the clock gets big */
    rebase(offset) {
      const t = A.aT.array;
      for (let i = 0; i < count; i++) t[i * 4] -= offset;
      pool.time -= offset;
      fullUpload(A.aT);
    },
    killAll() {
      const t = A.aT.array;
      for (let i = 0; i < count; i++) t[i * 4] = -1e6;
      fullUpload(A.aT);
    },
    dispose() { geo.dispose(); mat.dispose(); },
  };
  return pool;
}
