// QUALITY — tier detection + frame-time watchdog.
// createQuality(ctx) -> { tier, dprCap, sample(frameMs), onChange(fn) }   (+ level, gpu, forced, force(tier))
//
// Ladder (one rung per step, the contract's tier caps respected):
//   0 low@1.0   1 low@1.25   2 med@1.25   3 med@1.5   4 high@1.5   5 high@2
// Initial rung from the unmasked GPU string (WEBGL_debug_renderer_info), CPU cores,
// deviceMemory and screen size:
//   Apple GPU / Adreno 6xx+ / Immortalis / desktop GPUs -> high
//   Mali / PowerVR / Adreno 5xx / unknown mobile        -> med
//   SwiftShader / llvmpipe / software / very old GPUs  -> low
// Watchdog: EMA frame time > 20 ms for ~2 s -> step down one rung (2 s settle after every
// change, first 3 s after boot ignored, samples > 250 ms ignored as hitches/tab switches).
// Step UP: at most once per session, only after 15 s of steady <= 17.8 ms frames, never
// above the detected rung + 1, and if we have to step down again within 12 s of that
// upgrade the ladder is locked (no flapping). ?tier=low|med|high forces a tier (watchdog off).
// Every change is logged with console.info('[quality] ...').

const LADDER = [
  { tier: 'low', dpr: 1.0 }, { tier: 'low', dpr: 1.25 },
  { tier: 'med', dpr: 1.25 }, { tier: 'med', dpr: 1.5 },
  { tier: 'high', dpr: 1.5 }, { tier: 'high', dpr: 2 },
];
const TOP_OF = { low: 1, med: 3, high: 5 };

function gpuString(renderer) {
  try {
    const gl = renderer.getContext();
    let s = String(gl.getParameter(gl.RENDERER) || '');
    // Chrome/Safari report a generic string here; Firefox reports the (sanitised) real one.
    if (!s || /^(webkit|mozilla)\b.*webgl|^webkit webgl$/i.test(s)) {
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      if (ext) s = String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || s);
    }
    return s;
  } catch (e) { return ''; }
}

export function detectTier(renderer) {
  const gpu = gpuString(renderer);
  const g = gpu.toLowerCase();
  const nav = typeof navigator !== 'undefined' ? navigator : {};
  const ua = String(nav.userAgent || '');
  const mobile = /android|iphone|ipad|ipod|mobile/i.test(ua) || (nav.maxTouchPoints > 1 && /macintosh/i.test(ua));
  const cores = nav.hardwareConcurrency || 4;
  const mem = nav.deviceMemory || 0;           // Chrome only (GB, rounded)
  let tier = mobile ? 'med' : 'high';
  let why = 'default';

  if (/swiftshader|llvmpipe|softpipe|software|basic render|microsoft basic/.test(g)) { tier = 'low'; why = 'software GPU'; }
  else if (/apple/.test(g)) { tier = 'high'; why = 'Apple GPU'; }
  else if (/adreno/.test(g)) {
    const m = g.match(/adreno[^0-9]*(\d{3})/);
    const n = m ? +m[1] : 0;
    tier = n >= 600 ? 'high' : n >= 500 ? 'med' : 'low'; why = 'Adreno ' + (n || '?');
  } else if (/immortalis/.test(g)) { tier = 'high'; why = 'Immortalis'; }
  else if (/mali/.test(g)) {
    tier = /mali-(4|t[67])/.test(g) ? 'low' : 'med'; why = 'Mali';
  } else if (/powervr|sgx/.test(g)) { tier = /sgx/.test(g) ? 'low' : 'med'; why = 'PowerVR'; }
  else if (/nvidia|geforce|quadro|radeon|amd|intel|iris|uhd|arc/.test(g)) {
    tier = mobile ? 'med' : 'high'; why = 'desktop GPU';
    if (/intel.*hd graphics( [2-5]\d{2,3})?$/.test(g) || /gma/.test(g)) { tier = 'med'; why = 'old Intel iGPU'; }
  } else if (!gpu) { why = 'unknown GPU'; }

  // CPU / memory caps
  if (mobile && cores <= 4 && tier === 'high') { tier = 'med'; why += ', <=4 cores'; }
  if (mem && mem <= 2) { tier = 'low'; why += ', <=2 GB'; }
  else if (mem && mem <= 4 && tier === 'high' && mobile) { tier = 'med'; why += ', <=4 GB'; }

  let level = TOP_OF[tier];
  // very large drawing buffers: start one rung lower (high@1.5 instead of high@2)
  try {
    const w = window.screen ? window.screen.width : window.innerWidth;
    const h = window.screen ? window.screen.height : window.innerHeight;
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    if (tier === 'high' && w * h * dpr * dpr > 4.2e6) { level = 4; why += ', huge screen'; }
  } catch (e) { /* ignore */ }
  return { tier, level, gpu, why, software: /software|swiftshader|llvmpipe/.test(why + g) };
}

export function createQuality(ctx) {
  const det = detectTier(ctx.renderer);
  let forced = null;
  let forcedBy = '';
  try {
    const q = new URLSearchParams(window.location.search).get('tier');
    if (q && TOP_OF[q] !== undefined) { forced = q; forcedBy = '?tier'; }
  } catch (e) { /* ignore */ }
  if (!forced && ctx.forceTier && TOP_OF[ctx.forceTier] !== undefined) { forced = ctx.forceTier; forcedBy = 'ctx.forceTier'; }

  const startLevel = forced ? TOP_OF[forced] : det.level;
  const maxLevel = forced ? startLevel : (det.software ? startLevel : Math.min(LADDER.length - 1, startLevel + 1));
  let level = startLevel;
  const fns = [];

  let ema = 16.7, warm = 3.0, slowT = 0, fastT = 0;
  let upgraded = false, upgradeAge = 1e9, locked = false;

  const q = {
    get tier() { return LADDER[level].tier; },
    get dprCap() { return LADDER[level].dpr; },
    get level() { return level; },
    gpu: det.gpu, reason: det.why, forced: !!forced,
    onChange(fn) { fns.push(fn); return fn; },
    /** dev: force a tier (disables the watchdog) */
    force(tier) { if (TOP_OF[tier] === undefined) return; forced = tier; set(TOP_OF[tier], 'forced'); },
    sample(frameMs) {
      if (forced || !(frameMs > 0)) return;
      if (frameMs > 250) return;                       // tab switch / GC hitch / breakpoint
      const dt = frameMs / 1000;
      upgradeAge += dt;
      if (warm > 0) { warm -= dt; ema = 16.7; return; }
      ema += (frameMs - ema) * 0.06;
      if (ema > 20) { slowT += dt; } else { slowT = Math.max(0, slowT - dt * 2); }
      if (slowT > 2 && level > 0) {
        if (upgraded && upgradeAge < 12) locked = true;
        set(level - 1, `sustained ${ema.toFixed(1)} ms frames`);
        return;
      }
      if (!locked && !upgraded && level < maxLevel && ema <= 17.8) fastT += dt; else fastT = 0;
      if (fastT > 15) { upgraded = true; upgradeAge = 0; set(level + 1, '15 s of headroom'); }
    },
  };
  function set(l, why) {
    l = Math.max(0, Math.min(LADDER.length - 1, l));
    if (l === level && why !== 'forced') return;
    const prevTier = LADDER[level].tier;
    level = l; warm = 2.0; slowT = 0; fastT = 0; ema = 16.7;
    console.info(`[quality] ${why}: ${prevTier} -> ${q.tier} @ dpr ${q.dprCap}`);
    for (const fn of fns) { try { fn(q.tier, q.dprCap, q); } catch (e) { console.error(e); } }
  }
  console.info(`[quality] start ${q.tier} @ dpr ${q.dprCap} (${forced ? 'forced by ' + forcedBy : det.why}; GPU "${det.gpu || 'n/a'}")`);
  return q;
}
