// FEEL — hit-stop and slow-mo. createFeel() -> { onEvent(ev, sim), timeScale(realDt) -> simDt }
//
// All timers decay on the REAL dt handed to timeScale() (the wall-clock frame delta), never
// on sim time, so a slow-mo can't extend itself. Effects combine by taking the slowest.
//
//   hit-stop (sim frozen):  combo milestone 20 ms · +$100 bonus 30 ms · power-up 40 ms ·
//                           smash 30 ms · bump 35 ms · shieldBreak 50 ms · fatal hit 70 ms
//   near miss:              0.13 s at 0.55x
//   boostStart:             0.2 s dilation, 0.65x easing back to 1x
//   fatal hit:              after the 70 ms freeze, 1.0 -> 0.15 over 0.25 s, hold 0.45 s,
//                           ease back to 1.0 over 0.4 s (so the sim's dying phase still ends
//                           ~1.5 s after impact instead of 6x longer).
// Attract mode (sim.mode 'ready') never hitches. Extra (non-contract) API: reset(), scale.
import { FXBUS, easeOut } from './fx-bus.js';

export function createFeel() {
  let stop = 0;                 // seconds of freeze left
  let slow = 0;                 // near-miss sliver seconds left
  let boostT = -1;              // seconds since boostStart (-1 = off)
  let deathT = -1;              // seconds since the fatal hit (-1 = off)
  let deathDelay = 0;           // freeze before the death ramp

  const feel = {
    scale: 1,
    reset() { stop = 0; slow = 0; boostT = -1; deathT = -1; deathDelay = 0; feel.scale = 1; },
    onEvent(ev, sim) {
      const t = ev.type;
      if (t === 'start' || t === 'death') { feel.reset(); return; }
      if (sim && sim.mode === 'ready') return;
      switch (t) {
        case 'combo': stop = Math.max(stop, 0.02); break;
        case 'bonus': stop = Math.max(stop, 0.03); break;
        case 'powerup': stop = Math.max(stop, 0.04); break;
        case 'smash': stop = Math.max(stop, 0.03); break;
        case 'bump': stop = Math.max(stop, 0.035); break;
        case 'shieldBreak': stop = Math.max(stop, 0.05); break;
        case 'nearMiss': slow = Math.max(slow, 0.13); break;
        case 'boostStart': boostT = 0; break;
        case 'hit': stop = Math.max(stop, 0.07); deathDelay = 0.07; deathT = 0; break;
        default: break;
      }
    },
    timeScale(realDt) {
      if (!(realDt > 0)) return 0;
      // hit-stop eats the first part of this frame
      const frozen = Math.min(stop, realDt);
      stop = Math.max(0, stop - realDt);
      let s = 1;
      if (slow > 0) { s = Math.min(s, 0.55); slow = Math.max(0, slow - realDt); }
      if (boostT >= 0) {
        const u = boostT / 0.2;
        if (u >= 1) boostT = -1; else { s = Math.min(s, 0.65 + 0.35 * easeOut(u)); boostT += realDt; }
      }
      if (deathT >= 0) {
        let d = 1;
        const t = deathT - deathDelay;
        if (t < 0) d = 1;
        else if (t < 0.25) d = 1 - 0.85 * easeOut(t / 0.25);
        else if (t < 0.7) d = 0.15;
        else if (t < 1.1) { const u = (t - 0.7) / 0.4; d = 0.15 + 0.85 * u * u; }
        else { d = 1; deathT = -1; }
        s = Math.min(s, d);
        if (deathT >= 0) deathT += realDt;
      }
      const simDt = (realDt - frozen) * s;
      feel.scale = simDt / realDt;
      FXBUS.timeScale = feel.scale;
      return simDt;
    },
  };
  return feel;
}
