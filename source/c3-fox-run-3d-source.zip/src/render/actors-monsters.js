// ACTORS · the commission killers. All five painted strips are cleaned into ONE atlas so every
// monster on screen is a single instanced draw call; name tags are a second. Camera-facing,
// breathing, frame-animated, hot pixels (eyes / lava / scanner) pushed into bloom, a rim/edge
// light in the monster's signature colour, a lunge + rear-up as the fox closes in, drift arrows
// painted on the road, and a spinning, flashing tumble when smashed by shield or boost.
import * as THREE from 'three';
import { zOf, LANE_X } from '../core/constants.js';
import { projectBent as coreProjectBent } from '../core/bend.js';
import { Atlas, SpriteBatch, createSpriteMaterial, loadSheet } from './actors-sprites.js';
import { TAU, clamp, lerp, smooth, hash, canvas, fitText, roundRect, FONT } from './actors-common.js';

export const MON_COLOR = {
  chargeback: '#ff6a3d', exception: '#ff9a26', falloff: '#ff3f7a', nonusage: '#8fb2ff', retail360: '#3fe6ff',
};
const HOVER = { falloff: 0.32, retail360: 0.04 };
const SCALE = 0.625;                            // monster sheets are downscaled: 320 px tall is plenty

function buildTags(MONSTERS, MONSTER_LABEL) {
  const TW = 512, TH = 104;
  const cv = canvas(TW, TH * MONSTERS.length), g = cv.getContext('2d');
  const frames = {};
  MONSTERS.forEach((k, i) => {
    const y = i * TH, col = MON_COLOR[k] || '#ff4040';
    g.save();
    g.shadowColor = col; g.shadowBlur = 14;
    roundRect(g, 10, y + 12, TW - 20, TH - 24, 30);
    const bg = g.createLinearGradient(0, y + 12, 0, y + TH - 12);
    bg.addColorStop(0, '#2a0f18'); bg.addColorStop(1, '#10060c');
    g.fillStyle = bg; g.fill();
    g.shadowBlur = 0;
    g.lineWidth = 6; g.strokeStyle = col; g.stroke();
    g.restore();
    // warning triangle
    g.save(); g.translate(52, y + TH / 2 + 2);
    g.fillStyle = col; g.beginPath(); g.moveTo(0, -24); g.lineTo(23, 17); g.lineTo(-23, 17); g.closePath(); g.fill();
    g.fillStyle = '#1a0710'; g.fillRect(-3, -11, 6, 17); g.fillRect(-3, 9, 6, 5);
    g.restore();
    g.fillStyle = '#ffffff'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.shadowColor = col; g.shadowBlur = 10;
    fitText(g, MONSTER_LABEL[k] || k.toUpperCase(), TW / 2 + 26, y + TH / 2 + 3, TW - 130, 50, '900', 'italic');
    g.shadowBlur = 0;
    frames[k] = { rect: [0, 1 - (i + 1) * TH / cv.height, 1, 1 - i * TH / cv.height], w: TW, h: TH, ax: TW / 2, ay: TH };
  });
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return { tex, frames, aspect: TW / TH };
}

export function createMonsters(ctx, S) {
  const { scene, assets, MONSTERS, MONSTER_LABEL } = ctx;
  const env = S.env;
  const atlas = new Atlas(2048);
  const mat = createSpriteMaterial({ mode: 'lit', alphaTest: 0.34, edge: true });
  mat.uniforms.uGlowLo.value = 0.66;
  const batch = new SpriteBatch(mat, 40, 'monsters');
  batch.mesh.renderOrder = -2;
  atlas.onChange(tex => { mat.uniforms.map.value = tex; mat.uniforms.uTexel.value.set(1 / atlas.W, 1 / atlas.H); });
  const tags = buildTags(MONSTERS, MONSTER_LABEL);
  const tagMat = createSpriteMaterial({ mode: 'flat', alphaTest: 0.01, fogK: 0.35 });
  tagMat.depthWrite = false;
  tagMat.uniforms.map.value = tags.tex;
  const tagBatch = new SpriteBatch(tagMat, 40, 'monsterTags');
  tagBatch.mesh.renderOrder = 4;
  scene.add(batch.mesh, tagBatch.mesh);

  const kinds = {};                         // kind -> { frames, ppm, fps, edge: Color }
  let chain = Promise.resolve();
  for (const k of MONSTERS) {
    const key = 'sprites/mon_' + k;
    const meta = assets.SPRITE_META['mon_' + k] || {};
    kinds[k] = { frames: [], ppm: 0, fps: meta.fps || 8, edge: new THREE.Color(MON_COLOR[k] || '#ff4040'), hover: HOVER[k] || 0 };
    chain = chain.then(() => loadSheet(assets, key, atlas, { scale: SCALE })).then(fr => {
      const K = kinds[k];
      K.frames = fr;
      if (fr.length) {
        const hMax = Math.max(...fr.map(f => f.by1 - f.by0)), wMax = Math.max(...fr.map(f => f.bx1 - f.bx0));
        K.ppmH = hMax; K.ppmW = wMax;
      }
    });
  }
  const ready = chain.catch(e => console.warn('[actors] monster sheets', e && e.message)).then(() => atlas.seal());

  // smashed monsters tumble on as free debris (the entity may be culled mid-flight)
  const debris = [];
  const seen = new Set();
  const TAGS = Array.from({ length: 24 }, () => ({ f: null, x: 0, y: 0, z: 0, w: 1, h: 1, a: 0, d: 0, yaw: 0, sx: 0, sy: 0, hw: 0, hh: 0 }));
  const TAGS_ORDER = [];
  const _v = new THREE.Vector3(), _o = { x: 0, y: 0, visible: false };
  const projectBent = ctx.projectBent || coreProjectBent;
  let quality = 'high';

  function sizeFor(K, e) {
    // content height -> e.h (2.1 m), but never wider than ~2.5 m
    const targetH = (e.h || 2.1) * 1.02;
    let ppm = K.ppmH / targetH;
    if (K.ppmW / ppm > 2.55) ppm = K.ppmW / 2.55;
    return ppm;
  }

  function smash(e, sim, t) {
    if (seen.has(e.id)) return;
    if (seen.size > 256) seen.clear();
    seen.add(e.id);
    const K = kinds[e.kind]; if (!K || !K.frames.length) return;
    const dir = e.x > sim.player.x + 0.3 ? 1 : e.x < sim.player.x - 0.3 ? -1 : (hash(e.id) > 0.5 ? 1 : -1);
    debris.push({ kind: e.kind, x: e.x, s: e.s + (e.len || 0.8) / 2, h: e.h, t0: t, dir, spin: (5 + hash(e.id + 3) * 5) * dir, f: Math.floor(hash(e.id) * 4) });
    if (debris.length > 12) debris.shift();
  }

  let lastT = 0;
  function onEvent(ev, sim) {
    if (ev.type === 'smash' && ev.id != null) {
      const e = sim.obstacles.find(o => o.id === ev.id);
      if (e && e.type === 'monster') smash(e, sim, lastT);
      else if (!e && ev.kind && kinds[ev.kind]) smash({ id: ev.id, kind: ev.kind, x: ev.x, s: ev.s, len: 0, h: 2.1 }, sim, lastT);
    }
    if (ev.type === 'start') { debris.length = 0; seen.clear(); }
  }

  function update(sim, frame) {
    const t = frame.time; lastT = t;
    const cam = frame.camera;
    batch.begin(); tagBatch.begin();
    const u = mat.uniforms;
    u.uLight.value.copy(env.spriteLight).multiplyScalar(1.02);
    u.uRim.value.copy(env.rim).multiplyScalar(0.9);
    u.uRimOff.value.set(env.keySide * 2.6 / atlas.W, 1.4 / Math.max(1, atlas.H));
    const edgeStrength = lerp(0.55, 1.35, env.night);
    const camZ = cam.position.z;
    let nTag = 0;
    for (const e of sim.obstacles) {
      if (e.type !== 'monster') continue;
      if (e.smashed) { smash(e, sim, t); continue; }
      const K = kinds[e.kind]; if (!K || !K.frames.length) continue;
      const sMid = e.s + (e.len || 0.8) / 2;
      const z = zOf(sMid, sim.dist);
      if (z > camZ - 0.8) continue;
      const d = -z;
      const ph = hash(e.id);
      const near = d > -0.5 ? smooth(17, 5, d) : 0;
      const fps = K.fps * (1 + near * 0.9);
      const fi = Math.floor(t * fps + ph * 4) % K.frames.length;
      const f = K.frames[fi];
      const ppm = sizeFor(K, e);
      const br = Math.sin(t * 3.1 + ph * TAU);
      const sc = (1 + 0.11 * near) * (1 + 0.16 * smooth(28, 85, d));      // slight far exaggeration for readability
      const w = f.w / ppm * sc * (1 - 0.02 * br), h = f.h / ppm * sc * (1 + 0.035 * br);
      const hop = d > 9 && d < 14 ? Math.sin(Math.PI * (14 - d) / 5) * 0.3 : 0;
      let x = e.x, roll = 0;
      let driftDir = 0;
      if (e.drift) {
        const dr = e.drift;
        const fx = Math.abs(dr.from) <= 2 && Number.isInteger(dr.from) ? LANE_X[dr.from] : dr.from;
        const tx = Math.abs(dr.to) <= 2 && Number.isInteger(dr.to) ? LANE_X[dr.to] : dr.to;
        driftDir = Math.sign(tx - fx);
        const active = dr.t == null || dr.dur == null || dr.t < dr.dur;
        if (active && driftDir) {
          roll = -driftDir * (0.12 + 0.06 * Math.sin(t * 8));
          // telegraph: sliding chevrons beside the monster + arrows painted on the road
          const pulse = 0.55 + 0.45 * Math.sin(t * 10);
          const slide = (t * 1.6) % 1;
          const col = K.edge;
          for (let k = 0; k < 2; k++) {
            S.shadows.push(x + driftDir * (1.1 + k * 1.0), 0, z, 1.4, 1.4, -driftDir * Math.PI / 2,
              1.0, 0.5, 0.1, (0.6 + 0.35 * pulse) * (1 - k * 0.25), 'arrow', 0.035);
          }
          for (let k = 0; k < 2; k++) {
            const sl = (slide + k * 0.5) % 1;
            S.glows.push(x + driftDir * (1.0 + sl * 1.1), 1.2, z + 0.1, 1.05, 2.6, 1.2, 0.3, Math.sin(sl * Math.PI), driftDir > 0 ? 'arrowR' : 'arrowL');
          }
        }
      }
      const yaw = Math.atan2(cam.position.x - x, camZ - z);
      const pitch = 0.2 * near;
      const y = K.hover + (K.hover ? Math.sin(t * 2.2 + ph * 5) * 0.12 : 0) + hop;
      const glow = 0.9 + 1.6 * near;
      const red = near > 0.55 ? (0.5 + 0.5 * Math.sin(t * 16)) * 0.18 * near : 0;
      batch.edgeColor(K.edge.r, K.edge.g, K.edge.b);
      batch.push(f, x, y, z, w, h, yaw, pitch, roll, 0, 1, 0, glow, edgeStrength * (1 + near * 0.5), 1, 0.2, 0.15, red);
      // contact shadow + a danger glow on the road in the monster's colour (reads from far away)
      S.shadows.push(x, 0, z, Math.min(2.3, w * 0.62), 1.0, 0, 0, 0, 0, K.hover ? 0.4 : 0.6, 'blob', 0.03);
      const dg = (0.35 + 0.35 * env.night) * (0.8 + 0.2 * Math.sin(t * 5 + ph * 6));
      S.additive.push(x, 0, z, 2.6, 2.2, 0, K.edge.r * dg, K.edge.g * dg, K.edge.b * dg, 1, 'glow', 0.04);
      // floating NAME TAG: constant-ish screen size far away, fades out as it closes in
      const D = d + camZ;
      const ta = smooth(11, 19, d) * (1 - smooth(60, 78, d));   // integration: tighter window, less clutter
      if (ta > 0.01 && nTag < TAGS.length) {
        const tf = tags.frames[e.kind];
        if (tf) {
          const th = Math.max(0.36, D * 0.033), tw = th * tags.aspect;
          const lane = e.lane != null ? e.lane : 1;
          const T = TAGS[nTag++];
          T.f = tf; T.x = x + (lane - 1) * tw * 0.55 * smooth(18, 45, d);
          T.y = y + h * 0.93 + th * (0.45 + (lane === 1 ? 1.15 : 0));
          T.z = z + 0.05; T.w = tw; T.h = th; T.a = ta; T.d = d; T.yaw = yaw;
        }
      }
    }
    // declutter: a tag that overlaps a NEARER monster's tag on screen fades back
    const W = frame.width || 390, H = frame.height || 844;
    for (let i = 0; i < nTag; i++) {
      const T = TAGS[i];
      _v.set(T.x, T.y + T.h * 0.5, T.z); projectBent(_v, cam, W, H, _o); T.sx = _o.x; T.sy = _o.y;
      _v.set(T.x + T.w * 0.5, T.y + T.h * 0.5, T.z); projectBent(_v, cam, W, H, _o); T.hw = Math.abs(_o.x - T.sx);
      T.hh = T.hw * T.h / T.w;
    }
    // integration: only the 3 NEAREST tags are ever shown — a row of five labels near the horizon read as clutter
    let shown = 0;
    TAGS_ORDER.length = 0;
    for (let i = 0; i < nTag; i++) TAGS_ORDER.push(i);
    TAGS_ORDER.sort((a, b) => TAGS[a].d - TAGS[b].d);
    for (let k = 0; k < nTag; k++) {
      const i = TAGS_ORDER[k];
      const A = TAGS[i];
      if (shown >= 3) break;
      shown++;
      for (let j = 0; j < nTag; j++) {
        const B = TAGS[j];
        if (j === i || B.d >= A.d) continue;
        if (Math.abs(A.sx - B.sx) < (A.hw + B.hw) * 0.92 && Math.abs(A.sy - B.sy) < (A.hh + B.hh) * 0.92) { A.a *= 0.22; break; }
      }
      tagBatch.push(A.f, A.x, A.y, A.z, A.w, A.h, A.yaw, 0, 0, 0, A.a, 0, 0, 0, 0, 0, 0, 0);
    }
    // tumbling debris
    for (let i = debris.length - 1; i >= 0; i--) {
      const b = debris[i], K = kinds[b.kind];
      const a = t - b.t0;
      if (a > 1.2 || a < 0) { debris.splice(i, 1); continue; }
      const f0 = K.frames[b.f % K.frames.length];
      const f = f0.c || (f0.c = { rect: null, w: f0.w, h: f0.h, ax: f0.w / 2, ay: f0.h / 2 });
      f.rect = f0.rect;
      const ppm = sizeFor(K, b);
      const z = zOf(b.s + a * 9, sim.dist);
      const x = b.x + b.dir * a * 6.5;
      const y = Math.max(0, 5.5 * a - 9 * a * a) + a * 0.8;
      const sc = 1 - a * 0.35;
      const yaw = Math.atan2(cam.position.x - x, camZ - z);
      const flash = a < 0.12 ? 1 - a / 0.12 : 0;
      batch.push(f, x, y + f.h / ppm * 0.5 * sc, z, f.w / ppm * sc, f.h / ppm * sc, yaw, 0, b.spin * a, 0,
        1 - smooth(0.6, 1.2, a), flash * 0.9, 1.2, 0.8, 1, 1, 1, 0);
      if (a < 0.2) S.glows.push(b.x, 1.2, zOf(b.s, sim.dist), 3.5 * (1 - a * 3), 2.4, 1.6, 1.2, 0.9 * (1 - a / 0.2), 'glow');
    }
    batch.end(); tagBatch.end();
    u.uEdge.value.copy(env.key).multiplyScalar(0.25);
  }

  function setQuality(tier) { quality = tier; }
  return { update, onEvent, setQuality, ready, atlas, kinds };
}
