// ACTORS · barriers (3D construction barricades + JUMP road paint), orbs (spinning 3D
// collectibles, one InstancedMesh per kind) and power-up pickups (3D icon in a gimbal ring
// with a light beam and a ground marker).
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { zOf } from '../core/constants.js';
import { TAU, clamp, lerp, smooth, hash, canvas, fitText, roundRect, remapUV, paint } from './actors-common.js';
import { BEND_GLSL_PARS, BEND_GLSL_APPLY } from '../core/bend.js';

const _m = new THREE.Matrix4(), _m2 = new THREE.Matrix4(), _q = new THREE.Quaternion(), _e = new THREE.Euler();
const _p = new THREE.Vector3(), _s = new THREE.Vector3(), _d = new THREE.Vector3(), _c = new THREE.Color();

// ================================================================== BARRIERS
function barrierTexture() {
  const cv = canvas(512, 256), g = cv.getContext('2d');
  // stripe board (0..512 x 0..128): diagonal yellow / black, worn edges, reflective sheen, bolts
  g.fillStyle = '#ffc400'; g.fillRect(0, 0, 512, 128);
  g.save(); g.beginPath(); g.rect(0, 0, 512, 128); g.clip();
  g.fillStyle = '#16161a';
  for (let x = -128; x < 640; x += 96) { g.beginPath(); g.moveTo(x, 128); g.lineTo(x + 48, 128); g.lineTo(x + 48 + 128, 0); g.lineTo(x + 128, 0); g.closePath(); g.fill(); }
  const sh = g.createLinearGradient(0, 0, 0, 128);
  sh.addColorStop(0, 'rgba(255,255,255,0.35)'); sh.addColorStop(0.18, 'rgba(255,255,255,0.05)');
  sh.addColorStop(0.8, 'rgba(0,0,0,0.0)'); sh.addColorStop(1, 'rgba(0,0,0,0.35)');
  g.fillStyle = sh; g.fillRect(0, 0, 512, 128);
  for (let i = 0; i < 90; i++) { g.fillStyle = `rgba(40,30,20,${0.08 + Math.random() * 0.12})`; g.fillRect(Math.random() * 512, Math.random() * 128, 2 + Math.random() * 6, 1 + Math.random() * 3); }
  g.strokeStyle = 'rgba(0,0,0,0.55)'; g.lineWidth = 6; g.strokeRect(3, 3, 506, 122);
  g.fillStyle = '#8a8f96'; for (const x of [22, 490]) for (const y of [34, 94]) { g.beginPath(); g.arc(x, y, 7, 0, TAU); g.fill(); }
  g.restore();
  // steel (0..128 x 128..256)
  let gr = g.createLinearGradient(0, 0, 128, 0);
  gr.addColorStop(0, '#5d636c'); gr.addColorStop(0.45, '#b7bec8'); gr.addColorStop(0.6, '#8b929c'); gr.addColorStop(1, '#4b5058');
  g.fillStyle = gr; g.fillRect(0, 128, 128, 128);
  // plain yellow (128..256)
  g.fillStyle = '#f2b800'; g.fillRect(128, 128, 128, 128);
  // black plastic (256..384)
  g.fillStyle = '#1b1c20'; g.fillRect(256, 128, 128, 128);
  // orange-red rubber foot (384..512)
  g.fillStyle = '#c2410c'; g.fillRect(384, 128, 128, 128);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
  const R = {
    stripes: [0.004, 0.502, 0.996, 0.998], steel: [0.01, 0.01, 0.24, 0.49], yellow: [0.26, 0.01, 0.49, 0.49],
    black: [0.51, 0.01, 0.74, 0.49], foot: [0.76, 0.01, 0.99, 0.49],
  };
  return { tex, R };
}

/** Box with per-face atlas regions. faces: {px,nx,py,ny,pz,nz} → region | null (skip). */
export function boxGeo(w, h, d, faces, cx = 0, cy = 0, cz = 0, segZ = 1) {
  const g = new THREE.BoxGeometry(w, h, d, 1, 1, segZ);
  // BoxGeometry groups: 0 px, 1 nx, 2 py, 3 ny, 4 pz, 5 nz
  const names = ['px', 'nx', 'py', 'ny', 'pz', 'nz'];
  const uv = g.attributes.uv, keepIdx = [];
  const idx = g.index.array;
  for (const grp of g.groups) {
    const r = faces[names[grp.materialIndex]];
    if (r === null) continue;
    const reg = r || faces.all;
    const seen = new Set();
    for (let k = grp.start; k < grp.start + grp.count; k++) {
      const vi = idx[k];
      if (!seen.has(vi) && reg) { seen.add(vi); uv.setXY(vi, reg[0] + uv.getX(vi) * (reg[2] - reg[0]), reg[1] + uv.getY(vi) * (reg[3] - reg[1])); }
      keepIdx.push(vi);
    }
  }
  g.setIndex(keepIdx);
  g.clearGroups();
  g.translate(cx, cy, cz);
  return g;
}

// Everything stays inside the published barrier height (1.0 m at scale 1): top plank ends at
// 0.96, posts at 1.0, the amber lamp is mounted on the OUTSIDE of the left post (y 0.9).
function barrierGeometry(R) {
  const parts = [];
  const plank = (y) => boxGeo(2.1, 0.2, 0.05, { pz: R.stripes, nz: R.stripes, all: R.yellow }, 0, y, 0);
  parts.push(plank(0.86), plank(0.52));
  for (const x of [-0.84, 0.84]) {
    parts.push(boxGeo(0.075, 1.0, 0.075, { all: R.steel }, x, 0.5, 0.04));
    parts.push(boxGeo(0.12, 0.06, 0.6, { all: R.foot }, x, 0.03, 0));
    const br = boxGeo(0.05, 0.62, 0.05, { all: R.steel }, 0, 0, 0);
    br.rotateX(-0.55); br.translate(x, 0.28, 0.17);
    parts.push(br);
  }
  for (const x of [-0.94, 0.94]) parts.push(boxGeo(0.1, 0.13, 0.12, { all: R.black }, x, 0.9, 0.04));   // lamp housings
  return mergeGeometries(parts.map(p => p.toNonIndexed()));
}
const LAMP_X = -0.99, LAMP_Y = 0.9;

export function createBarriers(ctx, S) {
  const { scene } = ctx;
  const { tex, R } = barrierTexture();
  const geo = barrierGeometry(R);
  const mat = S.bend(new THREE.MeshStandardMaterial({ map: tex, roughness: 0.5, metalness: 0.2,
    emissive: new THREE.Color(0, 0, 0), emissiveMap: tex }));
  const CAP = 48;
  const mesh = new THREE.InstancedMesh(geo, mat, CAP);
  mesh.name = 'actors.barriers'; mesh.frustumCulled = false; mesh.count = 0;
  mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  const lampGeo = new THREE.SphereGeometry(0.075, 12, 8);
  lampGeo.scale(1, 0.8, 1);
  const lampMat = S.bend(new THREE.MeshBasicMaterial({ color: 0xffffff }));
  const lamps = new THREE.InstancedMesh(lampGeo, lampMat, CAP * 2);
  lampGeo.rotateZ(Math.PI / 2);
  lamps.name = 'actors.barrierLamps'; lamps.frustumCulled = false; lamps.count = 0;
  lamps.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  lamps.setColorAt(0, _c.setRGB(1, 1, 1));
  scene.add(mesh, lamps);
  const debris = [];
  const seen = new Set();
  let lastT = 0;
  // jump runway state (no per-frame allocation)
  const JW = { near: 0, far: 0, ideal: 0, paint: 0 };
  const FLASH = Array.from({ length: 6 }, () => ({ s: 0, x: 0, t: -99 }));
  let flashI = 0;
  const gateS = new Float64Array(24); let nGate = 0;

  function smash(e, t) {
    if (seen.has(e.id)) return;
    if (seen.size > 256) seen.clear();
    seen.add(e.id);
    debris.push({ e: { x: e.x, s: e.s, w: e.w, h: e.h, len: e.len, gateRow: e.gateRow, lane: e.lane }, t0: t, dir: hash(e.id) > 0.5 ? 1 : -1 });
    if (debris.length > 10) debris.shift();
  }
  function onEvent(ev, sim) {
    if (ev.type === 'smash' && ev.id != null) {
      const e = sim.obstacles.find(o => o.id === ev.id);
      if (e && e.type === 'barrier') smash(e, lastT);
    }
    if (ev.type === 'hop') { const F = FLASH[flashI++ % FLASH.length]; F.s = ev.s; F.x = ev.x; F.t = lastT; }
    if (ev.type === 'start') { debris.length = 0; seen.clear(); for (const F of FLASH) F.t = -99; }
  }

  // ---------------------------------------------------------------- JUMP RUNWAY
  // The takeoff window comes from the sim every frame (sim.jumpWindow: metres before the
  // barrier's near face where a takeoff at the CURRENT speed clears). The painted "tap now"
  // band runs far -> near, pulled back from the latest edge by ~0.08 s of travel so a tap made
  // when the player SEES the feet in the band (display + input latency) still takes off in time.
  function readWindow(sim) {
    const v = Math.max(1, sim.speed || 15), w = sim.jumpWindow;
    if (w && w.far > 0 && w.far >= w.near) { JW.near = w.near; JW.far = w.far; JW.ideal = w.ideal; }
    else { JW.far = v * 0.5; JW.near = v * 0.12; JW.ideal = v * 0.3; }
    JW.paint = Math.max(JW.near, Math.min(JW.ideal - 0.6, JW.near + v * 0.08));
  }

  function flashFor(e, t) {                       // 1 -> 0 over 0.6 s after a clean 'hop' of this barrier
    let fl = 0;
    for (let i = 0; i < FLASH.length; i++) {
      const F = FLASH[i], a = t - F.t;
      if (a >= 0 && a < 0.6 && Math.abs(F.s - e.s) < 0.8 && (e.gateRow || Math.abs(F.x - e.x) < 1.3)) fl = Math.max(fl, 1 - a / 0.6);
    }
    return fl;
  }

  function runway(e, sim, t, fade) {
    const P = S.paint, A = S.additive, dist = sim.dist, p = sim.player;
    const gate = !!e.gateRow;
    const xc = gate ? 0 : e.x, W = gate ? 7.9 : 2.3;
    const sFar = e.s - JW.far, sNear = e.s - JW.paint, sIdeal = e.s - JW.ideal;
    const L = JW.far - JW.paint;
    const zFar = zOf(sFar, dist), zNear = zOf(sNear, dist), zS = zOf(e.s, dist), zMid = (zFar + zNear) * 0.5;
    // is the fox standing in this band right now?
    const inLane = gate || Math.abs(p.x - e.x) < 1.2;
    const inside = inLane && p.grounded && sim.mode !== 'dying' && dist >= sFar && dist <= sNear;
    const fl = flashFor(e, t);
    const tick = inside ? (Math.sin(t * 30) > 0 ? 1 : 0.6) : 0;
    // lead-in: dashed amber lane-edge lines for ~9 m before the band
    for (let sd = -1; sd <= 1; sd += 2) P.push(xc + sd * (W * 0.5 - 0.12), 0, zOf(sFar - 4.6, dist), 0.22, 9, 0, 1.0, 0.62, 0.08, 0.85 * fade, 'dash', 0.02);
    // the takeoff band: painted green-cyan with bright edges
    P.push(xc, 0, zMid, W, L, 0, 0.12 + 0.2 * fl, 0.95, 0.62, (0.55 + 0.25 * tick + 0.3 * fl) * fade, 'band', 0.021);
    // chevrons + JUMP centred on the ideal takeoff, in every lane the runway covers
    for (let li = gate ? -1 : 0; li <= (gate ? 1 : 0); li++) {
      const lx = gate ? li * 2.6 : e.x;
      for (let sc = sFar + 0.7; sc < sNear - 0.35; sc += 1.45) {
        if (Math.abs(sc - sIdeal) < 1.55) continue;
        P.push(lx, 0, zOf(sc, dist), 1.0, 0.8, 0, 0.85, 1.0, 0.9, 0.6 * fade, 'chev', 0.023);
      }
      P.push(lx, 0, zOf(sIdeal, dist), 1.75, Math.min(2.6, L * 0.45), 0, 1, 1, 1, 0.88 * fade, 'word', 0.024);
    }
    // "too late" strip: red hatch from the band's end to the barrier, with a solid stop line
    // (a clean hop turns it green — it is the part right behind the fox, so the flash is seen)
    P.push(xc, 0, (zNear + zS) * 0.5, W, JW.paint, 0, lerp(0.95, 0.2, fl), lerp(0.12, 1.0, fl), lerp(0.08, 0.55, fl), 0.6 * fade, 'hatch', 0.021);
    P.push(xc, 0, zNear, W, 0.22, 0, lerp(1.0, 0.3, fl), lerp(0.18, 1.0, fl), lerp(0.1, 0.6, fl), 0.95 * fade, 'box', 0.023);
    // runway edge lights: flush dots chasing toward the barrier (in the fox's frame, so the
    // wave always runs away from the player whatever the speed)
    const step = Math.max(1.1, L / 12), n = Math.min(13, Math.floor(L / step) + 1);
    const boost = inside ? 1.9 : 1;
    for (let k = 0; k < n; k++) {
      const sk = sFar + 0.25 + k * step;
      const wave = Math.pow(0.5 + 0.5 * Math.sin((sk - dist) * 0.8 - t * 12), 6);
      const I = (0.3 + 1.5 * wave) * boost + fl * 1.5;
      const zk = zOf(sk, dist);
      const dk = sk - dist, gs = 0.42 + Math.max(0, dk) * 0.007;   // upright halo grows a little with range
      for (let sd = -1; sd <= 1; sd += 2) {
        const lx = xc + sd * (W * 0.5 + 0.06);
        A.push(lx, 0, zk, 0.36, 0.36, 0, 0.3 * I, 1.35 * I, 0.8 * I, fade, 'dot', 0.03);
        // low runway edge light: a small upright halo so the runway reads from 60+ m
        S.glows.push(lx, 0.3 + gs * 0.25, zk, gs, 0.35 * I, 1.5 * I, 0.95 * I, 0.8 * fade, 'glow');
      }
    }
    // standing in the band: it lights up and ticks; a clean hop flashes the whole runway green
    if (inside) A.push(xc, 0, zMid, W, L, 0, 0.05 * tick, 0.55 * tick, 0.35 * tick, fade, 'band', 0.026);
    if (fl > 0) {
      A.push(xc, 0, (zFar + zS) * 0.5, W * 1.05, JW.far, 0, 0.35 * fl, 1.7 * fl, 0.7 * fl, 1, 'band', 0.027);
      A.push(xc, 0, zS - 0.3, W * 1.4, 3.2, 0, 0.3 * fl, 1.6 * fl, 0.7 * fl, 1, 'glow', 0.03);
    }
  }

  function place(i, e, z, t, extra) {
    const gate = !!e.gateRow;
    const sx = (gate ? 2.6 : (e.w || 2.1)) / 2.1, sy = (e.h || 1) / 1.0, sz = Math.max(0.6, (e.len || 0.5) / 0.5);
    if (extra) {
      const a = extra.a;
      _q.setFromEuler(_e.set(-a * 7 * 0.6, 0, extra.dir * a * 8));
      _p.set(e.x + extra.dir * a * 5, Math.max(0, 5 * a - 9 * a * a) + 0.5 * sy * a, z);
      _s.set(sx * (1 - a * 0.3), sy * (1 - a * 0.3), sz);
    } else { _q.identity(); _p.set(e.x, 0, z); _s.set(sx, sy, sz); }
    _m.compose(_p, _q, _s);
    mesh.setMatrixAt(i, _m);
    return _m;
  }

  function update(sim, frame) {
    const t = frame.time; lastT = t;
    const env = S.env;
    let n = 0, nl = 0;
    const camZ = frame.camera.position.z;
    readWindow(sim);
    nGate = 0;
    const runwayK = sim.power && sim.power.boost > 0 ? 0.3 : 1;     // flying over everything in GIG BOOST
    mat.emissive.setRGB(0.12, 0.1, 0.02).multiplyScalar(env.night * 1.4);   // retro-reflective stripes at night
    for (const e of sim.obstacles) {
      if (e.type !== 'barrier') continue;
      if (e.smashed) { smash(e, t); continue; }
      const z = zOf(e.s + (e.len || 0.5) / 2, sim.dist);
      if (z > camZ - 0.5 || n >= CAP) continue;
      const M = place(n++, e, z, t, null);
      // blinking amber lamps (gate rows chase left -> right)
      const lampsHere = e.gateRow ? 2 : 1;
      for (let k = 0; k < lampsHere; k++) {
        const lx = k ? -LAMP_X : LAMP_X;
        _p.set(lx, LAMP_Y, 0.04).applyMatrix4(M);
        _m2.makeTranslation(_p.x, _p.y, _p.z);
        lamps.setMatrixAt(nl, _m2);
        const phase = e.gateRow ? (e.lane || 0) * 0.33 + k * 0.16 : hash(e.id) * 0.5;
        const hopK = flashFor(e, t);
        const on = hopK > 0 || ((t * 1.6 + phase) % 1) < 0.5;
        const I = on ? 5.5 : 0.35;
        lamps.setColorAt(nl, _c.setRGB(lerp(1.0, 0.25, hopK) * I, lerp(0.55, 1.0, hopK) * I, lerp(0.08, 0.45, hopK) * I));
        nl++;
        if (on) S.glows.push(_p.x, _p.y + 0.05, _p.z, 1.2 + env.night * 1.0 + hopK, lerp(1.0, 0.3, hopK), lerp(0.55, 1.2, hopK), lerp(0.1, 0.5, hopK), 0.55 + env.night * 0.35, 'glow');
      }
      // contact shadow
      S.shadows.push(e.x, 0, z + 0.02, (e.gateRow ? 2.7 : 2.3), 0.95, 0, 0, 0, 0, 0.42, 'blob', 0.03);
      // jump runway (one wide runway per gate row)
      let dup = false;
      if (e.gateRow) { for (let g = 0; g < nGate; g++) if (Math.abs(gateS[g] - e.s) < 0.5) { dup = true; break; } if (!dup && nGate < gateS.length) gateS[nGate++] = e.s; }
      const dFar = e.s - JW.far - sim.dist;
      if (!dup && dFar < 125) runway(e, sim, t, runwayK * (1 - smooth(95, 125, dFar)));
    }
    for (let i = debris.length - 1; i >= 0; i--) {
      const b = debris[i], a = t - b.t0;
      if (a > 1 || a < 0 || n >= CAP) { debris.splice(i, 1); continue; }
      place(n++, b.e, zOf(b.e.s + a * 8, sim.dist), t, { a, dir: b.dir });
    }
    mesh.count = n; lamps.count = nl;
    mesh.visible = n > 0; lamps.visible = nl > 0;
    if (n) mesh.instanceMatrix.needsUpdate = true;
    if (nl) { lamps.instanceMatrix.needsUpdate = true; lamps.instanceColor.needsUpdate = true; }
  }
  return { update, onEvent, setQuality() {} };
}

// ================================================================== ORBS
function emblem(g, kind, cx, cy, s, col, dark) {
  g.save(); g.translate(cx, cy);
  g.lineJoin = 'round'; g.lineCap = 'round';
  const stroke = (w) => { g.lineWidth = w; g.strokeStyle = dark; g.stroke(); };
  if (kind === 'xm') {           // smartphone
    roundRect(g, -s * 0.24, -s * 0.4, s * 0.48, s * 0.8, s * 0.08); g.fillStyle = dark; g.fill();
    roundRect(g, -s * 0.19, -s * 0.32, s * 0.38, s * 0.6, s * 0.03); g.fillStyle = col; g.fill();
    g.fillStyle = dark; roundRect(g, -s * 0.06, -s * 0.37, s * 0.12, s * 0.03, s * 0.015); g.fill();
    g.beginPath(); g.arc(0, s * 0.34, s * 0.03, 0, TAU); g.fill();
  } else if (kind === 'tab') {   // tablet (landscape)
    roundRect(g, -s * 0.4, -s * 0.28, s * 0.8, s * 0.56, s * 0.07); g.fillStyle = dark; g.fill();
    roundRect(g, -s * 0.33, -s * 0.22, s * 0.66, s * 0.44, s * 0.03); g.fillStyle = col; g.fill();
    g.fillStyle = dark; g.beginPath(); g.arc(s * 0.365, 0, s * 0.025, 0, TAU); g.fill();
  } else if (kind === 'watch') { // smartwatch
    g.fillStyle = dark; g.fillRect(-s * 0.13, -s * 0.46, s * 0.26, s * 0.92);
    roundRect(g, -s * 0.24, -s * 0.28, s * 0.48, s * 0.56, s * 0.12); g.fill();
    roundRect(g, -s * 0.18, -s * 0.22, s * 0.36, s * 0.44, s * 0.08); g.fillStyle = col; g.fill();
    g.beginPath(); g.moveTo(0, -s * 0.12); g.lineTo(0, 0); g.lineTo(s * 0.09, s * 0.06); stroke(s * 0.04);
    g.fillStyle = dark; g.fillRect(s * 0.24, -s * 0.05, s * 0.05, s * 0.1);
  } else {                       // T-sheet clipboard with a check
    roundRect(g, -s * 0.3, -s * 0.36, s * 0.6, s * 0.76, s * 0.06); g.fillStyle = dark; g.fill();
    roundRect(g, -s * 0.24, -s * 0.28, s * 0.48, s * 0.62, s * 0.03); g.fillStyle = col; g.fill();
    g.fillStyle = dark; roundRect(g, -s * 0.13, -s * 0.44, s * 0.26, s * 0.14, s * 0.04); g.fill();
    g.beginPath(); g.moveTo(-s * 0.13, s * 0.02); g.lineTo(-s * 0.03, s * 0.13); g.lineTo(s * 0.15, -s * 0.12); stroke(s * 0.07);
  }
  g.restore();
}

function orbTexture(kind, K) {
  // left square: face; right square: rim gradient. emissive twin highlights rim + emblem outline
  const cv = canvas(512, 256), g = cv.getContext('2d');
  const ev = canvas(128, 64), ge = ev.getContext('2d');
  const face = g.createRadialGradient(100, 90, 10, 128, 128, 140);
  const light = kind === 'xm' ? '#fff2a8' : kind === 'tab' ? '#c9f0ff' : kind === 'watch' ? '#d4ffe6' : '#efe2ff';
  face.addColorStop(0, light); face.addColorStop(0.5, K.c); face.addColorStop(1, K.cd);
  g.fillStyle = face; g.fillRect(0, 0, 256, 256);
  // bevel ring
  g.lineWidth = 16; g.strokeStyle = 'rgba(255,255,255,0.55)'; g.beginPath(); g.arc(128, 128, 104, Math.PI * 0.9, Math.PI * 1.9); g.stroke();
  g.strokeStyle = 'rgba(0,0,0,0.25)'; g.beginPath(); g.arc(128, 128, 104, Math.PI * 1.9, Math.PI * 2.9); g.stroke();
  // embossed emblem: shadow + highlight + body
  emblem(g, kind, 132, 134, 150, 'rgba(0,0,0,0)', 'rgba(0,0,0,0.28)');
  emblem(g, kind, 124, 124, 150, 'rgba(0,0,0,0)', 'rgba(255,255,255,0.45)');
  emblem(g, kind, 128, 128, 150, light, K.cd);
  // rim
  const rim = g.createLinearGradient(256, 0, 512, 0);
  rim.addColorStop(0, K.cd); rim.addColorStop(0.3, light); rim.addColorStop(0.55, K.c); rim.addColorStop(0.8, '#ffffff'); rim.addColorStop(1, K.cd);
  g.fillStyle = rim; g.fillRect(256, 0, 256, 256);
  // emissive: rim strip strong, face edge soft, emblem screen glow
  ge.fillStyle = '#000'; ge.fillRect(0, 0, 128, 64);
  const eg = ge.createRadialGradient(32, 32, 16, 32, 32, 32);
  eg.addColorStop(0, 'rgba(0,0,0,1)'); eg.addColorStop(0.7, K.cd); eg.addColorStop(1, K.c);
  ge.fillStyle = eg; ge.fillRect(0, 0, 64, 64);
  ge.save(); ge.scale(0.25, 0.25); emblem(ge, kind, 128, 128, 150, K.c, 'rgba(0,0,0,0)'); ge.restore();
  ge.fillStyle = K.c; ge.fillRect(64, 0, 64, 64);
  const t1 = new THREE.CanvasTexture(cv); t1.colorSpace = THREE.SRGBColorSpace; t1.anisotropy = 4;
  const t2 = new THREE.CanvasTexture(ev); t2.colorSpace = THREE.SRGBColorSpace;
  return { map: t1, emis: t2 };
}

/** Planar-project UVs: vertices whose normal faces ±Z go to the face square, others to the rim strip. */
function coinUV(geo, R) {
  const pos = geo.attributes.position, nor = geo.attributes.normal, n = pos.count;
  const uv = new Float32Array(n * 2);
  for (let i = 0; i < n; i++) {
    const nz = nor.getZ(i);
    if (Math.abs(nz) > 0.55) {
      let u = pos.getX(i) / (2 * R) + 0.5; const v = pos.getY(i) / (2 * R) + 0.5;
      if (nz < 0) u = 1 - u;                       // back face reads the right way round too
      uv[i * 2] = clamp(u, 0.01, 0.99) * 0.5; uv[i * 2 + 1] = clamp(v, 0.01, 0.99);
    } else {
      uv[i * 2] = 0.5 + 0.5 * clamp(0.5 + Math.atan2(pos.getY(i), pos.getX(i)) / TAU, 0.02, 0.98);
      uv[i * 2 + 1] = 0.5 + pos.getZ(i) * 3;
    }
  }
  geo.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  return geo;
}

function orbGeometry(kind) {
  let geo;
  if (kind === 'xm') {
    const pts = [[0, -0.04], [0.28, -0.04], [0.3, -0.05], [0.345, -0.03], [0.35, 0], [0.345, 0.03], [0.3, 0.05], [0.28, 0.04], [0, 0.04]]
      .map(([r, y]) => new THREE.Vector2(r, y));
    geo = new THREE.LatheGeometry(pts, 40); geo.rotateX(Math.PI / 2);
    geo = geo.toNonIndexed(); geo.computeVertexNormals();
    coinUV(geo, 0.35);
  } else if (kind === 'tsheet') {
    const sh = new THREE.Shape();
    const w = 0.25, h = 0.33, r = 0.07;
    sh.moveTo(-w + r, -h); sh.lineTo(w - r, -h); sh.quadraticCurveTo(w, -h, w, -h + r); sh.lineTo(w, h - r); sh.quadraticCurveTo(w, h, w - r, h);
    sh.lineTo(0.1, h); sh.lineTo(0.1, h + 0.07); sh.lineTo(-0.1, h + 0.07); sh.lineTo(-0.1, h);
    sh.lineTo(-w + r, h); sh.quadraticCurveTo(-w, h, -w, h - r); sh.lineTo(-w, -h + r); sh.quadraticCurveTo(-w, -h, -w + r, -h);
    geo = new THREE.ExtrudeGeometry(sh, { depth: 0.06, bevelEnabled: true, bevelThickness: 0.03, bevelSize: 0.035, bevelSegments: 2, curveSegments: 6 });
    geo.translate(0, -0.02, -0.03);
    if (geo.index) geo = geo.toNonIndexed();
    geo.computeVertexNormals();
    coinUV(geo, 0.4);
  } else {
    // faceted gem-coin: 8 sides (tablet) / 6 sides (watch), bevelled faces, flat shaded
    const seg = kind === 'tab' ? 8 : 6;
    const pts = [[0, -0.05], [0.25, -0.05], [0.35, 0], [0.25, 0.05], [0, 0.05]].map(([r, y]) => new THREE.Vector2(r, y));
    geo = new THREE.LatheGeometry(pts, seg, Math.PI / seg); geo.rotateX(Math.PI / 2);
    geo = geo.toNonIndexed(); geo.computeVertexNormals();
    coinUV(geo, 0.34);
  }
  return geo;
}

export function createOrbs(ctx, S) {
  const { scene, KINDS } = ctx;
  const CAP = 200;
  const byKind = {};
  for (const kind of Object.keys(KINDS)) {
    const K = KINDS[kind];
    const tx = orbTexture(kind, K);
    const metal = kind === 'xm';
    const mat = S.bend(new THREE.MeshStandardMaterial({
      map: tx.map, emissiveMap: tx.emis, emissive: new THREE.Color(1, 1, 1),
      emissiveIntensity: metal ? 1.1 : 1.35, metalness: metal ? 0.9 : 0.35, roughness: metal ? 0.22 : 0.12,
      envMap: S.envMap ? S.envMap.texture : null, envMapIntensity: metal ? 1.6 : 1.2, flatShading: !metal && kind !== 'tsheet',
    }));
    const mesh = new THREE.InstancedMesh(orbGeometry(kind), mat, CAP);
    mesh.name = 'actors.orbs.' + kind; mesh.frustumCulled = false; mesh.count = 0;
    mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    scene.add(mesh);
    const col = new THREE.Color(K.c);
    byKind[kind] = { mesh, mat, n: 0, col, scale: kind === 'tsheet' ? 1.2 : 1.05 };
  }
  let glowAll = true;
  const fox = new THREE.Vector3();

  function update(sim, frame) {
    const t = frame.time;
    for (const k in byKind) byKind[k].n = 0;
    const camZ = frame.camera.position.z;
    const p = sim.player;
    fox.set(p.x, p.y + 0.9, 0);
    const G = S.glows;
    for (const o of sim.orbs) {
      if (o.got) continue;
      const B = byKind[o.kind]; if (!B) continue;
      const z = zOf(o.s, sim.dist);
      if (z > camZ - 0.4 || z < -148) continue;
      const bob = o.magnet ? 0 : Math.sin(t * 3.2 + o.s * 0.35) * 0.07;
      const y = o.y + bob;
      const spin = t * 3.4 + o.s * 0.16;
      const sc = B.scale * (o.kind === 'tsheet' ? 1 + 0.06 * Math.sin(t * 5 + o.id) : 1);
      _q.setFromAxisAngle(_s.set(0, 1, 0), spin);
      _p.set(o.x, y, z);
      _m.compose(_p, _q, _s.set(sc, sc, sc));
      if (o.magnet) {
        // stretch along the pull direction (toward the fox), squeeze across it
        _d.set(fox.x - o.x, fox.y - y, -z);
        const L = _d.length();
        if (L > 1e-3) {
          _d.multiplyScalar(1 / L);
          const k = 1.65, c = 0.8;
          const e = _m2.elements;
          // S = c·I + (k - c)·d dᵀ
          e[0] = c + (k - c) * _d.x * _d.x; e[4] = (k - c) * _d.x * _d.y; e[8] = (k - c) * _d.x * _d.z; e[12] = 0;
          e[1] = (k - c) * _d.y * _d.x; e[5] = c + (k - c) * _d.y * _d.y; e[9] = (k - c) * _d.y * _d.z; e[13] = 0;
          e[2] = (k - c) * _d.z * _d.x; e[6] = (k - c) * _d.z * _d.y; e[10] = c + (k - c) * _d.z * _d.z; e[14] = 0;
          e[3] = 0; e[7] = 0; e[11] = 0; e[15] = 1;
          _m.elements[12] = 0; _m.elements[13] = 0; _m.elements[14] = 0;
          _m.premultiply(_m2);
          _m.elements[12] = o.x; _m.elements[13] = y; _m.elements[14] = z;
        }
      }
      B.mesh.setMatrixAt(B.n++, _m);
      if (glowAll || o.kind !== 'watch') {
        const far = smooth(20, 90, -z);
        G.push(o.x, y, z - 0.05, 0.95 + far * 1.2, B.col.r * 1.3, B.col.g * 1.3, B.col.b * 1.3, 0.3 + far * 0.25, 'glow');
      }
      const tw = hash(o.id * 3.1 + Math.floor(t * 2.5 + o.id * 0.37));
      if (tw > 0.86) {
        const ph = (t * 2.5 + o.id * 0.37) % 1;
        G.push(o.x + 0.18, y + 0.2, z + 0.1, 0.55 * Math.sin(ph * Math.PI), 2.2, 2.0, 1.6, 0.9, 'star');
      }
      if (o.magnet) G.push(o.x, y, z + 0.25, 0.7, B.col.r * 1.6, B.col.g * 1.6, B.col.b * 1.6, 0.45, 'glow');
    }
    for (const k in byKind) {
      const B = byKind[k];
      B.mesh.count = B.n; B.mesh.visible = B.n > 0;
      if (B.n) B.mesh.instanceMatrix.needsUpdate = true;
      if (S.envMap && B.mat.envMap !== S.envMap.texture) { B.mat.envMap = S.envMap.texture; B.mat.needsUpdate = true; }
    }
  }
  function setQuality(tier) { glowAll = tier !== 'low'; }
  return { update, onEvent() {}, setQuality };
}

// ================================================================== POWER-UPS
function beamMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: { uCol: { value: new THREE.Color() }, uTime: { value: 0 } },
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    vertexShader: /* glsl */`
      ${BEND_GLSL_PARS}
      varying float vY; varying float vF;
      void main() {
        vY = uv.y;
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        vec3 n = normalize(normalMatrix * normal);
        vF = abs(dot(n, normalize(-mvPosition.xyz)));
        ${BEND_GLSL_APPLY}
        gl_Position = projectionMatrix * mvPosition;
      }`,
    fragmentShader: /* glsl */`
      uniform vec3 uCol; uniform float uTime;
      varying float vY; varying float vF;
      void main() {
        float a = pow(1.0 - vY, 1.6) * pow(vF, 2.0) * (0.75 + 0.25 * sin(vY * 40.0 - uTime * 8.0));
        gl_FragColor = vec4(uCol * a, 1.0);
      }`,
  });
}

function x2Texture() {
  const cv = canvas(512, 256), g = cv.getContext('2d');
  const face = g.createRadialGradient(100, 90, 10, 128, 128, 150);
  face.addColorStop(0, '#fff6b0'); face.addColorStop(0.55, '#ffcc1f'); face.addColorStop(1, '#b86b00');
  g.fillStyle = face; g.fillRect(0, 0, 256, 256);
  g.lineWidth = 14; g.strokeStyle = '#8a4b00'; g.beginPath(); g.arc(128, 128, 110, 0, TAU); g.stroke();
  g.lineWidth = 6; g.strokeStyle = '#fff3b8'; g.beginPath(); g.arc(128, 128, 98, 0, TAU); g.stroke();
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillStyle = '#5a2a00'; fitText(g, '2X', 134, 136, 190, 130, '900', 'italic');
  g.fillStyle = '#e8141e'; fitText(g, '2X', 128, 128, 190, 130, '900', 'italic');
  g.lineWidth = 5; g.strokeStyle = '#fff'; g.strokeText('2X', 128, 128);
  const rim = g.createLinearGradient(256, 0, 512, 0);
  rim.addColorStop(0, '#9a5a00'); rim.addColorStop(0.35, '#fff1a0'); rim.addColorStop(0.6, '#ffc21a'); rim.addColorStop(1, '#9a5a00');
  g.fillStyle = rim; g.fillRect(256, 0, 256, 256);
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
  return tex;
}

function powerModels(S) {
  // MAGNET — red horseshoe with silver pole tips
  const parts = [];
  const arc = new THREE.TorusGeometry(0.33, 0.13, 14, 28, Math.PI); paint(arc, '#e3202f'); parts.push(arc.toNonIndexed());
  for (const x of [-0.33, 0.33]) {
    const leg = new THREE.CylinderGeometry(0.13, 0.13, 0.26, 18); leg.translate(x, -0.13, 0); paint(leg, '#e3202f'); parts.push(leg.toNonIndexed());
    const tip = new THREE.CylinderGeometry(0.135, 0.135, 0.17, 18); tip.translate(x, -0.345, 0); paint(tip, '#e8edf2'); parts.push(tip.toNonIndexed());
  }
  for (const p of parts) p.deleteAttribute('uv');
  const magGeo = mergeGeometries(parts); magGeo.translate(0, 0.08, 0);
  const magMat = S.bend(new THREE.MeshStandardMaterial({ vertexColors: true, metalness: 0.55, roughness: 0.28,
    emissive: new THREE.Color(0.45, 0.03, 0.05), envMap: S.envMap ? S.envMap.texture : null, envMapIntensity: 1.2 }));
  // 2X CASH — thick gold badge
  const pts = [[0, -0.07], [0.4, -0.07], [0.46, -0.04], [0.47, 0], [0.46, 0.04], [0.4, 0.07], [0, 0.07]].map(([r, y]) => new THREE.Vector2(r, y));
  let x2Geo = new THREE.LatheGeometry(pts, 48); x2Geo.rotateX(Math.PI / 2); x2Geo = x2Geo.toNonIndexed(); x2Geo.computeVertexNormals();
  coinUV(x2Geo, 0.47);
  const x2Tex = x2Texture();
  const x2Mat = S.bend(new THREE.MeshStandardMaterial({ map: x2Tex, metalness: 0.85, roughness: 0.25,
    emissive: new THREE.Color(0.55, 0.36, 0.02), emissiveMap: x2Tex, envMap: S.envMap ? S.envMap.texture : null, envMapIntensity: 1.5 }));
  // GIG BOOST — cyan lightning bolt
  const b = new THREE.Shape();
  b.moveTo(0.08, 0.5); b.lineTo(-0.26, -0.04); b.lineTo(-0.03, -0.04); b.lineTo(-0.12, -0.5);
  b.lineTo(0.27, 0.08); b.lineTo(0.04, 0.08); b.lineTo(0.15, 0.5); b.closePath();
  const boltGeo = new THREE.ExtrudeGeometry(b, { depth: 0.12, bevelEnabled: true, bevelThickness: 0.04, bevelSize: 0.03, bevelSegments: 2 });
  boltGeo.translate(-0.01, 0, -0.06); boltGeo.deleteAttribute('uv');
  const boltMat = S.bend(new THREE.MeshStandardMaterial({ color: '#5fe3ff', metalness: 0.3, roughness: 0.2,
    emissive: new THREE.Color(0.25, 1.4, 2.2), envMap: S.envMap ? S.envMap.texture : null }));
  return { magnet: [magGeo, magMat], x2: [x2Geo, x2Mat], boost: [boltGeo, boltMat] };
}

export function createPowerups(ctx, S) {
  const { scene, POWERUPS, assets } = ctx;
  const models = powerModels(S);
  const ringGeo = mergeGeometries([new THREE.TorusGeometry(0.8, 0.05, 10, 72),
    new THREE.TorusGeometry(0.66, 0.025, 8, 64).rotateY(Math.PI / 2)]);
  const beamGeo = new THREE.CylinderGeometry(0.42, 0.62, 16, 24, 10, true); beamGeo.translate(0, 8, 0);
  const pool = new Map();          // id -> rig
  const free = { magnet: [], x2: [], boost: [] };
  const mats = {};
  for (const k of Object.keys(POWERUPS)) {
    const c = new THREE.Color(POWERUPS[k].c);
    const ring = S.bend(new THREE.MeshBasicMaterial({ color: c.clone().multiplyScalar(2.6) }));
    const beam = beamMaterial(); beam.uniforms.uCol.value.setRGB(c.r * c.r, c.g * c.g, c.b * c.b).multiplyScalar(0.42);
    mats[k] = { ring, beam, col: c };
  }
  // painted icons from the ART agent (optional): shown as a camera-facing badge inside the ring
  const icons = {};
  for (const k of Object.keys(POWERUPS)) {
    const key = 'ui/pow_' + k;
    if (!assets.hasAsset(key)) continue;
    const tex = assets.getTexture(key);
    if (!tex) continue;
    const m = S.bend(new THREE.MeshBasicMaterial({ map: tex, color: new THREE.Color(1.12, 1.12, 1.12), transparent: true, alphaTest: 0.3, depthWrite: true, side: THREE.DoubleSide }));
    icons[k] = { tex, mat: m, ok: false };
    assets.getImage(key).then(img => { if (img) icons[k].ok = true; });
  }
  const iconGeo = new THREE.PlaneGeometry(1.25, 1.25);

  function rig(kind) {
    const f = free[kind] && free[kind].pop();
    if (f) { f.group.visible = true; return f; }
    const group = new THREE.Group(); group.name = 'actors.powerup.' + kind;
    const [g, m] = models[kind];
    const model = new THREE.Mesh(g, m);
    model.scale.setScalar(1.25);
    const ring = new THREE.Mesh(ringGeo, mats[kind].ring);
    const beam = new THREE.Mesh(beamGeo, mats[kind].beam); beam.renderOrder = 5;
    group.add(model, ring, beam);
    let icon = null;
    if (icons[kind]) { icon = new THREE.Mesh(iconGeo, icons[kind].mat); icon.visible = false; group.add(icon); }
    scene.add(group);
    return { group, model, ring, beam, icon, kind };
  }

  let stamp = 0;
  function update(sim, frame) {
    const t = frame.time, cam = frame.camera;
    stamp++;
    for (const u of sim.powerups) {
      if (u.got || !models[u.kind]) continue;
      const z = zOf(u.s, sim.dist);
      if (z > cam.position.z - 0.5) continue;
      let R = pool.get(u.id);
      if (!R) { R = rig(u.kind); pool.set(u.id, R); }
      R.stamp = stamp;
      const d = -z;
      const big = 1.1 + smooth(20, 85, d) * 1.5;          // grow with distance: readable from 80 m
      const y = (u.y || 1) + 0.35 + (big - 1.1) * 0.55 + Math.sin(t * 2.6 + u.id) * 0.12;
      R.group.position.set(u.x, 0, z);
      const yaw = Math.atan2(cam.position.x - u.x, cam.position.z - z);
      const useIcon = R.icon && icons[R.kind].ok;
      R.model.visible = !useIcon;
      R.model.position.set(0, y, 0); R.model.rotation.set(0, t * 2.4, 0); R.model.scale.setScalar(1.25 * big);
      if (R.icon) { R.icon.visible = useIcon; R.icon.position.set(0, y, 0); R.icon.rotation.set(0, yaw + Math.sin(t * 2.3 + u.id) * 0.5, Math.sin(t * 1.7 + u.id) * 0.08); R.icon.scale.setScalar(big); }
      R.ring.position.set(0, y, 0); R.ring.rotation.set(Math.sin(t * 1.3) * 0.25, yaw + t * 1.6, 0); R.ring.scale.setScalar(big);
      R.beam.scale.set(big, 1, big);
      mats[R.kind].beam.uniforms.uTime.value = t;
      const c = mats[R.kind].col;
      S.glows.push(u.x, y, z - 0.25, 2.4 * big, c.r * 1.3, c.g * 1.3, c.b * 1.3, 0.38, 'glow');
      S.additive.push(u.x, 0, z, 2.2 * big, 2.2 * big, t * 0.8, c.r * 1.6, c.g * 1.6, c.b * 1.6, 0.9, 'dashring', 0.04);
      S.shadows.push(u.x, 0, z, 1.2, 1.2, 0, 0, 0, 0, 0.35, 'blob', 0.03);
      if (hash(u.id + Math.floor(t * 3)) > 0.5) G2(S, u.x + (hash(Math.floor(t * 3)) - 0.5) * 1.4, y + (hash(Math.floor(t * 3) + 1) - 0.5) * 1.4, z + 0.2, (t * 3) % 1);
    }
    pool.forEach(recycle);
  }
  function recycle(R, id) { if (R.stamp !== stamp) { R.group.visible = false; free[R.kind].push(R); pool.delete(id); } }
  function G2(S, x, y, z, ph) { S.glows.push(x, y, z, 0.6 * Math.sin(ph * Math.PI), 2.5, 2.4, 2.2, 1, 'star'); }
  return { update, onEvent() {}, setQuality() {} };
}
