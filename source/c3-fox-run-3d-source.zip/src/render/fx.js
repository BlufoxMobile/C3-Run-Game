// FX — createFX(ctx) -> { update(sim, frame), onEvent(ev, sim), setQuality(tier) }
//
// Two GPU particle pools (fx-particles.js), i.e. TWO draw calls for everything:
//   ADD   (additive, HDR — blooms on 'high'): sparkles, stars, rings, sparks, speed lines,
//         GIG BOOST warp tunnel + trail, magnet trails, near-miss streaks, power-up blasts.
//   ALPHA (normal blend): dust kicks / jump & landing puffs, confetti, smash debris,
//         shield glass shards, landing dust rings.
// Event positions {x, y, s} are converted with zOf(s, sim.dist). Bursts that happen AT the
// fox (pickups, shield, power-ups, confetti) are fox-anchored so they don't smear off at
// 30 m/s; things that happen in the world (dust, hop sparks, smash debris) are
// world-anchored and stream past like real debris. Speed lines / warp are camera-anchored
// and never spawn over the running corridor (lower-centre of the screen).
// Particle time runs on SIM dt, so hit-stop freezes and slow-mo slows every particle.
// fx.onEvent also forwards screen pulses to post.js through FXBUS (no extra wiring).
import * as THREE from 'three';
import { zOf } from '../core/constants.js';
import { KINDS, POWERUPS } from '../data/themes.js';
import { createParticlePool, makeP } from './fx-particles.js';
import { FXBUS, clamp } from './fx-bus.js';

const Q_MUL = { high: 1, med: 0.65, low: 0.4 };

function lin(hex, k = 1) { const c = new THREE.Color(hex); return [c.r * k, c.g * k, c.b * k]; }

const MONSTER_COL = {
  exception: '#ff8a3d', falloff: '#b46cff', chargeback: '#ff4d5e', nonusage: '#6bd66b', retail360: '#3fc7d8',
  barrier: '#ffc531', train: '#dfe6ee',
};
const CONFETTI = ['#2f8cff', '#ffce4d', '#7CE7A8', '#c9a7ff', '#ffffff', '#ff5a6e', '#4fd8ff', '#ff9f43'].map(h => lin(h));

export function createFX(ctx) {
  const scene = ctx.scene;
  const ADD = createParticlePool(3072, true, 'add');
  const ALPHA = createParticlePool(1536, false, 'alpha');
  scene.add(ALPHA.mesh); scene.add(ADD.mesh);

  const KC = {}; for (const k in KINDS) KC[k] = lin(KINDS[k].c);
  const PC = {}; for (const k in POWERUPS) PC[k] = lin(POWERUPS[k].c);
  const MC = {}; for (const k in MONSTER_COL) MC[k] = lin(MONSTER_COL[k]);
  const WHITE = [1, 1, 1], GOLD = lin('#ffd23f'), ORANGE = lin('#ff9a3c'), CYAN = lin('#4fd8ff'), PURPLE = lin('#c9a7ff');
  const DARK = lin('#2a2d36'), GLASS = lin('#dff4ff'), MAGNET = PC.magnet || lin('#ff5a6e');
  const dustCol = [0.5, 0.45, 0.38], roofDust = [0.62, 0.64, 0.68];
  const tmpC = new THREE.Color(), tmpC2 = new THREE.Color();

  let tier = ctx.tier || 'high';
  let qMul = Q_MUL[tier] || 1;
  let lastDist = null, scroll = 15;
  let accSpeed = 0, accWarp = 0, accTrail = 0, accDust = 0, accAura = 0, themeIdx = -1;
  const P = makeP();
  const rnd = (a, b) => a + Math.random() * (b - a);
  const n = k => Math.max(1, Math.round(k * qMul * (FXBUS.reducedMotion ? 0.5 : 1)));

  // ------------------------------------------------ emit helpers
  function start(anchor, x, y, z) {
    P.anchor = anchor; P.x = x; P.y = y; P.z = z;
    P.vx = P.vy = P.vz = 0; P.grav = 0; P.drag = 0; P.spin = 0; P.floor = -100; P.stretch = 0;
    P.shape = 0; P.orient = 0; P.a = 1; return P;
  }
  function col(c, k = 1) { P.r = c[0] * k; P.g = c[1] * k; P.b = c[2] * k; }
  let dx = 0, dy = 0, dz = 0;
  function sphere(upBias = 0) {
    for (;;) {
      dx = Math.random() * 2 - 1; dy = Math.random() * 2 - 1; dz = Math.random() * 2 - 1;
      const l = dx * dx + dy * dy + dz * dz;
      if (l > 0.02 && l <= 1) { const s = 1 / Math.sqrt(l); dx *= s; dy = dy * s + upBias; dz *= s; return; }
    }
  }
  /** radial sparkle burst */
  function sparkles(pool, anchor, x, y, z, c, count, sMin, sMax, o = {}) {
    for (let i = 0; i < count; i++) {
      start(anchor, x, y, z); sphere(o.up || 0);
      const sp = rnd(sMin, sMax);
      P.vx = dx * sp; P.vy = dy * sp; P.vz = dz * sp + (o.vz || 0);
      P.grav = o.grav ?? -5; P.drag = o.drag ?? 2.5;
      P.life = rnd(o.lifeMin ?? 0.3, o.lifeMax ?? 0.6);
      P.s0 = rnd(o.sizeMin ?? 0.1, o.sizeMax ?? 0.2); P.s1 = P.s0 * (o.shrink ?? 0.15);
      P.shape = o.shape ?? 0; P.orient = o.orient ?? 0; P.stretch = o.stretch ?? 0;
      P.spin = o.spin ?? 0;
      col(c, (o.hdr ?? 3) * rnd(0.7, 1.2)); P.a = o.alpha ?? 1;
      pool.emit(P);
    }
  }
  function ring(pool, anchor, x, y, z, c, s0, s1, life, hdr = 2.5, flat = false, alpha = 1) {
    start(anchor, x, y, z); P.shape = 2; P.orient = flat ? 2 : 0; P.life = life; P.s0 = s0; P.s1 = s1;
    col(c, hdr); P.a = alpha; pool.emit(P);
  }
  function glow(anchor, x, y, z, c, s0, s1, life, hdr = 3) {
    start(anchor, x, y, z); P.shape = 0; P.life = life; P.s0 = s0; P.s1 = s1; col(c, hdr); ADD.emit(P);
  }
  function stars(anchor, x, y, z, c, count, spread, hdr = 4) {
    for (let i = 0; i < count; i++) {
      start(anchor, x + rnd(-spread, spread), y + rnd(-spread, spread) * 0.8, z + rnd(-spread, spread) * 0.4);
      P.shape = 1; P.vy = rnd(0.2, 1.4); P.drag = 2; P.life = rnd(0.35, 0.6); P.s0 = rnd(0.35, 0.6); P.s1 = 0.05;
      P.spin = rnd(-2, 2); col(c, hdr); ADD.emit(P);
    }
  }
  function puffs(anchor, x, y, z, c, count, sMin, sMax, o = {}) {
    for (let i = 0; i < count; i++) {
      start(anchor, x + rnd(-0.25, 0.25), y, z + rnd(-0.25, 0.25));
      const a = Math.random() * Math.PI * 2, sp = rnd(sMin, sMax);
      P.vx = Math.cos(a) * sp; P.vz = Math.sin(a) * sp * 0.7 + (o.vz || 0); P.vy = rnd(o.vyMin ?? 0.3, o.vyMax ?? 1.1);
      P.grav = -0.6; P.drag = o.drag ?? 3.2; P.floor = y - 0.05;
      P.life = rnd(o.lifeMin ?? 0.35, o.lifeMax ?? 0.6); P.s0 = rnd(0.14, 0.24) * (o.scale || 1); P.s1 = rnd(0.6, 0.95) * (o.scale || 1);
      P.shape = 4; P.spin = rnd(-1, 1);
      col(c, rnd(0.9, 1.1)); P.a = o.alpha ?? 0.45;
      ALPHA.emit(P);
    }
  }
  function confetti(anchor, x, y, z, count, o) {
    for (let i = 0; i < count; i++) {
      start(anchor, x + rnd(-o.sx, o.sx), y + rnd(-o.sy, o.sy), z + rnd(-o.sz, o.sz));
      P.vx = rnd(o.vx0, o.vx1); P.vy = rnd(o.vy0, o.vy1); P.vz = rnd(o.vz0, o.vz1);
      P.grav = o.grav; P.drag = o.drag; P.spin = rnd(5, 12) * (Math.random() < 0.5 ? -1 : 1);
      P.life = rnd(o.life0, o.life1); P.s0 = P.s1 = rnd(0.13, 0.2) * (o.size || 1);
      P.shape = 3; P.orient = 3; P.floor = o.floor ?? -100;
      col(CONFETTI[(Math.random() * CONFETTI.length) | 0], 1); P.a = 1;
      ALPHA.emit(P);
    }
  }
  function sparks(anchor, x, y, z, c, count, o = {}) {
    for (let i = 0; i < count; i++) {
      start(anchor, x, y, z); sphere(o.up ?? 0.5);
      const sp = rnd(o.sMin ?? 3, o.sMax ?? 8);
      P.vx = dx * sp + (o.vx || 0); P.vy = Math.abs(dy) * sp * (o.upOnly === false ? Math.sign(dy) : 1); P.vz = dz * sp + (o.vz || 0);
      P.grav = o.grav ?? -14; P.drag = o.drag ?? 1.2; P.floor = o.floor ?? -100;
      P.life = rnd(o.life0 ?? 0.3, o.life1 ?? 0.6); P.s0 = rnd(0.035, 0.06); P.s1 = 0.01;
      P.shape = 5; P.orient = 1; P.stretch = o.stretch ?? 0.035;
      col(c, (o.hdr ?? 4) * rnd(0.7, 1.3)); ADD.emit(P);
    }
  }
  function debris(anchor, x, y, z, c, count, o) {
    for (let i = 0; i < count; i++) {
      start(anchor, x + rnd(-0.3, 0.3), y + rnd(-0.4, 0.5), z + rnd(-0.2, 0.2)); sphere(0.6);
      const sp = rnd(o.sMin, o.sMax);
      P.vx = dx * sp; P.vy = Math.abs(dy) * sp + rnd(1, 3); P.vz = dz * sp + (o.vz || 0);
      P.grav = o.grav ?? -18; P.drag = o.drag ?? 0.5; P.floor = o.floor ?? 0.03;
      P.spin = rnd(8, 18) * (Math.random() < 0.5 ? -1 : 1);
      P.life = rnd(o.life0 ?? 0.8, o.life1 ?? 1.3); P.s0 = P.s1 = rnd(o.size0 ?? 0.14, o.size1 ?? 0.32);
      P.shape = o.shape ?? (Math.random() < 0.5 ? 3 : 6); P.orient = o.orient ?? 0;
      const cc = Math.random() < (o.darkMix ?? 0.3) ? DARK : c;
      col(cc, o.bright ?? rnd(0.8, 1.15)); P.a = o.alpha ?? 1;
      ALPHA.emit(P);
    }
  }

  // ------------------------------------------------ camera-anchored streaks
  const camRight = new THREE.Vector3(), camUp = new THREE.Vector3(), camFwd = new THREE.Vector3();
  function peripheralStreak(camera, dMin, dMax, speed, stretch, width, c, hdr, alpha, excludeLow, rMin = 0.4, lowSin = -0.25) {
    const d = rnd(dMin, dMax);
    const tF = Math.tan(camera.fov * Math.PI / 360), asp = camera.aspect || 1;
    // angle around the view axis; the lower-centre sector (the running corridor) is excluded
    // ...and never below the road surface (the depth test would just eat them)
    let ox = 0, oy = 0;
    for (let tries = 0; tries < 8; tries++) {
      const th = Math.random() * Math.PI * 2;
      const s = Math.sin(th), cth = Math.cos(th);
      if (s < lowSin && Math.abs(cth) < excludeLow) continue;
      const rx = d * tF * asp * rnd(rMin, 0.95), ry = d * tF * rnd(rMin, 0.9);
      ox = cth * rx; oy = s * ry;
      if (camera.position.y + camFwd.y * d + camRight.y * ox + camUp.y * oy > 0.6) break;
    }
    start(2, camFwd.x * d + camRight.x * ox + camUp.x * oy, camFwd.y * d + camRight.y * ox + camUp.y * oy, camFwd.z * d + camRight.z * ox + camUp.z * oy);
    P.vz = speed; P.life = Math.min(1.2, Math.max(0.12, (d * Math.abs(camFwd.z) - 1.2) / speed));
    P.s0 = P.s1 = width; P.shape = 5; P.orient = 1; P.stretch = stretch;
    col(c, hdr); P.a = alpha; ADD.emit(P);
  }

  // ------------------------------------------------ events
  function onEvent(ev, sim) {
    if (!sim) return;
    const dist = sim.dist, p = sim.player;
    const fz = s => (s == null ? 0 : zOf(s, dist));
    // bursts AT the fox spawn a little toward the camera so the sprite doesn't hide them
    const front = s => Math.min(0, Math.max(-1.5, fz(s))) + 0.8;
    switch (ev.type) {
      case 'start': ADD.killAll(); ALPHA.killAll(); lastDist = null; break;
      case 'coin': {
        const c = KC[ev.kind] || GOLD, z = front(ev.s), y = ev.y ?? 1;
        const big = 1 + Math.min(1, ((ev.combo || 1) - 1) / 8) * 0.6;
        sparkles(ADD, 1, ev.x, y, z, c, n(12 * big), 2.4, 5.5, { vz: 2.5, grav: -4, drag: 3, sizeMin: 0.12, sizeMax: 0.2, hdr: 3.2 });
        stars(1, ev.x, y, z, c, n(2 * big), 0.35, 4);
        ring(ADD, 1, ev.x, y, z, c, 0.3, 1.5 * big, 0.28, 2.0);
        glow(1, ev.x, y, z, c, 0.9, 0.25, 0.1, 1.6);
        FXBUS.pulse('coin', 0.35);
        break;
      }
      case 'tsheet': {
        const z = front(ev.s), y = ev.y ?? 1;
        ring(ADD, 1, ev.x, y, z, PURPLE, 0.5, 2.6, 0.36, 2.6);
        ring(ADD, 1, p.x, (p.surfaceY || 0) + 0.06, 0, PURPLE, 0.4, 2.8, 0.45, 1.8, true);
        sparkles(ADD, 1, ev.x, y, z, PURPLE, n(18), 1.5, 4.5, { up: 0.8, vz: 2, grav: 1.5, drag: 2.2, lifeMin: 0.45, lifeMax: 0.85, hdr: 3 });
        stars(1, ev.x, y + 0.3, z, WHITE, n(4), 0.6, 3.5);
        glow(1, p.x, p.y + 0.9, 0.6, PURPLE, 2.6, 2.0, 0.22, 0.9);
        FXBUS.pulse('coin', 0.5);
        break;
      }
      case 'bonus': {
        confetti(1, p.x, p.y + 1.2, 0.5, n(70), { sx: 0.3, sy: 0.2, sz: 0.3, vx0: -2.6, vx1: 2.6, vy0: 6, vy1: 10.5, vz0: -2.5, vz1: 2.5, grav: -9, drag: 0.9, life0: 1.6, life1: 2.4 });
        sparkles(ADD, 1, p.x, p.y + 1.2, 0.7, GOLD, n(24), 3, 7, { up: 0.9, grav: -6, drag: 1.6, lifeMin: 0.5, lifeMax: 0.9, hdr: 3.5, shape: 1, sizeMin: 0.25, sizeMax: 0.4 });
        ring(ADD, 1, p.x, p.y + 1, 0.7, GOLD, 0.5, 3.4, 0.4, 2.6);
        FXBUS.pulse('coin', 1); FXBUS.pulse('flash', 0.12);
        break;
      }
      case 'combo': {
        const k = ev.combo || 3;
        ring(ADD, 1, p.x, p.y + 1, 0.7, GOLD, 0.6, 2.2 + k * 0.15, 0.32, 2.2);
        stars(1, p.x, p.y + 1.1, 0.7, GOLD, n(2 + (k / 3 | 0) * 2), 0.9, 4);
        FXBUS.pulse('coin', 0.6);
        break;
      }
      case 'jump': {
        const surf = p.surfaceY || 0;
        puffs(0, ev.x ?? p.x, surf + 0.05, dist, surf > 1 ? roofDust : dustCol, n(8), 1.2, 2.8, { alpha: 0.42 });
        break;
      }
      case 'land': {
        const y = ev.y ?? p.surfaceY ?? 0, imp = clamp((ev.impact || 6) / 6, 0.4, 2), roof = !!ev.onRoof;
        puffs(0, ev.x ?? p.x, y + 0.05, dist, roof ? roofDust : dustCol, n(9 * imp), 1.6, 3.6 * imp, { alpha: 0.46, scale: 0.9 + imp * 0.2 });
        start(0, ev.x ?? p.x, y + 0.04, dist); P.shape = 2; P.orient = 2; P.life = 0.36; P.s0 = 0.5; P.s1 = 2.4 + imp;
        col(roof ? roofDust : dustCol, 1.25); P.a = 0.45; ALPHA.emit(P);
        if (roof) sparks(0, ev.x ?? p.x, y + 0.05, dist, ORANGE, n(6), { sMin: 2, sMax: 5, life0: 0.2, life1: 0.4, hdr: 3 });
        break;
      }
      case 'hop': {
        const s = ev.s ?? dist, x = ev.x ?? p.x;
        sparks(0, x, 1.0, s, ORANGE, n(12), { sMin: 3, sMax: 7, vz: -scroll * 0.35, grav: -16, life0: 0.3, life1: 0.55, hdr: 4.5 });
        sparkles(ADD, 0, x, 1.05, s, GOLD, n(6), 1, 3, { vz: -scroll * 0.3, shape: 1, sizeMin: 0.25, sizeMax: 0.4, hdr: 3.5 });
        break;
      }
      case 'smash': {
        const s = ev.s ?? dist, x = ev.x ?? p.x, y = Math.max(0.6, ev.y ?? 1);
        const c = MC[ev.kind] || MC.barrier;
        const floor = (p.surfaceY || 0) + 0.03;
        debris(0, x, y, s, c, n(24), { sMin: 3, sMax: 8, vz: -scroll * 0.7, floor, darkMix: ev.kind === 'barrier' ? 0.45 : 0.25, size0: 0.2, size1: 0.42, life0: 0.9, life1: 1.4 });
        sparks(0, x, y, s, WHITE, n(16), { sMin: 4, sMax: 11, vz: -scroll * 0.6, hdr: 3.5 });
        sparkles(ADD, 0, x, y, s, c, n(14), 2, 6, { vz: -scroll * 0.6, grav: -6, drag: 2, hdr: 3, sizeMin: 0.14, sizeMax: 0.24 });
        glow(0, x, y, s, c, 2.6, 0.8, 0.2, 2.4);
        start(0, x, y, s); P.vz = -scroll * 0.7; P.shape = 2; P.life = 0.3; P.s0 = 0.5; P.s1 = 3.2; col(c, 2.4); ADD.emit(P);
        break;
      }
      case 'shieldBreak': {
        const z = front(ev.s), x = ev.x ?? p.x, y = ev.y ?? p.y + 1;
        debris(1, x, y, z, GLASS, n(24), { sMin: 4, sMax: 9, vz: 2.5, grav: -12, drag: 0.9, floor: (p.surfaceY || 0) + 0.03, shape: 6, darkMix: 0, bright: 1.0, alpha: 0.5, size0: 0.1, size1: 0.24, life0: 0.45, life1: 0.8 });
        sparkles(ADD, 1, x, y, z, GLASS, n(16), 4, 9, { grav: -10, drag: 1, lifeMin: 0.3, lifeMax: 0.6, hdr: 2.2, shape: 6, orient: 0, spin: 14, sizeMin: 0.12, sizeMax: 0.22, shrink: 0.6 });
        sparkles(ADD, 1, x, y, z, PURPLE, n(22), 3, 8, { grav: -6, drag: 2.2, lifeMin: 0.35, lifeMax: 0.7, hdr: 3.5 });
        ring(ADD, 1, x, y, z, PURPLE, 0.6, 3.4, 0.35, 3);
        ring(ADD, 1, x, y, z, WHITE, 0.3, 2.2, 0.2, 1.6);
        glow(1, x, y, z, PURPLE, 2.0, 0.8, 0.15, 1.5);
        FXBUS.pulse('shield', 1);
        break;
      }
      case 'nearMiss': {
        const side = ev.side === 'left' || ev.side < 0 ? -1 : 1;
        for (let i = 0, m = n(8); i < m; i++) {
          start(1, p.x + side * rnd(0.55, 1.1), p.y + rnd(0.2, 1.9), rnd(-2.5, 0.5));
          P.vz = rnd(22, 34); P.life = rnd(0.18, 0.3); P.s0 = P.s1 = rnd(0.03, 0.05);
          P.shape = 5; P.orient = 1; P.stretch = 0.03; col(CYAN, rnd(1.8, 2.6)); ADD.emit(P);
        }
        sparkles(ADD, 1, p.x + side * 0.7, p.y + 1, -0.5, WHITE, n(6), 1, 3, { vz: 6, hdr: 2.5, shape: 1, sizeMin: 0.2, sizeMax: 0.32 });
        break;
      }
      case 'trainPass': {
        const side = ev.side === 'left' || ev.side < 0 ? -1 : 1;
        for (let i = 0, m = n(6); i < m; i++) {
          start(1, p.x + side * rnd(1.3, 2.4), p.y + rnd(0.3, 3), rnd(-4, 0));
          P.vz = rnd(28, 40); P.life = rnd(0.16, 0.26); P.s0 = P.s1 = rnd(0.025, 0.04);
          P.shape = 5; P.orient = 1; P.stretch = 0.03; col(WHITE, 1.2); P.a = 0.7; ADD.emit(P);
        }
        break;
      }
      case 'bump': {
        const dir = ev.dir || 0;
        sparks(1, p.x + dir * 0.6, p.y + 1, 0, ORANGE, n(14), { sMin: 3, sMax: 7, vx: -dir * 3, hdr: 4.5, life0: 0.25, life1: 0.5 });
        stars(1, p.x + dir * 0.55, p.y + 1.1, 0, WHITE, n(2), 0.2, 4);
        break;
      }
      case 'powerup': {
        const c = PC[ev.kind] || CYAN, z = front(ev.s), x = ev.x ?? p.x, y = ev.y ?? p.y + 1;
        ring(ADD, 1, x, y, z, c, 0.4, 3.8, 0.42, 3.2);
        ring(ADD, 1, p.x, (p.surfaceY || 0) + 0.06, 0, c, 0.5, 4.6, 0.5, 2.2, true);
        sparkles(ADD, 1, x, y, z, c, n(36), 3, 9, { grav: -3, drag: 2.2, lifeMin: 0.4, lifeMax: 0.85, hdr: 3.6, sizeMin: 0.12, sizeMax: 0.22 });
        stars(1, x, y, z, WHITE, n(7), 0.9, 4);
        glow(1, x, y, z, c, 3.0, 0.6, 0.2, 3);
        FXBUS.pulse('flash', 0.3);
        break;
      }
      case 'boostStart': {
        ring(ADD, 1, p.x, p.y + 1, 0.7, CYAN, 0.6, 5.5, 0.45, 3);
        for (let i = 0, m = n(36); i < m; i++) {
          const a = Math.random() * Math.PI * 2, sp = rnd(8, 16);
          start(1, p.x, p.y + 1, 0.6); P.vx = Math.cos(a) * sp; P.vy = Math.sin(a) * sp; P.vz = rnd(2, 8);
          P.drag = 3; P.life = rnd(0.25, 0.45); P.s0 = 0.06; P.s1 = 0.02; P.shape = 5; P.orient = 1; P.stretch = 0.035;
          col(Math.random() < 0.3 ? WHITE : CYAN, 3.5); ADD.emit(P);
        }
        FXBUS.pulse('flash', 0.45);
        break;
      }
      case 'boostEnd':
        puffs(0, p.x, (p.surfaceY || 0) + 0.05, dist, roofDust, n(6), 1, 2.5, { alpha: 0.3 });
        break;
      case 'levelUp': {
        if (sim.mode !== 'play' && sim.mode !== 'ready') break;
        confetti(1, p.x * 0.5, 4.6, -4.5, n(110), { sx: 3.2, sy: 1.3, sz: 3, vx0: -1.5, vx1: 1.5, vy0: -0.5, vy1: 2.5, vz0: 1.5, vz1: 4, grav: -3.5, drag: 1.6, life0: 2.2, life1: 3.2, floor: 0.05, size: 1.3 });
        sparkles(ADD, 1, p.x * 0.4, 5.5, -9, GOLD, n(22), 3, 8, { grav: -4, drag: 1.8, shape: 1, sizeMin: 0.35, sizeMax: 0.6, lifeMin: 0.5, lifeMax: 0.9, hdr: 3.5, vz: 4 });
        FXBUS.pulse('levelUp', 1);
        break;
      }
      case 'hit': {
        const z = front(ev.s), x = ev.x ?? p.x, y = ev.y ?? p.y + 1;
        glow(1, x, y, z, ORANGE, 2.8, 0.9, 0.22, 2.2);
        glow(1, x, y, z, WHITE, 1.3, 0.3, 0.1, 2.4);
        sparks(1, x, y, z, ORANGE, n(34), { sMin: 5, sMax: 13, up: 0.3, grav: -12, drag: 1.4, life0: 0.4, life1: 0.9, hdr: 5, stretch: 0.03 });
        ring(ADD, 1, x, y, z, WHITE, 0.5, 3.6, 0.32, 2.4);
        ring(ADD, 1, p.x, (p.surfaceY || 0) + 0.05, z, ORANGE, 0.5, 5, 0.5, 2, true);
        debris(1, x, y, z, MC[ev.kind] || MC.chargeback, n(14), { sMin: 3, sMax: 8, vz: 1, floor: (p.surfaceY || 0) + 0.03, darkMix: 0.4 });
        stars(1, x, y, z, WHITE, n(6), 0.8, 5);
        puffs(1, x, (p.surfaceY || 0) + 0.05, z, dustCol, n(10), 2, 4.5, { alpha: 0.5, scale: 1.3 });
        FXBUS.pulse('hit', 1);
        break;
      }
      default: break;
    }
  }

  // ------------------------------------------------ per-frame
  function update(sim, frame) {
    if (!sim) return;
    FXBUS.sim = sim;
    const dt = Math.max(0, Math.min(0.1, frame && frame.dt != null ? frame.dt : 1 / 60));
    const rdt = Math.min(0.1, frame && (frame.realDt ?? frame.dt) || 1 / 60);
    if (FXBUS.post && FXBUS.post.tick) { FXBUS.post.tick(rdt, sim); FXBUS.ticked = true; }

    const dist = sim.dist;
    if (lastDist === null || Math.abs(dist - lastDist) > 60) lastDist = dist;
    if (dt > 1e-5) scroll += (((dist - lastDist) / dt) - scroll) * Math.min(1, dt * 10);
    lastDist = dist;
    ADD.time += dt; ALPHA.time += dt;
    if (ADD.time > 4000) { ADD.rebase(3000); ALPHA.rebase(3000); }

    if (sim.themeIdx !== themeIdx && sim.theme) {
      themeIdx = sim.themeIdx;
      const t = sim.theme;
      tmpC.set(t.rdB || '#6a6a70').lerp(tmpC2.set(t.night ? '#6f6a64' : '#d9ccb0'), 0.55);
      dustCol[0] = tmpC.r; dustCol[1] = tmpC.g; dustCol[2] = tmpC.b;
    }

    const p = sim.player, camera = (frame && frame.camera) || ctx.camera;
    const alive = sim.mode === 'play' || sim.mode === 'ready';
    const boost = sim.power && sim.power.boost > 0;
    const rm = FXBUS.reducedMotion;
    const speedK = clamp(((sim.speed || 15) - 15) / 15, 0, 1);

    if (dt > 0 && alive) {
      camera.matrixWorld.extractBasis(camRight, camUp, camFwd); camFwd.negate();
      // speed lines: always a whisper, dense and long at top speed
      if (!rm) {
        accSpeed += dt * (5 + 28 * speedK * speedK) * qMul;
        while (accSpeed >= 1) {
          accSpeed -= 1;
          peripheralStreak(camera, 10, 24, scroll * rnd(1.1, 1.5), 0.02 + 0.022 * speedK, rnd(0.028, 0.045), WHITE, 1.0 + speedK * 0.7, 0.4 + 0.45 * speedK, 0.55);
        }
      }
      // GIG BOOST warp tunnel + trail
      if (boost) {
        accWarp += dt * (rm ? 20 : 210) * qMul;
        while (accWarp >= 1) {
          accWarp -= 1;
          const c = Math.random() < 0.35 ? WHITE : CYAN;
          // sky + flanks only: never across the corridor / fox (lower half)
          peripheralStreak(camera, 16, 40, rnd(55, 90), 0.055, rnd(0.04, 0.08), c, rnd(2.4, 4), 0.9, 2, 0.45, -0.12);
        }
        accTrail += dt * 110 * qMul;
        while (accTrail >= 1) {
          accTrail -= 1;
          start(0, p.x + rnd(-0.25, 0.25), p.y + rnd(0.35, 1.3), dist + rnd(-0.1, 0.3));
          P.vx = rnd(-0.6, 0.6); P.vy = rnd(-0.4, 0.4); P.drag = 2; P.life = rnd(0.3, 0.55);
          P.s0 = rnd(0.05, 0.09); P.s1 = 0.01; P.shape = 5; P.orient = 1; P.stretch = 0.012;
          col(Math.random() < 0.25 ? WHITE : CYAN, 3); ADD.emit(P);
        }
      } else { accWarp = 0; accTrail = 0; }

      // running dust kicks (road or roof)
      if (p.grounded && !boost && sim.mode === 'play' || (p.grounded && sim.mode === 'ready')) {
        const roof = (p.surfaceY || 0) > 1;
        accDust += dt * (4 + 16 * speedK) * qMul * (roof ? 0.5 : 1) * (rm ? 0.5 : 1);
        while (accDust >= 1) {
          accDust -= 1;
          start(0, p.x + rnd(-0.3, 0.3), (p.surfaceY || 0) + 0.06, dist + rnd(0, 0.4));
          P.vx = rnd(-0.9, 0.9); P.vy = rnd(0.5, 1.4); P.vz = rnd(0.5, 2.5); P.grav = -1; P.drag = 2.5; P.floor = (p.surfaceY || 0) + 0.02;
          P.life = rnd(0.35, 0.6); P.s0 = rnd(0.1, 0.18); P.s1 = rnd(0.45, 0.8); P.shape = 4; P.spin = rnd(-1, 1);
          col(roof ? roofDust : dustCol, 1); P.a = 0.28 + 0.12 * speedK; ALPHA.emit(P);
        }
      }

      // power-up auras + magnet pull trails
      const pw = sim.power || {};
      if (pw.magnet > 0 || pw.x2 > 0) {
        accAura += dt * 14 * qMul;
        while (accAura >= 1) {
          accAura -= 1;
          const c = pw.x2 > 0 && (pw.magnet <= 0 || Math.random() < 0.5) ? GOLD : MAGNET;
          const a = Math.random() * Math.PI * 2, r = rnd(0.5, 0.8);
          start(1, p.x + Math.cos(a) * r, p.y + rnd(0.2, 1.6), Math.sin(a) * r * 0.6);
          P.vy = rnd(0.8, 2); P.drag = 1.5; P.life = rnd(0.4, 0.7); P.s0 = rnd(0.18, 0.3); P.s1 = 0.02;
          P.shape = c === GOLD ? 1 : 0; col(c, 2.6); ADD.emit(P);
        }
      }
      if (pw.magnet > 0 && sim.orbs) {
        for (let i = 0; i < sim.orbs.length; i++) {
          const o = sim.orbs[i];
          if (!o.magnet || o.got || Math.random() > 0.7 * qMul) continue;
          const kc = KC[o.kind] || GOLD;
          start(0, o.x + rnd(-0.1, 0.1), o.y + rnd(-0.1, 0.1), o.s);
          P.life = rnd(0.18, 0.3); P.s0 = rnd(0.18, 0.28); P.s1 = 0.02; P.shape = 0;
          P.r = (kc[0] + MAGNET[0]) * 1.4; P.g = (kc[1] + MAGNET[1]) * 1.4; P.b = (kc[2] + MAGNET[2]) * 1.4;
          ADD.emit(P);
        }
      }
    }
    const bufH = ctx.renderer ? ctx.renderer.domElement.height : 800;
    const px = 2 * Math.tan(camera.fov * Math.PI / 360) / Math.max(1, bufH);
    ADD.commit(dist, scroll, px); ALPHA.commit(dist, scroll, px);
  }

  function setQuality(t) { tier = t; qMul = Q_MUL[t] || 1; }

  return { update, onEvent, setQuality, pools: { ADD, ALPHA }, get scroll() { return scroll; } };
}
