// POST — createPost(ctx) -> { render(frame), setSize(w, h, dpr), setQuality(tier), pulse(name, amount) }
//   (+ tick(realDt, sim) — called for you by fx.update through FXBUS; + tier, info)
//
// 'high': scene -> HalfFloat RT (MSAA x4, WebGL2) in LINEAR HDR (three.js never tone-maps or
//         sRGB-encodes when rendering into a render target, so the renderer's ACES setting is
//         simply ignored for the scene pass — no double tonemapping) ->
//         bloom: threshold+Karis prefilter at 1/2 res, dual-filter (ARM "dual Kawase") mip chain
//         1/4..1/32 down + up (9 tiny passes, ~0.7 full-screen-equivalents in total) ->
//         ONE composite pass to the canvas: GIG BOOST radial zoom blur + chromatic streaks
//         (masked off the fox/corridor), chromatic-aberration pulse, bloom add, exposure,
//         ACES (three's exact fit) -> sRGB, per-theme lift/gamma/gain + saturation (crossfades
//         with the theme), vignette, power-up edge glow, flash, dither.
// 'med':  same, MSAA x2, bloom prefilter at 1/4 res and 3 mips, no radial blur.
// 'low':  renderer.render(scene, camera) with renderer ACES + sRGB, no RTs. Flash / edge glow
//         are drawn as a thin additive overlay (only when active).
// If the GPU can't render to half-float targets, 'high'/'med' fall back to the 'low' path.
// Bloom threshold: linear luminance ~1.2 with a soft knee (0.95..1.6) — lit albedo <= 1.0
// won't bloom; emissive >= ~1.6 blooms fully.
// Pulses ('hit','shield','flash','levelUp','coin') take max(current, amount) and decay on
// real time; sim-driven fades (power-up edge glow, boost blur, theme grade) run in tick().
import * as THREE from 'three';
import { FXBUS, clamp, damp } from './fx-bus.js';

const FS_VERT = /* glsl */`
varying vec2 vUv;
void main() { vUv = position.xy * 0.5 + 0.5; gl_Position = vec4(position.xy, 0.0, 1.0); }
`;

const PREFILTER = /* glsl */`
uniform sampler2D tSrc;
uniform vec2 uTexel;
uniform vec3 uThresh;   // threshold, knee, clamp
varying vec2 vUv;
vec3 pre(vec3 c) {
  c = min(max(c, vec3(0.0)), vec3(uThresh.z));
  float br = max(c.r, max(c.g, c.b));
  float soft = clamp(br - uThresh.x + uThresh.y, 0.0, 2.0 * uThresh.y);
  soft = soft * soft / (4.0 * uThresh.y + 1e-4);
  float w = max(soft, br - uThresh.x) / max(br, 1e-4);
  return c * w;
}
float kw(vec3 c) { return 1.0 / (1.0 + max(c.r, max(c.g, c.b))); }
void main() {
  vec3 a = pre(texture2D(tSrc, vUv + uTexel * vec2(-1.0, -1.0)).rgb);
  vec3 b = pre(texture2D(tSrc, vUv + uTexel * vec2( 1.0, -1.0)).rgb);
  vec3 c = pre(texture2D(tSrc, vUv + uTexel * vec2(-1.0,  1.0)).rgb);
  vec3 d = pre(texture2D(tSrc, vUv + uTexel * vec2( 1.0,  1.0)).rgb);
  float wa = kw(a), wb = kw(b), wc = kw(c), wd = kw(d);
  gl_FragColor = vec4((a * wa + b * wb + c * wc + d * wd) / (wa + wb + wc + wd), 1.0);
}
`;

const DOWN = /* glsl */`
uniform sampler2D tSrc;
uniform vec2 uTexel;    // source texel
varying vec2 vUv;
void main() {
  vec2 h = uTexel * 0.5;
  vec3 s = texture2D(tSrc, vUv).rgb * 4.0;
  s += texture2D(tSrc, vUv - h).rgb;
  s += texture2D(tSrc, vUv + h).rgb;
  s += texture2D(tSrc, vUv + vec2(h.x, -h.y)).rgb;
  s += texture2D(tSrc, vUv - vec2(h.x, -h.y)).rgb;
  gl_FragColor = vec4(s * 0.125, 1.0);
}
`;

const UP = /* glsl */`
uniform sampler2D tSrc;   // smaller, accumulated level
uniform sampler2D tAdd;   // this level's downsample
uniform vec2 uTexel;      // source texel
uniform float uAddW;
varying vec2 vUv;
void main() {
  vec2 h = uTexel * 0.5;
  vec3 s = texture2D(tSrc, vUv + vec2(-h.x * 2.0, 0.0)).rgb;
  s += texture2D(tSrc, vUv + vec2(-h.x, h.y)).rgb * 2.0;
  s += texture2D(tSrc, vUv + vec2(0.0, h.y * 2.0)).rgb;
  s += texture2D(tSrc, vUv + vec2(h.x, h.y)).rgb * 2.0;
  s += texture2D(tSrc, vUv + vec2(h.x * 2.0, 0.0)).rgb;
  s += texture2D(tSrc, vUv + vec2(h.x, -h.y)).rgb * 2.0;
  s += texture2D(tSrc, vUv + vec2(0.0, -h.y * 2.0)).rgb;
  s += texture2D(tSrc, vUv + vec2(-h.x, -h.y)).rgb * 2.0;
  gl_FragColor = vec4(s / 12.0 + texture2D(tAdd, vUv).rgb * uAddW, 1.0);
}
`;

const COMPOSITE = /* glsl */`
uniform sampler2D tScene;
uniform sampler2D tBloom;
uniform float uBloom;
uniform float uExposure;
uniform vec3 uLift;
uniform vec3 uGammaInv;
uniform vec3 uGain;
uniform float uSat;
uniform float uVig;
uniform float uAspect;
uniform vec2 uCenter;
uniform vec2 uFox;
uniform float uRadial;
uniform float uStreak;
uniform float uCA;
uniform vec3 uEdgeCol;
uniform float uEdge;
uniform vec3 uFlashCol;
uniform float uFlash;
uniform float uTime;
varying vec2 vUv;

vec3 RRTAndODTFit(vec3 v) {
  vec3 a = v * (v + 0.0245786) - 0.000090537;
  vec3 b = v * (0.983729 * v + 0.4329510) + 0.238081;
  return a / b;
}
vec3 acesThree(vec3 color) {
  const mat3 ACESInputMat = mat3(vec3(0.59719, 0.07600, 0.02840), vec3(0.35458, 0.90834, 0.13383), vec3(0.04823, 0.01566, 0.83777));
  const mat3 ACESOutputMat = mat3(vec3(1.60475, -0.10208, -0.00327), vec3(-0.53108, 1.10813, -0.07276), vec3(-0.07367, -0.00605, 1.07602));
  color *= 1.0 / 0.6;
  color = ACESInputMat * color;
  color = RRTAndODTFit(color);
  color = ACESOutputMat * color;
  return clamp(color, 0.0, 1.0);
}
vec3 srgb(vec3 c) {
  return mix(pow(c, vec3(0.41666)) * 1.055 - vec3(0.055), c * 12.92, vec3(lessThanEqual(c, vec3(0.0031308))));
}
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }

void main() {
  vec2 uv = vUv;
  vec3 col;
#ifdef RADIAL
  if (uRadial > 0.0005) {
    vec2 d = uv - uCenter;
    float rc = length(vec2(d.x * uAspect, d.y));
    vec2 fd = vec2((uv.x - uFox.x) * uAspect, (uv.y - uFox.y) * 0.8);
    float mask = smoothstep(0.1, 0.55, rc) * smoothstep(0.1, 0.34, length(fd));
    float amt = uRadial * mask;
    vec3 acc = vec3(0.0), ws = vec3(0.0);
    float jit = hash(gl_FragCoord.xy + fract(uTime * 7.0) * 57.0);   // per-pixel tap jitter: no ghost copies
    for (int i = 0; i < 8; i++) {
      float t = (float(i) + jit) / 8.0;
      vec3 s = texture2D(tScene, uCenter + d * (1.0 - amt * t)).rgb;
      float k = (t - 0.5) * uStreak * mask;
      vec3 w = vec3(1.0 + k, 1.0, 1.0 - k) * (1.0 - t * 0.45);
      acc += s * w; ws += w;
    }
    col = acc / ws;
  } else
#endif
  if (uCA > 0.0005) {
    vec2 off = (uv - 0.5) * uCA * 0.018;
    col = vec3(texture2D(tScene, uv + off).r, texture2D(tScene, uv).g, texture2D(tScene, uv - off).b);
  } else {
    col = texture2D(tScene, uv).rgb;
  }
  col += texture2D(tBloom, uv).rgb * uBloom;
  col = acesThree(col * uExposure);
  col = srgb(col);
  // grade (display space): lift / gamma / gain, saturation
  col = col * uGain + uLift * (1.0 - col);
  col = pow(max(col, vec3(0.0)), uGammaInv);
  float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = mix(vec3(l), col, uSat);
  // vignette (aspect-aware, gentle)
  vec2 vd = (uv - 0.5) * vec2(min(uAspect, 1.0) * 1.6, 1.25);
  col *= 1.0 - uVig * smoothstep(0.45, 1.15, length(vd));
  // power-up edge glow — a thin band hugging the screen edges
  if (uEdge > 0.001) {
    float ex = min(uv.x, 1.0 - uv.x) * uAspect;
    float ey = min(uv.y, 1.0 - uv.y);
    float e = min(ex, ey);
    col += uEdgeCol * uEdge * (exp(-e * 70.0) * 0.75 + exp(-e * 18.0) * 0.1);
  }
  col += uFlashCol * uFlash;
  col += (hash(gl_FragCoord.xy + fract(uTime) * 91.0) - 0.5) / 255.0;
  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
`;

const OVERLAY = /* glsl */`
uniform vec3 uEdgeCol;
uniform float uEdge;
uniform vec3 uFlashCol;
uniform float uFlash;
uniform float uAspect;
varying vec2 vUv;
void main() {
  float ex = min(vUv.x, 1.0 - vUv.x) * uAspect;
  float ey = min(vUv.y, 1.0 - vUv.y);
  float e = min(ex, ey);
  vec3 c = uEdgeCol * uEdge * (exp(-e * 70.0) * 0.75 + exp(-e * 18.0) * 0.1) + uFlashCol * uFlash;
  gl_FragColor = vec4(c, 1.0);
}
`;

// per time-of-day grade (display space). gain/lift/gamma per channel, saturation, exposure.
const GRADES = {
  dawn:     { lift: [0.0, 0.006, 0.03], gamma: [1.0, 1.0, 1.03], gain: [1.0, 0.985, 1.02], sat: 1.08, exp: 1.02 },
  sunrise:  { lift: [0.015, 0.0, 0.02], gamma: [1.02, 1.0, 0.98], gain: [1.05, 1.0, 0.93], sat: 1.12, exp: 1.02 },
  day:      { lift: [0.0, 0.0, 0.012], gamma: [1.0, 1.0, 1.0], gain: [1.02, 1.01, 0.99], sat: 1.12, exp: 1.0 },
  golden:   { lift: [0.012, 0.005, 0.0], gamma: [1.02, 1.0, 0.97], gain: [1.07, 1.0, 0.89], sat: 1.12, exp: 1.02 },
  dusk:     { lift: [0.022, 0.0, 0.035], gamma: [1.0, 0.98, 1.02], gain: [1.05, 0.97, 0.95], sat: 1.1, exp: 1.04 },
  bluehour: { lift: [0.0, 0.01, 0.045], gamma: [0.98, 1.0, 1.04], gain: [0.96, 1.0, 1.06], sat: 1.07, exp: 1.06 },
  night:    { lift: [0.0, 0.007, 0.03], gamma: [0.98, 1.0, 1.03], gain: [0.98, 1.0, 1.05], sat: 1.14, exp: 1.08 },
};

export function createPost(ctx) {
  const { renderer } = ctx;
  const scene = ctx.scene;
  const canHalf = renderer.extensions.has('EXT_color_buffer_float') || renderer.extensions.has('EXT_color_buffer_half_float');
  // MSAA sample counts actually supported for RGBA16F renderbuffers (some GPUs allow fewer, or none)
  let maxSamples = renderer.capabilities.maxSamples || 4;
  try {
    const gl = renderer.getContext();
    const s = gl.getInternalformatParameter && gl.getInternalformatParameter(gl.RENDERBUFFER, gl.RGBA16F, gl.SAMPLES);
    if (s && s.length) maxSamples = Math.min(maxSamples, Math.max(...s)); else if (s) maxSamples = 0;
  } catch (e) { /* keep capabilities.maxSamples */ }
  if (!canHalf) console.warn('[post] no half-float render targets — using the low (direct) path');

  let tier = 'high';
  let W = 0, H = 0;
  const size = new THREE.Vector2();

  // --- fullscreen triangle
  const tri = new THREE.BufferGeometry();
  tri.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]), 3));
  tri.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e9);
  const fsCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  const fsScene = new THREE.Scene();
  const quad = new THREE.Mesh(tri, null);
  quad.frustumCulled = false;
  fsScene.add(quad);
  const mat = (frag, uniforms, defines = {}) => new THREE.ShaderMaterial({
    vertexShader: FS_VERT, fragmentShader: frag, uniforms, defines,
    depthTest: false, depthWrite: false, toneMapped: false,
  });
  const preMat = mat(PREFILTER, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() }, uThresh: { value: new THREE.Vector3(1.2, 0.4, 48) } });
  const downMat = mat(DOWN, { tSrc: { value: null }, uTexel: { value: new THREE.Vector2() } });
  const upMat = mat(UP, { tSrc: { value: null }, tAdd: { value: null }, uTexel: { value: new THREE.Vector2() }, uAddW: { value: 1 } });
  const U = {
    tScene: { value: null }, tBloom: { value: null }, uBloom: { value: 0.3 }, uExposure: { value: 1 },
    uLift: { value: new THREE.Vector3() }, uGammaInv: { value: new THREE.Vector3(1, 1, 1) }, uGain: { value: new THREE.Vector3(1, 1, 1) },
    uSat: { value: 1.1 }, uVig: { value: 0.22 }, uAspect: { value: 1 },
    uCenter: { value: new THREE.Vector2(0.5, 0.64) }, uFox: { value: new THREE.Vector2(0.5, 0.25) },
    uRadial: { value: 0 }, uStreak: { value: 0 }, uCA: { value: 0 },
    uEdgeCol: { value: new THREE.Vector3() }, uEdge: { value: 0 },
    uFlashCol: { value: new THREE.Vector3(1, 1, 1) }, uFlash: { value: 0 }, uTime: { value: 0 },
  };
  const compHigh = mat(COMPOSITE, U, { RADIAL: 1 });
  const compMed = mat(COMPOSITE, U);
  const overlayMat = new THREE.ShaderMaterial({
    vertexShader: FS_VERT, fragmentShader: OVERLAY,
    uniforms: { uEdgeCol: U.uEdgeCol, uEdge: U.uEdge, uFlashCol: U.uFlashCol, uFlash: U.uFlash, uAspect: U.uAspect },
    depthTest: false, depthWrite: false, transparent: true, blending: THREE.AdditiveBlending, toneMapped: false,
  });

  // --- targets
  let sceneRT = null, downs = [], ups = [];
  const rtOpts = { type: THREE.HalfFloatType, format: THREE.RGBAFormat, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter,
    depthBuffer: false, stencilBuffer: false, generateMipmaps: false };
  function disposeRTs() {
    if (sceneRT) sceneRT.dispose();
    for (const r of downs) r.dispose(); for (const r of ups) r.dispose();
    sceneRT = null; downs = []; ups = [];
  }
  function buildRTs() {
    disposeRTs();
    if (tier === 'low' || !canHalf) return;
    const samples = Math.max(0, Math.min(maxSamples, tier === 'high' ? 4 : 2));
    sceneRT = new THREE.WebGLRenderTarget(W, H, { ...rtOpts, depthBuffer: true, samples });
    sceneRT.texture.name = 'post.scene';
    const first = tier === 'high' ? 1 : 2;           // 1/2 or 1/4 res
    const levels = tier === 'high' ? 5 : 4;
    for (let i = 0; i < levels; i++) {
      const d = Math.pow(2, first + i);
      const w = Math.max(1, Math.round(W / d)), h = Math.max(1, Math.round(H / d));
      const r = new THREE.WebGLRenderTarget(w, h, rtOpts); r.texture.name = 'post.down' + i; downs.push(r);
      if (i < levels - 1) { const u = new THREE.WebGLRenderTarget(w, h, rtOpts); u.texture.name = 'post.up' + i; ups.push(u); }
    }
  }
  function ensureSize() {
    renderer.getDrawingBufferSize(size);
    const w = Math.max(1, size.x | 0), h = Math.max(1, size.y | 0);
    if (w !== W || h !== H || (!sceneRT && tier !== 'low' && canHalf)) { W = w; H = h; buildRTs(); }
    U.uAspect.value = W / H;
  }
  function pass(material, target) {
    quad.material = material;
    renderer.setRenderTarget(target);
    renderer.render(fsScene, fsCam);
  }

  // --- pulses & fades
  const pul = { hit: 0, shield: 0, flash: 0, levelUp: 0, coin: 0 };
  const edge = { magnet: 0, x2: 0, boost: 0 };
  const EDGE_COL = {
    magnet: new THREE.Color('#ff5a6e'), x2: new THREE.Color('#ffd23f'), boost: new THREE.Color('#4fd8ff'),
  };
  const grade = { lift: [0, 0, 0.01], gamma: [1, 1, 1], gain: [1, 1, 1], sat: 1.1, exp: 1 };
  const tint = new THREE.Color(1, 1, 1), tmpC = new THREE.Color();
  let gradeTarget = GRADES.day, themeIdx = -1, radial = 0, time = 0, warnT = 0, deathK = 0;

  function themeGrade(theme) {
    const g = GRADES[theme && theme.tod] || GRADES.day;
    // tint the gain a touch toward the stage's key light
    if (theme && theme.key) { tmpC.set(theme.key); tint.setRGB(0.93 + tmpC.r * 0.07, 0.93 + tmpC.g * 0.07, 0.93 + tmpC.b * 0.07); }
    else tint.setRGB(1, 1, 1);
    return g;
  }

  function tick(rdt, sim) {
    if (!(rdt >= 0)) rdt = 1 / 60;
    time += rdt;
    pul.hit = Math.max(0, pul.hit - rdt * 2.2); pul.shield = Math.max(0, pul.shield - rdt * 2.8);
    pul.flash = Math.max(0, pul.flash - rdt * 4); pul.levelUp = Math.max(0, pul.levelUp - rdt * 1.3);
    pul.coin = Math.max(0, pul.coin - rdt * 6);
    sim = sim || FXBUS.sim;
    const rm = FXBUS.reducedMotion;
    if (sim) {
      if (sim.themeIdx !== themeIdx) {
        const snap = themeIdx < 0;
        themeIdx = sim.themeIdx; gradeTarget = themeGrade(sim.theme);
        if (snap) copyGrade(gradeTarget, 1);
      }
      const pw = sim.power || {}, mx = sim.powerMax || { magnet: 10, x2: 12, boost: 5 };
      const dead = sim.mode === 'dying' || sim.mode === 'over' || sim.mode === 'ready';   // no HUD glow on title/death
      const dying = sim.mode === 'dying' || sim.mode === 'over';
      deathK = damp(deathK, dying ? 1 : 0, dying ? 3 : 6, rdt);
      warnT += rdt;
      for (const k in edge) {
        const left = pw[k] || 0;
        let target = left > 0 && !dead ? 1 : 0;
        if (target > 0 && left < 2) target = 0.45 + 0.55 * (0.5 + 0.5 * Math.cos(warnT * 18)); // expiring: blink
        if (target > 0 && mx[k] && left > mx[k] - 0.35) target = 1.35;                         // pickup pop
        edge[k] = damp(edge[k], target, target > edge[k] ? 12 : 5, rdt);
      }
      const boostK = FXBUS.boostK || 0, speedK = FXBUS.speedK || 0;
      // zoom-blur strength, normalised so wide screens don't smear further in pixels
      const wide = 1 / Math.max(1, U.uAspect.value);
      const r = rm ? 0 : (boostK * 0.08 + speedK * speedK * 0.018) * wide;
      radial = damp(radial, r, 8, rdt);
    }
    copyGrade(gradeTarget, 1 - Math.exp(-rdt * 1.2));
  }
  function copyGrade(g, k) {
    for (let i = 0; i < 3; i++) {
      grade.lift[i] += (g.lift[i] - grade.lift[i]) * k;
      grade.gamma[i] += (g.gamma[i] - grade.gamma[i]) * k;
      grade.gain[i] += (g.gain[i] - grade.gain[i]) * k;
    }
    grade.sat += (g.sat - grade.sat) * k; grade.exp += (g.exp - grade.exp) * k;
  }

  function applyUniforms() {
    const rm = FXBUS.reducedMotion;
    U.uLift.value.set(grade.lift[0], grade.lift[1], grade.lift[2]);
    U.uGammaInv.value.set(1 / grade.gamma[0], 1 / grade.gamma[1], 1 / grade.gamma[2]);
    U.uGain.value.set(grade.gain[0] * tint.r, grade.gain[1] * tint.g, grade.gain[2] * tint.b);
    U.uSat.value = grade.sat * (1 - 0.3 * deathK);
    U.uExposure.value = grade.exp * (1 + pul.levelUp * 0.12 - pul.hit * 0.08);
    U.uBloom.value = (tier === 'high' ? 0.22 : 0.26) * (1 + pul.coin * 0.35 + pul.levelUp * 0.8 + pul.shield * 0.5);
    U.uCA.value = rm ? 0 : Math.max(pul.hit, pul.shield * 0.8);
    U.uRadial.value = tier === 'high' ? radial : 0;
    U.uStreak.value = clamp(radial * 7 + U.uCA.value * 0.6, 0, 0.9);
    U.uCenter.value.set(FXBUS.vanishUV[0], FXBUS.vanishUV[1]);
    U.uFox.value.set(FXBUS.foxUV[0], FXBUS.foxUV[1]);
    let er = 0, eg = 0, eb = 0, ea = 0;
    for (const k in edge) { const e = edge[k]; if (e > 0.001) { er += EDGE_COL[k].r * e; eg += EDGE_COL[k].g * e; eb += EDGE_COL[k].b * e; ea = Math.max(ea, e); } }
    const es = ea > 0 ? 1 / Math.max(1, (er + eg + eb) / 1.6) : 0;
    U.uEdgeCol.value.set(er * es, eg * es, eb * es);
    U.uEdge.value = ea > 0.001 ? 0.42 * (0.85 + 0.15 * Math.sin(time * 5.5)) : 0;
    // flash colour: hit = hot red-white, shield = lavender, otherwise white
    const f = Math.max(pul.flash * 0.55, pul.hit * 0.28, pul.shield * 0.3, pul.levelUp * 0.08);
    if (pul.hit * 0.28 >= f - 1e-4 && pul.hit > 0) U.uFlashCol.value.set(1, 0.45, 0.35);
    else if (pul.shield * 0.3 >= f - 1e-4 && pul.shield > 0) U.uFlashCol.value.set(0.8, 0.7, 1);
    else U.uFlashCol.value.set(1, 1, 0.96);
    U.uFlash.value = rm ? f * 0.4 : f;
    U.uTime.value = time % 1000;
    U.uVig.value = 0.2 + pul.hit * 0.25 + deathK * 0.14;
  }

  const post = {
    get tier() { return tier; },
    info: { passes: 0 },
    tick,
    pulse(name, amount = 1) {
      if (!(name in pul)) return;
      pul[name] = Math.max(pul[name], clamp(amount, 0, 2));
    },
    setSize(w, h, dpr) { ensureSize(); },
    setQuality(t) {
      if (t !== 'high' && t !== 'med' && t !== 'low') return;
      if (t === tier && (sceneRT || t === 'low')) return;
      tier = t; W = 0; H = 0; ensureSize();
    },
    render(frame) {
      const camera = (frame && frame.camera) || ctx.camera;
      if (!FXBUS.ticked) tick(typeof frame === 'number' ? frame : (frame && (frame.realDt ?? frame.dt)) || 1 / 60, FXBUS.sim);
      FXBUS.ticked = false;
      ensureSize();
      applyUniforms();
      if (tier === 'low' || !sceneRT) {
        renderer.toneMappingExposure = U.uExposure.value;      // carry the grade's exposure/pulses over
        renderer.setRenderTarget(null);
        renderer.render(scene, camera);
        if (U.uEdge.value > 0.001 || U.uFlash.value > 0.002) {
          const ac = renderer.autoClear; renderer.autoClear = false;
          quad.material = overlayMat; renderer.render(fsScene, fsCam);
          renderer.autoClear = ac;
        }
        post.info.passes = 1;
        return;
      }
      // 1. scene -> HDR target (three skips tone mapping / sRGB encode for render targets)
      renderer.setRenderTarget(sceneRT);
      renderer.render(scene, camera);
      // 2. bloom chain
      preMat.uniforms.tSrc.value = sceneRT.texture;
      preMat.uniforms.uTexel.value.set(1 / W, 1 / H);
      pass(preMat, downs[0]);
      for (let i = 1; i < downs.length; i++) {
        downMat.uniforms.tSrc.value = downs[i - 1].texture;
        downMat.uniforms.uTexel.value.set(1 / downs[i - 1].width, 1 / downs[i - 1].height);
        pass(downMat, downs[i]);
      }
      let src = downs[downs.length - 1];
      for (let i = downs.length - 2; i >= 0; i--) {
        upMat.uniforms.tSrc.value = src.texture;
        upMat.uniforms.tAdd.value = downs[i].texture;
        upMat.uniforms.uTexel.value.set(1 / src.width, 1 / src.height);
        upMat.uniforms.uAddW.value = 1;
        pass(upMat, ups[i]);
        src = ups[i];
      }
      // 3. composite -> canvas
      U.tScene.value = sceneRT.texture;
      U.tBloom.value = src.texture;
      pass(tier === 'high' ? compHigh : compMed, null);
      post.info.passes = 2 + downs.length * 2 - 1;
    },
    dispose() { disposeRTs(); tri.dispose(); for (const m of [preMat, downMat, upMat, compHigh, compMed, overlayMat]) m.dispose(); },
  };
  post.setQuality(ctx.tier || 'high');
  FXBUS.post = post;
  return post;
}
