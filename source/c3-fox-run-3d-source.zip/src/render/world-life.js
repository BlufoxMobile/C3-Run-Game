// WORLD — ambient life: bird flocks, low mist banks, fireflies, oncoming traffic on the far
// carriageway (headlights at night), the Chicago L (parallel elevated line + overhead crossings
// with trains rumbling across), neon blade signs in the Loop. Everything stays off the lanes.
// Owned by the WORLD agent.
import * as THREE from 'three';
import { BEND_GLSL_PARS, BEND_GLSL_APPLY, BEND } from '../core/bend.js';
import { WU, Pool, bentMat, patchShader, hs, lerp, mergeGeos, boxGeo, beamGeo, paint, NEAR_FADE_GLSL, NEAR_FADE_PARS, NEAR_FADE_VPARS, NEAR_FADE_VBEGIN, nearFadeUniforms } from './world-common.js';
import { mistTexture, glowTexture, trainTextures, neonTexture, NEON_WORDS } from './world-tex.js';
import { LOOKS, BB_VPARS, BB_PROJECT, BEHIND } from './world-props.js';

const STEP_ = 2;
const SIDES = [-1, 1];
const HEAD_X = [-0.62, 0.62];
function carGeo() {
  const g = [];
  g.push(boxGeo(-0.92, 0.32, -2.25, 0.92, 1.02, 2.25, '#ffffff'));                 // body (instance colour paints it)
  g.push(boxGeo(-0.8, 1.02, -1.25, 0.8, 1.55, 0.85, '#27313c'));                   // cabin glass
  g.push(boxGeo(-0.78, 1.55, -1.15, 0.78, 1.6, 0.75, '#dfe3e8'));                   // roof
  for (const x of [-0.8, 0.8]) for (const z of [-1.45, 1.45]) g.push(boxGeo(x - 0.16, 0, z - 0.34, x + 0.16, 0.66, z + 0.34, '#15171a'));
  for (const x of [-0.62, 0.62]) {
    g.push(boxGeo(x - 0.22, 0.66, 2.24, x + 0.22, 0.84, 2.3, new THREE.Color(9, 8.6, 7.6)));   // headlights
    g.push(boxGeo(x - 0.2, 0.7, -2.3, x + 0.2, 0.86, -2.24, new THREE.Color(6, 0.25, 0.2)));  // taillights
  }
  return mergeGeos(g);
}
function lSegGeo() {           // parallel L, 8 m, left of the road (x -6.4 .. -11)
  const g = [], st = '#5f7464', st2 = '#4b5d50';
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  for (const x of [-6.7, -10.6]) g.push(boxGeo(x - 0.22, 0, -0.22, x + 0.22, 6.6, 0.22, st));
  g.push(boxGeo(-11.0, 6.1, -0.3, -6.3, 6.7, 0.3, st2));
  for (const x of [-6.45, -10.85]) {
    g.push(boxGeo(x - 0.14, 6.6, -4.02, x + 0.14, 7.7, 4.02, st));
    for (let k = 0; k < 4; k++) g.push(beamGeo(V(x, 6.7, -4 + k * 2), V(x, 7.6, -3 + k * 2), 0.07, st2));
  }
  g.push(boxGeo(-10.9, 7.6, -4.02, -6.4, 7.72, 4.02, '#3a3430'));
  for (const x of [-7.35, -8.1, -9.25, -10.0]) g.push(boxGeo(x - 0.05, 7.72, -4.02, x + 0.05, 7.86, 4.02, '#8b8f93'));
  return mergeGeos(g);
}
function lCrossGeo() {         // L crossing over the road, bottom at 7.8 m
  const g = [], st = '#5f7464', st2 = '#4b5d50';
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  for (const z of [-1.7, 1.7]) {
    g.push(boxGeo(-48, 7.8, z - 0.16, 48, 9.1, z + 0.16, st));
    for (let k = -12; k < 12; k++) g.push(beamGeo(V(k * 4, 7.9, z), V(k * 4 + 2, 9.0, z), 0.09, st2));
  }
  g.push(boxGeo(-48, 8.95, -1.9, 48, 9.1, 1.9, '#3a3430'));
  for (const z of [-0.9, -0.2, 0.2, 0.9]) g.push(boxGeo(-48, 9.1, z - 0.05, 48, 9.24, z + 0.05, '#8b8f93'));
  for (let k = -5; k <= 5; k++) g.push(boxGeo(k * 3.2 - 0.3, 7.7, -0.12, k * 3.2 + 0.3, 7.8, 0.12, new THREE.Color(4.5, 3.6, 2.2)));
  for (const x of [-6.3, 6.3, -24, 24]) {
    for (const z of [-1.5, 1.5]) g.push(boxGeo(x - 0.24, 0, z - 0.24, x + 0.24, 7.8, z + 0.24, st));
    g.push(boxGeo(x - 0.3, 7.3, -1.9, x + 0.3, 7.8, 1.9, st2));
  }
  return mergeGeos(g);
}

export function createLife(ctx, root, env, props) {
  const T = env.track;
  const P = {};
  let density = 1, extras = true;

  // ---------------------------------------------------------------- mist banks
  const mistMat = bentMat(new THREE.MeshBasicMaterial({ map: mistTexture(), transparent: true, depthWrite: false, fog: false, color: '#dfe6ee', opacity: 1.0 }),
    sh => patchShader(sh, {
      uniforms: { uTime: WU.uTime, uWind: WU.uWind },
      vPars: BB_VPARS + 'varying float vNear;',
      vProject: BB_PROJECT.replace('float sw =', 'float sw = 0.0 *').replace('gl_Position = projectionMatrix * mvPosition;', 'gl_Position = projectionMatrix * mvPosition;\nvNear = smoothstep(aP.y, aP.y + 24.0, -mvPosition.z);'),
      fPars: 'varying float vNear;',
      fColor: 'diffuseColor.a *= vNear;',
    }), 'mist');
  const bbGeo = new THREE.PlaneGeometry(1, 1); bbGeo.translate(0.5, 0.5, 0);
  P.mist = new Pool(bbGeo.clone(), mistMat, 60, { attrs: { aUV: 4, aP: 4 }, color: true, name: 'world-mist', order: 3 });

  // ---------------------------------------------------------------- neon blade signs (Loop)
  const neonTex = neonTexture();
  const neonMat = bentMat(new THREE.MeshBasicMaterial({ map: neonTex, color: new THREE.Color(3.2, 3.2, 3.2) }), sh => patchShader(sh, {
    vPars: 'attribute vec4 aUV;',
    vEnd: '#ifdef USE_MAP\nvMapUv = aUV.xy + uv * aUV.zw;\n#endif',
  }), 'neon');
  const neonGeo = new THREE.PlaneGeometry(1.7, 3.6); neonGeo.translate(0, 1.8, 0);
  P.neon = new Pool(neonGeo, neonMat, 40, { attrs: { aUV: 4 }, name: 'world-neon' });
  env.neon = (s, x, seed) => {
    const k = Math.floor(hs(seed, 5) * NEON_WORDS.length);
    const i = P.neon.add(s, x - Math.sign(x) * 0.95, lerp(4.4, 8.5, hs(seed, 6)), 0, 0, 1, 1, 1, 1);
    if (i < 0) return;
    const cx = (k % 4) * 0.25, cy = 1 - ((k / 4 | 0) + 1) * 0.5;
    P.neon.attr('aUV', i, cx + 0.125 - 0.0625, cy + 0.02, 0.125, 0.46);
  };

  // ---------------------------------------------------------------- traffic (far carriageway, oncoming)
  const carMat = bentMat(new THREE.MeshLambertMaterial({ vertexColors: true }), sh => patchShader(sh, {
    uniforms: { uGlowK: { value: 1 } },
    vPars: 'attribute float aGlow;\nvarying float vGlow;',
    vBegin: 'vGlow = aGlow;',
    fPars: 'uniform float uGlowK;\nvarying float vGlow;',
    fColor: 'vec3 pGlow = max(vColor.rgb - 1.0, 0.0);\ndiffuseColor.rgb = min(diffuseColor.rgb, vec3(1.0));',
    fEmissive: 'totalEmissiveRadiance += pGlow * (0.06 + vGlow * 0.9);',
  }), 'car');
  P.car = new Pool(carGeo(), carMat, 24, { attrs: { aGlow: 1 }, color: true, name: 'world-cars' });
  const haloMat = bentMat(new THREE.MeshBasicMaterial({ map: glowTexture(), transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, fog: false }),
    sh => patchShader(sh, { uniforms: { uTime: WU.uTime, uWind: WU.uWind }, vPars: BB_VPARS, vProject: BB_PROJECT }), 'carHalo');
  P.carHalo = new Pool(bbGeo.clone(), haloMat, 60, { attrs: { aUV: 4, aP: 4 }, color: true, name: 'world-carhalos', order: 6 });
  const cars = [];   // { s, v, x, i (car idx is tracked via data) }
  const PAINT = ['#c8102e', '#f2f2f2', '#1b1d22', '#2456a8', '#9aa3ad', '#d8a31a', '#3d6b4a', '#6c2a8c'].map(c => new THREE.Color(c));
  let carT = 0;

  // ---------------------------------------------------------------- the L (Loop)
  const lGlow = { value: 1 };
  const lMat = bentMat(new THREE.MeshLambertMaterial({ vertexColors: true }), sh => patchShader(sh, {
    uniforms: { ...nearFadeUniforms(), uGlowK: lGlow },
    vPars: NEAR_FADE_VPARS, vBegin: NEAR_FADE_VBEGIN,
    fPars: NEAR_FADE_PARS + '\nuniform float uGlowK;',
    fColor: 'vec3 pGlow = max(vColor.rgb - 1.0, 0.0);\ndiffuseColor.rgb = min(diffuseColor.rgb, vec3(1.0));\n' + NEAR_FADE_GLSL,
    fEmissive: 'totalEmissiveRadiance += pGlow * uGlowK;',
  }), 'lsteel');
  P.lseg = new Pool(lSegGeo(), lMat, 30, { name: 'world-l-structure' });
  P.lcross = new Pool(lCrossGeo(), lMat, 3, { name: 'world-l-crossing' });
  const tt = trainTextures();
  const trainU = { uNightE: { value: 1 } };
  const trainMat = bentMat(new THREE.MeshLambertMaterial({ map: tt.map, emissiveMap: tt.emissive, emissive: 0xffffff }), sh => patchShader(sh, {
    uniforms: { ...trainU, ...nearFadeUniforms() }, fPars: 'uniform float uNightE;\n' + NEAR_FADE_PARS,
    vPars: NEAR_FADE_VPARS, vBegin: NEAR_FADE_VBEGIN,
    fEmissive: 'totalEmissiveRadiance *= uNightE;', fColor: NEAR_FADE_GLSL,
  }), 'train');
  const trainGeo = new THREE.BoxGeometry(2.8, 3.1, 14.4); trainGeo.translate(0, 1.55, 0);
  P.train = new Pool(trainGeo, trainMat, 24, { name: 'world-l-trains' });
  const trains = [];  // parallel: { s, v, cars:[...] } ; crossing: { s, x, v, n }
  let nextCross = 0, trainT = 3;

  // ---------------------------------------------------------------- birds (camera-relative)
  const birdGeo = new THREE.BufferGeometry();
  birdGeo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([
    0, 0, -0.35, -1, 0.05, 0.1, 0, 0, 0.25,
    0, 0, -0.35, 0, 0, 0.25, 1, 0.05, 0.1]), 3));
  birdGeo.computeVertexNormals();
  const birdMat = bentMat(new THREE.MeshBasicMaterial({ color: '#1d2230', side: THREE.DoubleSide, fog: true }), sh => patchShader(sh, {
    uniforms: { uTime: WU.uTime },
    vPars: 'uniform float uTime;',
    vBegin: 'transformed.y += sin(uTime * 11.0 + instanceMatrix[3].x * 0.7 + instanceMatrix[3].y) * abs(position.x) * 0.75;',
  }), 'bird');
  const BIRDS = 36;
  const birds = new THREE.InstancedMesh(birdGeo, birdMat, BIRDS);
  birds.frustumCulled = false; birds.count = 0; birds.name = 'world-birds';
  const flocks = [0, 1].map(k => ({ x: -80 + k * 150, y: 30, z: 90, vx: 6, n: 0, off: [], active: false }));
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3();

  // ---------------------------------------------------------------- fireflies (points, GPU wrapped)
  const FF = 220;
  const ffPos = new Float32Array(FF * 3), ffSeed = new Float32Array(FF);
  for (let i = 0; i < FF; i++) {
    const side = i % 2 ? 1 : -1;
    ffPos[i * 3] = side * lerp(5.8, 30, Math.pow(hs(i, 1), 1.6));
    ffPos[i * 3 + 1] = Math.abs(ffPos[i * 3]) < 6.2 ? lerp(0.5, 2.5, hs(i, 2)) : lerp(2.9, 5.0, hs(i, 2));
    ffPos[i * 3 + 2] = hs(i, 3) * 80;
    ffSeed[i] = hs(i, 4);
  }
  const ffGeo = new THREE.BufferGeometry();
  ffGeo.setAttribute('position', new THREE.BufferAttribute(ffPos, 3));
  ffGeo.setAttribute('aSeed', new THREE.BufferAttribute(ffSeed, 1));
  const ffU = { uTime: WU.uTime, uScroll: WU.uScroll, uAmt: { value: 0 }, uTex: { value: glowTexture() }, ...BEND.uniforms };
  const ffMat = new THREE.ShaderMaterial({
    uniforms: ffU, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    vertexShader: /* glsl */`
${BEND_GLSL_PARS}
uniform float uTime, uScroll, uAmt;
attribute float aSeed;
varying float vA;
void main() {
  vec3 p = position;
  p.z = mod(uScroll + p.z, 80.0) - 72.0;
  p.x += sin(uTime * 0.6 + aSeed * 30.0) * 0.8;
  p.y += sin(uTime * 0.9 + aSeed * 17.0) * 0.35;
  vec4 mvPosition = modelViewMatrix * vec4(p, 1.0);
  ${BEND_GLSL_APPLY}
  gl_Position = projectionMatrix * mvPosition;
  float blink = pow(max(sin(uTime * (1.1 + aSeed) + aSeed * 40.0), 0.0), 4.0);
  vA = blink * uAmt * smoothstep(-72.0, -55.0, p.z);
  gl_PointSize = clamp(220.0 / -mvPosition.z, 2.0, 12.0);
}`,
    fragmentShader: /* glsl */`
uniform sampler2D uTex;
varying float vA;
void main() {
  float a = texture2D(uTex, gl_PointCoord).a * vA;
  if (a < 0.01) discard;
  gl_FragColor = vec4(vec3(2.2, 2.6, 0.7) * a, a);
}`,
  });
  const fireflies = new THREE.Points(ffGeo, ffMat);
  fireflies.frustumCulled = false; fireflies.visible = false; fireflies.name = 'world-fireflies';

  for (const k in P) root.add(P[k].mesh);
  root.add(birds, fireflies);

  // ---------------------------------------------------------------- spawning (far cursor)
  function step(s, dist) {
    const ti = T.themeAt(s), L = LOOKS[ti], th = env.themes[ti];
    const vis = env.visFor(ti);
    // mist banks
    if (th.mist && extras && hs(s, 501) < STEP_ / 7 * th.mist * density) {
      // side banks drift among the trees; far banks may veil the crest (they fade out before 75 m)
      const far = hs(s, 508) < 0.35;
      const side = hs(s, 502) < 0.5 ? -1 : 1;
      const w = lerp(26, 60, hs(s, 503));
      const x = far ? (hs(s, 504) - 0.5) * 50 : side * (lerp(8, 50, hs(s, 504)) + w * 0.5);
      if (!props.blocked(s, x)) {
        const i = P.mist.add(s, x, lerp(-1.0, 1.2, hs(s, 505)), 0, 0, w, lerp(5, 9, hs(s, 506)), 1, 0);
        if (i >= 0) {
          P.mist.attr('aUV', i, 0, 0, 1, 1); P.mist.attr('aP', i, 0.5, far ? 75 : 12, 0, hs(s, 507) < 0.5 ? 1 : -1);
          const c = vis.mistCol; P.mist.color(i, c.r, c.g, c.b);
        }
      }
    }
    // the L
    if (L.loop) {
      if (s % 8 === 0) P.lseg.add(s, 0, 0, 0, 0, 1, 1, 1, 4);
      if (s >= nextCross && Math.abs(s - T.nextLevelAt) > 45 && Math.abs(s - T.levelAt(s).start) > 30) {
        P.lcross.add(s, 0, 0, 0, 0, 1, 1, 1, 2);
        trains.push({ cross: true, s, x: -95, v: 0, armed: true, cars: [] });
        nextCross = s + lerp(150, 210, hs(s, 511));
      } else if (s >= nextCross) nextCross = s + 30;
    }
  }

  function spawnParallelTrain(dist, speed) {
    const oncoming = hs(dist, 521) < 0.55;
    const v = oncoming ? -lerp(14, 20, hs(dist, 522)) : lerp(8, 12, hs(dist, 523));
    const s0 = oncoming ? dist + 175 : dist + 95;
    const x = oncoming ? -7.72 : -9.62;
    const tr = { cross: false, s: s0, v, x, cars: [] };
    for (let k = 0; k < 4; k++) {
      const i = P.train.add(s0 + k * 14.8 + 7.2, x, 7.86, 0, 0, 1, 1, 1, 8);
      if (i < 0) break;
      tr.cars.push(k);
    }
    trains.push(tr);
  }

  // ---------------------------------------------------------------- per frame
  function update(sim, dist, dt, time, vis, cam) {
    const sp = Math.max(sim.speed || 0, 1);
    // ---- traffic
    const tiNow = T.themeAt(dist + 170);
    carT -= dt;
    if (carT <= 0 && LOOKS[tiNow].road2 && sim.mode !== 'over') {
      carT = lerp(0.8, 2.4, Math.random()) / Math.max(0.5, density);
      const lane = Math.random() < 0.55 ? -15.6 : -19.4;
      const v = lane > -17 ? lerp(26, 33, Math.random()) : lerp(20, 26, Math.random());
      const s = dist + 175;
      const i = P.car.add(s, lane, 0, 0, 0, 1, 1, 1, 3);
      if (i >= 0) {
        const c = PAINT[Math.floor(Math.random() * PAINT.length)];
        P.car.colorC(i, c);
        const night = env.visFor(tiNow).night;
        P.car.attr('aGlow', i, night);
        P.car.data[i] = { v, halos: [] };
        if (night > 0.3) {
          for (const hx of HEAD_X) {
            const j = P.carHalo.add(s, lane + hx, 0.3, 2.4, 0, 2.6, 2.6, 1, 3);
            if (j >= 0) { P.carHalo.attr('aUV', j, 0, 0, 1, 1); P.carHalo.attr('aP', j, 0.5, 0, 0, 1); P.carHalo.color(j, 1.4, 1.3, 1.1); P.carHalo.data[j] = { v }; }
          }
        }
      }
    }
    for (let i = 0; i < P.car.n; i++) { const d = P.car.data[i]; if (d) P.car.s[i] -= d.v * dt; }
    for (let i = 0; i < P.carHalo.n; i++) { const d = P.carHalo.data[i]; if (d) P.carHalo.s[i] -= d.v * dt; }

    // ---- L trains
    const inLoop = LOOKS[T.themeAt(dist + 60)].loop;
    trainT -= dt;
    if (inLoop && trainT <= 0) { trainT = lerp(5, 10, Math.random()); spawnParallelTrain(dist, sp); }
    // rebuild train car transforms each frame (few cars)
    P.train.n = 0;
    for (let k = trains.length - 1; k >= 0; k--) {
      const tr = trains[k];
      if (tr.cross) {
        const ahead = tr.s - dist;
        if (tr.armed && ahead < 140 && ahead > 0) {
          // time it so the middle of the train is over the road while the fox is ~45 m out
          tr.armed = false;
          const tArrive = Math.max(ahead - 45, 10) / sp;
          tr.v = Math.min(30, Math.max(12, 117 / Math.max(tArrive, 0.5)));
          tr.dir = hs(tr.s, 531) < 0.5 ? 1 : -1;
          tr.x = -95 * tr.dir;
        }
        if (!tr.armed) tr.x += tr.v * tr.dir * dt;
        if (tr.s < dist - 30) { trains.splice(k, 1); continue; }
        if (!tr.armed) {
          for (let c = 0; c < 4; c++) {
            const x = tr.x - tr.dir * c * 14.8;
            if (Math.abs(x) > 70) continue;
            const i = P.train.add(tr.s, x, 9.24, 0, Math.PI / 2, 1, 1, 1, 8);
            if (i < 0) break;
          }
        }
      } else {
        tr.s += tr.v * dt;
        if (tr.s + 60 < dist - 20 || tr.s > dist + 260) { trains.splice(k, 1); continue; }
        for (let c = 0; c < 4; c++) P.train.add(tr.s + c * 14.8 + 7.2, tr.x, 7.86, 0, 0, 1, 1, 1, 8);
      }
    }
    trainU.uNightE.value = 0.15 + vis.night * 1.6;
    lGlow.value = 0.1 + vis.night * 0.9;

    for (const k in P) P[k].sync(dist, BEHIND);

    // ---- birds
    const wantBirds = vis.birds > 0.01 && extras;
    let bn = 0;
    for (const f of flocks) {
      if (!f.active && wantBirds) {
        f.active = true; f.vx = (Math.random() < 0.5 ? -1 : 1) * lerp(5, 9, Math.random());
        f.x = -Math.sign(f.vx) * lerp(60, 110, Math.random()); f.y = lerp(26, 42, Math.random()); f.z = lerp(70, 120, Math.random());
        f.n = Math.round(lerp(7, 16, Math.random()) * (density < 0.6 ? 0.6 : 1));
        f.off = [];
        for (let b = 0; b < f.n; b++) {
          const row = Math.ceil(b / 2), sd = b % 2 ? 1 : -1;
          f.off.push([-Math.sign(f.vx) * row * 2.2 + (Math.random() - 0.5), (Math.random() - 0.5) * 1.2, sd * row * 1.6 + (Math.random() - 0.5)]);
        }
      }
      if (!f.active) continue;
      f.x += f.vx * dt;
      f.z += 1.5 * dt;
      if (Math.abs(f.x) > 140) { f.active = false; continue; }
      for (const o of f.off) {
        if (bn >= BIRDS) break;
        _p.set(cam.position.x + f.x + o[0], f.y + o[1] + Math.sin(time * 0.8 + o[0]) * 0.3, cam.position.z - f.z + o[2]);
        _q.setFromAxisAngle(_s.set(0, 1, 0), f.vx > 0 ? -Math.PI / 2 : Math.PI / 2);
        const sc = 1.1 * Math.min(1, vis.birds * 1.5);
        _m.compose(_p, _q, _s.set(sc, sc, sc));
        birds.setMatrixAt(bn++, _m);
      }
    }
    birds.count = bn; birds.visible = bn > 0; birds.instanceMatrix.needsUpdate = true;
    birdMat.color.copy(vis.birdCol);

    // ---- fireflies
    ffU.uAmt.value = extras ? vis.fireflies : 0;
    fireflies.visible = ffU.uAmt.value > 0.01;
  }

  return {
    step, update, P,
    cullAll(dist) { for (const k in P) P[k].cull(dist, BEHIND); },
    flush(dist) {
      for (const k in P) P[k].clear();
      trains.length = 0; nextCross = dist + 40; trainT = 2; carT = 0;
    },
    setDensity(k) { density = k; },
    setExtras(b) { extras = b; },
  };
}
