// ACTORS · trucks you can run on. Procedural cab-over semis, box trucks and city buses built
// from textured quads (long faces subdivided so they bend with the curved world), ONE draw
// call per truck body: every face samples a per-livery 1024² canvas atlas (side art, rear
// doors, cab front, bus faces, roof walkway, swatches) plus one shared emissive atlas (head /
// tail / marker lamps, destination sign, bus windows). Wheels (all trucks), loading ramps
// and headlight cones are each a single InstancedMesh shared by every truck on screen.
//
// Liveries (entity.livery % 3): 0 BLUFOX MOBILE (blue, white fox-tail swoosh)
//                               1 C³ FOX FREIGHT (charcoal + orange)   2 plain white + stripe
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { zOf } from '../core/constants.js';
import { TAU, clamp, lerp, smooth, hash, canvas, fitText, roundRect, FONT } from './actors-common.js';
import { BEND_GLSL_PARS, BEND_GLSL_APPLY } from '../core/bend.js';

const AW = 1024;                                   // albedo atlas size; emissive atlas is AW/4
const E = 0.25;
const REG = {                                      // px in the 1024 atlas: x, y, w, h (y down)
  side: [0, 0, 1024, 256], busSide: [0, 256, 1024, 256],
  boxSide: [0, 512, 512, 256], rear: [512, 512, 256, 256], cabFront: [768, 512, 256, 256],
  busFront: [0, 768, 256, 256], busRear: [256, 768, 256, 256], boxRear: [512, 768, 256, 256],
  cabSide: [768, 768, 128, 128], roof: [896, 768, 64, 256], ramp: [960, 768, 64, 128],
};
const SW = ['white', 'dark', 'chrome', 'rubber', 'glass', 'primary', 'secondary', 'headOn', 'tail', 'amber', 'tape', 'steel'];
SW.forEach((n, i) => { REG[n] = [768 + (i % 4) * 32 + 6, 896 + Math.floor(i / 4) * 32 + 6, 20, 20]; });
const UV = {};
for (const k in REG) { const [x, y, w, h] = REG[k]; UV[k] = [x / AW, 1 - (y + h) / AW, (x + w) / AW, 1 - y / AW]; }

const LIV = [
  { primary: '#0d4fb8', dark: '#083077', secondary: '#ffffff', accent: '#7fd1ff', doors: '#0b3f98', cab: '#1257c9' },
  { primary: '#23272f', dark: '#16191f', secondary: '#ff7a1a', accent: '#ffb347', doors: '#2b3038', cab: '#ff7a1a' },
  { primary: '#eef0f2', dark: '#c9ced4', secondary: '#1f5fd1', accent: '#d8262e', doors: '#e7e9ec', cab: '#f4f5f6' },
];

// ------------------------------------------------------------------ livery art
function clipRegion(g, r) { g.save(); g.beginPath(); g.rect(r[0], r[1], r[2], r[3]); g.clip(); g.translate(r[0], r[1]); }
function tape(g, x, y, w, h, seg) {
  for (let i = 0; i * seg < w; i++) { g.fillStyle = i % 2 ? '#f4f4f4' : '#d4121c'; g.fillRect(x + i * seg, y, Math.min(seg, w - i * seg), h); }
}
function foxTail(g, x, y, s, fill, tip) {
  // bold swooping fox tail in a 0..1 box scaled by s (x right, y down): fat body, white tip up-right
  g.save(); g.translate(x, y); g.scale(s, s);
  const body = () => {
    g.beginPath();
    g.moveTo(0.0, 0.97);
    g.bezierCurveTo(0.32, 1.02, 0.78, 0.86, 0.93, 0.36);
    g.bezierCurveTo(0.97, 0.22, 0.99, 0.1, 1.0, 0.0);
    g.bezierCurveTo(0.84, 0.12, 0.62, 0.22, 0.5, 0.42);
    g.bezierCurveTo(0.36, 0.66, 0.2, 0.84, 0.0, 0.97);
    g.closePath();
  };
  body(); g.fillStyle = fill; g.fill();
  g.save(); body(); g.clip();
  g.beginPath(); g.moveTo(0.52, 0.0); g.bezierCurveTo(0.62, 0.3, 0.78, 0.42, 1.1, 0.4); g.lineTo(1.1, -0.1); g.closePath();
  g.fillStyle = tip; g.fill();
  g.restore();
  g.restore();
}
/** "C³": draws C with a raised small 3. Returns width. */
function c3(g, x, y, px, fill, stroke) {
  g.font = `italic 900 ${px}px ${FONT}`; g.textBaseline = 'alphabetic';
  const cw = g.measureText('C').width;
  if (stroke) { g.lineWidth = px * 0.08; g.strokeStyle = stroke; g.strokeText('C', x, y); }
  g.fillStyle = fill; g.fillText('C', x, y);
  g.font = `italic 900 ${px * 0.5}px ${FONT}`;
  if (stroke) g.strokeText('3', x + cw * 0.98, y - px * 0.42);
  g.fillText('3', x + cw * 0.98, y - px * 0.42);
  return cw + g.measureText('3').width;
}

function drawSideArt(g, L, livIdx, LW, H, kind) {
  // logical canvas LW x H (already squashed to the vehicle's real aspect)
  const gr = g.createLinearGradient(0, 0, 0, H);
  gr.addColorStop(0, livIdx === 2 ? '#f7f8f9' : L.primary); gr.addColorStop(0.8, L.primary); gr.addColorStop(1, L.dark);
  g.fillStyle = gr; g.fillRect(0, 0, LW, H);
  // panel seams / logistic posts
  g.fillStyle = livIdx === 2 ? 'rgba(0,0,0,0.07)' : 'rgba(0,0,0,0.16)';
  for (let x = LW / 16; x < LW; x += LW / 16) g.fillRect(x, 0, 3, H);
  if (livIdx === 0) {
    foxTail(g, LW * 0.02, H * -0.02, H * 1.02, '#ffffff', '#7fd1ff');
    g.save(); g.transform(1, 0, -0.18, 1, 0, 0);
    g.fillStyle = 'rgba(0,0,0,0.25)'; g.textAlign = 'left'; g.textBaseline = 'middle';
    const tx = LW * (kind === 'box' ? 0.34 : 0.3) + H * 0.2;
    fitText(g, 'BLUFOX MOBILE', tx + 6, H * 0.52 + 6, LW * 0.64, H * 0.42);
    g.fillStyle = '#ffffff';
    fitText(g, 'BLUFOX MOBILE', tx, H * 0.52, LW * 0.64, H * 0.42);
    g.restore();
    g.fillStyle = '#7fd1ff'; g.fillRect(LW * 0.32, H * 0.76, LW * 0.6, H * 0.035);
  } else if (livIdx === 1) {
    g.fillStyle = L.secondary;
    for (let i = 0; i < 4; i++) { g.beginPath(); const x = LW * 0.62 + i * H * 0.28; g.moveTo(x, H); g.lineTo(x + H * 0.14, H); g.lineTo(x + H * 0.62, 0); g.lineTo(x + H * 0.48, 0); g.closePath(); g.fill(); }
    c3(g, LW * 0.05, H * 0.8, H * 0.78, L.secondary, '#ffffff');
    g.save(); g.transform(1, 0, -0.15, 1, 0, 0); g.textBaseline = 'middle'; g.textAlign = 'left';
    g.fillStyle = '#ffffff'; fitText(g, 'FOX FREIGHT', LW * 0.2 + H * 0.2, H * 0.44, LW * 0.42, H * 0.34);
    g.fillStyle = L.accent; fitText(g, 'COMMISSION EXPRESS', LW * 0.2 + H * 0.26, H * 0.74, LW * 0.36, H * 0.13, '700');
    g.restore();
  } else {
    g.fillStyle = L.secondary; g.fillRect(0, H * 0.56, LW, H * 0.11);
    g.fillStyle = L.accent; g.fillRect(0, H * 0.7, LW, H * 0.035);
    const dirt = g.createLinearGradient(0, H * 0.75, 0, H);
    dirt.addColorStop(0, 'rgba(90,80,60,0)'); dirt.addColorStop(1, 'rgba(90,80,60,0.28)');
    g.fillStyle = dirt; g.fillRect(0, 0, LW, H);
  }
  // top rail + conspicuity tape
  g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(0, 0, LW, H * 0.025);
  g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(0, H * 0.97, LW, H * 0.03);
  tape(g, 0, H * 0.905, LW, H * 0.045, H * 0.16);
}

function drawBusSide(g, L, livIdx, LW, H, E) {
  if (!E) {
    g.fillStyle = livIdx === 2 ? '#f2f3f5' : L.primary; g.fillRect(0, 0, LW, H);
    g.fillStyle = livIdx === 1 ? L.secondary : livIdx === 2 ? L.secondary : '#ffffff';
    g.fillRect(0, H * 0.6, LW, H * 0.05);
  }
  // window band with pillars
  const y0 = H * 0.1, y1 = H * 0.54, n = 7;
  for (let i = 0; i < n; i++) {
    const x0 = LW * 0.03 + i * LW * 0.94 / n, w = LW * 0.94 / n - LW * 0.012;
    if (E) { g.fillStyle = 'rgba(255,196,120,0.22)'; g.fillRect(x0, y0, w, y1 - y0); continue; }
    const gl = g.createLinearGradient(0, y0, 0, y1);
    gl.addColorStop(0, '#2b4666'); gl.addColorStop(0.45, '#0f1c2e'); gl.addColorStop(1, '#172b44');
    g.fillStyle = gl; roundRect(g, x0, y0, w, y1 - y0, 6); g.fill();
    g.fillStyle = 'rgba(255,255,255,0.14)'; g.beginPath(); g.moveTo(x0 + w * 0.15, y0); g.lineTo(x0 + w * 0.4, y0); g.lineTo(x0 + w * 0.12, y1); g.lineTo(x0, y1); g.lineTo(x0, y0 + (y1 - y0) * 0.4); g.closePath(); g.fill();
  }
  if (E) return;
  g.save(); g.transform(1, 0, -0.16, 1, 0, 0); g.textBaseline = 'middle'; g.textAlign = 'center';
  if (livIdx === 0) {
    foxTail(g, LW * 0.08, H * 0.62, H * 0.36, '#ffffff', '#7fd1ff');
    g.fillStyle = '#ffffff'; fitText(g, 'BLUFOX MOBILE', LW * 0.55 + H * 0.12, H * 0.81, LW * 0.6, H * 0.2);
  } else if (livIdx === 1) {
    g.textAlign = 'left'; c3(g, LW * 0.1, H * 0.93, H * 0.3, L.secondary, null);
    g.textBaseline = 'middle'; g.fillStyle = '#ffffff'; fitText(g, 'TRANSIT', LW * 0.2 + H * 0.12, H * 0.81, LW * 0.3, H * 0.2);
  } else {
    g.fillStyle = L.secondary; fitText(g, 'CITY EXPRESS', LW * 0.55 + H * 0.12, H * 0.81, LW * 0.4, H * 0.15);
  }
  g.restore();
  g.fillStyle = 'rgba(0,0,0,0.35)'; g.fillRect(0, H * 0.95, LW, H * 0.05);
}

function drawRear(g, L, livIdx, S, E) {                // trailer rear doors, 256x256
  if (E) {
    g.fillStyle = '#ff2a2a'; for (const x of [0.3, 0.5, 0.7]) { g.beginPath(); g.arc(S * x, S * 0.035, S * 0.018, 0, TAU); g.fill(); }
    return;
  }
  g.fillStyle = '#9aa1ab'; g.fillRect(0, 0, S, S);                       // steel frame
  const d = livIdx === 2 ? '#e9ebee' : L.doors;
  const gr = g.createLinearGradient(0, 0, 0, S); gr.addColorStop(0, d); gr.addColorStop(1, livIdx === 2 ? '#cfd3d8' : L.dark);
  g.fillStyle = gr; g.fillRect(S * 0.05, S * 0.07, S * 0.9, S * 0.88);
  g.fillStyle = 'rgba(0,0,0,0.45)'; g.fillRect(S * 0.495, S * 0.07, S * 0.012, S * 0.88);
  // lock rods + handles
  g.fillStyle = '#d9dee5';
  for (const x of [0.2, 0.4, 0.6, 0.8]) { g.fillRect(S * x - 2, S * 0.08, 4, S * 0.86); g.fillRect(S * x - 7, S * 0.62, 14, 6); }
  g.fillStyle = '#50565f'; for (const y of [0.16, 0.38, 0.62, 0.85]) { g.fillRect(S * 0.04, S * y, S * 0.05, 10); g.fillRect(S * 0.91, S * y, S * 0.05, 10); }
  // logo
  if (livIdx === 0) { foxTail(g, S * 0.56, S * 0.2, S * 0.3, '#ffffff', '#7fd1ff'); }
  else if (livIdx === 1) c3(g, S * 0.6, S * 0.46, S * 0.22, L.secondary, '#fff');
  // plate + tape
  g.fillStyle = '#f1e7b5'; g.fillRect(S * 0.18, S * 0.78, S * 0.18, S * 0.08);
  g.fillStyle = '#1e3b8a'; g.font = `900 ${S * 0.05}px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('C3 FOX', S * 0.27, S * 0.82);
  tape(g, S * 0.05, S * 0.92, S * 0.9, S * 0.03, S * 0.075);
  tape(g, S * 0.05, S * 0.07, S * 0.22, S * 0.025, S * 0.055); tape(g, S * 0.73, S * 0.07, S * 0.22, S * 0.025, S * 0.055);
  g.fillStyle = '#b3141c'; for (const x of [0.3, 0.5, 0.7]) { g.beginPath(); g.arc(S * x, S * 0.035, S * 0.018, 0, TAU); g.fill(); }
}

function drawCabFront(g, L, livIdx, S, E) {             // oncoming cab face, 256x256 (fairing top .. bumper)
  const hl = (sx) => {                                  // angry angled headlight
    g.save(); g.translate(S * sx, S * 0.69); g.scale(sx < 0.5 ? 1 : -1, 1);
    g.beginPath(); g.moveTo(-S * 0.13, -S * 0.05); g.lineTo(S * 0.12, S * 0.01); g.lineTo(S * 0.11, S * 0.07); g.lineTo(-S * 0.13, S * 0.06); g.closePath();
    g.fillStyle = E ? '#ffffff' : '#fdfbf0'; g.fill();
    if (!E) { g.lineWidth = 3; g.strokeStyle = '#2a2f36'; g.stroke(); }
    // DRL strip
    g.beginPath(); g.moveTo(-S * 0.13, -S * 0.075); g.lineTo(S * 0.13, -S * 0.012); g.lineWidth = S * 0.018; g.strokeStyle = E ? '#aee6ff' : '#dff4ff'; g.stroke();
    g.restore();
  };
  if (E) {
    hl(0.2); hl(0.8);
    g.fillStyle = '#ffb000'; for (let i = 0; i < 5; i++) { g.beginPath(); g.arc(S * (0.3 + i * 0.1), S * 0.045, S * 0.02, 0, TAU); g.fill(); }
    g.fillStyle = '#ffd27a'; for (const x of [0.12, 0.88]) { g.beginPath(); g.arc(S * x, S * 0.92, S * 0.025, 0, TAU); g.fill(); }
    return;
  }
  g.fillStyle = L.cab; g.fillRect(0, 0, S, S);
  const sh = g.createLinearGradient(0, 0, S, 0); sh.addColorStop(0, 'rgba(0,0,0,0.25)'); sh.addColorStop(0.5, 'rgba(255,255,255,0.08)'); sh.addColorStop(1, 'rgba(0,0,0,0.25)');
  g.fillStyle = sh; g.fillRect(0, 0, S, S);
  // fairing marker lights
  g.fillStyle = '#c77a00'; for (let i = 0; i < 5; i++) { g.beginPath(); g.arc(S * (0.3 + i * 0.1), S * 0.045, S * 0.02, 0, TAU); g.fill(); }
  // windshield
  const ws = g.createLinearGradient(0, S * 0.14, 0, S * 0.47);
  ws.addColorStop(0, '#3a5575'); ws.addColorStop(0.35, '#0c1626'); ws.addColorStop(1, '#16263b');
  g.fillStyle = ws; roundRect(g, S * 0.06, S * 0.13, S * 0.88, S * 0.34, S * 0.04); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.16)'; g.beginPath(); g.moveTo(S * 0.18, S * 0.13); g.lineTo(S * 0.34, S * 0.13); g.lineTo(S * 0.2, S * 0.47); g.lineTo(S * 0.06, S * 0.47); g.closePath(); g.fill();
  g.fillStyle = '#1b1f26'; g.fillRect(S * 0.495, S * 0.13, S * 0.012, S * 0.34);
  g.fillStyle = 'rgba(0,0,0,0.6)'; g.fillRect(S * 0.06, S * 0.13, S * 0.88, S * 0.05);   // visor
  // grille
  const gg = g.createLinearGradient(0, S * 0.52, 0, S * 0.84);
  gg.addColorStop(0, '#e8edf3'); gg.addColorStop(0.5, '#7e8792'); gg.addColorStop(1, '#c3cad3');
  g.fillStyle = gg; roundRect(g, S * 0.3, S * 0.52, S * 0.4, S * 0.32, S * 0.03); g.fill();
  g.fillStyle = '#111419'; for (let i = 0; i < 7; i++) g.fillRect(S * 0.32, S * (0.545 + i * 0.041), S * 0.36, S * 0.022);
  // emblem
  g.fillStyle = '#0d4fb8'; g.beginPath(); g.arc(S * 0.5, S * 0.68, S * 0.06, 0, TAU); g.fill();
  g.lineWidth = 3; g.strokeStyle = '#e9eef5'; g.stroke();
  foxTail(g, S * 0.455, S * 0.635, S * 0.09, '#ffffff', '#7fd1ff');
  hl(0.2); hl(0.8);
  // bumper
  const bb = g.createLinearGradient(0, S * 0.86, 0, S);
  bb.addColorStop(0, '#9aa3ad'); bb.addColorStop(0.4, '#2a2f36'); bb.addColorStop(1, '#15181d');
  g.fillStyle = bb; g.fillRect(0, S * 0.86, S, S * 0.14);
  g.fillStyle = '#e8d49a'; for (const x of [0.12, 0.88]) { g.beginPath(); g.arc(S * x, S * 0.92, S * 0.025, 0, TAU); g.fill(); }
}

function drawCabSide(g, L, livIdx, S) {
  g.fillStyle = L.cab; g.fillRect(0, 0, S, S);
  g.fillStyle = 'rgba(0,0,0,0.18)'; g.fillRect(0, S * 0.85, S, S * 0.15);
  const ws = g.createLinearGradient(0, S * 0.12, 0, S * 0.45);
  ws.addColorStop(0, '#3a5575'); ws.addColorStop(1, '#0f1b2c');
  g.fillStyle = ws; roundRect(g, S * 0.12, S * 0.12, S * 0.62, S * 0.32, 5); g.fill();
  g.strokeStyle = 'rgba(0,0,0,0.45)'; g.lineWidth = 2; g.strokeRect(S * 0.08, S * 0.08, S * 0.72, S * 0.78);
  g.fillStyle = '#d9dee5'; g.fillRect(S * 0.62, S * 0.5, S * 0.12, S * 0.03);
  if (livIdx === 0) foxTail(g, S * 0.2, S * 0.5, S * 0.3, '#ffffff', '#7fd1ff');
  else if (livIdx === 1) c3(g, S * 0.2, S * 0.75, S * 0.22, '#23272f', null);
  g.fillStyle = '#50565f'; g.fillRect(S * 0.1, S * 0.9, S * 0.5, S * 0.04);
}

function drawBusFront(g, L, livIdx, S, E) {
  const lights = () => {
    for (const x of [0.07, 0.75]) { g.fillStyle = '#ffffff'; roundRect(g, S * x, S * 0.78, S * 0.18, S * 0.07, S * 0.02); g.fill(); }
  };
  const sign = () => {
    g.fillStyle = '#ff9d1a'; g.font = `900 ${S * 0.085}px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.fillText(livIdx === 1 ? '3  C3 LOOP' : livIdx === 0 ? '12 BLUFOX' : '7 CITY', S * 0.5, S * 0.105);
  };
  if (E) { lights(); sign(); return; }
  g.fillStyle = livIdx === 2 ? '#f2f3f5' : L.primary; g.fillRect(0, 0, S, S);
  g.fillStyle = '#0a0b0e'; g.fillRect(S * 0.08, S * 0.05, S * 0.84, S * 0.11);
  sign();
  const ws = g.createLinearGradient(0, S * 0.18, 0, S * 0.66);
  ws.addColorStop(0, '#3c5a7e'); ws.addColorStop(0.4, '#0c1626'); ws.addColorStop(1, '#1a2c44');
  g.fillStyle = ws; roundRect(g, S * 0.05, S * 0.18, S * 0.9, S * 0.48, S * 0.04); g.fill();
  g.fillStyle = 'rgba(255,255,255,0.14)'; g.beginPath(); g.moveTo(S * 0.2, S * 0.18); g.lineTo(S * 0.38, S * 0.18); g.lineTo(S * 0.22, S * 0.66); g.lineTo(S * 0.05, S * 0.66); g.closePath(); g.fill();
  if (livIdx === 0) foxTail(g, S * 0.4, S * 0.68, S * 0.18, '#ffffff', '#7fd1ff');
  g.fillStyle = '#1b1e24'; g.fillRect(0, S * 0.88, S, S * 0.12);
  g.fillStyle = '#e9edf2'; lights();
}

function drawBusRear(g, L, livIdx, S, E) {
  const tails = () => { g.fillStyle = '#ff2020'; for (const x of [0.06, 0.82]) { roundRect(g, S * x, S * 0.55, S * 0.12, S * 0.2, S * 0.02); g.fill(); } };
  if (E) { g.save(); g.globalAlpha = 0.45; tails(); g.restore(); return; }
  g.fillStyle = livIdx === 2 ? '#f2f3f5' : L.primary; g.fillRect(0, 0, S, S);
  const ws = g.createLinearGradient(0, S * 0.08, 0, S * 0.35);
  ws.addColorStop(0, '#34506f'); ws.addColorStop(1, '#0e192a');
  g.fillStyle = ws; roundRect(g, S * 0.12, S * 0.08, S * 0.76, S * 0.27, S * 0.03); g.fill();
  g.fillStyle = '#23272e'; roundRect(g, S * 0.24, S * 0.45, S * 0.52, S * 0.3, S * 0.02); g.fill();
  g.fillStyle = '#3a4049'; for (let i = 0; i < 8; i++) g.fillRect(S * 0.26, S * (0.47 + i * 0.034), S * 0.48, S * 0.016);
  g.fillStyle = '#b3141c'; tails();
  g.fillStyle = '#1b1e24'; g.fillRect(0, S * 0.88, S, S * 0.12);
  g.fillStyle = livIdx === 1 ? L.secondary : '#ffffff'; g.font = `900 ${S * 0.06}px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(livIdx === 0 ? 'RIDE BLUFOX' : livIdx === 1 ? 'C3 TRANSIT' : 'CITY EXPRESS', S * 0.5, S * 0.4);
}

function drawBoxRear(g, L, livIdx, S, E) {
  const tails = () => { g.fillStyle = '#ff2020'; for (const x of [0.02, 0.9]) g.fillRect(S * x, S * 0.62, S * 0.08, S * 0.22); };
  if (E) { g.save(); g.globalAlpha = 0.45; tails(); g.restore(); return; }
  g.fillStyle = '#8f96a0'; g.fillRect(0, 0, S, S);
  g.fillStyle = livIdx === 1 ? '#d9dde2' : '#eef0f3'; g.fillRect(S * 0.1, S * 0.05, S * 0.8, S * 0.88);
  g.fillStyle = 'rgba(0,0,0,0.16)'; for (let i = 1; i < 12; i++) g.fillRect(S * 0.1, S * (0.05 + i * 0.073), S * 0.8, 3);
  g.fillStyle = '#50565f'; g.fillRect(S * 0.44, S * 0.84, S * 0.12, S * 0.04);
  if (livIdx === 0) foxTail(g, S * 0.3, S * 0.18, S * 0.4, '#0d4fb8', '#7fd1ff');
  else if (livIdx === 1) c3(g, S * 0.36, S * 0.5, S * 0.22, '#ff7a1a', null);
  tape(g, S * 0.1, S * 0.9, S * 0.8, S * 0.03, S * 0.07);
  g.fillStyle = '#b3141c'; tails();
}

function drawRoof(g, S_w, S_h) {                        // 64 x 256: across x, along y (stretched ~2.5x along)
  const gr = g.createLinearGradient(0, 0, S_w, 0);
  gr.addColorStop(0, '#9aa1a9'); gr.addColorStop(0.5, '#c4c9cf'); gr.addColorStop(1, '#9aa1a9');
  g.fillStyle = gr; g.fillRect(0, 0, S_w, S_h);
  g.fillStyle = 'rgba(0,0,0,0.13)'; for (let y = 0; y < S_h; y += 6) g.fillRect(0, y, S_w, 1);      // roof bows
  g.fillStyle = '#d3d7dc'; g.fillRect(S_w * 0.3, 0, S_w * 0.4, S_h);                              // walkway
  g.fillStyle = 'rgba(70,76,84,0.35)'; for (let y = 1; y < S_h; y += 3) g.fillRect(S_w * 0.31, y, S_w * 0.38, 0.8);
  g.fillStyle = 'rgba(0,0,0,0.3)'; g.fillRect(S_w * 0.29, 0, 1, S_h); g.fillRect(S_w * 0.7, 0, 1, S_h);
  g.fillStyle = '#f5c400'; g.fillRect(0, 0, S_w * 0.07, S_h); g.fillRect(S_w * 0.93, 0, S_w * 0.07, S_h);
  g.fillStyle = '#1a1a1a'; for (let y = 0; y < S_h; y += 8) { g.fillRect(0, y, S_w * 0.07, 4); g.fillRect(S_w * 0.93, y + 4, S_w * 0.07, 4); }
}

function drawRamp(g, W, H) {                            // 64 x 128, v up the ramp (canvas top = top of ramp)
  g.fillStyle = '#f2b800'; g.fillRect(0, 0, W, H);
  g.fillStyle = '#16161a';
  for (let y = -16; y < H + 16; y += 32) {
    g.beginPath(); g.moveTo(0, y + 16); g.lineTo(W / 2, y); g.lineTo(W, y + 16); g.lineTo(W, y + 26); g.lineTo(W / 2, y + 10); g.lineTo(0, y + 26); g.closePath(); g.fill();
  }
  g.fillStyle = 'rgba(255,255,255,0.18)'; for (let y = 1; y < H; y += 3) for (let x = (y % 2) * 1.5; x < W; x += 3) g.fillRect(x, y, 1, 1);
  g.fillStyle = '#5b6068'; g.fillRect(0, 0, 3, H); g.fillRect(W - 3, 0, 3, H);
}

function drawSwatches(g, L, E) {
  const sw = (n, c) => { const [x, y, w, h] = REG[n]; g.fillStyle = c; g.fillRect(x - 6, y - 6, w + 12, h + 12); };
  if (E) {
    for (const n of SW) sw(n, '#000');
    sw('headOn', '#ffffff'); sw('tail', '#8a1010'); sw('amber', '#ffae00');
    return;
  }
  sw('white', '#eef0f2'); sw('dark', '#23262c'); sw('chrome', '#c7ced7'); sw('rubber', '#141518'); sw('glass', '#0e1a2b');
  sw('primary', L.primary); sw('secondary', L.secondary); sw('headOn', '#fffdf2'); sw('tail', '#c8141c'); sw('amber', '#ffab00');
  sw('steel', '#80878f');
  const [x, y, w, h] = REG.tape; for (let i = 0; i < 4; i++) { g.fillStyle = i % 2 ? '#f4f4f4' : '#d4121c'; g.fillRect(x - 6 + i * 8, y - 6, 8, h + 12); }
}

function buildAtlas(livIdx) {
  const L = LIV[livIdx];
  const cv = canvas(AW, AW), g = cv.getContext('2d');
  g.fillStyle = '#80868e'; g.fillRect(0, 0, AW, AW);
  const logical = (r, aspect, fn) => {              // draw at the vehicle's real aspect, squashed into the region
    clipRegion(g, r);
    const LW = r[3] * aspect; g.scale(r[2] / LW, 1);
    fn(LW, r[3]); g.restore();
  };
  logical(REG.side, 8.4, (LW, H) => drawSideArt(g, L, livIdx, LW, H, 'semi'));
  logical(REG.busSide, 4.7, (LW, H) => drawBusSide(g, L, livIdx, LW, H, false));
  logical(REG.boxSide, 3.4, (LW, H) => drawSideArt(g, L, livIdx, LW, H, 'box'));
  clipRegion(g, REG.rear); drawRear(g, L, livIdx, 256, false); g.restore();
  clipRegion(g, REG.cabFront); drawCabFront(g, L, livIdx, 256, false); g.restore();
  clipRegion(g, REG.busFront); drawBusFront(g, L, livIdx, 256, false); g.restore();
  clipRegion(g, REG.busRear); drawBusRear(g, L, livIdx, 256, false); g.restore();
  clipRegion(g, REG.boxRear); drawBoxRear(g, L, livIdx, 256, false); g.restore();
  clipRegion(g, REG.cabSide); drawCabSide(g, L, livIdx, 128); g.restore();
  clipRegion(g, REG.roof); drawRoof(g, 64, 256); g.restore();
  clipRegion(g, REG.ramp); drawRamp(g, 64, 128); g.restore();
  drawSwatches(g, L, false);
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  return tex;
}

function buildEmissive() {
  const S = AW * E;
  const cv = canvas(S, S), g = cv.getContext('2d');
  g.fillStyle = '#000'; g.fillRect(0, 0, S, S);
  g.save(); g.scale(E, E);
  const L = LIV[0];
  clipRegion(g, REG.busSide); { const LW = 256 * 4.7; g.scale(1024 / LW, 1); drawBusSide(g, L, 0, LW, 256, true); } g.restore();
  clipRegion(g, REG.rear); drawRear(g, L, 0, 256, true); g.restore();
  clipRegion(g, REG.cabFront); drawCabFront(g, L, 0, 256, true); g.restore();
  clipRegion(g, REG.busFront); drawBusFront(g, L, 0, 256, true); g.restore();
  clipRegion(g, REG.busRear); drawBusRear(g, L, 0, 256, true); g.restore();
  clipRegion(g, REG.boxRear); drawBoxRear(g, L, 0, 256, true); g.restore();
  drawSwatches(g, L, true);
  g.restore();
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

// ------------------------------------------------------------------ geometry
// Canonical frame: cab / bus front at z = 0 facing +z, body extends to z = -len.
class GeoBuilder {
  constructor() { this.p = []; this.n = []; this.uv = []; }
  /** quad p0..p3 = bottom-left, bottom-right, top-right, top-left seen from outside. */
  quad(p0, p1, p2, p3, r, segU = 1, segV = 1) {
    const ax = new THREE.Vector3().subVectors(p1, p0), ay = new THREE.Vector3().subVectors(p3, p0);
    const nrm = new THREE.Vector3().crossVectors(ax, ay).normalize();
    const P = (u, v) => new THREE.Vector3().copy(p0).addScaledVector(ax, u).addScaledVector(ay, v);
    for (let j = 0; j < segV; j++) for (let i = 0; i < segU; i++) {
      const u0 = i / segU, u1 = (i + 1) / segU, v0 = j / segV, v1 = (j + 1) / segV;
      const c = [[u0, v0], [u1, v0], [u1, v1], [u0, v0], [u1, v1], [u0, v1]];
      for (const [u, v] of c) {
        const q = P(u, v);
        this.p.push(q.x, q.y, q.z); this.n.push(nrm.x, nrm.y, nrm.z);
        this.uv.push(r[0] + u * (r[2] - r[0]), r[1] + v * (r[3] - r[1]));
      }
    }
  }
  /** axis-aligned box: x0<x1, y0<y1, zb<zf; faces {front, back, left, right, top} = UV rect | null */
  box(x0, x1, y0, y1, zb, zf, f, seg = 1) {
    const V = (x, y, z) => new THREE.Vector3(x, y, z);
    const s = Math.max(1, seg);
    if (f.front !== null) this.quad(V(x0, y0, zf), V(x1, y0, zf), V(x1, y1, zf), V(x0, y1, zf), f.front || f.all);
    if (f.back !== null) this.quad(V(x1, y0, zb), V(x0, y0, zb), V(x0, y1, zb), V(x1, y1, zb), f.back || f.all);
    if (f.right !== null) this.quad(V(x1, y0, zf), V(x1, y0, zb), V(x1, y1, zb), V(x1, y1, zf), f.right || f.side || f.all, s, 1);
    if (f.left !== null) this.quad(V(x0, y0, zb), V(x0, y0, zf), V(x0, y1, zf), V(x0, y1, zb), f.left || f.side || f.all, s, 1);
    if (f.top !== null) this.quad(V(x0, y1, zf), V(x1, y1, zf), V(x1, y1, zb), V(x0, y1, zb), f.top || f.all, 1, s);
    if (f.bottom) this.quad(V(x0, y0, zb), V(x1, y0, zb), V(x1, y0, zf), V(x0, y0, zf), f.bottom, 1, s);
  }
  geometry() {
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.p, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(this.n, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(this.uv, 2));
    return g;
  }
}

/** Returns { geo, wheels:[[x,y,z,r,dual]], heads:[[x,y,z]], tails:[[x,y,z]] } in the entity frame
 *  (near end z = 0, far end z = -len). toward = oncoming (cab at the near end). */
function buildVehicle(kind, len, h, w, toward) {
  const B = new GeoBuilder();
  const hw = w / 2;
  const segs = n => Math.max(1, Math.ceil(n / 2));
  const wheels = [], heads = [], tails = [];
  if (kind === 'bus') {
    B.box(-hw, hw, 0.32, h, -len, 0, { front: UV.busFront, back: UV.busRear, side: UV.busSide, top: UV.roof }, segs(len));
    B.box(-hw - 0.02, hw + 0.02, 0.2, 0.55, -0.25, 0.14, { all: UV.dark, top: null });
    B.box(-hw - 0.02, hw + 0.02, 0.2, 0.55, -len - 0.14, -len + 0.25, { all: UV.dark, top: null });
    B.box(-hw - 0.01, hw + 0.01, 0.2, 0.34, -len + 0.2, -0.2, { all: UV.rubber, top: null, front: null, back: null }, segs(len));
    wheels.push([-hw + 0.3, 0.5, -2.4, 0.5, 0], [-hw + 0.3, 0.5, -len + 3.1, 0.5, 1]);
    heads.push([-hw + 0.45, 0.32 + (h - 0.32) * 0.18, 0.05], [hw - 0.45, 0.32 + (h - 0.32) * 0.18, 0.05]);
    tails.push([-hw + 0.3, 0.32 + (h - 0.32) * 0.35, -len - 0.05], [hw - 0.3, 0.32 + (h - 0.32) * 0.35, -len - 0.05]);
  } else {
    const cabL = kind === 'semi' ? 2.3 : 2.1;
    const gap = kind === 'semi' ? 0.22 : 0.12;
    const floor = kind === 'semi' ? 1.18 : 0.98;
    // cab (cab-over, full height with roof fairing)
    B.box(-hw * 0.97, hw * 0.97, 0.5, h, -cabL, 0, { front: UV.cabFront, back: UV.dark, side: UV.cabSide, top: UV.roof });
    // bumper + mirrors + steps
    B.box(-hw - 0.04, hw + 0.04, 0.34, 0.62, -0.3, 0.16, { all: UV.dark, front: UV.chrome });
    for (const s of [-1, 1]) {
      B.box(s > 0 ? hw * 0.97 : -hw * 0.97 - 0.2, s > 0 ? hw * 0.97 + 0.2 : -hw * 0.97, 2.05, 2.55, -0.32, -0.22, { all: UV.dark });
      B.box(s > 0 ? hw * 0.97 : -hw - 0.05, s > 0 ? hw + 0.05 : -hw * 0.97, 0.52, 0.6, -1.3, -0.6, { all: UV.steel });
    }
    // body
    const zb = -len, zf = -cabL - gap;
    const bodyLen = zf - zb;
    const side = kind === 'semi' ? UV.side : UV.boxSide;
    const back = kind === 'semi' ? UV.rear : UV.boxRear;
    B.box(-hw, hw, floor, h, zb, zf, { front: UV.primary, back, side, top: UV.roof }, segs(bodyLen));
    // chassis + underride guard + tail light pods + side skirts
    B.box(-0.55, 0.55, 0.5, floor, zb + 0.4, -0.6, { all: UV.dark, top: null }, segs(len));
    B.box(-hw + 0.1, hw - 0.1, 0.42, 0.58, zb - 0.08, zb + 0.06, { all: UV.tape, top: UV.dark });
    for (const s of [-1, 1]) {
      B.box(s * (hw - 0.34) - 0.14, s * (hw - 0.34) + 0.14, floor - 0.2, floor - 0.04, zb - 0.06, zb + 0.02, { all: UV.dark, back: UV.tail });
      if (kind === 'semi' && bodyLen > 9) {
        const z0 = zb + 3.6, z1 = zf - 3.2;
        B.box(s > 0 ? hw - 0.05 : -hw, s > 0 ? hw : -hw + 0.05, 0.42, floor, z0, z1, { all: UV.primary, top: null }, segs(z1 - z0));
      }
      // fuel tank
      if (kind === 'semi') B.box(s > 0 ? hw - 0.52 : -hw + 0.02, s > 0 ? hw - 0.02 : -hw + 0.52, 0.5, 1.0, -cabL - 1.3, -cabL - 0.25, { all: UV.chrome });
    }
    wheels.push([-hw + 0.28, 0.52, -1.05, 0.52, 0]);
    if (kind === 'semi') {
      wheels.push([-hw + 0.3, 0.52, -cabL - 1.9, 0.52, 1], [-hw + 0.3, 0.52, -cabL - 3.1, 0.52, 1]);
      wheels.push([-hw + 0.3, 0.52, zb + 1.4, 0.52, 1], [-hw + 0.3, 0.52, zb + 2.65, 0.52, 1]);
    } else wheels.push([-hw + 0.3, 0.48, zb + 1.8, 0.48, 1]);
    const hy = 0.5 + (h - 0.5) * (1 - 0.69);
    heads.push([-hw * 0.6, hy, 0.05], [hw * 0.6, hy, 0.05]);
    tails.push([-(hw - 0.34), floor - 0.12, zb - 0.08], [hw - 0.34, floor - 0.12, zb - 0.08]);
  }
  let geo = B.geometry();
  const W2 = [];
  for (const [x, y, z, r, dual] of wheels) { W2.push([x, y, z, r, dual], [-x, y, z, r, dual]); }
  if (!toward) {
    // parked / same-direction: rear faces the fox. rotate 180° about Y and shift so the rear sits at z = 0
    const m = new THREE.Matrix4().makeRotationY(Math.PI).premultiply(new THREE.Matrix4().makeTranslation(0, 0, -len));
    geo.applyMatrix4(m);
    const tf = a => a.map(([x, y, z, ...rest]) => [-x, y, -z - len, ...rest]);
    return { geo, wheels: tf(W2), heads: tf(heads), tails: tf(tails) };
  }
  return { geo, wheels: W2, heads, tails };
}

// ------------------------------------------------------------------ wheels / ramps / cones
function wheelParts() {
  const cv = canvas(256, 128), g = cv.getContext('2d');
  g.fillStyle = '#16171a'; g.fillRect(0, 0, 128, 128);                // tread
  g.fillStyle = '#26282d'; for (let x = 0; x < 128; x += 16) g.fillRect(x, 0, 7, 128);
  g.fillStyle = '#141518'; g.fillRect(128, 0, 128, 128);               // hub face
  const cx = 192, cy = 64;
  const rim = g.createRadialGradient(cx - 10, cy - 10, 4, cx, cy, 44);
  rim.addColorStop(0, '#f2f5f8'); rim.addColorStop(0.7, '#9aa2ac'); rim.addColorStop(1, '#5d646d');
  g.fillStyle = rim; g.beginPath(); g.arc(cx, cy, 42, 0, TAU); g.fill();
  g.fillStyle = '#3b4047'; for (let i = 0; i < 8; i++) { const a = i * TAU / 8; g.beginPath(); g.arc(cx + Math.cos(a) * 26, cy + Math.sin(a) * 26, 6, 0, TAU); g.fill(); }
  g.fillStyle = '#2a2e34'; g.beginPath(); g.arc(cx, cy, 13, 0, TAU); g.fill();
  g.fillStyle = '#d9a200'; g.fillRect(cx - 3, cy - 40, 6, 12);        // a painted mark so the spin reads
  const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
  const geo = new THREE.CylinderGeometry(1, 1, 1, 20, 1);
  // groups: 0 side, 1 top cap, 2 bottom cap
  const uv = geo.attributes.uv, idx = geo.index.array;
  for (const grp of geo.groups) {
    const done = new Set();
    for (let k = grp.start; k < grp.start + grp.count; k++) {
      const v = idx[k]; if (done.has(v)) continue; done.add(v);
      if (grp.materialIndex === 0) uv.setXY(v, uv.getX(v) * 0.5, uv.getY(v));
      else uv.setXY(v, 0.5 + uv.getX(v) * 0.5, uv.getY(v));
    }
  }
  geo.clearGroups();
  geo.rotateZ(Math.PI / 2);       // axis along X
  return { geo, tex };
}

function coneMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: { uI: { value: 1 } },
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
    vertexShader: /* glsl */`
      ${BEND_GLSL_PARS}
      #include <common>
      varying float vT; varying float vF;
      void main() {
        vT = uv.y;
        vec4 mvPosition = modelViewMatrix * instanceMatrix * vec4(position, 1.0);
        vec3 n = normalize(normalMatrix * mat3(instanceMatrix) * normal);
        vF = abs(dot(n, normalize(-mvPosition.xyz)));
        ${BEND_GLSL_APPLY}
        gl_Position = projectionMatrix * mvPosition;
      }`,
    fragmentShader: /* glsl */`
      uniform float uI;
      varying float vT; varying float vF;
      void main() {
        float a = pow(vT, 2.4) * pow(vF, 1.5) * uI;
        gl_FragColor = vec4(vec3(1.0, 0.93, 0.78) * a, 1.0);
      }`,
  });
}

export function createTrucks(ctx, S) {
  const { scene } = ctx;
  const emis = buildEmissive();
  const mats = [0, 1, 2].map(i => S.bend(new THREE.MeshStandardMaterial({
    map: buildAtlas(i), emissiveMap: emis, emissive: new THREE.Color(1, 1, 1), emissiveIntensity: 2.4,
    roughness: 0.42, metalness: 0.18, envMap: S.envMap ? S.envMap.texture : null, envMapIntensity: 0.55,
  })));
  const cache = new Map();
  function vehicle(kind, len, h, w, toward) {
    const key = `${kind}|${len}|${h}|${w}|${toward ? 1 : 0}`;
    let v = cache.get(key);
    if (!v) { v = buildVehicle(kind, len, h, w, toward); cache.set(key, v); }
    return v;
  }
  // wheels
  const WP = wheelParts();
  const wheelMat = S.bend(new THREE.MeshStandardMaterial({ map: WP.tex, roughness: 0.7, metalness: 0.2 }));
  const WCAP = 160;
  const wheels = new THREE.InstancedMesh(WP.geo, wheelMat, WCAP);
  wheels.name = 'actors.truckWheels'; wheels.frustumCulled = false; wheels.count = 0; wheels.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  // ramps: unit wedge (w 1, h 1, len 1) from z = 0 (top, at the truck) to z = +1 (road).
  // Own tiling texture: yellow steel deck, black chevrons pointing up the ramp, steel edge strips.
  const rcv = canvas(128, 128), rg = rcv.getContext('2d');
  rg.fillStyle = '#f2b800'; rg.fillRect(0, 0, 128, 128);
  rg.fillStyle = 'rgba(255,255,255,0.16)'; for (let y = 1; y < 128; y += 4) for (let x = (y % 8 < 4 ? 0 : 2) + 12; x < 116; x += 4) rg.fillRect(x, y, 2, 1);
  rg.fillStyle = '#17171b';
  rg.beginPath(); rg.moveTo(12, 92); rg.lineTo(64, 40); rg.lineTo(116, 92); rg.lineTo(116, 116); rg.lineTo(64, 64); rg.lineTo(12, 116); rg.closePath(); rg.fill();
  const eg = rg.createLinearGradient(0, 0, 12, 0); eg.addColorStop(0, '#8d949d'); eg.addColorStop(1, '#c3c9d0');
  rg.fillStyle = eg; rg.fillRect(0, 0, 12, 128); rg.save(); rg.translate(128, 0); rg.scale(-1, 1); rg.fillRect(0, 0, 12, 128); rg.restore();
  rg.fillStyle = 'rgba(0,0,0,0.3)'; rg.fillRect(0, 0, 128, 3);
  const rampTex = new THREE.CanvasTexture(rcv); rampTex.colorSpace = THREE.SRGBColorSpace; rampTex.wrapS = rampTex.wrapT = THREE.RepeatWrapping; rampTex.anisotropy = 8;
  const RB = new GeoBuilder();
  const V = (x, y, z) => new THREE.Vector3(x, y, z);
  const STEEL = [0.01, 0, 0.05, 1];
  RB.quad(V(-0.5, 0, 1), V(0.5, 0, 1), V(0.5, 1, 0), V(-0.5, 1, 0), [0, 0, 1, 5], 1, 8);          // deck (5 chevrons)
  RB.quad(V(0.5, 0, 1), V(0.5, 0, 0), V(0.5, 1, 0), V(0.5, 1, 0), STEEL, 1, 1);                    // right side (triangle)
  RB.quad(V(-0.5, 0, 0), V(-0.5, 0, 1), V(-0.5, 1, 0), V(-0.5, 1, 0), STEEL, 1, 1);                // left side
  RB.quad(V(-0.5, 0, 0), V(0.5, 0, 0), V(0.5, 1, 0), V(-0.5, 1, 0), STEEL, 1, 1);                  // back plate
  const rampGeo = RB.geometry();
  const rampMat = S.bend(new THREE.MeshStandardMaterial({ map: rampTex, roughness: 0.55, metalness: 0.35,
    emissive: new THREE.Color(0, 0, 0), emissiveMap: rampTex }));
  const RCAP = 12;
  const ramps = new THREE.InstancedMesh(rampGeo, rampMat, RCAP);
  ramps.name = 'actors.ramps'; ramps.frustumCulled = false; ramps.count = 0; ramps.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  // headlight cones (two per oncoming truck)
  const coneOne = new THREE.CylinderGeometry(0.2, 2.3, 18, 18, 12, true);
  coneOne.translate(0, -9, 0); coneOne.rotateX(-Math.PI / 2 - 0.05);          // narrow end at origin, opening toward +z, dipping down
  const coneGeo = mergeGeometries([coneOne.clone().translate(-0.66, 0, 0), coneOne.clone().translate(0.66, 0, 0)]);
  const coneMat = coneMaterial();
  const cones = new THREE.InstancedMesh(coneGeo, coneMat, 8);
  cones.name = 'actors.headlightCones'; cones.frustumCulled = false; cones.count = 0; cones.renderOrder = 5; cones.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  scene.add(wheels, ramps, cones);

  const pool = new Map();        // id -> { mesh, spin, stamp }
  const freeMeshes = [];
  const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3(), _ax = new THREE.Vector3(1, 0, 0);
  let stamp = 0, quality = 'high';

  function meshFor(t) {
    let R = pool.get(t.id);
    if (!R) {
      const mesh = freeMeshes.pop() || new THREE.Mesh(undefined, mats[0]);
      mesh.name = 'actors.truck'; mesh.matrixAutoUpdate = true;
      mesh.frustumCulled = false;
      scene.add(mesh);
      R = { mesh, spin: 0, stamp: 0, v: null };
      pool.set(t.id, R);
    }
    return R;
  }

  function recycle(R, id) { if (R.stamp !== stamp) { R.mesh.visible = false; freeMeshes.push(R.mesh); pool.delete(id); } }
  function update(sim, frame) {
    const time = frame.time, dt = frame.dt, env = S.env;
    stamp++;
    let nw = 0, nr = 0, nc = 0;
    const camZ = frame.camera.position.z;
    for (const m of mats) {
      m.emissiveIntensity = 2.2 + env.night * 1.4;
      if (S.envMap && m.envMap !== S.envMap.texture) { m.envMap = S.envMap.texture; m.needsUpdate = true; }
    }
    rampMat.emissive.setRGB(0.1, 0.08, 0.02).multiplyScalar(env.night * 1.5);
    for (const t of sim.trains) {
      const zNear = zOf(t.s, sim.dist);
      const zFar = zNear - t.len;
      if (zFar > camZ || zNear < -175) { continue; }
      const toward = t.v < 0;
      const kind = t.kind === 'bus' || t.kind === 'box' ? t.kind : 'semi';
      const len = Math.round(t.len * 4) / 4, h = Math.round((t.h || 3.1) * 20) / 20, w = Math.round((t.w || 2.25) * 20) / 20;
      const V = vehicle(kind, len, h, w, toward);
      const R = meshFor(t);
      R.stamp = stamp;
      if (R.mesh.geometry !== V.geo) R.mesh.geometry = V.geo;
      const mat = mats[((t.livery | 0) % 3 + 3) % 3];
      if (R.mesh.material !== mat) R.mesh.material = mat;
      const shake = toward ? Math.sin(time * 37 + t.id) * 0.012 + Math.sin(time * 13) * 0.01 : 0;
      R.mesh.position.set(t.x, shake, zNear);
      R.mesh.visible = true;
      // wheels
      const speed = Math.abs(t.v || 0);
      R.spin += speed * dt / 0.5 * (toward ? -1 : 1);
      for (const wv of V.wheels) {
        if (nw >= WCAP) break;
        const [x, y, z, r, dual] = wv;
        _q.setFromAxisAngle(_ax, R.spin);
        _p.set(t.x + x, y + shake, zNear + z);
        _s.set(dual ? 0.5 : 0.32, r, r);
        _m.compose(_p, _q, _s);
        wheels.setMatrixAt(nw++, _m);
      }
      // ramp
      if (t.ramp && t.rampLen > 0 && nr < RCAP && !toward) {
        _q.identity(); _p.set(t.x, 0, zNear); _s.set(w * 0.94, h, t.rampLen);
        _m.compose(_p, _q, _s);
        ramps.setMatrixAt(nr++, _m);
        S.shadows.push(t.x, 0, zNear + t.rampLen * 0.4, w * 1.05, t.rampLen * 0.8, 0, 0, 0, 0, 0.35, 'box', 0.025);
      }
      // contact shadow
      S.shadows.push(t.x, 0, zNear - len / 2, w + 0.9, len + 1.2, 0, 0, 0, 0, 0.7, 'box', 0.025);
      // lights
      if (toward) {
        const d = -zNear;
        const I = 1 + env.night * 0.8;
        const near = smooth(60, 12, d), close = smooth(3, 12, d);
        for (const [hx, hy, hz] of V.heads) {
          S.glows.push(t.x + hx, hy, zNear + hz + 0.1, (1.3 + near * 1.1) , 2.4 * I, 2.3 * I, 2.0 * I, 0.9 * (0.5 + 0.5 * close), 'glow');
          S.glows.push(t.x + hx, hy, zNear + hz + 0.12, (1.6 + near * 1.6), 1.2 * I, 1.3 * I, 1.6 * I, 0.4 * close, 'flare');
          S.additive.push(t.x + hx * 1.4, 0, zNear + 8, 2.4, 15, 0, 0.45 * I, 0.42 * I, 0.34 * I, 1, 'glow', 0.03);
        }
        if (nc < 8 && quality !== 'low' && env.night > 0.3) { _q.identity(); _p.set(t.x, V.heads[0][1], zNear + 0.05); _s.set(1, 1, 1); _m.compose(_p, _q, _s); cones.setMatrixAt(nc++, _m); }
      } else if (env.night > 0.25) {
        for (const [tx, ty, tz] of V.tails) S.glows.push(t.x + tx, ty, zNear + tz, 1.0, 2.2, 0.15, 0.1, 0.5 * env.night, 'glow');
      }
    }
    pool.forEach(recycle);
    wheels.count = nw; ramps.count = nr; cones.count = nc;
    wheels.visible = nw > 0; ramps.visible = nr > 0; cones.visible = nc > 0;
    if (nw) wheels.instanceMatrix.needsUpdate = true;
    if (nr) ramps.instanceMatrix.needsUpdate = true;
    if (nc) cones.instanceMatrix.needsUpdate = true;
    coneMat.uniforms.uI.value = 0.3 * env.night;
  }
  function setQuality(tier) { quality = tier; }
  return { update, onEvent() {}, setQuality, mats };
}
