// ACTORS · shared pieces: theme lighting state, the FX sprite atlas (glow / sparkle / ring /
// blob shadow / road chevrons), GlowBatch (additive camera-facing billboards) and DecalBatch
// (flat quads lying on the road or a truck roof). Each batch is ONE draw call for everything.
import * as THREE from 'three';
import { BEND_GLSL_PARS, BEND_GLSL_APPLY } from '../core/bend.js';

export const TAU = Math.PI * 2;
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const smooth = (a, b, v) => { const t = clamp((v - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
export const damp = (a, b, k, dt) => a + (b - a) * (1 - Math.exp(-k * dt));
export function hash(n) { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); }

// ------------------------------------------------------------------ theme light
const TOD_BRIGHT = { dawn: 0.86, sunrise: 0.97, day: 1.0, golden: 0.98, dusk: 0.86, bluehour: 0.78, night: 0.74 };
const TOD_NIGHT = { dawn: 0.35, sunrise: 0.1, day: 0, golden: 0.05, dusk: 0.45, bluehour: 0.8, night: 1 };

/** Eased per-theme lighting numbers every actor uses (sprites don't see scene lights). */
export function createEnv(THEMES) {
  const env = {
    idx: -1,
    night: 0, bright: 1,
    amb: new THREE.Color(1, 1, 1), key: new THREE.Color(1, 1, 1),
    spriteLight: new THREE.Color(1, 1, 1), rim: new THREE.Color(0.4, 0.4, 0.4),
    keySide: 1,
    ambA: 0.2, keyA: 0.3,
    _t: { night: 0, bright: 1, amb: new THREE.Color(), key: new THREE.Color(), keySide: 1, ambA: 0.2, keyA: 0.3 },
    target(idx) {
      const th = THEMES[idx] || THEMES[0];
      this.idx = idx;
      const t = this._t;
      t.night = TOD_NIGHT[th.tod] ?? (th.night ? 1 : 0);
      t.bright = TOD_BRIGHT[th.tod] ?? 1;
      t.amb.set(th.amb || '#ffffff');
      t.key.set(th.key || '#ffffff');
      t.keySide = th.keyDir || 1;
      t.ambA = th.ambA != null ? th.ambA : 0.2; t.keyA = th.keyA != null ? th.keyA : 0.3;
    },
    update(sim, dt, instant) {
      if (sim.themeIdx !== this.idx) this.target(sim.themeIdx);
      const k = instant ? 1 : 1 - Math.exp(-dt * 1.6);
      const t = this._t;
      this.night += (t.night - this.night) * k;
      this.bright += (t.bright - this.bright) * k;
      this.amb.lerp(t.amb, k); this.key.lerp(t.key, k);
      this.keySide += (t.keySide - this.keySide) * k;
      this.ambA += (t.ambA - this.ambA) * k; this.keyA += (t.keyA - this.keyA) * k;
      // painted sprites: ambient tint (theme amb x ambA), darker at night, never muddy;
      // rim light in the key colour, scaled by keyA, stronger at night so silhouettes separate
      this.spriteLight.setRGB(1, 1, 1).lerp(this.amb, clamp(0.08 + this.ambA * 0.75, 0.1, 0.32) + 0.12 * this.night).multiplyScalar(this.bright * 1.02);
      this.rim.copy(this.key).multiplyScalar(0.12 + this.keyA * 0.75 + 0.4 * this.night);
    },
  };
  return env;
}

// ------------------------------------------------------------------ canvas helpers
export function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
export const FONT = '"Arial Black", "Helvetica Neue", Helvetica, Arial, sans-serif';
/** Draw text scaled to fit maxW. */
export function fitText(g, text, x, y, maxW, px, weight = '900', style = '') {
  let size = px;
  g.font = `${style} ${weight} ${size}px ${FONT}`;
  const w = g.measureText(text).width;
  if (w > maxW) { size = Math.floor(px * maxW / w); g.font = `${style} ${weight} ${size}px ${FONT}`; }
  g.fillText(text, x, y);
  return size;
}
export function roundRect(g, x, y, w, h, r) {
  g.beginPath();
  g.moveTo(x + r, y); g.lineTo(x + w - r, y); g.quadraticCurveTo(x + w, y, x + w, y + r);
  g.lineTo(x + w, y + h - r); g.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  g.lineTo(x + r, y + h); g.quadraticCurveTo(x, y + h, x, y + h - r);
  g.lineTo(x, y + r); g.quadraticCurveTo(x, y, x + r, y); g.closePath();
}

// ------------------------------------------------------------------ FX atlas (white shapes, alpha only)
// 512 x 512, 128 px cells. Rects in UV [u0, v0, u1, v1] (v up).
export function createFxAtlas() {
  const S = 512, C = 128;
  const cv = canvas(S, S), g = cv.getContext('2d');
  const rects = {};
  const cell = (name, cx, cy, cw = 1, ch = 1) => {
    rects[name] = [cx * C / S, 1 - (cy + ch) * C / S, (cx + cw) * C / S, 1 - cy * C / S];
    return [cx * C, cy * C, cw * C, ch * C];
  };
  let [x, y, w, h] = cell('glow', 0, 0);
  let gr = g.createRadialGradient(x + w / 2, y + h / 2, 0, x + w / 2, y + h / 2, w / 2);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.18, 'rgba(255,255,255,0.75)');
  gr.addColorStop(0.45, 'rgba(255,255,255,0.22)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(x, y, w, h);
  // 4-point sparkle star
  [x, y, w, h] = cell('star', 1, 0);
  g.save(); g.translate(x + w / 2, y + h / 2);
  gr = g.createRadialGradient(0, 0, 0, 0, 0, w * 0.2);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(-w / 2, -h / 2, w, h);
  g.fillStyle = '#fff';
  for (let k = 0; k < 2; k++) {
    g.beginPath();
    const L = k ? w * 0.3 : w * 0.48, T = w * 0.045;
    g.moveTo(0, -L); g.quadraticCurveTo(T, -T, L, 0); g.quadraticCurveTo(T, T, 0, L);
    g.quadraticCurveTo(-T, T, -L, 0); g.quadraticCurveTo(-T, -T, 0, -L); g.fill();
    g.rotate(Math.PI / 4);
  }
  g.restore();
  // ring
  [x, y, w, h] = cell('ring', 2, 0);
  gr = g.createRadialGradient(x + w / 2, y + h / 2, w * 0.3, x + w / 2, y + h / 2, w / 2);
  gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.55, 'rgba(255,255,255,0.15)');
  gr.addColorStop(0.8, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(x, y, w, h);
  // blob shadow (soft, dense core)
  [x, y, w, h] = cell('blob', 3, 0);
  gr = g.createRadialGradient(x + w / 2, y + h / 2, 0, x + w / 2, y + h / 2, w / 2);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.45, 'rgba(255,255,255,0.8)');
  gr.addColorStop(0.75, 'rgba(255,255,255,0.3)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(x, y, w, h);
  // soft box (truck contact shadow) — rounded rectangle with blurred edges
  [x, y, w, h] = cell('box', 0, 1);
  g.save(); g.filter = 'blur(9px)'; g.fillStyle = '#fff'; roundRect(g, x + 16, y + 16, w - 32, h - 32, 18); g.fill(); g.restore();
  // anamorphic flare
  [x, y, w, h] = cell('flare', 1, 1, 2, 1);
  gr = g.createRadialGradient(x + w / 2, y + h / 2, 0, x + w / 2, y + h / 2, h / 2);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.save(); g.translate(x + w / 2, y + h / 2); g.scale(w / h, 0.14); g.translate(-(x + w / 2), -(y + h / 2));
  g.fillStyle = gr; g.fillRect(x, y, w, h); g.restore();
  gr = g.createRadialGradient(x + w / 2, y + h / 2, 0, x + w / 2, y + h / 2, h * 0.3);
  gr.addColorStop(0, 'rgba(255,255,255,0.9)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(x, y, w, h);
  // single chevron arrow pointing +v (up = forward on the road)
  [x, y, w, h] = cell('arrow', 3, 1);
  g.save(); g.translate(x + w / 2, y + h / 2); g.fillStyle = '#fff';
  g.beginPath(); g.moveTo(0, -h * 0.42); g.lineTo(w * 0.42, h * 0.05); g.lineTo(w * 0.24, h * 0.05);
  g.lineTo(0, -h * 0.17); g.lineTo(-w * 0.24, h * 0.05); g.lineTo(-w * 0.42, h * 0.05); g.closePath(); g.fill();
  g.beginPath(); g.moveTo(0, -h * 0.02); g.lineTo(w * 0.42, h * 0.45); g.lineTo(w * 0.24, h * 0.45);
  g.lineTo(0, h * 0.23); g.lineTo(-w * 0.24, h * 0.45); g.lineTo(-w * 0.42, h * 0.45); g.closePath(); g.fill();
  g.restore();
  // "JUMP" road marking: word + two chevrons, 1 x 2 cells (tall = along the road)
  [x, y, w, h] = cell('jump', 0, 2, 1, 2);
  g.save(); g.fillStyle = '#fff'; g.translate(x + w / 2, y);
  for (let k = 0; k < 2; k++) {
    const cy = h * (0.12 + k * 0.2);
    g.beginPath(); g.moveTo(0, cy); g.lineTo(w * 0.46, cy + h * 0.12); g.lineTo(w * 0.46, cy + h * 0.19);
    g.lineTo(0, cy + h * 0.07); g.lineTo(-w * 0.46, cy + h * 0.19); g.lineTo(-w * 0.46, cy + h * 0.12); g.closePath(); g.fill();
  }
  // word, stretched long like real road paint (read from a low angle)
  g.save(); g.translate(0, h * 0.8); g.scale(1, 2.6);
  g.textAlign = 'center'; g.textBaseline = 'middle';
  fitText(g, 'JUMP', 0, 0, w * 0.94, 44);
  g.restore(); g.restore();
  // dashed ring (power-up ground marker)
  [x, y, w, h] = cell('dashring', 1, 2);
  g.save(); g.translate(x + w / 2, y + h / 2); g.strokeStyle = '#fff'; g.lineWidth = 9;
  for (let k = 0; k < 12; k++) { g.beginPath(); g.arc(0, 0, w * 0.4, k * TAU / 12, k * TAU / 12 + TAU / 20); g.stroke(); }
  g.lineWidth = 3; g.beginPath(); g.arc(0, 0, w * 0.3, 0, TAU); g.stroke();
  g.restore();
  // streak (vertical soft line, for trails)
  [x, y, w, h] = cell('streak', 2, 2);
  gr = g.createLinearGradient(x, 0, x + w, 0);
  gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(x, y, w, h);
  // hard dot
  [x, y, w, h] = cell('dot', 3, 2);
  gr = g.createRadialGradient(x + w / 2, y + h / 2, 0, x + w / 2, y + h / 2, w / 2);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,255,255,1)'); gr.addColorStop(0.5, 'rgba(255,255,255,0.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(x, y, w, h);

  // chevron arrows pointing right / left (upright telegraph for drifting monsters)
  for (const [name, cx, dir] of [['arrowR', 1, 1], ['arrowL', 2, -1]]) {
    [x, y, w, h] = cell(name, cx, 3);
    g.save(); g.translate(x + w / 2, y + h / 2); g.scale(dir, 1); g.fillStyle = '#fff';
    for (const ox of [-0.3, 0.08]) {
      g.beginPath(); g.moveTo(w * (ox - 0.08), -h * 0.36); g.lineTo(w * (ox + 0.22), 0); g.lineTo(w * (ox - 0.08), h * 0.36);
      g.lineTo(w * (ox - 0.2), h * 0.36); g.lineTo(w * (ox + 0.1), 0); g.lineTo(w * (ox - 0.2), -h * 0.36); g.closePath(); g.fill();
    }
    g.restore();
  }
  // trail: soft across, fading out toward the bottom (v = 0 end)
  [x, y, w, h] = cell('trail', 3, 3);
  for (let j = 0; j < h; j++) {
    const k = 1 - j / h;
    gr = g.createLinearGradient(x, 0, x + w, 0);
    gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, `rgba(255,255,255,${k * k})`); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(x, y + j, w, 1);
  }

  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.NoColorSpace;
  tex.premultiplyAlpha = false;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  return { tex, rects, canvas: cv };
}

// ------------------------------------------------------------------ GlowBatch
/** Additive camera-facing billboards. push(x,y,z, size, r,g,b, alpha, rectName, rot, stretch) */
export class GlowBatch {
  constructor(fx, capacity = 512, name = 'glows') {
    const geo = new THREE.InstancedBufferGeometry();
    const base = new THREE.PlaneGeometry(1, 1);
    geo.index = base.index; geo.setAttribute('position', base.attributes.position); geo.setAttribute('uv', base.attributes.uv);
    const mk = n => new THREE.InstancedBufferAttribute(new Float32Array(capacity * n), n).setUsage(THREE.DynamicDrawUsage);
    this.aC = mk(4); this.aCol = mk(4); this.aRect = mk(4);
    geo.setAttribute('aC', this.aC); geo.setAttribute('aCol', this.aCol); geo.setAttribute('aRect', this.aRect);
    geo.instanceCount = 0;
    this.mat = new THREE.ShaderMaterial({
      uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { map: { value: fx.tex } }]),
      fog: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      vertexShader: /* glsl */`
        #include <common>
        #include <fog_pars_vertex>
        ${BEND_GLSL_PARS}
        attribute vec4 aC;     // xyz centre, w size
        attribute vec4 aCol;   // rgb (HDR ok), a alpha
        attribute vec4 aRect;  // u0 v0 u1 v1  (packed: rotation in sign-free extra via aspect)
        varying vec2 vUv; varying vec4 vCol; varying float vH;
        void main() {
          vUv = vec2(mix(aRect.x, aRect.z, uv.x), mix(aRect.y, aRect.w, uv.y));
          vCol = aCol;
          vec4 mvPosition = modelViewMatrix * vec4(aC.xyz, 1.0);
          float asp = (aRect.z - aRect.x) / max(1e-5, aRect.w - aRect.y);
          vec2 off = position.xy * vec2(aC.w * asp, aC.w);
          mvPosition.xy += off;
          // world height of this corner (camera right/up in world space = rows of the view matrix)
          vH = aC.y + off.x * viewMatrix[1][0] + off.y * viewMatrix[1][1];
          ${BEND_GLSL_APPLY}
          gl_Position = projectionMatrix * mvPosition;
          #include <fog_vertex>
        }`,
      fragmentShader: /* glsl */`
        #include <common>
        #include <fog_pars_fragment>
        uniform sampler2D map;
        varying vec2 vUv; varying vec4 vCol; varying float vH;
        void main() {
          // fade out before the billboard cuts into the road (no hard intersection line)
          float a = texture2D(map, vUv).a * vCol.a * smoothstep(0.0, 0.35, vH);
          if (a < 0.003) discard;
          gl_FragColor = vec4(vCol.rgb * a, 1.0);
          #ifdef USE_FOG
            #ifdef FOG_EXP2
              float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
            #else
              float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
            #endif
            gl_FragColor.rgb *= 1.0 - fogFactor * 0.85;
          #endif
        }`,
    });
    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = 6;
    this.mesh.name = 'actors.' + name;
    this.geo = geo; this.cap = capacity; this.n = 0; this.rects = fx.rects;
  }
  begin() { this.n = 0; }
  push(x, y, z, size, r, g, b, a, rect = 'glow') {
    if (this.n >= this.cap || a <= 0.002) return;
    const i = this.n++, R = this.rects[rect];
    const c = this.aC.array, k = this.aCol.array, u = this.aRect.array;
    c[i * 4] = x; c[i * 4 + 1] = y; c[i * 4 + 2] = z; c[i * 4 + 3] = size;
    k[i * 4] = r; k[i * 4 + 1] = g; k[i * 4 + 2] = b; k[i * 4 + 3] = a;
    u[i * 4] = R[0]; u[i * 4 + 1] = R[1]; u[i * 4 + 2] = R[2]; u[i * 4 + 3] = R[3];
  }
  end() {
    this.geo.instanceCount = this.n;
    for (const at of [this.aC, this.aCol, this.aRect]) { at.clearUpdateRanges(); at.addUpdateRange(0, Math.max(1, this.n) * 4); at.needsUpdate = true; }
    this.mesh.visible = this.n > 0;
  }
}

// ------------------------------------------------------------------ DecalBatch
/** Flat quads on a horizontal surface, subdivided along their length so they bend with the road.
 *  blend: 'normal' (premultiplied: colour*alpha over) or 'add'. For shadows use colour 0,0,0. */
export class DecalBatch {
  constructor(fx, capacity = 256, blend = 'normal', name = 'decals') {
    const geo = new THREE.InstancedBufferGeometry();
    const base = new THREE.PlaneGeometry(1, 1, 1, 10);
    base.rotateX(-Math.PI / 2);                        // lie flat, +v toward -z (forward)
    geo.index = base.index; geo.setAttribute('position', base.attributes.position); geo.setAttribute('uv', base.attributes.uv);
    const mk = n => new THREE.InstancedBufferAttribute(new Float32Array(capacity * n), n).setUsage(THREE.DynamicDrawUsage);
    this.aC = mk(4); this.aS = mk(4); this.aCol = mk(4); this.aRect = mk(4);
    geo.setAttribute('aC', this.aC); geo.setAttribute('aS', this.aS); geo.setAttribute('aCol', this.aCol); geo.setAttribute('aRect', this.aRect);
    geo.instanceCount = 0;
    const add = blend === 'add';
    this.mat = new THREE.ShaderMaterial({
      uniforms: THREE.UniformsUtils.merge([THREE.UniformsLib.fog, { map: { value: fx.tex } }]),
      fog: true, transparent: true, depthWrite: false,
      polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4,
      blending: add ? THREE.AdditiveBlending : THREE.CustomBlending,
      blendSrc: THREE.OneFactor, blendDst: THREE.OneMinusSrcAlphaFactor,
      blendSrcAlpha: THREE.OneFactor, blendDstAlpha: THREE.OneMinusSrcAlphaFactor,
      defines: add ? { ADD: 1 } : {},
      vertexShader: /* glsl */`
        #include <common>
        #include <fog_pars_vertex>
        ${BEND_GLSL_PARS}
        attribute vec4 aC;    // xyz centre, w yaw
        attribute vec4 aS;    // x width, y length, z lift, w unused
        attribute vec4 aCol;
        attribute vec4 aRect;
        varying vec2 vUv; varying vec4 vCol;
        void main() {
          vUv = vec2(mix(aRect.x, aRect.z, uv.x), mix(aRect.y, aRect.w, uv.y));
          vCol = aCol;
          vec2 p = position.xz * aS.xy;
          float c = cos(aC.w), s = sin(aC.w);
          vec3 w = vec3(aC.x + c * p.x + s * p.y, aC.y + aS.z, aC.z - s * p.x + c * p.y);
          vec4 mvPosition = modelViewMatrix * vec4(w, 1.0);
          ${BEND_GLSL_APPLY}
          gl_Position = projectionMatrix * mvPosition;
          #include <fog_vertex>
        }`,
      fragmentShader: /* glsl */`
        #include <common>
        #include <fog_pars_fragment>
        uniform sampler2D map;
        varying vec2 vUv; varying vec4 vCol;
        void main() {
          float a = texture2D(map, vUv).a * vCol.a;
          if (a < 0.003) discard;
          float fogFactor = 0.0;
          #ifdef USE_FOG
            #ifdef FOG_EXP2
              fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
            #else
              fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
            #endif
          #endif
          #ifdef ADD
            gl_FragColor = vec4(vCol.rgb * a * (1.0 - fogFactor), 1.0);
          #else
            a *= 1.0 - fogFactor;
            gl_FragColor = vec4(vCol.rgb * a, a);
          #endif
        }`,
    });
    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = add ? -4 : -5;
    this.mesh.name = 'actors.' + name;
    this.geo = geo; this.cap = capacity; this.n = 0; this.rects = fx.rects;
  }
  begin() { this.n = 0; }
  push(x, y, z, width, length, yaw, r, g, b, a, rect = 'blob', lift = 0.03) {
    if (this.n >= this.cap || a <= 0.002) return;
    const i = this.n++, R = this.rects[rect];
    const c = this.aC.array, s = this.aS.array, k = this.aCol.array, u = this.aRect.array;
    c[i * 4] = x; c[i * 4 + 1] = y; c[i * 4 + 2] = z; c[i * 4 + 3] = yaw;
    s[i * 4] = width; s[i * 4 + 1] = length; s[i * 4 + 2] = lift; s[i * 4 + 3] = 0;
    k[i * 4] = r; k[i * 4 + 1] = g; k[i * 4 + 2] = b; k[i * 4 + 3] = a;
    u[i * 4] = R[0]; u[i * 4 + 1] = R[1]; u[i * 4 + 2] = R[2]; u[i * 4 + 3] = R[3];
  }
  end() {
    this.geo.instanceCount = this.n;
    for (const at of [this.aC, this.aS, this.aCol, this.aRect]) { at.clearUpdateRanges(); at.addUpdateRange(0, Math.max(1, this.n) * 4); at.needsUpdate = true; }
    this.mesh.visible = this.n > 0;
  }
}

// ------------------------------------------------------------------ reflection env
/** Small PMREM env from a theme-coloured gradient (sky above, warm/cool band, ground below)
 *  so metal (coins, chrome, paint clear-coat) reflects each stage's sky. */
export function createEnvMap(renderer) {
  const pmrem = new THREE.PMREMGenerator(renderer);
  const cv = canvas(256, 128), g = cv.getContext('2d');
  const tex = new THREE.CanvasTexture(cv);
  tex.mapping = THREE.EquirectangularReflectionMapping;
  tex.colorSpace = THREE.SRGBColorSpace;
  let rt = null;
  const api = {
    texture: null,
    update(theme) {
      const gr = g.createLinearGradient(0, 0, 0, 128);
      gr.addColorStop(0, theme.skyT); gr.addColorStop(0.36, theme.skyM); gr.addColorStop(0.49, theme.skyB);
      gr.addColorStop(0.52, theme.grT || '#445'); gr.addColorStop(1, theme.grB || '#223');
      g.fillStyle = gr; g.fillRect(0, 0, 256, 128);
      // soft key-light blob + a bright horizon strip give coins a catchlight
      const sx = theme.keyDir > 0 ? 190 : 66;
      const rg = g.createRadialGradient(sx, 34, 0, sx, 34, 34);
      rg.addColorStop(0, 'rgba(255,255,255,1)'); rg.addColorStop(0.3, 'rgba(255,250,235,0.7)'); rg.addColorStop(1, 'rgba(255,255,255,0)');
      g.fillStyle = rg; g.fillRect(0, 0, 256, 128);
      g.fillStyle = 'rgba(255,255,255,0.35)'; g.fillRect(0, 58, 256, 4);
      tex.needsUpdate = true;
      const next = pmrem.fromEquirectangular(tex);
      if (rt) rt.dispose();
      rt = next;
      api.texture = rt.texture;
      return api.texture;
    },
  };
  return api;
}

/** Remap a geometry's UVs (0..1) into an atlas rect [u0,v0,u1,v1]. */
export function remapUV(geo, r) {
  const uv = geo.attributes.uv;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, r[0] + uv.getX(i) * (r[2] - r[0]), r[1] + uv.getY(i) * (r[3] - r[1]));
  return geo;
}
/** Paint a constant vertex colour attribute. */
export function paint(geo, color) {
  const c = new THREE.Color(color), n = geo.attributes.position.count;
  const a = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) { a[i * 3] = c.r; a[i * 3 + 1] = c.g; a[i * 3 + 2] = c.b; }
  geo.setAttribute('color', new THREE.BufferAttribute(a, 3));
  return geo;
}
