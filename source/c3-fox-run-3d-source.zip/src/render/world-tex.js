// WORLD — procedural canvas textures (asphalt, grass, glows, puffs, corn, chain-link, train
// livery, neon) and the scenery sprite atlas built from the painted scen_* sprites.
// Owned by the WORLD agent.
import * as THREE from 'three';
import { rng } from './world-common.js';

export function makeCanvas(w, h) {
  const c = document.createElement('canvas'); c.width = w; c.height = h; return c;
}
export function canvasTex(c, o = {}) {
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = o.srgb === false ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  if (o.repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = o.aniso || 8;
  t.generateMipmaps = o.mips !== false;
  t.minFilter = t.generateMipmaps ? THREE.LinearMipmapLinearFilter : THREE.LinearFilter;
  t.magFilter = THREE.LinearFilter;
  t.needsUpdate = true;
  return t;
}

// ---------------------------------------------------------------- tileable value noise
function makeNoise(period, seed) {
  const R = rng(seed), g = new Float32Array(period * period);
  for (let i = 0; i < g.length; i++) g[i] = R();
  return (x, y) => {
    const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi;
    const x0 = ((xi % period) + period) % period, y0 = ((yi % period) + period) % period;
    const x1 = (x0 + 1) % period, y1 = (y0 + 1) % period;
    const u = fx * fx * (3 - 2 * fx), v = fy * fy * (3 - 2 * fy);
    const a = g[y0 * period + x0], b = g[y0 * period + x1], c = g[y1 * period + x0], d = g[y1 * period + x1];
    return a + (b - a) * u + (c - a) * v + (a - b - c + d) * u * v;
  };
}

// ---------------------------------------------------------------- asphalt
/** 512 x 1024 = the full 8.6 m road width x 16 m along. Linear data (a multiplier ~0.6..1.1). */
export function asphaltTexture() {
  const W = 512, H = 1024, pxm = W / 8.6, pym = H / 16;
  const c = makeCanvas(W, H), g = c.getContext('2d');
  const R = rng(1234);
  g.fillStyle = 'rgb(196,196,196)'; g.fillRect(0, 0, W, H);
  // wide soft tonal blotches (wrap vertically)
  for (let i = 0; i < 26; i++) {
    const x = R() * W, y = R() * H, r = (1.2 + R() * 3.5) * pxm, a = 0.05 + R() * 0.07;
    const dark = R() < 0.6;
    for (const oy of [-H, 0, H]) {
      const gr = g.createRadialGradient(x, y + oy, 0, x, y + oy, r);
      gr.addColorStop(0, dark ? `rgba(60,60,64,${a})` : `rgba(255,255,255,${a * 0.8})`);
      gr.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = gr; g.fillRect(x - r, y + oy - r, r * 2, r * 2);
    }
  }
  // tyre darkening in the wheel paths of each lane + oil streak between them
  for (const lx of [-2.6, 0, 2.6]) {
    for (const o of [-0.82, 0.82]) {
      const x = (lx + o + 4.3) * pxm, w = 0.55 * pxm;
      const gr = g.createLinearGradient(x - w, 0, x + w, 0);
      gr.addColorStop(0, 'rgba(30,30,34,0)'); gr.addColorStop(0.5, 'rgba(30,30,34,0.20)'); gr.addColorStop(1, 'rgba(30,30,34,0)');
      g.fillStyle = gr; g.fillRect(x - w, 0, w * 2, H);
    }
    const x = (lx + 4.3) * pxm, w = 0.35 * pxm;
    const gr = g.createLinearGradient(x - w, 0, x + w, 0);
    gr.addColorStop(0, 'rgba(20,20,20,0)'); gr.addColorStop(0.5, 'rgba(20,20,20,0.10)'); gr.addColorStop(1, 'rgba(20,20,20,0)');
    g.fillStyle = gr; g.fillRect(x - w, 0, w * 2, H);
  }
  // repair patches (slightly darker, crisp edges)
  for (let i = 0; i < 5; i++) {
    const w = (0.8 + R() * 2.2) * pxm, h = (0.8 + R() * 3.5) * pym;
    const x = R() * (W - w), y = R() * H, dark = R() < 0.7;
    g.fillStyle = dark ? 'rgba(40,40,46,0.10)' : 'rgba(255,255,255,0.05)';
    for (const oy of [-H, 0, H]) g.fillRect(x, y + oy, w, h);
    g.strokeStyle = 'rgba(20,20,20,0.10)'; g.lineWidth = 1.5;
    for (const oy of [-H, 0, H]) g.strokeRect(x, y + oy, w, h);
  }
  // tar snakes (crack sealant): dark wiggles
  g.lineCap = 'round';
  for (let i = 0; i < 9; i++) {
    let x = R() * W, y = R() * H;
    const n = 10 + (R() * 20 | 0), ang0 = (R() < 0.5 ? 0 : Math.PI / 2) + (R() - 0.5) * 0.8;
    g.strokeStyle = `rgba(18,18,20,${0.16 + R() * 0.14})`; g.lineWidth = 1.5 + R() * 2;
    for (const oy of [-H, 0, H]) {
      let px = x, py = y + oy, a = ang0;
      g.beginPath(); g.moveTo(px, py);
      for (let k = 0; k < n; k++) { a += (R() - 0.5) * 0.9; px += Math.cos(a) * 9; py += Math.sin(a) * 9; g.lineTo(px, py); }
      g.stroke();
    }
  }
  // grain: aggregate speckle per pixel
  const id = g.getImageData(0, 0, W, H), d = id.data;
  for (let i = 0; i < d.length; i += 4) {
    const r = R();
    let k = (R() - 0.5) * 34;
    if (r < 0.018) k += 55;            // light stones
    else if (r < 0.045) k -= 45;       // dark pits
    d[i] = Math.max(0, Math.min(255, d[i] + k));
    d[i + 1] = Math.max(0, Math.min(255, d[i + 1] + k));
    d[i + 2] = Math.max(0, Math.min(255, d[i + 2] + k * 1.05));
  }
  g.putImageData(id, 0, 0);
  return canvasTex(c, { srgb: false, repeat: true, aniso: 16 });
}

// ---------------------------------------------------------------- ground detail (RGB = 3 noise layers)
/** 256x256 tileable: R = fine grass blades, G = macro blotches, B = gravel speckle. Linear data. */
export function groundTexture() {
  const N = 256, c = makeCanvas(N, N), g = c.getContext('2d');
  const id = g.createImageData(N, N), d = id.data;
  const n1 = makeNoise(32, 11), n2 = makeNoise(8, 12), n3 = makeNoise(64, 13), n4 = makeNoise(4, 14);
  const R = rng(99);
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const u = x / N, v = y / N;
    const fine = 0.55 * n1(u * 32, v * 32) + 0.3 * n3(u * 64, v * 64) + 0.15 * R();
    const macro = 0.6 * n2(u * 8, v * 8) + 0.4 * n4(u * 4, v * 4);
    const grav = 0.5 * n3(u * 64 + 7, v * 64 + 3) + 0.5 * R();
    const i = (y * N + x) * 4;
    d[i] = fine * 255; d[i + 1] = macro * 255; d[i + 2] = grav * 255; d[i + 3] = 255;
  }
  g.putImageData(id, 0, 0);
  return canvasTex(c, { srgb: false, repeat: true, aniso: 8 });
}

// ---------------------------------------------------------------- soft shapes
export function glowTexture() {
  const N = 128, c = makeCanvas(N, N), g = c.getContext('2d');
  const gr = g.createRadialGradient(N / 2, N / 2, 0, N / 2, N / 2, N / 2);
  gr.addColorStop(0, 'rgba(255,255,255,1)');
  gr.addColorStop(0.12, 'rgba(255,255,255,0.75)');
  gr.addColorStop(0.35, 'rgba(255,255,255,0.22)');
  gr.addColorStop(0.7, 'rgba(255,255,255,0.05)');
  gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, N, N);
  return canvasTex(c, { srgb: false });
}
/** Soft cumulus puff (smoke, mist). White with alpha. */
export function puffTexture(seed = 5) {
  const N = 128, c = makeCanvas(N, N), g = c.getContext('2d');
  const R = rng(seed);
  for (let i = 0; i < 16; i++) {
    const a = R() * Math.PI * 2, rr = R() * 26;
    const x = N / 2 + Math.cos(a) * rr, y = N / 2 + Math.sin(a) * rr * 0.8, r = 18 + R() * 26;
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, 'rgba(255,255,255,0.42)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, N, N);
  }
  return canvasTex(c, { srgb: false });
}
/** Wide horizontal mist bank. */
export function mistTexture() {
  const W = 256, H = 64, c = makeCanvas(W, H), g = c.getContext('2d');
  const R = rng(77);
  for (let i = 0; i < 40; i++) {
    const x = 20 + R() * (W - 40), y = H * 0.55 + (R() - 0.5) * H * 0.35, r = 14 + R() * 30;
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, 'rgba(255,255,255,0.4)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, W, H);
  }
  // fade the edges
  const id = g.getImageData(0, 0, W, H), d = id.data;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const ex = Math.min(x, W - 1 - x) / (W * 0.18), ey = Math.min(y, H - 1 - y) / (H * 0.3);
    const f = Math.min(1, ex) * Math.min(1, ey);
    d[(y * W + x) * 4 + 3] *= f;
  }
  g.putImageData(id, 0, 0);
  return canvasTex(c, { srgb: false });
}

// ---------------------------------------------------------------- corn stalks (alpha cut-out)
export function cornTexture() {
  const W = 256, H = 512, c = makeCanvas(W, H), g = c.getContext('2d');
  const R = rng(4242);
  g.lineCap = 'round';
  const stalk = (x0, h, lean) => {
    const top = H - h;
    // leaves
    for (let k = 0; k < 9; k++) {
      const y = H - (0.12 + k * 0.09) * h, side = k % 2 ? 1 : -1, len = (0.28 + R() * 0.2) * W;
      const x = x0 + lean * (H - y) / H * 20;
      const green = 90 + (R() * 50 | 0);
      g.strokeStyle = `rgb(${50 + (R() * 30 | 0)},${green + 40},${30 + (R() * 20 | 0)})`;
      g.lineWidth = 9 + R() * 5;
      g.beginPath(); g.moveTo(x, y);
      g.quadraticCurveTo(x + side * len * 0.55, y - 40 - R() * 30, x + side * len, y + 30 + R() * 50);
      g.stroke();
      g.strokeStyle = 'rgba(210,230,140,0.35)'; g.lineWidth = 2;
      g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo(x + side * len * 0.55, y - 42, x + side * len, y + 28); g.stroke();
    }
    // stalk
    g.strokeStyle = 'rgb(96,132,52)'; g.lineWidth = 9;
    g.beginPath(); g.moveTo(x0, H); g.quadraticCurveTo(x0 + lean * 8, H - h * 0.5, x0 + lean * 20, top + 40); g.stroke();
    // ear
    g.fillStyle = 'rgb(196,186,90)';
    g.beginPath(); g.ellipse(x0 + 10, H - h * 0.48, 9, 28, 0.35, 0, Math.PI * 2); g.fill();
    // tassel
    g.strokeStyle = 'rgb(226,196,110)'; g.lineWidth = 3.5;
    const tx = x0 + lean * 20, ty = top + 40;
    for (let k = 0; k < 7; k++) {
      g.beginPath(); g.moveTo(tx, ty);
      g.quadraticCurveTo(tx + (k - 3) * 7, ty - 30, tx + (k - 3) * 11, ty - 50 + Math.abs(k - 3) * 8); g.stroke();
    }
  };
  stalk(W * 0.28, H * 0.9, -0.6);
  stalk(W * 0.72, H * 0.84, 0.7);
  stalk(W * 0.5, H * 0.97, 0.1);
  return canvasTex(c, { srgb: true });
}

// ---------------------------------------------------------------- chain-link fence (alpha)
export function chainTexture() {
  const N = 64, c = makeCanvas(N, N), g = c.getContext('2d');
  g.strokeStyle = 'rgba(210,215,220,1)'; g.lineWidth = 2.2;
  for (let k = -1; k <= 1; k++) {
    g.beginPath(); g.moveTo(k * N, 0); g.lineTo(k * N + N, N); g.stroke();
    g.beginPath(); g.moveTo(k * N + N, 0); g.lineTo(k * N, N); g.stroke();
  }
  return canvasTex(c, { srgb: true, repeat: true });
}

// ---------------------------------------------------------------- L train car livery
/** map (RGB) + emissive (lit windows) for a CTA-style stainless car. 512x128. */
export function trainTextures() {
  const W = 512, H = 128;
  const c = makeCanvas(W, H), g = c.getContext('2d');
  const gr = g.createLinearGradient(0, 0, 0, H);
  gr.addColorStop(0, '#dfe4ea'); gr.addColorStop(0.45, '#b9c1cb'); gr.addColorStop(0.55, '#9aa3ae'); gr.addColorStop(1, '#6d7580');
  g.fillStyle = gr; g.fillRect(0, 0, W, H);
  for (let x = 0; x < W; x += 6) { g.fillStyle = 'rgba(255,255,255,0.08)'; g.fillRect(x, 0, 2, H); }
  const e = makeCanvas(W, H), ge = e.getContext('2d');
  ge.fillStyle = '#000'; ge.fillRect(0, 0, W, H);
  // windows
  for (let i = 0; i < 8; i++) {
    const x = 18 + i * 61, w = 46;
    if (i === 3 || i === 7) { g.fillStyle = '#58606a'; g.fillRect(x + 4, 22, 36, 92); g.fillStyle = '#2a3440'; g.fillRect(x + 8, 28, 13, 50); g.fillRect(x + 23, 28, 13, 50); ge.fillStyle = '#ffe9c0'; ge.fillRect(x + 8, 28, 13, 50); ge.fillRect(x + 23, 28, 13, 50); continue; }
    g.fillStyle = '#26303b'; g.fillRect(x, 28, w, 40);
    g.fillStyle = 'rgba(255,255,255,0.18)'; g.fillRect(x, 28, w, 8);
    ge.fillStyle = i % 3 ? '#fff1d0' : '#e8f4ff'; ge.fillRect(x + 2, 30, w - 4, 36);
  }
  // red/blue CTA stripe
  g.fillStyle = '#c8202c'; g.fillRect(0, 80, W, 7);
  g.fillStyle = '#1b4fb8'; g.fillRect(0, 87, W, 7);
  return { map: canvasTex(c), emissive: canvasTex(e) };
}

// ---------------------------------------------------------------- neon signs atlas (4x2 cells of 256)
export const NEON_WORDS = [
  ['BLUFOX', '#39b6ff'], ['OPEN', '#ff3d6e'], ['JAZZ', '#ffcf3a'], ['HOTEL', '#ff5ad1'],
  ['PIZZA', '#ff8a2a'], ['C³', '#6cf2ff'], ['DINER', '#7dff8a'], ['BLUES', '#4f7dff'],
];
export function neonTexture() {
  const W = 1024, H = 512, c = makeCanvas(W, H), g = c.getContext('2d');
  g.fillStyle = '#000'; g.fillRect(0, 0, W, H);
  NEON_WORDS.forEach(([word, col], i) => {
    const cx = (i % 4) * 256 + 128, cy = (i / 4 | 0) * 256 + 128;
    // vertical blade sign: dark panel with neon tubes
    g.save(); g.translate(cx, cy);
    g.fillStyle = '#10121a'; g.fillRect(-58, -120, 116, 240);
    g.strokeStyle = col; g.lineWidth = 5; g.shadowColor = col; g.shadowBlur = 14;
    g.strokeRect(-50, -112, 100, 224);
    g.fillStyle = '#fff'; g.shadowBlur = 18;
    const letters = [...word];
    const fs = Math.min(64, 200 / letters.length);
    g.font = `900 ${fs}px system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif`;
    g.textAlign = 'center'; g.textBaseline = 'middle';
    letters.forEach((ch, k) => {
      const y = -100 + (k + 0.5) * (200 / letters.length);
      g.fillStyle = col; g.fillText(ch, 0, y);
      g.fillStyle = 'rgba(255,255,255,0.85)'; g.shadowBlur = 0; g.fillText(ch, 0, y); g.shadowBlur = 18;
    });
    g.restore();
  });
  return canvasTex(c);
}

// ---------------------------------------------------------------- scenery sprite atlas
// 2048x1024. Painted sprites are drawn in when they load; procedural bush / hay bale / billboards
// with Blufox ads are added. Layout is synchronous so UV rects exist from frame 0.
const ATLAS_W = 2048, ATLAS_H = 1024;
const AD_COPY = [
  { top: 'BLUFOX', bot: 'MOBILE', sub: 'SWITCH & SAVE TODAY', c1: '#ffffff', c2: '#ffd34d' },
  { top: 'C³', bot: 'FOX RUN', sub: 'COOK COUNTY COOKS', c1: '#ffd34d', c2: '#ffffff' },
  { top: 'CHICAGO', bot: '→ KEEP GOING', sub: 'BLUFOX MOBILE · NEXT EXIT', c1: '#ffffff', c2: '#9fe0ff' },
];
export function createSpriteAtlas(assets) {
  const c = makeCanvas(ATLAS_W, ATLAS_H), g = c.getContext('2d');
  const tex = canvasTex(c, { aniso: 8 });
  const meta = assets.SPRITE_META || {};
  const rects = {};
  const PAD = 8, MAXH = 496;
  const place = (name, w, h, x, y) => {
    rects[name] = { x, y, w, h, u0: x / ATLAS_W, v0: 1 - (y + h) / ATLAS_H, du: w / ATLAS_W, dv: h / ATLAS_H, aspect: w / h };
    return rects[name];
  };
  const sizeOf = (key, fw, fh) => {
    const m = meta[key] || { w: fw, h: fh };
    const k = Math.min(1, MAXH / m.h);
    return [Math.round(m.w * k), Math.round(m.h * k), m];
  };
  // row 0
  let x = PAD, y = PAD;
  const row0 = ['scen_pine', 'scen_tree', 'scen_barn', 'scen_walkup', 'scen_flag', 'scen_turbine'];
  const jobs = [];
  for (const k of row0) {
    const [w, h, m] = sizeOf(k, 256, 496);
    const r = place(k, w, h, x, y + (MAXH - h)); r.ax = m.ax ?? 0.5; x += w + PAD;
    jobs.push([k, r]);
  }
  // row 1
  x = PAD; y = MAXH + PAD * 3;
  {
    const [w, h, m] = sizeOf('scen_ltrain', 512, 323);
    const r = place('scen_ltrain', w, h, x, y + (MAXH - h)); r.ax = m.ax ?? 0.5; x += w + PAD;
    jobs.push(['scen_ltrain', r]);
  }
  const signRects = [];
  for (let i = 0; i < AD_COPY.length; i++) {
    const [w, h, m] = sizeOf('scen_sign', 361, 496);
    const r = place('ad' + i, w, h, x, y + (MAXH - h)); r.ax = m.ax ?? 0.5; x += w + PAD;
    signRects.push(r);
  }
  // procedural bush + hay bale in the remaining space
  const bush = place('bush', 200, 150, x, y + MAXH - 150); bush.ax = 0.5; drawBush(g, bush);
  const hay = place('hay', 170, 150, x, y + MAXH - 150 - 170); hay.ax = 0.5; drawHay(g, hay);
  tex.needsUpdate = true;

  let pending = jobs.length + 1;
  const done = () => { if (--pending <= 0) tex.needsUpdate = true; else tex.needsUpdate = true; };
  for (const [k, r] of jobs) {
    assets.getImage('sprites/' + k).then(img => { if (img) g.drawImage(img, r.x, r.y, r.w, r.h); done(); });
  }
  assets.getImage('sprites/scen_sign').then(img => {
    signRects.forEach((r, i) => { if (img) g.drawImage(img, r.x, r.y, r.w, r.h); drawAd(g, r, AD_COPY[i]); });
    done();
  });
  return { tex, rects, ads: signRects.length };
}

function drawAd(g, r, ad) {
  // the blue panel sits at ~3..97% x, ~3..57% y of the sign sprite
  const px = r.x + r.w * 0.1, pw = r.w * 0.8, py = r.y + r.h * 0.085, ph = r.h * 0.44;
  g.save();
  g.beginPath(); g.rect(px, py, pw, ph); g.clip();
  const gr = g.createLinearGradient(0, py, 0, py + ph);
  gr.addColorStop(0, 'rgba(30,110,230,0.0)'); gr.addColorStop(1, 'rgba(0,20,80,0.35)');
  g.fillStyle = gr; g.fillRect(px, py, pw, ph);
  g.textAlign = 'center'; g.textBaseline = 'middle';
  const cx = px + pw / 2;
  const fit = (txt, size, maxW, weight = 900) => {
    let s = size;
    g.font = `${weight} ${s}px system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif`;
    while (g.measureText(txt).width > maxW && s > 8) { s -= 2; g.font = `${weight} ${s}px system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif`; }
    return s;
  };
  g.shadowColor = 'rgba(0,0,20,0.6)'; g.shadowBlur = 6; g.shadowOffsetY = 3;
  fit(ad.top, 78, pw * 0.9); g.fillStyle = ad.c1; g.fillText(ad.top, cx, py + ph * 0.34);
  fit(ad.bot, 40, pw * 0.86); g.fillStyle = ad.c2; g.fillText(ad.bot, cx, py + ph * 0.66);
  g.shadowBlur = 0; g.shadowOffsetY = 0;
  fit(ad.sub, 17, pw * 0.86, 700); g.fillStyle = 'rgba(255,255,255,0.85)'; g.fillText(ad.sub, cx, py + ph * 0.87);
  g.restore();
}
function drawBush(g, r) {
  const R = rng(31);
  const cx = r.x + r.w / 2, base = r.y + r.h - 2;
  // mound silhouette: overlapping soft lobes, dark core
  const lobes = [];
  for (let i = 0; i < 9; i++) {
    const t = i / 8;
    lobes.push([cx + (t - 0.5) * r.w * 0.78, base - r.h * (0.28 + 0.22 * Math.sin(t * Math.PI) + 0.08 * R()), r.w * (0.13 + 0.06 * Math.sin(t * Math.PI))]);
  }
  g.fillStyle = 'rgb(24,48,22)';
  for (const [x, y, rr] of lobes) { g.beginPath(); g.arc(x, y, rr, 0, Math.PI * 2); g.fill(); }
  g.fillRect(cx - r.w * 0.4, base - r.h * 0.3, r.w * 0.8, r.h * 0.3);
  // leaves: small rotated ellipses, darker low, lighter & warmer toward the top-left (sun)
  for (let i = 0; i < 520; i++) {
    const [lx, ly, lr] = lobes[(R() * lobes.length) | 0];
    const a = R() * Math.PI * 2, d = Math.sqrt(R()) * lr * 1.05;
    const x = lx + Math.cos(a) * d, y = Math.min(base - 3, ly + Math.sin(a) * d);
    const up = 1 - (y - (base - r.h)) / r.h;                    // 0 bottom .. 1 top
    const lit = 0.45 + 0.65 * up * (0.75 + 0.25 * Math.cos(a + 2.2)) + (R() - 0.5) * 0.15;
    const gr = Math.min(255, (92 + R() * 40) * lit) | 0;
    g.fillStyle = `rgb(${Math.min(255, (54 + R() * 26) * lit) | 0},${gr},${Math.min(255, (30 + R() * 16) * lit) | 0})`;
    g.save(); g.translate(x, y); g.rotate(R() * Math.PI);
    g.beginPath(); g.ellipse(0, 0, r.w * 0.022, r.w * 0.011, 0, 0, Math.PI * 2); g.fill(); g.restore();
  }
}
function drawHay(g, r) {
  const cx = r.x + r.w / 2, cy = r.y + r.h * 0.55, rr = r.h * 0.42;
  g.fillStyle = '#b8903e'; g.fillRect(cx - r.w * 0.42, cy - rr, r.w * 0.5, rr * 2);
  const gr = g.createRadialGradient(cx + r.w * 0.08, cy, 2, cx + r.w * 0.08, cy, rr);
  gr.addColorStop(0, '#f0d27a'); gr.addColorStop(1, '#c79a45');
  g.fillStyle = gr; g.beginPath(); g.ellipse(cx + r.w * 0.08, cy, rr * 0.8, rr, 0, 0, Math.PI * 2); g.fill();
  g.strokeStyle = 'rgba(120,80,20,0.6)'; g.lineWidth = 2;
  for (let k = 1; k < 5; k++) { g.beginPath(); g.ellipse(cx + r.w * 0.08, cy, rr * 0.8 * k / 5, rr * k / 5, 0, 0, Math.PI * 2); g.stroke(); }
  g.fillStyle = 'rgba(80,50,10,0.25)'; g.fillRect(cx - r.w * 0.42, cy + rr * 0.6, r.w * 0.5, rr * 0.4);
}
