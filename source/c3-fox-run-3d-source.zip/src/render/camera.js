// CAMERA DIRECTOR — createCameraDirector(ctx) -> { update(sim, frame), onEvent(ev, sim) }
//
// Framing is SOLVED per aspect ratio (on resize) against the curved world:
//   portrait 390x844: vFOV ~64°, fox ~14% of screen height, feet ~79.5% down, the road
//   crest (the visible horizon of the bent world) ~34.5% from the top, all three lanes
//   visible at the fox's depth. Landscape/desktop: vFOV ~57°, fox ~18-19%, same horizon.
// The pose comes from a tiny numeric solver that mirrors the bend shader (view-space
// d²) so the horizon stays put even if BEND defaults change.
//
// Motion layers (all dt-based; springs use real dt so hit-stop freezes the sim, not the
// camera): x follow spring (38% — never fully centres), smooth rise onto roofs / ramps /
// boost flight (pull back + up, FOV +12°), lean roll ±2.4°, footstep bob, jump lift,
// landing dip, near-miss lateral kick, speed FOV (+4.5°), trauma shake (bump / smash /
// shieldBreak / hit), level-up push-in, DEATH CAM (slow orbit + push-in, ~1.1 s, real
// time) and a cinematic ATTRACT mode (sim.mode 'ready': crane / orbit / high-wide /
// low-track shots with crossfades) plus a swoop from attract into play.
// It also drives BEND.targetX/targetY (stronger sweeps at speed & in boost) unless
// ctx.cameraDrivesBend === false. prefers-reduced-motion: no roll, shake, bob or FOV kicks.
//
// Publishes FXBUS.foxUV / vanishUV / boostK / speedK for post.js (zoom-blur centre & mask).
import * as THREE from 'three';
import { FXBUS, clamp, lerp, smoothstep, easeInOut, damp } from './fx-bus.js';

const DEG = Math.PI / 180;
const FOX_H = 1.75;

// ---------------------------------------------------------------- framing solver
function ndcY(y, z, H, D, th, tF, bendY, bendStart) {
  const ry = y - H, rz = z - D, s = Math.sin(th), c = Math.cos(th);
  const depth = -ry * s - rz * c;
  let up = ry * c - rz * s;
  const d = Math.max(0, depth - bendStart);
  up -= bendY * d * d;
  return up / depth / tF;
}
function poseFor(F, hN, fN, frac, bendY, bs) {
  const tF = Math.tan(F * DEG / 2), th = Math.atan(hN * tF), al = th + Math.atan(-fN * tF);
  let lo = 1, hi = 80, L = 10;
  for (let i = 0; i < 40; i++) {
    L = (lo + hi) / 2;
    const H = L * Math.sin(al), D = L * Math.cos(al);
    const n1 = ndcY(FOX_H, 0, H, D, th, tF, bendY, bs), n0 = ndcY(0, 0, H, D, th, tF, bendY, bs);
    if ((n1 - n0) / 2 > frac) lo = L; else hi = L;
  }
  return { F, tF, th, H: L * Math.sin(al), D: L * Math.cos(al) };
}
function crestOf(P, bendY, bs) {
  let m = 1e9;
  for (let z = 4; z <= 150; z += 2) {
    const pct = (1 - ndcY(0, -z, P.H, P.D, P.th, P.tF, bendY, bs)) / 2;
    if (pct < m) m = pct;
  }
  return m;
}
/** Solve the base gameplay pose for an aspect ratio. Exported for tests. */
export function solveFraming(aspect, bendY = 0.0013, bendStart = 8) {
  const t = smoothstep(0.55, 1.45, aspect);
  const F = lerp(64, 57, t);
  const frac = lerp(0.14, 0.185, smoothstep(0.55, 2.1, aspect));
  const fN = 1 - 2 * 0.795;
  const crestT = 0.345;
  let lo = 0.05, hi = 0.98, P = null;
  for (let i = 0; i < 22; i++) {
    const hN = (lo + hi) / 2;
    P = poseFor(F, hN, fN, frac, bendY, bendStart);
    if (crestOf(P, bendY, bendStart) > crestT) lo = hN; else hi = hN;
  }
  P.aspect = aspect; P.frac = frac;
  return P;
}

// ---------------------------------------------------------------- small dynamics
function smoothDamp(st, target, smoothTime, dt) {
  const omega = 2 / Math.max(1e-4, smoothTime), x = omega * dt;
  const e = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
  const change = st.x - target, temp = (st.v + omega * change) * dt;
  st.v = (st.v - omega * temp) * e;
  st.x = target + (change + temp) * e;
  return st.x;
}
function springStep(s, k, zeta, dt) {
  const n = Math.max(1, Math.ceil(dt / (1 / 120))), h = dt / n, c = 2 * Math.sqrt(k) * zeta;
  for (let i = 0; i < n; i++) { s.v += (-k * s.x - c * s.v) * h; s.x += s.v * h; }
  return s.x;
}
const sd = (x = 0) => ({ x, v: 0 });
function noise(t, seed) {
  return Math.sin(t * 1.0 + seed) * 0.5 + Math.sin(t * 2.31 + seed * 1.7) * 0.3 + Math.sin(t * 4.63 + seed * 2.9) * 0.2;
}

// pose = { px,py,pz, tx,ty,tz, roll(rad), fov(deg) }
const mkPose = () => ({ px: 0, py: 4, pz: 7, tx: 0, ty: 1, tz: -14, roll: 0, fov: 60 });
function copyPose(o, a) { o.px = a.px; o.py = a.py; o.pz = a.pz; o.tx = a.tx; o.ty = a.ty; o.tz = a.tz; o.roll = a.roll; o.fov = a.fov; return o; }
function lerpPose(o, a, b, t) {
  o.px = lerp(a.px, b.px, t); o.py = lerp(a.py, b.py, t); o.pz = lerp(a.pz, b.pz, t);
  o.tx = lerp(a.tx, b.tx, t); o.ty = lerp(a.ty, b.ty, t); o.tz = lerp(a.tz, b.tz, t);
  o.roll = lerp(a.roll, b.roll, t); o.fov = lerp(a.fov, b.fov, t); return o;
}

export function createCameraDirector(ctx) {
  const { camera, BEND, projectBent } = ctx;
  const bendStart = () => (BEND && BEND.uniforms ? BEND.uniforms.uBendStart.value : 8);
  const BASE_BEND_Y = BEND ? BEND.targetY : 0.0013;
  const drivesBend = ctx.cameraDrivesBend !== false && !!BEND;

  let frameP = null, frameAspect = 0;
  const ensureFraming = aspect => {
    if (!frameP || Math.abs(aspect - frameAspect) > 1e-3) {
      frameP = solveFraming(aspect, BASE_BEND_Y, bendStart());
      frameAspect = aspect;
    }
    return frameP;
  };

  // --- state
  const camX = sd(), lookX = sd(), support = sd(), lift = sd();
  const kickX = sd(), kickRoll = sd(), dip = sd(), fovKick = sd();
  let boostK = 0, speedK = 0, rollS = 0, trauma = 0, shakeT = 0, bobPhase = 0, runK = 0;
  let lastGroundSurf = 0, levelT = -1, bendT = 0;
  let mode = 'play', prevSimMode = null;
  let deathT = 0, deathSide = 1, deathFox = { x: 0, y: 0 }, deathFov = 60;
  let attractT = 0;
  let blendT = 1, blendDur = 1;
  const out = mkPose(), from = mkPose(), aux2 = mkPose(), tgt = mkPose();
  const foxV = new THREE.Vector3(), tmpO = {};
  let first = true;

  function startBlend(dur) { copyPose(from, out); blendT = 0; blendDur = dur; }
  function resetDynamics(sim) {
    const p = sim.player;
    camX.x = p.x * 0.38; camX.v = 0; lookX.x = camX.x; lookX.v = 0;
    support.x = p.surfaceY || 0; support.v = 0; lift.x = 0; lift.v = 0;
    kickX.x = kickX.v = kickRoll.x = kickRoll.v = dip.x = dip.v = fovKick.x = fovKick.v = 0;
    trauma = 0; rollS = 0; boostK = sim.power && sim.power.boost > 0 ? 1 : 0; levelT = -1;
    lastGroundSurf = p.surfaceY || 0;
  }

  // ------------------------------------------------ gameplay pose
  function gameplayPose(sim, rdt, sdt, P, o) {
    const p = sim.player, rm = FXBUS.reducedMotion;
    const boosting = sim.power && sim.power.boost > 0;
    boostK = damp(boostK, boosting ? 1 : 0, boosting ? 3.2 : 2.2, rdt);
    const bk = smoothstep(0, 1, boostK);
    const spd = sim.speed || 15;
    speedK = damp(speedK, clamp((spd - 15) / 15, 0, 1), 2, rdt);

    // lateral: follow 38 % of the fox's x, look slightly further toward it
    const laneTarget = (p.lane != null && ctx.C && ctx.C.LANE_X) ? ctx.C.LANE_X[p.lane] : p.x;
    smoothDamp(camX, (p.x * 0.5 + laneTarget * 0.5) * 0.38, 0.12, rdt);
    smoothDamp(lookX, camX.x + (p.x - camX.x) * 0.3, 0.1, rdt);

    // vertical support: roof / ramp surface, follows a drop off a roof, full height in boost
    if (p.grounded) lastGroundSurf = p.surfaceY || 0;
    let sup = p.grounded ? (p.surfaceY || 0) : Math.min(p.y, lastGroundSurf);
    if (boosting) sup = Math.max(sup, p.y);
    smoothDamp(support, sup, boosting ? 0.35 : (p.grounded ? 0.2 : 0.12), rdt);
    const above = boosting ? 0 : Math.max(0, p.y - Math.max(sup, p.surfaceY || 0));
    smoothDamp(lift, above * 0.3, 0.07, rdt);

    // footstep bob
    const running = p.grounded && sim.mode !== 'dying' && (p.anim === 'run' || p.anim === 'land') ? 1 : 0;
    runK = damp(runK, running, 8, rdt);
    bobPhase += sdt * Math.PI * 2 * (1.35 + spd * 0.028);
    const bob = rm ? 0 : -Math.abs(Math.sin(bobPhase)) * 0.045 * runK * (1 - bk);
    const bobRoll = rm ? 0 : Math.sin(bobPhase) * 0.22 * DEG * runK * (1 - bk);

    // springs
    springStep(kickX, 70, 0.42, rdt);
    springStep(kickRoll, 80, 0.45, rdt);
    springStep(dip, 150, 0.5, rdt);
    springStep(fovKick, 55, 0.55, rdt);

    // level-up push-in (1.2 s envelope)
    let push = 0;
    if (levelT >= 0) { levelT += rdt; const u = levelT / 1.2; if (u >= 1) levelT = -1; else push = Math.sin(Math.PI * u) * (1 - u * 0.3); }

    // safe frame: whatever the springs are doing, the fox (±0.45 m) stays fully on screen
    {
      const fovNow = (P.F + (rm ? 0 : speedK * 4.5)) * DEG;
      const depth = P.H * Math.sin(P.th) + P.D * Math.cos(P.th);
      const lim = Math.max(0.3, depth * Math.tan(fovNow / 2) * (camera.aspect || 1) - 0.6);
      if (camX.x < p.x - lim) { camX.x = p.x - lim; camX.v = Math.max(0, camX.v); }
      if (camX.x > p.x + lim) { camX.x = p.x + lim; camX.v = Math.min(0, camX.v); }
    }
    const sY = support.x * 0.94;
    const H = P.H, D = P.D, th = P.th;
    o.px = camX.x + kickX.x;
    o.py = H + sY + lift.x + bk * 0.9 + dip.x + bob;
    o.pz = D + bk * 1.3 - push * 0.55;
    const tDist = 20;
    o.tx = lookX.x + kickX.x * 0.5;
    o.ty = H - tDist * Math.sin(th) + sY + lift.x * 0.55 + bk * 0.25;
    o.tz = D - tDist * Math.cos(th);
    rollS = damp(rollS, -(p.lean || 0) * 2.4 * DEG, 12, rdt);
    o.roll = rm ? 0 : rollS + kickRoll.x + bobRoll;
    o.fov = P.F + (rm ? 0 : speedK * 4.5 + bk * 11 + fovKick.x - push * 2.2);
    return o;
  }

  // ------------------------------------------------ attract shots (relative to the fox)
  const SHOT_LEN = 6.0, XFADE = 1.6;
  // Every shot aims at the fox (x = fx) so it stays centred even in a narrow portrait
  // frame; lateral camera offsets are scaled by L (portrait ~0.45, landscape 1).
  const shots = [
    (u, fx, fy, F, o, L) => {          // hero crane: low behind -> high over the road
      o.px = fx + lerp(0.9, 0.2, u) * L; o.py = fy + lerp(0.8, 6.4, easeInOut(u)); o.pz = lerp(3.6, 8.2, u);
      o.tx = fx; o.ty = fy + lerp(1.55, 0.3, u); o.tz = lerp(-3, -14, u);
      o.roll = lerp(-2.5, 0, u) * DEG; o.fov = F - 4;
    },
    (u, fx, fy, F, o, L) => {          // slow orbit, behind-left -> behind-right
      const a = lerp(-32, 26, easeInOut(u)) * DEG, r = lerp(6.0, 5.2, u);
      o.px = fx + Math.sin(a) * r; o.py = fy + 2.0; o.pz = Math.cos(a) * r;
      o.tx = fx; o.ty = fy + 1.5; o.tz = -1.5;
      o.roll = 0; o.fov = F - 8;
    },
    (u, fx, fy, F, o, L) => {          // high & wide down the road, slow push
      o.px = fx * 0.4 + lerp(-1.2, 0.8, u) * L; o.py = lerp(11.5, 9.5, u); o.pz = lerp(12.5, 9.5, u);
      o.tx = fx * 0.7; o.ty = 0; o.tz = -20;
      o.roll = 0; o.fov = F - 2;
    },
    (u, fx, fy, F, o, L) => {          // low tracking shot just off the fox's shoulder
      o.px = fx + lerp(1.6, 1.0, u) * L; o.py = fy + lerp(0.6, 0.85, u); o.pz = lerp(4.2, 3.4, u);
      o.tx = fx; o.ty = fy + 1.25; o.tz = -5;
      o.roll = 3.0 * DEG; o.fov = F - 6;
    },
    (u, fx, fy, F, o, L) => {          // descending 3/4 from the right
      const a = lerp(34, 12, u) * DEG, r = lerp(8.5, 6.2, u);
      o.px = fx + Math.sin(a) * r; o.py = fy + lerp(5.2, 2.6, easeInOut(u)); o.pz = Math.cos(a) * r;
      o.tx = fx; o.ty = fy + 1.0; o.tz = -3;
      o.roll = 0; o.fov = F - 6;
    },
  ];
  // Shots overlap by XFADE: shot i runs over [i*period, i*period + SHOT_LEN] on its own clock,
  // so both shots keep moving during a crossfade (no dead stop between shots).
  function attractPose(sim, rdt, P, o) {
    const p = sim.player;
    attractT += rdt * (FXBUS.reducedMotion ? 0.6 : 1);
    smoothDamp(camX, p.x, 0.12, rdt);           // shots track a lightly softened fox x
    smoothDamp(support, Math.max(p.surfaceY || 0, p.y * 0.6), 0.3, rdt);
    const fx = camX.x, fy = support.x;
    const period = SHOT_LEN - XFADE, n = shots.length;
    const t = attractT % (period * n);
    const i = Math.floor(t / period), local = t - i * period;
    const F = Math.max(50, P.F);
    const L = clamp((camera.aspect || 1) / 1.3, 0.45, 1);
    shots[i](local / SHOT_LEN, fx, fy, F, o, L);
    if (local < XFADE) {
      const j = (i + n - 1) % n;                // previous shot, finishing its tail
      shots[j]((local + period) / SHOT_LEN, fx, fy, F, aux2, L);
      lerpPose(o, aux2, o, easeInOut(local / XFADE));
    }
    if (FXBUS.reducedMotion) o.roll = 0;
    return keepInFrame(o, p.x, p.y + 0.9, 0);
  }

  // Guard for cinematic poses: if the fox's chest leaves a safe cone around the aim
  // (60% of the smaller half-FOV), swing the aim toward it. Works for any shot/aspect.
  const _d = new THREE.Vector3(), _f = new THREE.Vector3();
  function keepInFrame(o, fx, fy, fz) {
    const vHalf = o.fov * DEG / 2, hHalf = Math.atan(Math.tan(vHalf) * (camera.aspect || 1));
    const maxA = Math.min(vHalf, hHalf) * 0.6;
    _d.set(o.tx - o.px, o.ty - o.py, o.tz - o.pz);
    const dist = _d.length(); _d.multiplyScalar(1 / dist);
    _f.set(fx - o.px, fy - o.py, fz - o.pz).normalize();
    const ang = Math.acos(clamp(_d.dot(_f), -1, 1));
    if (ang <= maxA) return o;
    const k = 1 - maxA / ang;                         // fraction to swing toward the fox
    _d.lerp(_f, k).normalize();
    o.tx = o.px + _d.x * dist; o.ty = o.py + _d.y * dist; o.tz = o.pz + _d.z * dist;
    return o;
  }

  // ------------------------------------------------ death cam
  function deathPose(sim, rdt, P, o) {
    deathT += rdt;
    const p = sim.player;
    deathFox.x = damp(deathFox.x, p.x, 6, rdt);
    deathFox.y = damp(deathFox.y, Math.max(0, p.y), 6, rdt);
    const u = easeInOut(clamp(deathT / 1.1, 0, 1));
    const drift = Math.max(0, deathT - 1.1) * 3.5;
    const a = deathSide * (lerp(4, 27, u) + Math.min(drift, 12)) * DEG;
    const r = lerp(Math.hypot(P.H, P.D) * 0.85, 6.4, u) - Math.min(drift * 0.05, 0.6);
    const h = lerp(P.H * 0.8, 2.9, u);
    o.px = deathFox.x + Math.sin(a) * r; o.py = deathFox.y + h; o.pz = Math.cos(a) * r;
    o.tx = deathFox.x; o.ty = deathFox.y + lerp(0.2, 0.7, u); o.tz = lerp(-6, -0.9, u);
    o.roll = FXBUS.reducedMotion ? 0 : deathSide * lerp(0, -2.5, u) * DEG;
    o.fov = lerp(deathFov, Math.min(deathFov, 58), u);
    return keepInFrame(o, p.x, p.y + 0.9, 0);
  }

  // ------------------------------------------------ events
  function onEvent(ev, sim) {
    const rm = FXBUS.reducedMotion;
    const shake = a => { if (!rm) trauma = Math.min(1, Math.max(trauma, a)); };
    switch (ev.type) {
      case 'jump': if (!rm) fovKick.v += 9; break;
      case 'land': {
        const imp = clamp((ev.impact || 6) / 6, 0.3, 2);
        dip.v -= 1.25 * imp; if (imp > 1.3) shake(0.18);
        break;
      }
      case 'roof': dip.v -= 0.6; break;
      case 'bump': shake(0.42); kickX.v += -(ev.dir || 0) * 1.6; if (!rm) fovKick.v += 10; break;
      case 'smash': shake(0.3); break;
      case 'shieldBreak': shake(0.55); if (!rm) fovKick.v += 26; break;
      case 'nearMiss': {
        const side = ev.side === 'left' || ev.side < 0 ? -1 : 1;   // side the obstacle was on
        if (!rm) { kickX.v -= side * 1.9; kickRoll.v += side * 3.2 * DEG * 6; }
        break;
      }
      case 'trainPass': {
        const side = ev.side === 'left' || ev.side < 0 ? -1 : 1;
        shake(0.14); if (!rm) kickX.v -= side * 0.9;
        break;
      }
      case 'boostStart': shake(0.25); if (!rm) fovKick.v += 38; break;
      case 'boostEnd': if (!rm) fovKick.v -= 12; break;
      case 'powerup': shake(0.1); if (!rm) fovKick.v += 14; break;
      case 'levelUp': if (sim && sim.mode === 'play') levelT = 0; break;
      case 'hit':
        shake(0.85);
        if (sim) enterDeath(sim);
        break;
      default: break;
    }
  }
  function enterDeath(sim) {
    if (mode === 'death') return;
    mode = 'death'; deathT = 0;
    const p = sim.player;
    deathFox.x = p.x; deathFox.y = Math.max(0, p.y);
    deathSide = p.x > 0.4 ? -1 : p.x < -0.4 ? 1 : (out.roll > 0 ? 1 : -1);
    deathFov = out.fov;
    startBlend(0.45);
  }

  // ------------------------------------------------ update
  function update(sim, frame) {
    if (!sim) return;
    FXBUS.sim = sim;
    const rdt = Math.min(0.1, frame && (frame.realDt ?? frame.dt) || 1 / 60);
    const sdt = Math.min(0.1, frame && frame.dt != null ? frame.dt : rdt);
    const aspect = camera.aspect || (frame && frame.width / frame.height) || 1;
    const P = ensureFraming(aspect);

    // ---- mode transitions
    const sm = sim.mode;
    if (first) { resetDynamics(sim); mode = sm === 'ready' ? 'attract' : (sm === 'dying' || sm === 'over') ? 'death' : 'play'; }
    if (sm !== prevSimMode && !first) {
      if (sm === 'ready') {
        if (mode !== 'attract') { mode = 'attract'; attractT = 0; resetDynamics(sim); blendT = 1; }
      } else if (sm === 'play') {
        if (mode === 'attract') { mode = 'play'; resetDynamics(sim); startBlend(1.1); }
        else if (mode === 'death') { mode = 'play'; resetDynamics(sim); blendT = 1; }
      } else if (sm === 'dying' || sm === 'over') enterDeath(sim);
    }
    prevSimMode = sm; first = false;

    // ---- target pose
    let target;
    if (mode === 'attract') target = attractPose(sim, rdt, P, tgt);
    else if (mode === 'death') target = deathPose(sim, rdt, P, tgt);
    else target = gameplayPose(sim, rdt, sdt, P, tgt);
    if (blendT < 1) {
      blendT = Math.min(1, blendT + rdt / blendDur);
      lerpPose(out, from, target, easeInOut(blendT));
    } else copyPose(out, target);

    // ---- shake (trauma²)
    trauma = Math.max(0, trauma - rdt * 1.5);
    shakeT += rdt * 26;
    const tr = FXBUS.reducedMotion ? 0 : trauma * trauma;

    camera.position.set(out.px + noise(shakeT, 1.3) * 0.26 * tr, out.py + noise(shakeT, 7.1) * 0.2 * tr, out.pz);
    camera.up.set(0, 1, 0);
    foxV.set(out.tx, out.ty, out.tz);
    camera.lookAt(foxV);
    camera.rotateZ(out.roll + noise(shakeT, 3.7) * 2.2 * DEG * tr);
    if (tr > 0) { camera.rotateX(noise(shakeT, 11.9) * 1.1 * DEG * tr); camera.rotateY(noise(shakeT, 5.3) * 1.1 * DEG * tr); }
    const fov = clamp(out.fov, 30, 100);
    if (Math.abs(camera.fov - fov) > 1e-3) { camera.fov = fov; camera.updateProjectionMatrix(); }
    camera.updateMatrixWorld(true);

    // ---- bend drive
    if (drivesBend) {
      BEND.setExternal(true);
      if (mode !== 'death') bendT += sdt;
      const amp = 0.00095 + 0.0005 * speedK + 0.00045 * boostK;
      BEND.targetX = amp * Math.sin(bendT * 0.285) * Math.sin(bendT * 0.117 + 1.3);
      BEND.targetY = BASE_BEND_Y * (1 + 0.16 * speedK + 0.22 * boostK);
    }

    // ---- publish anchors for post
    FXBUS.boostK = boostK; FXBUS.speedK = speedK;
    const p = sim.player;
    foxV.set(p.x, p.y + 0.9, 0);
    projectBent(foxV, camera, 1, 1, tmpO);
    FXBUS.foxUV[0] = tmpO.x; FXBUS.foxUV[1] = 1 - tmpO.y;
    foxV.set(camX.x, 1.0, -70);
    projectBent(foxV, camera, 1, 1, tmpO);
    FXBUS.vanishUV[0] = clamp(tmpO.x, 0.1, 0.9); FXBUS.vanishUV[1] = clamp(1 - tmpO.y, 0.3, 0.95);
  }

  const director = { update, onEvent, get mode() { return mode; }, get framing() { return frameP; } };
  return director;
}
