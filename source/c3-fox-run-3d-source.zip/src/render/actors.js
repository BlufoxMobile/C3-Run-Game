// ACTORS — every gameplay object in the 3D scene, pooled and synced to the sim by entity id.
//
//   const actors = createActors(ctx);          // ctx per CONTRACT §5
//   actors.onEvent(ev, sim)                     // for each sim event, before update
//   actors.update(sim, frame)                   // once per frame
//   actors.setQuality('high' | 'med' | 'low')
//   actors.foxPos                               // THREE.Vector3: the fox's feet in render space (FX / camera may read)
//   actors.ready                                // Promise: fox + monster sheets cleaned and packed
//
// Modules: actors-fox (hero), actors-monsters (commission killers + name tags),
// actors-props (barriers, orbs, power-ups), actors-trucks (semis / box trucks / buses, ramps,
// wheels, headlights), actors-sprites (sheet cleaning, atlas, sprite shader), actors-common
// (theme light, FX atlas, glow / decal batches, reflection env).
//
// Assumptions (documented per CONTRACT): sprites are lit by the theme palette (THEMES amb/key/tod)
// rather than scene lights, because painted art must not be re-shaded by a directional light.
// 3D meshes (trucks, barriers, orbs, pickups) are MeshStandardMaterial and rely on the WORLD's
// scene lights; they carry their own small PMREM reflection env (per theme) for metal/paint.
// Render order among transparents: road paint (-6) < decals/shadows (-5/-4) < sprites (-2) < ghosts (-1) <
// auras (3) < tags (4) < beams/cones (5) < glows (6). Sprites are alpha-tested AND depth-writing.
import * as THREE from 'three';
import { applyBend as coreApplyBend } from '../core/bend.js';
import { createEnv, createFxAtlas, createEnvMap, GlowBatch, DecalBatch } from './actors-common.js';
import { createFox } from './actors-fox.js';
import { createMonsters } from './actors-monsters.js';
import { createBarriers, createOrbs, createPowerups } from './actors-props.js';
import { createTrucks } from './actors-trucks.js';

export function createActors(ctx) {
  const { scene, renderer, THEMES } = ctx;
  const bend = ctx.applyBend || coreApplyBend;
  const fx = createFxAtlas();
  const env = createEnv(THEMES);
  let envMap = null;
  try { envMap = createEnvMap(renderer); envMap.update(THEMES[0]); } catch (e) { console.warn('[actors] env map unavailable', e && e.message); envMap = null; }
  const S = {
    env, fx, bend, envMap,
    glows: new GlowBatch(fx, 1024, 'glows'),
    paint: new DecalBatch(fx, 256, 'normal', 'roadPaint'),        // under everything (jump runways)
    shadows: new DecalBatch(fx, 384, 'normal', 'decals'),
    additive: new DecalBatch(fx, 320, 'add', 'lightDecals'),
  };
  S.paint.mesh.renderOrder = -6;
  scene.add(S.glows.mesh, S.paint.mesh, S.shadows.mesh, S.additive.mesh);

  const trucks = createTrucks(ctx, S);
  const barriers = createBarriers(ctx, S);
  const orbs = createOrbs(ctx, S);
  const powerups = createPowerups(ctx, S);
  const monsters = createMonsters(ctx, S);
  const fox = createFox(ctx, S);
  const parts = [fox, monsters, barriers, trucks, orbs, powerups];

  let envIdx = 0, envT = 0, primed = false;
  const api = {
    foxPos: fox.pos,
    ready: Promise.all([fox.ready, monsters.ready]),
    parts: { fox, monsters, barriers, trucks, orbs, powerups },
    onEvent(ev, sim) {
      for (const p of parts) p.onEvent(ev, sim);
    },
    update(sim, frame) {
      env.update(sim, frame.dt, !primed);
      primed = true;
      // re-bake the reflection env for the new stage (once, a moment after the theme changes)
      if (envMap && sim.themeIdx !== envIdx) { envT += frame.dt; if (envT > 0.4) { envIdx = sim.themeIdx; envT = 0; envMap.update(THEMES[envIdx]); } }
      S.glows.begin(); S.paint.begin(); S.shadows.begin(); S.additive.begin();
      for (const p of parts) p.update(sim, frame);
      S.glows.end(); S.paint.end(); S.shadows.end(); S.additive.end();
    },
    setQuality(tier) {
      for (const p of parts) p.setQuality(tier);
    },
  };
  api.setQuality(ctx.tier || 'high');
  return api;
}
