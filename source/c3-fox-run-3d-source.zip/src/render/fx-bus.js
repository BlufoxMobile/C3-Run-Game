// FX BUS — tiny shared state between the FX agent's modules (camera, feel, post, fx).
//
// Why: post.render(frame) only receives `frame`, but the composite needs sim state
// (power-ups, theme, boost) and screen-space anchors the camera director computes
// (where the fox is, where the road vanishes). Rather than asking main.js for extra
// wiring, every FX module reads/writes this singleton:
//   camera.update  -> foxUV, vanishUV, boostK, speedK
//   fx.update      -> sim (latest), ticks post pulses/fades with the frame's real dt
//   fx.onEvent     -> post pulses ('hit','shield','flash','levelUp','coin')
//   feel.timeScale -> timeScale (for anyone curious)
// Nothing outside src/render/{fx*,camera,post,feel,quality}.js should depend on it.

export const FXBUS = {
  sim: null,              // last sim seen by fx.update / camera.update
  post: null,             // the live post instance (registered by createPost)
  reducedMotion: false,   // prefers-reduced-motion (live)
  timeScale: 1,           // last simDt / realDt from feel
  boostK: 0,              // 0..1 eased GIG BOOST amount (camera)
  speedK: 0,              // 0..1 normalised run speed (camera)
  foxUV: [0.5, 0.22],     // fox chest in UV (x right, y UP), from the camera director
  vanishUV: [0.5, 0.64],  // road vanishing point in UV (y up)
  ticked: false,          // set when fx.update already advanced post fades this frame
  pulse(name, amount) { if (this.post) this.post.pulse(name, amount); },
};

if (typeof window !== 'undefined' && window.matchMedia) {
  try {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    FXBUS.reducedMotion = !!mq.matches;
    const on = e => { FXBUS.reducedMotion = !!e.matches; };
    if (mq.addEventListener) mq.addEventListener('change', on); else if (mq.addListener) mq.addListener(on);
  } catch (e) { /* ignore */ }
  try {
    const q = new URLSearchParams(window.location.search);
    if (q.get('reduced') === '1') FXBUS.reducedMotion = true;
  } catch (e) { /* ignore */ }
}

// small shared math helpers (no allocation)
export const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
export const lerp = (a, b, t) => a + (b - a) * t;
export const smoothstep = (a, b, v) => { const t = clamp((v - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
export const easeInOut = t => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
export const easeOut = t => 1 - Math.pow(1 - t, 3);
/** frame-rate independent exponential approach */
export const damp = (a, b, rate, dt) => a + (b - a) * (1 - Math.exp(-rate * dt));
