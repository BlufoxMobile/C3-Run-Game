// WORLD — sky dome (painted panorama with a procedural gradient/sun/cloud/star/moon fallback)
// and the far landform cards (ridge/hills/plateau/flat/city/stacks silhouettes + hero sprites).
// The dome is the only unbent object. The cards are bent and camera-pinned; world.js slides
// their base onto the curved-world crest every frame so they always peek over the horizon.
// Owned by the WORLD agent.
import * as THREE from 'three';
import { BEND, BEND_GLSL_PARS, BEND_GLSL_APPLY } from '../core/bend.js';
import { INV_ACES_GLSL } from './world-common.js';

const NOISE_GLSL = /* glsl */`
float h11(float p) { return fract(sin(p * 127.1) * 43758.5453); }
float h21(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float n11(float x) { float i = floor(x), f = fract(x); f = f * f * (3.0 - 2.0 * f); return mix(h11(i), h11(i + 1.0), f); }
float n21(vec2 p) {
  vec2 i = floor(p), f = fract(p); f = f * f * (3.0 - 2.0 * f);
  return mix(mix(h21(i), h21(i + vec2(1, 0)), f.x), mix(h21(i + vec2(0, 1)), h21(i + vec2(1, 1)), f.x), f.y);
}
`;

// ============================================================ SKY DOME
const SKY_VS = /* glsl */`
varying vec3 vDir;
void main() {
  vDir = position;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_Position.z = gl_Position.w * 0.99995;
}`;

const SKY_FS = /* glsl */`
precision highp float;
varying vec3 vDir;
uniform vec3 uTop, uMid, uBot, uSunCol, uCloudCol, uSunDir, uSunR, uSunU, uMoonDir, uGlowCol;
uniform float uHorizon, uSunAmt, uGlow, uRays, uCloudAmt, uStars, uMoonAmt, uTime, uCloudShift, uHaze;
uniform sampler2D tPanoA, tPanoB;
uniform float uPanoA, uPanoB, uMix, uPanoSpan, uPanoVA, uPanoVB, uPanoVSpan, uPanoStars;
${INV_ACES_GLSL}
${NOISE_GLSL}
float fbm(vec2 p) {
  float a = 0.5, s = 0.0;
  for (int i = 0; i < CLOUD_OCT; i++) { s += a * n21(p); p = p * 2.03 + vec2(17.1, 3.7); a *= 0.5; }
  return s;
}
vec3 samplePano(sampler2D t, float u, float v, vec3 top) {
  vec3 c = textureLod(t, vec2(u, clamp(v, 0.002, 0.995)), 0.0).rgb;
  return mix(c, top, smoothstep(0.96, 1.12, v));
}
void main() {
  vec3 d = normalize(vDir);
  float el = asin(clamp(d.y, -1.0, 1.0));
  float e = el - uHorizon;
  float az = atan(d.x, -d.z);
  // ---------- gradient
  vec3 col = mix(uBot, uMid, smoothstep(0.0, 0.30, e));
  col = mix(col, uTop, smoothstep(0.20, 1.0, e));
  float cs = dot(d, uSunDir);
  float up = max(cs, 0.0);
  // atmospheric glow hugging the horizon on the sun side + around the sun
  float hz = exp(-max(e, 0.0) * 7.0);
  col += uGlowCol * uGlow * (0.55 * pow(up, 5.0) + 0.45 * hz * pow(cs * 0.5 + 0.5, 3.0));
  // god rays
  if (uRays > 0.0) {
    float ang = atan(dot(d, uSunR), dot(d, uSunU));
    float r = pow(0.5 + 0.5 * sin(ang * 11.0 + sin(ang * 5.0 + uTime * 0.07) * 1.7), 5.0);
    r *= 0.6 + 0.4 * sin(ang * 23.0 - uTime * 0.05);
    col += uGlowCol * uRays * 0.22 * r * pow(up, 3.0) * smoothstep(-0.02, 0.1, e);
  }
  // ---------- clouds (perspective plane over the painted horizon)
  float cloud = 0.0;
  if (uCloudAmt > 0.0 && e > -0.02) {
    float ye = max(sin(e) + 0.06, 0.02);
    vec2 cp = vec2(d.x, -d.z) / ye * 0.55;
    cp += vec2(uTime * 0.012, uCloudShift);
    float f = fbm(cp * 0.9);
    cloud = smoothstep(0.44, 0.72, f) * smoothstep(-0.01, 0.10, e) * uCloudAmt;
    float lit = fbm(cp * 0.9 + uSunDir.xz * 0.12);
    vec3 cc = uCloudCol * (0.78 + 0.35 * (f - lit) * 4.0 + 0.1);
    cc += uGlowCol * uGlow * 0.5 * pow(up, 3.0);
    col = mix(col, cc, cloud * 0.9);
  }
  // ---------- painted panoramas (procedural sun / clouds / stars are the fallback only)
  float pw = mix(uPanoA, uPanoB, uMix);
  if (pw > 0.0) {
    float u = 0.5 + az / uPanoSpan;
    u = 1.0 - abs(mod(u, 2.0) - 1.0);
    vec3 ca = uPanoA > 0.0 ? samplePano(tPanoA, u, uPanoVA + e / uPanoVSpan, uTop) : col;
    vec3 cb = uPanoB > 0.0 ? samplePano(tPanoB, u, uPanoVB + e / uPanoVSpan, uTop) : col;
    vec3 pa = mix(col, ca, uPanoA), pb = mix(col, cb, uPanoB);
    col = mix(pa, pb, uMix);
    cloud *= 1.0 - pw;
  }
  col = mix(col, uBot, uHaze * hz * 0.6 * (1.0 - pw * 0.7));
  vec3 outc = invACES(col, 1.35);
  float proc = 1.0 - pw;
  // ---------- HDR extras added after the inverse so they bloom
  float nightSky = uStars * smoothstep(0.03, 0.3, e) * (1.0 - cloud) * max(proc, uPanoStars);
  if (nightSky > 0.0) {
    vec3 sp = d * 230.0; vec3 id = floor(sp); vec3 f = fract(sp) - 0.5;
    float h = fract(sin(dot(id, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
    float st = step(0.9915, h) * smoothstep(0.36, 0.05, length(f));
    float tw = 0.55 + 0.45 * sin(uTime * (1.5 + h * 6.0) + h * 60.0);
    outc += vec3(0.9, 0.95, 1.1) * st * tw * nightSky * (0.6 + 2.0 * fract(h * 91.0));
  }
  if (uMoonAmt * proc > 0.0) {
    float md = acos(clamp(dot(d, uMoonDir), -1.0, 1.0));
    float disc = smoothstep(0.028, 0.025, md);
    vec2 mp = vec2(dot(d, cross(uMoonDir, vec3(0, 1, 0))), d.y - uMoonDir.y) * 60.0;
    float crater = 0.75 + 0.25 * n21(mp * 1.3) - 0.15 * smoothstep(0.55, 0.8, n21(mp * 0.7 + 3.0));
    outc += uMoonAmt * proc * (vec3(1.3, 1.28, 1.2) * disc * crater + vec3(0.35, 0.42, 0.6) * exp(-md * 18.0) * 0.5);
  }
  if (uSunAmt * proc > 0.0) {
    float sd = acos(clamp(cs, -1.0, 1.0));
    float disc = smoothstep(0.042, 0.036, sd);
    outc += uSunCol * uSunAmt * proc * (disc * 5.0 + exp(-sd * 22.0) * 0.8) * (1.0 - cloud * 0.7) * smoothstep(-0.03, 0.01, e + 0.02);
  }
  gl_FragColor = vec4(outc, 1.0);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

/** Degrees of azimuth one panorama width covers (mirrored beyond). */
export const PANO_SPAN = 120;

export function createSky(renderer) {
  const black = new THREE.DataTexture(new Uint8Array([0, 0, 0, 255]), 1, 1);
  black.needsUpdate = true;
  const U = {
    uTop: { value: new THREE.Color() }, uMid: { value: new THREE.Color() }, uBot: { value: new THREE.Color() },
    uSunCol: { value: new THREE.Color() }, uGlowCol: { value: new THREE.Color() }, uCloudCol: { value: new THREE.Color() },
    uSunDir: { value: new THREE.Vector3(0, 0.2, -1).normalize() }, uSunR: { value: new THREE.Vector3(1, 0, 0) }, uSunU: { value: new THREE.Vector3(0, 1, 0) },
    uMoonDir: { value: new THREE.Vector3(0.3, 0.4, -1).normalize() },
    uHorizon: { value: -0.1 }, uSunAmt: { value: 0 }, uGlow: { value: 0 }, uRays: { value: 0 }, uCloudAmt: { value: 0 },
    uStars: { value: 0 }, uMoonAmt: { value: 0 }, uTime: { value: 0 }, uCloudShift: { value: 0 }, uHaze: { value: 0 },
    tPanoA: { value: black }, tPanoB: { value: black }, uPanoA: { value: 0 }, uPanoB: { value: 0 }, uMix: { value: 0 },
    uPanoSpan: { value: THREE.MathUtils.degToRad(PANO_SPAN) }, uPanoVA: { value: 0.37 }, uPanoVB: { value: 0.37 }, uPanoVSpan: { value: THREE.MathUtils.degToRad(PANO_SPAN * 878 / 2048) }, uPanoStars: { value: 0 },
    uInvTM: { value: 1 }, uTMExp: { value: 1 },
  };
  const mat = new THREE.ShaderMaterial({
    uniforms: U, vertexShader: SKY_VS, fragmentShader: SKY_FS,
    side: THREE.BackSide, depthWrite: false, depthTest: false, fog: false,
    defines: { CLOUD_OCT: 4 },
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(480, 48, 32), mat);
  mesh.frustumCulled = false;
  mesh.renderOrder = -1000;
  mesh.name = 'world-sky';
  return { mesh, U, mat, black };
}

// ============================================================ FAR LANDFORM CARDS
const CARD_VS = /* glsl */`
${BEND_GLSL_PARS}
varying vec2 vL;
void main() {
  vL = position.xy;                                 // metres: x across, y above the card base
  vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
  ${BEND_GLSL_APPLY}
  gl_Position = projectionMatrix * mvPosition;
}`;

const CARD_FS = /* glsl */`
precision highp float;
varying vec2 vL;
uniform float uKindA, uKindB, uMix, uScale, uTime, uNightA, uNightB, uSeed, uAmtA, uAmtB, uHazeK;
uniform vec3 uColA, uColB, uHazeA, uHazeB, uRimA, uRimB;
uniform sampler2D tHeroA, tHeroB;
uniform vec4 uHeroRectA, uHeroRectB;       // x0, width, height, amount
${INV_ACES_GLSL}
${NOISE_GLSL}
// profile height (metres above the card base) for a landform kind at x
float prof(float k, float x, out float win) {
  win = 0.0;
  float S = uScale;
  if (k < 0.5) {                     // ridge: layered peaks
    float r = 0.0, a = 1.0, f = 1.0 / 140.0;
    for (int i = 0; i < 4; i++) { float n = n11(x * f + uSeed * 7.0 + float(i) * 13.0); r += a * (1.0 - abs(n * 2.0 - 1.0)); a *= 0.48; f *= 2.1; }
    return S * (0.35 + 0.55 * r);
  } else if (k < 1.5) {              // hills: soft rolling
    return S * (0.45 + 0.28 * sin(x / 95.0 + uSeed) + 0.18 * sin(x / 41.0 + 2.0 * uSeed) + 0.12 * n11(x / 22.0));
  } else if (k < 2.5) {              // plateau: flat-topped mesas
    float n = n11(x / 170.0 + uSeed * 3.0);
    float top = smoothstep(0.38, 0.48, n);
    return S * (0.35 + 0.55 * top + 0.04 * n11(x / 9.0));
  } else if (k < 3.5) {              // flat: distant tree line
    float t = n11(x / 7.0 + uSeed) * 0.6 + n11(x / 2.3) * 0.4;
    float gap = smoothstep(0.25, 0.35, n11(x / 60.0 + uSeed * 5.0));
    return S * (0.25 + 0.75 * t * gap);
  } else if (k < 4.5) {              // city skyline
    float w = 15.0 + 12.0 * h11(floor(x / 23.0) + uSeed);
    float id = floor(x / w);
    float hh = h11(id * 1.7 + uSeed * 11.0);
    float cen = exp(-pow(x / 260.0, 2.0));   // taller downtown ahead
    float h = S * (0.25 + 0.75 * hh * hh * (0.45 + 0.55 * cen));
    float fx = fract(x / w);
    if (hh > 0.78 && fx > 0.42 && fx < 0.58) h += S * 0.28 * cen;   // spires
    // lit windows
    vec2 cell = floor(vec2(x / 2.2, vL.y / 3.0));
    win = step(0.6, h21(cell + id)) * step(0.3, fract(x / 2.2)) * step(0.35, fract(vL.y / 3.0)) * step(vL.y, h - 3.0);
    return h;
  } else {                           // stacks: industrial skyline with chimneys
    float id = floor(x / 34.0);
    float base = S * (0.18 + 0.14 * h11(id + uSeed));
    float fx = fract(x / 34.0);
    float stack = step(0.55, h11(id * 3.1 + 2.0)) * step(abs(fx - 0.5), 0.045);
    float h = max(base, stack * S * (0.7 + 0.3 * h11(id * 5.3)));
    vec2 cell = floor(vec2(x / 3.0, vL.y / 4.0));
    win = step(0.8, h21(cell + id)) * step(vL.y, base - 2.0) * step(0.5, fract(x / 3.0));
    return h;
  }
}
vec4 layer(float kind, vec3 col, vec3 haze, vec3 rim, float night, vec4 hr, sampler2D th, float amt) {
  float win;
  float x = vL.x;
  float h = prof(kind, x, win);
  float dy = vL.y - h;
  float aa = max(fwidth(dy), 0.05);
  float a = clamp(0.5 - dy / aa, 0.0, 1.0) * amt;
  float t = clamp(vL.y / max(h, 1.0), 0.0, 1.0);
  vec3 c = mix(haze, col, uHazeK + (1.0 - uHazeK) * smoothstep(0.0, 0.9, t));
  c += rim * smoothstep(-3.5, 0.0, dy) * 0.35;
  vec3 e = vec3(0.0);
  if (night > 0.0) e = vec3(1.4, 1.05, 0.62) * win * night * (0.4 + 0.6 * h21(floor(vL.xy)));
  // hero sprite
  if (hr.w > 0.0) {
    vec2 uv = vec2((vL.x - hr.x) / hr.y, vL.y / hr.z);
    if (uv.x > 0.0 && uv.x < 1.0 && uv.y > 0.0 && uv.y < 1.0) {
      vec4 s = texture2D(th, uv);
      float sa = s.a * hr.w;
      c = mix(c, mix(s.rgb, haze, 0.18), sa);
      a = max(a, sa);
      e *= 1.0 - sa;
    }
  }
  return vec4(invACES(c, 1.2) + e, a);
}
void main() {
  vec4 A = uMix < 0.999 ? layer(uKindA, uColA, uHazeA, uRimA, uNightA, uHeroRectA, tHeroA, uAmtA) : vec4(0.0);
  vec4 B = uMix > 0.001 ? layer(uKindB, uColB, uHazeB, uRimB, uNightB, uHeroRectB, tHeroB, uAmtB) : vec4(0.0);
  vec4 o = mix(A, B, uMix);
  if (o.a < 0.01) discard;
  gl_FragColor = vec4(o.rgb, o.a);
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
}`;

export const KIND_ID = { ridge: 0, hills: 1, plateau: 2, flat: 3, trees: 3, fence: 1, corn: 3, city: 4, stacks: 5, stoop: 4 };

export function createCard(name, depth, width, height, scale, seed, black) {
  const U = {
    uKindA: { value: 0 }, uKindB: { value: 0 }, uMix: { value: 0 }, uScale: { value: scale }, uTime: { value: 0 },
    uNightA: { value: 0 }, uNightB: { value: 0 }, uSeed: { value: seed }, uAmtA: { value: 1 }, uAmtB: { value: 1 }, uHazeK: { value: 0.35 },
    uColA: { value: new THREE.Color() }, uColB: { value: new THREE.Color() },
    uHazeA: { value: new THREE.Color() }, uHazeB: { value: new THREE.Color() },
    uRimA: { value: new THREE.Color() }, uRimB: { value: new THREE.Color() },
    tHeroA: { value: black }, tHeroB: { value: black },
    uHeroRectA: { value: new THREE.Vector4(0, 1, 1, 0) }, uHeroRectB: { value: new THREE.Vector4(0, 1, 1, 0) },
    uInvTM: { value: 1 }, uTMExp: { value: 1 },
    ...BEND.uniforms,
  };
  const mat = new THREE.ShaderMaterial({
    uniforms: U, vertexShader: CARD_VS, fragmentShader: CARD_FS,
    transparent: true, depthWrite: false, fog: false,
  });
  // x across, y up (metres). Many columns so the curved-world bend sweeps it smoothly.
  const geo = new THREE.PlaneGeometry(width, height, 64, 1);
  geo.translate(0, height / 2 - 20, 0);
  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;
  mesh.renderOrder = -900 + (depth < 215 ? 1 : 0);
  mesh.name = name;
  return { mesh, U, depth };
}
