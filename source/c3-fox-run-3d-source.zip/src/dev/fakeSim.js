// FAKE SIM — a scripted stand-in for src/sim/sim.js that produces the EXACT state shape
// documented in CONTRACT.md §3, so render / UI / audio modules can be built and
// screenshotted before the real simulation exists. No real collision: the fox is on
// autopilot and everything is choreographed so every entity type is on screen.
//
//   const sim = createFakeSim({ themeIdx: 0, speed: 18 });
//   app.addTick(dt => { sim.step(dt); ...; sim.events.length = 0; });
//   sim.forceTheme(9); sim.setPower('boost', 5); sim.player.lane = 2; sim.kill();
import { LANE_X, VIEW_AHEAD, VIEW_BEHIND, TRUCK_H, TRUCK_W } from '../core/constants.js';
import { THEMES, tierOf, MONSTERS, KINDS, POWERUPS } from '../data/themes.js';

export function createFakeSim(opts = {}) {
  let nextId = 1;
  let rowS = 30;           // next row spawn distance
  let rowN = 0;
  let autoT = 0, autoStep = 0;
  const speed = opts.speed || 18;
  const levelLen = opts.levelLen || 320;

  const sim = {
    mode: 'play', time: 0, runTime: 0, dist: 0,
    speed, baseSpeed: speed, level: 1, lap: 1,
    themeIdx: opts.themeIdx || 0, theme: null, nextThemeIdx: 0,
    levelStart: 0, nextLevelAt: levelLen, levelProgress: 0,
    score: 0, combo: 1, comboTimer: 0, bestCombo: 1,
    tsheets: 0, shield: 1,
    power: { magnet: 0, x2: 0, boost: 0 },
    powerMax: { magnet: POWERUPS.magnet.dur, x2: POWERUPS.x2.dur, boost: POWERUPS.boost.dur },
    invuln: 0, timeScaleHint: 1,
    player: { lane: 1, fromLane: 1, laneT: 1, x: 0, y: 0, vy: 0, grounded: true,
              onRoof: null, surfaceY: 0, anim: 'run', animT: 0, lean: 0, stumbleT: 0 },
    obstacles: [], trains: [], orbs: [], powerups: [],
    events: [], killer: null,
    stats: { orbs: 0, nearMisses: 0, hops: 0, smashed: 0, distance: 0 },
    autopilot: opts.autopilot !== false,
  };
  sim.theme = THEMES[sim.themeIdx];
  sim.nextThemeIdx = (sim.themeIdx + 1) % THEMES.length;

  const emit = e => sim.events.push(e);

  function monster(lane, s) {
    sim.obstacles.push({ id: nextId++, type: 'monster', kind: MONSTERS[(nextId * 7) % MONSTERS.length],
      lane, x: LANE_X[lane], s, w: 1.5, h: 2.1, len: 0.8, drift: null, hit: false, smashed: false, near: false });
  }
  function barrier(lane, s, gateRow = false) {
    sim.obstacles.push({ id: nextId++, type: 'barrier', kind: 'barrier', lane, x: LANE_X[lane], s,
      w: 2.1, h: 1.0, len: 0.5, drift: null, hit: false, smashed: false, near: false, gateRow });
  }
  function train(lane, s, len, v = 0, ramp = false, kind = 'semi') {
    sim.trains.push({ id: nextId++, kind, lane, x: LANE_X[lane], s, len, h: TRUCK_H, w: TRUCK_W, v,
      ramp, rampLen: ramp ? 7 : 0, livery: nextId % 3, lights: v < 0 });
  }
  function orbs(lane, s, n, kind = 'xm', y = 0.9, gap = 2.4) {
    for (let i = 0; i < n; i++) sim.orbs.push({ id: nextId++, kind, lane, x: LANE_X[lane], s: s + i * gap, y, got: false, magnet: false });
  }
  function power(lane, s, kind) {
    sim.powerups.push({ id: nextId++, kind, lane, x: LANE_X[lane], s, y: 1.0, got: false });
  }

  function spawnRow(s) {
    const n = rowN++ % 6;
    if (n === 0) { monster(0, s); barrier(2, s); orbs(1, s - 6, 5); }
    else if (n === 1) { train(1, s, 20, 0, true, 'semi'); orbs(1, s - 5, 4, 'xm', 0.9, 2.2); orbs(1, s + 2, 6, 'tab', TRUCK_H + 0.9); monster(2, s + 6); }
    else if (n === 2) { train(0, s + 20, 14, -9, false, 'box'); barrier(1, s); power(2, s, ['magnet', 'x2', 'boost'][(rowN / 6 | 0) % 3]); }
    else if (n === 3) { barrier(0, s, true); barrier(1, s, true); barrier(2, s, true); orbs(1, s - 1, 3, 'watch', 2.0, 1.2); }
    else if (n === 4) { monster(1, s); monster(2, s); orbs(0, s - 4, 1, 'tsheet'); train(2, s + 18, 26, 0, false, 'bus'); }
    else { train(0, s, 16, 0, true, 'box'); train(2, s + 4, 16, 0, false, 'semi'); orbs(1, s, 6, 'xm'); }
  }

  function surfaceAt(lane, s) {
    for (const t of sim.trains) {
      if (t.lane !== lane) continue;
      if (s >= t.s && s <= t.s + t.len) return t.h;
      if (t.ramp && s >= t.s - t.rampLen && s < t.s) return t.h * (s - (t.s - t.rampLen)) / t.rampLen;
    }
    return 0;
  }

  sim.moveLane = dir => {
    const p = sim.player, to = Math.max(0, Math.min(2, p.lane + dir));
    if (to === p.lane) return;
    p.fromLane = p.lane; p.lane = to; p.laneT = 0;
    emit({ type: 'lane', dir, lane: to });
  };
  sim.jump = () => {
    const p = sim.player;
    if (!p.grounded) return;
    p.vy = 7.2; p.grounded = false; p.anim = 'jump'; p.animT = 0;
    emit({ type: 'jump', x: p.x, y: p.y });
  };
  sim.forceTheme = i => {
    const prev = sim.themeIdx;
    sim.themeIdx = ((i % THEMES.length) + THEMES.length) % THEMES.length;
    sim.theme = THEMES[sim.themeIdx]; sim.nextThemeIdx = (sim.themeIdx + 1) % THEMES.length;
    if (prev !== sim.themeIdx) emit({ type: 'levelUp', level: sim.level, themeIdx: sim.themeIdx, lap: sim.lap,
      name: sim.theme.name, region: sim.theme.reg, tier: tierOf(sim.level) });
  };
  sim.setPower = (k, sec) => { sim.power[k] = sec ?? sim.powerMax[k]; emit({ type: 'powerup', kind: k, x: sim.player.x, y: 1, s: sim.dist }); };
  sim.kill = () => {
    sim.mode = 'dying'; sim.player.anim = 'hit'; sim.player.animT = 0;
    sim.killer = { type: 'monster', kind: 'chargeback' };
    emit({ type: 'hit', kind: 'chargeback', x: sim.player.x, y: 1, s: sim.dist + 1 });
    setTimeout(() => { sim.mode = 'over'; emit({ type: 'death' }); }, 900);
  };

  sim.step = (dt) => {
    const p = sim.player;
    sim.time += dt;
    if (sim.mode === 'over') return;
    const dying = sim.mode === 'dying';
    const v = dying ? 0 : sim.speed * (sim.power.boost > 0 ? 1.6 : 1);
    sim.dist += v * dt; sim.runTime += dt;
    sim.stats.distance = sim.dist;
    sim.score += dt * (2 + sim.speed * 0.6);
    for (const k in sim.power) if (sim.power[k] > 0) { sim.power[k] = Math.max(0, sim.power[k] - dt); if (!sim.power[k]) emit({ type: 'powerEnd', kind: k }); }

    // level / theme progression
    if (sim.dist >= sim.nextLevelAt) {
      sim.level++; sim.levelStart = sim.nextLevelAt; sim.nextLevelAt += levelLen;
      sim.lap = 1 + Math.floor((sim.level - 1) / THEMES.length);
      sim.forceTheme(sim.themeIdx + 1);
    }
    sim.levelProgress = (sim.dist - sim.levelStart) / (sim.nextLevelAt - sim.levelStart);

    // spawn ahead / recycle behind
    while (rowS < sim.dist + VIEW_AHEAD) { spawnRow(rowS); rowS += 26; }
    for (const t of sim.trains) t.s += t.v * dt;
    const alive = e => e.s + (e.len || 0) > sim.dist - VIEW_BEHIND;
    sim.obstacles = sim.obstacles.filter(alive);
    sim.trains = sim.trains.filter(alive);
    sim.powerups = sim.powerups.filter(e => alive(e) && !e.got);

    // autopilot: weave + hop
    if (sim.autopilot && !dying) {
      autoT += dt;
      if (autoT > 1.15) { autoT = 0; const seq = [-1, 1, 1, -1]; sim.moveLane(seq[autoStep++ % 4]); }
      if (autoStep % 3 === 1 && p.grounded && autoT > 0.5 && autoT < 0.55) sim.jump();
    }

    // lane tween (ease-out-back, 110 ms)
    if (p.laneT < 1) {
      p.laneT = Math.min(1, p.laneT + dt / 0.11);
      const u = p.laneT - 1, c1 = 1.15, c3 = c1 + 1, e = 1 + c3 * u * u * u + c1 * u * u;
      p.x = LANE_X[p.fromLane] + (LANE_X[p.lane] - LANE_X[p.fromLane]) * e;
    } else p.x = LANE_X[p.lane];
    const leanTarget = p.laneT < 1 ? Math.sign(LANE_X[p.lane] - LANE_X[p.fromLane]) : 0;
    p.lean += (leanTarget - p.lean) * Math.min(1, dt * 14);

    // vertical: ground or truck roof / ramp
    const surf = surfaceAt(p.lane, sim.dist);
    p.animT += dt;
    if (!p.grounded) {
      p.vy -= 22 * dt; p.y += p.vy * dt;
      if (p.y <= surf) {
        p.y = surf; p.vy = 0; p.grounded = true; p.anim = 'run'; p.animT = 0;
        emit({ type: 'land', x: p.x, y: p.y, onRoof: surf > 1, impact: 6 });
      }
    } else {
      if (surf < p.y - 0.3) { p.grounded = false; p.anim = 'fall'; emit({ type: 'drop' }); }
      else p.y = surf;
    }
    p.surfaceY = surf; p.onRoof = surf >= TRUCK_H - 0.01 ? 1 : null;
    if (p.anim !== 'hit' && p.grounded) p.anim = sim.power.boost > 0 ? 'boost' : 'run';

    // orbs: magnet pull + pickup when passing the player
    for (const o of sim.orbs) {
      if (o.got) continue;
      if (sim.power.magnet > 0 && o.s - sim.dist < 22 && o.s > sim.dist) {
        o.magnet = true; const k = Math.min(1, dt * 7);
        o.x += (p.x - o.x) * k; o.y += (p.y + 0.9 - o.y) * k;
      }
      const reach = o.magnet || Math.abs(o.x - p.x) < 1.0;
      if (o.s <= sim.dist + 0.3 && o.s > sim.dist - 1 && reach && Math.abs((p.y + 0.9) - o.y) < 1.4) {
        o.got = true;
        if (o.kind === 'tsheet') { sim.tsheets++; sim.shield = Math.min(3, sim.shield + 1); emit({ type: 'tsheet', count: sim.tsheets, shield: sim.shield, x: o.x, y: o.y, s: o.s }); }
        else {
          sim.combo = Math.min(9, sim.combo + 1); sim.comboTimer = 1.6;
          const value = KINDS[o.kind].val * sim.combo * (sim.power.x2 > 0 ? 2 : 1);
          sim.score += value; sim.stats.orbs++;
          emit({ type: 'coin', kind: o.kind, value, combo: sim.combo, x: o.x, y: o.y, s: o.s });
        }
      }
    }
    sim.orbs = sim.orbs.filter(o => !o.got && o.s > sim.dist - VIEW_BEHIND);
    for (const u of sim.powerups) {
      if (!u.got && u.lane === p.lane && u.s <= sim.dist + 0.3 && u.s > sim.dist - 1) {
        u.got = true; sim.setPower(u.kind);
      }
    }
    if (sim.comboTimer > 0) { sim.comboTimer -= dt; if (sim.comboTimer <= 0) sim.combo = 1; }
  };

  // pre-populate so the first frame already has a full road
  sim.step(0);
  return sim;
}
