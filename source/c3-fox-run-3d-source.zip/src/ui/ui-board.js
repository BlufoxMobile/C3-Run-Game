// TOP-5 BOARD — renders LB.top(5) into a fixed set of 5 rows (no per-refresh DOM churn).
// LB promises never reject, but we still guard every call: the game never breaks because of
// the leaderboard. Rows render optimistically from the last good answer (shared cache).
import { fmtMoney, normName, frag, q, qa, setText, ICONS } from './ui-dom.js';

let CACHE = null;          // last rows from any board, so the second screen paints instantly

export function boardHTML(title = 'TOP 5 EARNERS') {
  const rows = [1, 2, 3, 4, 5].map(i =>
    `<li class="bd-row" data-rk="${i}"><span class="bd-rk">${i === 1 ? ICONS.crown : ''}<em>${i}</em></span>` +
    `<span class="bd-nm"></span><span class="bd-lv"></span><span class="bd-sc"></span></li>`).join('');
  return `<div class="board">
    <div class="bd-head"><span class="bd-title">${title}</span><span class="bd-live"><i></i><span class="bd-live-t">LIVE</span></span></div>
    <ol class="bd-list">${rows}</ol>
    <div class="bd-you" hidden><span class="bd-you-l">YOU</span><span class="bd-you-rk"></span><span class="bd-you-sc"></span></div>
    <div class="bd-note" role="status" aria-live="polite"></div>
  </div>`;
}

export function createBoard(el, LB) {
  const rows = qa(el, '.bd-row').map(li => ({ li, nm: q(li, '.bd-nm'), lv: q(li, '.bd-lv'), sc: q(li, '.bd-sc') }));
  const you = q(el, '.bd-you'), youRk = q(el, '.bd-you-rk'), youSc = q(el, '.bd-you-sc');
  const note = q(el, '.bd-note'), live = q(el, '.bd-live'), liveT = q(el, '.bd-live-t');
  let seq = 0;
  let lastRows = null;

  function paint(list, opts = {}) {
    const hl = opts.highlight ? normName(opts.highlight) : '';
    const soft = opts.soft ? normName(opts.soft) : '';
    let hlFound = false;
    for (let i = 0; i < rows.length; i++) {
      const r = rows[i], d = list && list[i];
      r.li.classList.toggle('empty', !d);
      if (d) {
        setText(r.nm, String(d.name || '').toUpperCase());
        setText(r.lv, 'L' + (d.level || 1));
        setText(r.sc, fmtMoney(d.score));
        const k = normName(d.name);
        const me = !!hl && k === hl;
        if (me) hlFound = true;
        r.li.classList.toggle('me', me);
        r.li.classList.toggle('mine', !me && !!soft && k === soft);
        r.li.classList.toggle('pending', !!d.pending);
      } else {
        setText(r.nm, list ? (i === 0 && !list.length ? 'NO RUNS YET — BE THE FIRST' : '—') : '');
        setText(r.lv, ''); setText(r.sc, '');
        r.li.classList.remove('me', 'mine', 'pending');
      }
    }
    // "YOU: #12" when the posted run is outside the top 5
    if (hl && !hlFound && opts.youScore > 0) {
      you.hidden = false;
      setText(youRk, opts.youRank > 0 ? '#' + opts.youRank : '');
      setText(youSc, fmtMoney(opts.youScore));
    } else you.hidden = true;
  }

  function status(list) {
    let online = false;
    try { online = !!(LB && LB.isOnline && LB.isOnline()); } catch (e) {}
    live.classList.toggle('off', !online);
    setText(liveT, online ? 'LIVE' : 'THIS PHONE');
    el.classList.toggle('loading', !list);
  }

  /** Refresh from LB.top(5). opts: {highlight, soft, youRank, youScore}. Resolves with the rows. */
  function refresh(opts = {}) {
    const my = ++seq;
    if (CACHE || lastRows) paint(lastRows || CACHE, opts); else paint(null, opts);
    status(CACHE || lastRows);
    if (!LB || !LB.top) { paint([], opts); status([]); return Promise.resolve([]); }
    let p;
    try { p = Promise.resolve(LB.top(5)); } catch (e) { p = Promise.resolve([]); }
    return p.then(list => {
      list = Array.isArray(list) ? list.slice(0, 5) : [];
      if (my !== seq) return list;          // a newer refresh owns the board
      lastRows = CACHE = list;
      paint(list, opts); status(list);
      return list;
    }, () => { if (my === seq) { paint(lastRows || [], opts); status(lastRows || []); } return lastRows || []; });
  }

  function setNote(text, kind = '') {
    setText(note, text || '');
    note.className = 'bd-note' + (kind ? ' ' + kind : '');
  }

  return { refresh, paint, setNote, get rows() { return lastRows; } };
}

/** Where would `score` land in `list` (1-based)? 0 if outside the top 5 or already beaten by your own row. */
export function prospectiveRank(list, score, name) {
  if (!(score > 0) || !Array.isArray(list)) return 0;
  const k = name ? normName(name) : '';
  let rank = 1;
  for (const r of list) {
    if (k && normName(r.name) === k && r.score >= score) return 0;   // your own better run is already there
    if (r.score > score) rank++;
  }
  return rank <= 5 ? rank : 0;
}

export { frag };
