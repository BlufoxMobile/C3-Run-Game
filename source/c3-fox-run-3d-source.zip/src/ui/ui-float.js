// FLOATING WORLD TEXT — pooled DOM nodes pinned to 3D points with projectBent().
// Transform/opacity only (compositor-cheap), zero allocations per frame.
// The anchor is kept in RENDER space (relative to the fox), so "+$60" stays by the fox
// instead of rushing past the camera with the world; the rise happens in screen space.
import { REDUCED } from './ui-dom.js';

const STYLES = {
  // life (s), rise (px), size class
  cash:   { life: 0.72, rise: 54 },
  cash2x: { life: 0.72, rise: 54 },
  near:   { life: 0.95, rise: 46 },
  hop:    { life: 0.62, rise: 40 },
  smash:  { life: 0.80, rise: 50 },
  bonus:  { life: 1.05, rise: 64 },
  power:  { life: 0.95, rise: 58 },
  pmagnet: { life: 0.95, rise: 58 },
  px2:    { life: 0.95, rise: 58 },
  pboost: { life: 0.95, rise: 58 },
  shield: { life: 0.95, rise: 52 },
  tsheet: { life: 0.85, rise: 50 },
  bump:   { life: 0.55, rise: 28 },
};

export function createFloats(layer, projectBent, Vec3, size = 22) {
  const pool = [];
  const out = { x: 0, y: 0, visible: false };
  for (let i = 0; i < size; i++) {
    const el = document.createElement('div');
    el.className = 'flt';
    el.setAttribute('aria-hidden', 'true');
    const b = document.createElement('b');
    const sm = document.createElement('small');
    el.appendChild(b); el.appendChild(sm);
    el.style.opacity = '0';
    layer.appendChild(el);
    pool.push({ el, b, sm, pos: new Vec3(), age: 0, life: 1, rise: 50, active: false,
      style: '', main: '', sub: '', born: 0, jx: 0, oy: 0, value: 0, combo: 0 });
  }
  let serial = 0;

  function spawn(main, sub, pos, style) {
    let f = null, oldest = null;
    for (const p of pool) {
      if (!p.active) { f = p; break; }
      if (!oldest || p.born < oldest.born) oldest = p;
    }
    if (!f) f = oldest;
    const st = STYLES[style] || STYLES.cash;
    // stack floats born together at (nearly) the same anchor instead of drawing them on top of each other
    let stack = 0;
    for (const p of pool) {
      if (p === f || !p.active || p.age > 0.35) continue;
      if (Math.abs(p.pos.x - pos.x) < 1.3 && Math.abs(p.pos.y - pos.y) < 1.0 && Math.abs(p.pos.z - pos.z) < 3) stack++;
    }
    f.oy = -26 * Math.min(stack, 3);
    f.active = true; f.age = 0; f.life = st.life; f.rise = st.rise; f.born = ++serial;
    f.pos.copy(pos);
    f.jx = ((serial * 37) % 21) - 10;                // small deterministic horizontal scatter
    if (f.style !== style) { f.el.className = 'flt f-' + style; f.style = style; }
    if (f.main !== main) { f.b.textContent = main; f.main = main; }
    if (f.sub !== sub) { f.sm.textContent = sub; f.sm.style.display = sub ? '' : 'none'; f.sub = sub; }
    return f;
  }

  /** Re-pop an existing float with new text (coin streams coalesce into one float). */
  function repop(f, main, sub) {
    if (!f || !f.active) return;
    f.age = Math.min(f.age, 0.04);
    if (f.main !== main) { f.b.textContent = main; f.main = main; }
    if (f.sub !== sub) { f.sm.textContent = sub; f.sm.style.display = sub ? '' : 'none'; f.sub = sub; }
  }

  function update(dt, camera, w, h) {
    let any = false;
    for (const f of pool) if (f.active) { any = true; break; }
    if (!any || !camera) return;
    camera.updateMatrixWorld();
    for (const f of pool) {
      if (!f.active) continue;
      f.age += dt;
      const t = f.age / f.life;
      if (t >= 1) { f.active = false; f.el.style.opacity = '0'; f.el.style.transform = 'translate3d(-999px,-999px,0)'; continue; }
      projectBent(f.pos, camera, w, h, out);
      if (!out.visible) { f.el.style.opacity = '0'; continue; }
      // pop: 0.55 -> 1.18 (overshoot) -> 1.0, then drift to 0.92
      let s;
      if (REDUCED) s = 1;
      else if (t < 0.12) s = 0.55 + (1.18 - 0.55) * (t / 0.12);
      else if (t < 0.24) s = 1.18 - 0.18 * ((t - 0.12) / 0.12);
      else s = 1 - 0.08 * ((t - 0.24) / 0.76);
      const e = 1 - (1 - t) * (1 - t) * (1 - t);    // ease-out cubic rise
      const rise = (REDUCED ? 0.4 : 1) * f.rise * e;
      const a = t < 0.06 ? t / 0.06 : t > 0.62 ? Math.max(0, 1 - (t - 0.62) / 0.38) : 1;
      let x = out.x + f.jx * e;
      const y = out.y - rise + f.oy;
      // near a screen edge, anchor the text by its near side so it never clips (no layout reads)
      let ax = -50;
      if (x > w - 96) { ax = -100; x = Math.min(x + 40, w - 8); }
      else if (x < 96) { ax = 0; x = Math.max(x - 40, 8); }
      f.el.style.transform = `translate3d(${x.toFixed(1)}px,${y.toFixed(1)}px,0) translate(${ax}%,-50%) scale(${s.toFixed(3)})`;
      if (f.ax !== ax) { f.ax = ax; f.el.style.transformOrigin = ax === -100 ? '100% 50%' : ax === 0 ? '0 50%' : '50% 50%'; }
      f.el.style.opacity = a.toFixed(3);
    }
  }

  function clear() {
    for (const f of pool) { f.active = false; f.el.style.opacity = '0'; f.el.style.transform = 'translate3d(-999px,-999px,0)'; }
  }

  return { spawn, repop, update, clear, pool };
}
