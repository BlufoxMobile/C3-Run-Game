// UI helpers — tiny DOM utilities, formatting and inline SVG icons.
// No user-supplied string ever goes through innerHTML: names use textContent.

/** $12,480 — fast, locale-independent, integer dollars. */
export function fmtMoney(n) {
  n = Math.floor(Math.max(0, +n || 0));
  return '$' + String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/** Trim + truncate by CODE POINT (never cuts an emoji in half) — mirrors lb.js cleanName. */
export function trimName(v, max = 24) {
  const s = String(v == null ? '' : v).replace(/[\x00-\x1F\x7F<>]/g, ' ').replace(/\s+/g, ' ').trim();
  let cp; try { cp = Array.from(s); } catch (e) { cp = s.split(''); }
  return cp.length > max ? cp.slice(0, max).join('').trim() : s;
}

/** Board identity key: lowercase letters + digits only (same idea as lb.js normKey). */
export function normName(v) {
  const s = trimName(v).toLowerCase();
  let k;
  try { k = s.replace(/[^\p{L}\p{N}]+/gu, ''); } catch (e) { k = s.replace(/[^a-z0-9]+/g, ''); }
  return k || s.replace(/\s+/g, '');
}

/** Build an element from a static template string (trusted markup only). */
export function frag(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

/** querySelector shorthand bound to a root. */
export const q = (root, sel) => root.querySelector(sel);
export const qa = (root, sel) => Array.from(root.querySelectorAll(sel));

export function setText(el, s) { if (el && el.textContent !== s) el.textContent = s; }

export const REDUCED = (() => {
  try { return !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches); }
  catch (e) { return false; }
})();

export const COARSE = (() => {
  try { return !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches); }
  catch (e) { return false; }
})();

/** Fire-and-forget Web Animation (transform/opacity only). No reflow, unlike class re-adding. */
export function anim(el, frames, opts) {
  if (!el || REDUCED || !el.animate) return null;
  try { return el.animate(frames, opts); } catch (e) { return null; }
}

// ---------------------------------------------------------------- icons
const S = (vb, body, cls = '') => `<svg class="ico ${cls}" viewBox="${vb}" aria-hidden="true" focusable="false">${body}</svg>`;
export const ICONS = {
  pause: S('0 0 24 24', '<rect x="6" y="5" width="4.3" height="14" rx="1.3"/><rect x="13.7" y="5" width="4.3" height="14" rx="1.3"/>'),
  play: S('0 0 24 24', '<path d="M8.2 4.9v14.2a1.1 1.1 0 0 0 1.7.93l11.1-7.1a1.1 1.1 0 0 0 0-1.86L9.9 3.97a1.1 1.1 0 0 0-1.7.93z"/>'),
  soundOn: S('0 0 24 24', '<path d="M3.5 9.2h3.6L12.4 4.6v14.8l-5.3-4.6H3.5z"/><path d="M15.6 8.4a5 5 0 0 1 0 7.2M18.4 5.6a9 9 0 0 1 0 12.8" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"/>', 'i-on'),
  soundOff: S('0 0 24 24', '<path d="M3.5 9.2h3.6L12.4 4.6v14.8l-5.3-4.6H3.5z"/><path d="M16 9.2l5.2 5.6M21.2 9.2L16 14.8" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"/>', 'i-off'),
  retry: S('0 0 24 24', '<path d="M12 4.2a7.8 7.8 0 1 1-7.5 5.7" fill="none" stroke="currentColor" stroke-width="2.8" stroke-linecap="round"/><path d="M3.2 3.6l1.5 6.6 6.4-2.2z"/>'),
  home: S('0 0 24 24', '<path d="M3.5 11.2 12 4l8.5 7.2V20a1 1 0 0 1-1 1h-4.6v-5.6H9.1V21H4.5a1 1 0 0 1-1-1z"/>'),
  check: S('0 0 24 24', '<path d="M4.5 12.8l4.6 4.6L19.8 6.7" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>'),
  send: S('0 0 24 24', '<path d="M3.4 11.1 20 4.2c.8-.3 1.5.4 1.2 1.2l-6.9 16.6c-.3.8-1.5.8-1.8 0l-2.2-6.2-6.2-2.2c-.8-.3-.8-1.5 0-1.8z"/>'),
  shield: S('0 0 24 24', '<path d="M12 2.2 4.2 5.1v6.1c0 5 3.3 9.2 7.8 10.6 4.5-1.4 7.8-5.6 7.8-10.6V5.1z"/>'),
  sheet: S('0 0 24 24', '<path d="M6 2.5h8.3L19 7.2V20a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 20V4A1.5 1.5 0 0 1 6 2.5z"/><path d="M8.2 11h7.6M8.2 14.2h7.6M8.2 17.4h5" stroke="rgba(0,0,0,.45)" stroke-width="1.6" stroke-linecap="round"/>'),
  magnet: S('0 0 24 24', '<path d="M4.5 3.5h5v8.3a2.5 2.5 0 0 0 5 0V3.5h5v8.3a7.5 7.5 0 0 1-15 0z"/><path d="M4.5 3.5h5v3.4h-5zM14.5 3.5h5v3.4h-5z" fill="#fff"/>'),
  bolt: S('0 0 24 24', '<path d="M13.6 1.8 4.4 13.6h6.2l-1.4 8.6 9.4-12.1h-6.3z"/>'),
  crown: S('0 0 24 24', '<path d="M3 8.2l4.6 3.6L12 5l4.4 6.8L21 8.2l-1.9 10.3H4.9z"/>'),
  keys: S('0 0 24 24', '<rect x="2" y="12.5" width="6" height="6" rx="1.4"/><rect x="9" y="12.5" width="6" height="6" rx="1.4"/><rect x="16" y="12.5" width="6" height="6" rx="1.4"/><rect x="9" y="5.5" width="6" height="6" rx="1.4"/>'),
  swipe: S('0 0 24 24', '<path d="M10 11V5.6a1.6 1.6 0 0 1 3.2 0v6.2l3.6.8c1 .2 1.7 1.1 1.6 2.2l-.5 5.2H9.4l-3.5-4.6a1.5 1.5 0 0 1 2.3-1.9L10 15z"/><path d="M3 5.8h4M17 5.8h4M4.6 4.2 3 5.8l1.6 1.6M19.4 4.2 21 5.8l-1.6 1.6" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>'),
};

/** The "C³ FOX RUN" lockup: pure CSS/SVG type (no web fonts). */
export function logoHTML(size = '') {
  return `<div class="logo ${size}" role="img" aria-label="C³ Fox Run">
    <span class="logo-badge"><span class="logo-c">C<sup>3</sup></span></span>
    <span class="logo-word" data-text="FOX RUN"><span>FOX RUN</span></span>
  </div>`;
}
