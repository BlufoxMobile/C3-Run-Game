// INPUT — swipe / tap / keyboard -> sim actions ('left' | 'right' | 'jump').
//
//   const input = createInput(app.canvas);        // or document / window
//   each frame:  sim.step(dt, input.poll());
//   input.enabled = sim.mode === 'play' && !paused;   // toggling clears the queue
//   input.onAny((action, e) => audio.unlock());   // every key / pointer down, even when disabled
//
// Ported from the tuned 2D build (§11 INPUT), with these changes:
//  * SAME-direction continuation is gated by a FLAT 180 px of travel from the last fire AND a
//    pause (the thumb slowed below 0.12 px/ms for 70 ms, or stopped) since that fire. The old
//    90 ms re-arm let a 120 px throw fire two lane changes; a pure 180 px gate still let a
//    real 220 px throw fire two (measured through Chromium's touch pipeline). One continuous
//    throw = one lane change, like every runner. A reversal re-arms immediately
//    (left-then-right without lifting).
//  * Reversal detection tracks the extreme point instead of per-sample deltas, so it no
//    longer depends on the touch sampling rate (120 Hz panels sent < 3 px per sample).
//  * After a fire, a CROSS-axis fire in the same stroke needs 2:1 dominance, so the
//    natural arc of a thumb swipe can't turn a lane change into a lane change + jump.
//  * Swipe down is ignored (no slide in this game). Tap = jump. Swipe up = jump.
//  * JUMP TIMING (Jeff: "I click to jump but it's not accurate"):
//      - MOUSE left button jumps on pointerdown (zero lag). The press already jumped, so a mouse
//        drag can still change lanes but never adds a second (swipe-up / release) jump.
//      - TOUCH / PEN taps are only known on release, so they are emitted as
//        { a: 'jump', lag } with lag = (up - down) seconds, capped at TAP_LAG_CAP (0.15 s); the
//        sim starts the jump as if it began `lag` seconds earlier. (Firing taps early while the
//        finger is still down was evaluated and rejected: a resting palm, a long press and a
//        swipe that begins with a pause would all turn into phantom jumps.)
//      - Swipe-up jumps fire mid-gesture and stay plain 'jump'. Keys fire on keydown.
//    poll() therefore returns a mix: 'left' | 'right' | 'jump' | { a: 'jump', lag }.
//  * P / Esc are NOT handled here — the UI owns pause/resume (it knows which screen is up).
// Every event's time comes from opts.now() (default performance.now) so tests can drive a
// fake clock.

export const SWIPE = {
  dist: 38,          // px of travel that always counts as a swipe
  flick: 22,         // ...or this much, if thrown fast enough
  flickSpeed: 0.30,  // px/ms
  turn: 3,           // px of counter-travel from the extreme point = a reversal (re-anchor)
  unlatch: 14,       // px of counter-travel that ENDS a stroke (re-enables the same direction)
  idle: 180,         // ms: a pause this long starts a fresh flick segment
  repeat: 180,       // px: flat gate for a same-direction continuation after a fire
  pauseMs: 70,       // ...which also needs the thumb to have paused this long since the fire
  pauseSpeed: 0.12,  // px/ms: slower than this counts as paused
  crossRatio: 2,     // dominance needed for a cross-axis fire inside a latched stroke
  tapSlop: 20,       // px a tap may wander
  tapMaxMs: 600,     // a resting finger is not a tap
  maxQueue: 4,
};

const EMPTY = Object.freeze([]);
export const TAP_LAG_CAP = 0.15;   // s: max press-to-release time credited back to a tap jump
let hapticsOn = true;
const CAN_BUZZ = (() => { try { return typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function'; } catch (e) { return false; } })();
const RM = (() => { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } })();

/** Tiny vibration (Android; iOS ignores). Gated on the input.haptics option and reduced motion. */
export function haptic(pattern) {
  if (!hapticsOn || !CAN_BUZZ || RM || !pattern) return;
  try {
    // Chrome logs a console error for vibrate() before the first user gesture: skip until then
    const ua = navigator.userActivation;
    if (ua && !ua.hasBeenActive) return;
    navigator.vibrate(pattern);
  } catch (e) {}
}

function isEditable(t) {
  if (!t || !t.tagName) return false;
  const tag = t.tagName;
  return tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT' || t.isContentEditable;
}
/** UI controls own their own presses: a tap on a button must never also jump. */
function isControl(t) {
  if (!t || !t.closest) return false;
  return !!t.closest('button, input, textarea, select, a, label, [data-ui-hit]');
}

export function createInput(el, opts = {}) {
  el = el || window;
  const T = Object.assign({}, SWIPE, opts.tune || {});
  const now = opts.now || (() => performance.now());
  const queue = [];
  const anyFns = [];
  const ptrs = new Map();
  let enabled = true;
  const stats = { fired: 0, taps: 0, swipes: 0 };

  function push(action, src) {
    if (!enabled) return;
    if (queue.length >= T.maxQueue) queue.shift();
    queue.push(action);
    stats.fired++;
    if (input.log) {
      const obj = typeof action === 'object';
      input.log.push({ action: obj ? action.a : action, src, t: now(), lag: obj ? action.lag : 0 });
    }
  }
  function any(action, e) { for (const fn of anyFns) { try { fn(action, e); } catch (err) { console.error(err); } } }

  // ------------------------------------------------------------------ gesture core
  // Per-pointer state. x0/y0/t0 = immutable DOWN point (tap test). ax/ay = distance anchor.
  // fx/fy/ft = flick anchor + clock. ex/ey = extreme point in the current direction of travel
  // (sx/sy = that direction). lastDir/lastX/lastY = the last fire of this stroke; latched = the
  // same-direction gate is armed.
  function down(id, x, y, t, type) {
    ptrs.set(id, { id, type, x0: x, y0: y, t0: t, ax: x, ay: y, fx: x, fy: y, ft: t,
      lx: x, ly: y, lt: t, sx: 0, sy: 0, ex: x, ey: y, ext: t, eyt: t,
      swiped: false, latched: false, lastDir: null, lastX: x, lastY: y, backX: x, backY: y,
      slowMs: 0, paused: false, pressJumped: false });
    if (type === 'mouse') {
      // a mouse press IS the jump: no tap-vs-swipe wait, so the fox leaves when the player clicked
      push('jump', 'mouse');
      ptrs.get(id).pressJumped = true;
    }
  }

  function axis(s, v, t, k) {
    // k: 'x' or 'y'. Tracks direction + extreme; a reversal re-anchors at the turning point.
    const sk = k === 'x' ? 'sx' : 'sy', ek = k === 'x' ? 'ex' : 'ey', tk = k === 'x' ? 'ext' : 'eyt';
    const ak = k === 'x' ? 'ax' : 'ay', fk = k === 'x' ? 'fx' : 'fy';
    const dir = s[sk];
    if (dir === 0) {
      if (Math.abs(v - s[ak]) > T.turn) { s[sk] = v > s[ak] ? 1 : -1; s[ek] = v; s[tk] = t; }
      return;
    }
    if ((v - s[ek]) * dir >= 0) { s[ek] = v; s[tk] = t; return; }     // still going (new extreme)
    if (Math.abs(v - s[ek]) > T.turn) {                                // turned around
      const turnPt = s[ek];
      s[sk] = -dir; s[ak] = turnPt; s[fk] = turnPt; s.ft = s[tk];
      s[ek] = v; s[tk] = t;
    }
  }

  function move(id, x, y, t) {
    const s = ptrs.get(id); if (!s) return;
    const gap = t - s.lt;
    if (gap > T.idle) { s.fx = s.lx; s.fy = s.ly; s.ft = t; }          // rested, then moved: judge the throw
    // pause tracking (for the same-direction repeat gate): time spent SLOW. A late sample that
    // covered a lot of ground is a dropped frame, not a pause (seen on real touch streams).
    if (Math.hypot(x - s.lx, y - s.ly) < T.pauseSpeed * Math.max(1, gap)) { s.slowMs += gap; if (s.slowMs >= T.pauseMs) s.paused = true; }
    else s.slowMs = 0;
    s.lt = t;
    axis(s, x, t, 'x');
    axis(s, y, t, 'y');
    s.lx = x; s.ly = y;

    // Un-latch: counter-travel against the last fire's direction ends that stroke.
    if (s.latched) {
      if (s.lastDir === 'left')  { s.backX = Math.min(s.backX, x); if (x - s.backX >= T.unlatch) s.latched = false; }
      else if (s.lastDir === 'right') { s.backX = Math.max(s.backX, x); if (s.backX - x >= T.unlatch) s.latched = false; }
      else if (s.lastDir === 'jump')  { s.backY = Math.min(s.backY, y); if (y - s.backY >= T.unlatch) s.latched = false; }
    }

    const dx = x - s.ax, dy = y - s.ay;
    const gx = x - s.fx, gy = y - s.fy;
    const age = Math.max(1, t - s.ft);
    const adx = Math.abs(dx), ady = Math.abs(dy), agx = Math.abs(gx), agy = Math.abs(gy);
    const fastX = agx > T.flick && agx / age > T.flickSpeed && agx > agy;
    const fastY = agy > T.flick && agy / age > T.flickSpeed && agy > agx;
    let act = null;
    if ((adx > T.dist && adx > ady) || fastX) act = (fastX ? gx : dx) > 0 ? 'right' : 'left';
    else if ((-dy > T.dist && ady > adx) || (fastY && gy < 0)) act = 'jump';
    if (!act) return;
    if (act === 'jump' && s.pressJumped) return;       // the mouse press already jumped

    if (s.latched) {
      if (act === s.lastDir) {
        // same direction, no reversal since the last fire: flat gate from the fire point
        const travel = act === 'left' ? s.lastX - x : act === 'right' ? x - s.lastX : s.lastY - y;
        if (travel < T.repeat || !s.paused) return;
      } else {
        const lateral = act !== 'jump';
        const wasLateral = s.lastDir !== 'jump';
        if (lateral !== wasLateral) {
          // cross-axis inside one stroke: needs clear dominance (a curved thumb arc is not an L)
          const main = lateral ? Math.max(adx, agx) : Math.max(ady, agy);
          const cross = lateral ? Math.max(ady, agy) : Math.max(adx, agx);
          if (main < cross * T.crossRatio) return;
        }
      }
    }
    fire(s, act, x, y, t);
  }

  function fire(s, act, x, y, t) {
    push(act, 'swipe');
    stats.swipes++;
    s.swiped = true; s.latched = true; s.lastDir = act; s.lastX = x; s.lastY = y; s.backX = x; s.backY = y;
    s.paused = false; s.slowMs = 0;
    s.ax = x; s.ay = y; s.fx = x; s.fy = y; s.ft = t;
    s.sx = 0; s.sy = 0; s.ex = x; s.ey = y; s.ext = t; s.eyt = t;
    if (s.type === 'touch') haptic(act === 'jump' ? 9 : 7);
  }

  function up(id, x, y, t, cancelled) {
    const s = ptrs.get(id); if (!s) return;
    ptrs.delete(id);
    if (cancelled || s.swiped || s.pressJumped) return;
    if (t - s.t0 > T.tapMaxMs) return;
    if (Math.abs(x - s.x0) < T.tapSlop && Math.abs(y - s.y0) < T.tapSlop) {
      // credit the press-to-release time back to the jump so the arc starts when the finger landed
      const lag = Math.min(TAP_LAG_CAP, Math.max(0, (t - s.t0) / 1000));
      push({ a: 'jump', lag: Math.round(lag * 1000) / 1000 }, 'tap'); stats.taps++;
      if (s.type === 'touch') haptic(9);
    }
  }

  // ------------------------------------------------------------------ DOM wiring
  const onDown = e => {
    if (isControl(e.target)) return;
    if (e.pointerType === 'mouse' && e.button !== 0) return;
    any(null, e);
    if (!enabled) return;
    down(e.pointerId, e.clientX, e.clientY, now(), e.pointerType);
  };
  const onMove = e => {
    if (!enabled || !ptrs.size) return;
    // coalesced events carry the full-rate path (120 Hz panels); use them when present
    if (e.getCoalescedEvents) {
      let list = null; try { list = e.getCoalescedEvents(); } catch (err) {}
      if (list && list.length > 1) { const t = now(); for (const c of list) move(e.pointerId, c.clientX, c.clientY, t); return; }
    }
    move(e.pointerId, e.clientX, e.clientY, now());
  };
  const onUp = e => { if (ptrs.has(e.pointerId)) up(e.pointerId, e.clientX, e.clientY, now(), !enabled); };
  const onCancel = e => { ptrs.delete(e.pointerId); };
  // touchstart preventDefault kills iOS double-tap zoom, the magnifier and synthetic clicks
  const onTouch = e => { if (!isControl(e.target) && e.cancelable) e.preventDefault(); };
  const onCtx = e => { if (!isControl(e.target)) e.preventDefault(); };
  const onGesture = e => { if (e.cancelable) e.preventDefault(); };
  const onBlur = () => { ptrs.clear(); };

  const KEYMAP = {
    ArrowLeft: 'left', ArrowRight: 'right', ArrowUp: 'jump', ' ': 'jump', Spacebar: 'jump',
    a: 'left', A: 'left', d: 'right', D: 'right', w: 'jump', W: 'jump',
  };
  const CODEMAP = { KeyA: 'left', KeyD: 'right', KeyW: 'jump', Space: 'jump' };
  const onKey = e => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (isEditable(e.target)) return;
    const act = KEYMAP[e.key] || CODEMAP[e.code] || null;
    any(act, e);
    if (!enabled) return;
    if (act || e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') e.preventDefault();  // no page scroll / button activation
    if (!act || e.repeat) return;
    push(act, 'key');
  };

  const pOpts = { passive: true };
  el.addEventListener('pointerdown', onDown, pOpts);
  window.addEventListener('pointermove', onMove, pOpts);
  window.addEventListener('pointerup', onUp, pOpts);
  window.addEventListener('pointercancel', onCancel, pOpts);
  el.addEventListener('touchstart', onTouch, { passive: false });
  el.addEventListener('contextmenu', onCtx);
  document.addEventListener('gesturestart', onGesture, { passive: false });
  document.addEventListener('dblclick', onGesture, { passive: false });
  window.addEventListener('keydown', onKey);
  window.addEventListener('blur', onBlur);

  const input = {
    tune: T,
    stats,
    log: null,               // set to [] to record every fired action {action, src, t} (tests)
    /** Actions since the last poll, oldest first: 'left' | 'right' | 'jump' | {a:'jump', lag}.
     *  Returns a shared empty array when idle. */
    poll() {
      if (!queue.length) return EMPTY;
      const out = queue.slice(); queue.length = 0; return out;
    },
    get enabled() { return enabled; },
    set enabled(b) {
      b = !!b;
      if (b === enabled) return;
      enabled = b; queue.length = 0; ptrs.clear();
    },
    get haptics() { return hapticsOn; },
    set haptics(b) { hapticsOn = !!b; },
    /** fn(action | null, event) on EVERY key/pointer down (also while disabled) — audio unlock etc. */
    onAny(fn) { anyFns.push(fn); return () => { const i = anyFns.indexOf(fn); if (i >= 0) anyFns.splice(i, 1); }; },
    /** Test hooks: drive the recognizer directly with explicit times. */
    _down: down, _move: move, _up: up,
    clear() { queue.length = 0; ptrs.clear(); },
    destroy() {
      el.removeEventListener('pointerdown', onDown, pOpts);
      window.removeEventListener('pointermove', onMove, pOpts);
      window.removeEventListener('pointerup', onUp, pOpts);
      window.removeEventListener('pointercancel', onCancel, pOpts);
      el.removeEventListener('touchstart', onTouch, { passive: false });
      el.removeEventListener('contextmenu', onCtx);
      document.removeEventListener('gesturestart', onGesture);
      document.removeEventListener('dblclick', onGesture);
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('blur', onBlur);
    },
  };
  return input;
}
