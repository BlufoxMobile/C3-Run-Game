// UI — every DOM screen of C³ FOX RUN: LOADING, TITLE, HUD, PAUSE, GAME OVER + floating world text.
//
//   const ui = createUI({ ...ctx, root: document.getElementById('ui'), LB, camera });
//   ui.on('play', startRun); ui.on('retry', startRun); ui.on('quit', toTitle);
//   ui.on('pause', ...); ui.on('resume', ...); ui.on('mute', b => audio.setMuted(b));
//   per frame:  ui.updateHUD(sim, frame);   per event: ui.onEvent(ev, sim)
//
// RULES this module keeps (CONTRACT §6.5 + Jeff's complaint):
//  * Nothing drawn during play ever covers the running corridor. HUD lives in the top band and
//    the right edge; the level toast is a SLIM (<= 44 px) strip under the HUD for 1.6 s;
//    celebratory callouts use the same top band. Floating world text is small and short-lived.
//  * During play the ONLY hit-testable element is the pause button; every other pixel lets
//    touches through to the canvas (input is never swallowed).
//  * updateHUD writes to the DOM only when a displayed value changes; animations are
//    transform/opacity only (JS-driven by the HUD clock, or WAAPI one-shots).
//
// Assumptions (documented for the orchestrator):
//  * Extra emitted event 'quit' (pause -> QUIT TO TITLE). If nobody handles it the UI still
//    shows the title; main should reset the sim to attract mode.
//  * The UI emits and ALSO applies its own screen change when main does not do it
//    synchronously (PLAY -> HUD, RETRY -> HUD, pause/resume overlay), so a minimal main works.
//  * UI owns P / Esc (pause/resume), Space/Enter on title, Space/R/Enter on game over, M (mute).
//    input.js owns only lanes/jump.
//  * UI also pauses itself (emitting 'pause') when the tab is hidden during a run.
//  * Mute state persists in localStorage ('c3fr3d_muted'); read it via ui.muted at boot.
import './style.css';
import * as THREE from 'three';
import { projectBent as coreProjectBent } from '../core/bend.js';
import { zOf } from '../core/constants.js';
import { THEMES, tierOf, MONSTER_LABEL, POWERUPS } from '../data/themes.js';
import { assetInfo } from '../core/assets.js';
import { fmtMoney, trimName, frag, q, qa, setText, anim, REDUCED, ICONS, logoHTML } from './ui-dom.js';
import { createFloats } from './ui-float.js';
import { boardHTML, createBoard, prospectiveRank } from './ui-board.js';
import { haptic } from './input.js';

const MUTE_KEY = 'c3fr3d_muted';
const COMBO_WINDOW = 1.6;
const TOAST_LIFE = 1.6;
const CALLOUT_LIFE = 1.15;
const RING_C = 2 * Math.PI * 21;          // chip ring circumference (r = 21 in a 48 viewBox)
const POWER_KEYS = ['magnet', 'x2', 'boost'];
const POWER_FLOAT = { magnet: 'MAGNET!', x2: '2X!', boost: 'GIG BOOST!' };
const TRUCK_NAME = { semi: 'A SEMI', box: 'A BOX TRUCK', bus: 'A CITY BUS' };

const clamp01 = v => (v > 0 ? (v < 1 ? v : 1) : 0);
const easeOutBack = t => { const c1 = 1.7, c3 = c1 + 1, u = t - 1; return 1 + c3 * u * u * u + c1 * u * u; };
const isEditable = t => !!t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
const isButton = t => !!t && t.tagName === 'BUTTON';

function readMuted() { try { return localStorage.getItem(MUTE_KEY) === '1'; } catch (e) { return false; } }
function saveMuted(b) { try { localStorage.setItem(MUTE_KEY, b ? '1' : '0'); } catch (e) {} }

/** One-line cause of death: "CAUGHT BY A CHARGE BACK". */
export function causeLine(killer) {
  if (!killer) return 'WIPED OUT';
  const k = killer.kind;
  if (killer.type === 'monster' && MONSTER_LABEL[k]) {
    const label = MONSTER_LABEL[k];
    return 'CAUGHT BY ' + (/^[AEIOU]/.test(label) ? 'AN ' : 'A ') + label;
  }
  if (killer.type === 'barrier') return 'TRIPPED ON A ROADBLOCK';
  if (killer.type === 'train' || killer.type === 'truck') {
    if (k === 'bump' || killer.bump) return 'SIDESWIPED ' + (TRUCK_NAME[killer.truck] || 'A TRUCK');
    return (killer.oncoming ? 'HEAD-ON WITH ' : 'SLAMMED INTO ') + (TRUCK_NAME[k] || 'A TRUCK');
  }
  if (MONSTER_LABEL[k]) return 'CAUGHT BY A ' + MONSTER_LABEL[k];
  return 'WIPED OUT';
}

export function createUI(ctx = {}) {
  const root = ctx.root || document.getElementById('ui');
  const LB = ctx.LB || (typeof window !== 'undefined' ? window.LB : null);
  const project = ctx.projectBent || coreProjectBent;
  const V3 = (ctx.THREE && ctx.THREE.Vector3) || THREE.Vector3;
  let camera = ctx.camera || (ctx.app && ctx.app.camera) || null;
  const hasAsset = (ctx.assets && ctx.assets.hasAsset) || (() => false);

  root.classList.add('c3ui');
  root.textContent = '';

  // ============================================================== markup
  const powIcon = k => {
    const key = 'ui/pow_' + k;
    if (hasAsset(key)) {
      const info = assetInfo(key);
      if (info) return `<img class="chip-img" alt="" src="${((typeof window !== 'undefined' && window.ASSET_BASE) || '') + info.url}">`;
    }
    return k === 'magnet' ? `<span class="chip-ico">${ICONS.magnet}</span>`
      : k === 'boost' ? `<span class="chip-ico">${ICONS.bolt}</span>` : '<span class="chip-2x">2X</span>';
  };
  const chipHTML = k => `<div class="chip c-${k}" data-k="${k}">
      <div class="chip-o"><svg class="ring" viewBox="0 0 48 48" aria-hidden="true"><circle class="ring-bg" cx="24" cy="24" r="21"/><circle class="ring-fg" cx="24" cy="24" r="21" transform="rotate(-90 24 24)"/></svg>${powIcon(k)}</div>
      <span class="chip-l">${POWERUPS[k].label}</span></div>`;
  const soundBtn = (cls, withLabel) => `<button type="button" class="${cls} snd hit" aria-pressed="true" aria-label="Sound">${ICONS.soundOn}${ICONS.soundOff}${withLabel ? '<span class="snd-l">SOUND ON</span>' : ''}</button>`;

  const scrLoad = frag(`<section class="scr scr-load" aria-label="Loading">
    <div class="load-road" aria-hidden="true"><div class="load-plane"><i></i></div></div>
    <div class="load-mid">
      ${logoHTML('big')}
      <div class="load-tag">TENNESSEE <span>→</span> CHICAGO</div>
      <div class="load-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i></i><b></b></div>
      <div class="load-row"><span class="load-label">Warming up the engine…</span><span class="load-pct">0%</span></div>
    </div>
  </section>`);

  const scrTitle = frag(`<section class="scr scr-title" aria-label="Title">
    <div class="t-scrim" aria-hidden="true"></div>
    ${soundBtn('icon-btn t-sound', false)}
    <div class="t-brand">
      ${logoHTML('big')}
      <p class="t-tag">Tennessee <span class="arr">→</span> Chicago. <span class="t-tag2">Dodge the commission killers.</span></p>
    </div>
    <div class="t-boardwrap glass">${boardHTML('TOP 5 EARNERS')}</div>
    <div class="t-spacer"></div>
    <button type="button" class="btn btn-play t-play hit">${ICONS.play}<span>PLAY</span></button>
    <div class="t-how">
      <span class="how-touch">${ICONS.swipe}<span>Swipe <b>← →</b> to switch lanes · swipe <b>↑</b> or <b>tap</b> to jump</span></span>
      <span class="how-keys">${ICONS.keys}<span><b>← →</b> / <b>A D</b> lanes · <b>↑ W Space</b> jump · <b>P</b> pause</span></span>
    </div>
  </section>`);

  const scrHud = frag(`<section class="scr scr-hud" aria-label="Game HUD">
    <div class="floats" aria-hidden="true"></div>
    <div class="hud-l glass-lite">
      <div class="lbl">COMMISSION</div>
      <div class="cash"><span class="cash-v">$0</span><span class="cash-x2">2X</span></div>
      <div class="lvrow"><span class="pill">LVL 1 · ROOKIE</span></div>
      <div class="stage"><span class="stage-n">SMOKY DAWN</span></div>
      <div class="route"><i></i></div>
    </div>
    <div class="hud-r">
      <div class="hud-r1">
        <div class="combo glass-lite" data-heat="0">
          <div class="lbl combo-l">STREAK</div>
          <div class="combo-v">x1</div>
          <div class="combo-bar"><i></i></div>
          <div class="combo-tag">ON FIRE!</div>
        </div>
        <button type="button" class="icon-btn pause-btn hit" aria-label="Pause">${ICONS.pause}</button>
      </div>
      <div class="kit glass-lite">
        <span class="shields" aria-label="Shields"><i>${ICONS.shield}</i><i>${ICONS.shield}</i><i>${ICONS.shield}</i></span>
        <span class="kit-sep"></span>
        <span class="ts" aria-label="T-sheets">${ICONS.sheet}<span class="ts-seg"><i></i><i></i><i></i><i></i><i></i></span><b class="ts-b">$100</b></span>
      </div>
      <div class="chips">${POWER_KEYS.map(chipHTML).join('')}</div>
    </div>
    <div class="band">
      <div class="toast" role="status" aria-live="polite">
        <div class="toast-badge"><b class="toast-lv">LVL 2</b><span class="toast-tier">ROOKIE</span></div>
        <div class="toast-txt"><span class="toast-k">NOW ENTERING</span><span class="toast-n">TENNESSEE SUNRISE</span></div>
      </div>
      <div class="callout" aria-hidden="true"></div>
    </div>
  </section>`);

  const scrPause = frag(`<section class="scr scr-pause" role="dialog" aria-modal="true" aria-label="Paused">
    <div class="scrim" aria-hidden="true"></div>
    <div class="panel glass p-pause hit">
      <div class="p-title">PAUSED</div>
      <div class="p-sub"><span class="p-cash">$0</span><span class="p-dot">·</span><span class="p-lv">LVL 1 · SMOKY DAWN</span></div>
      <button type="button" class="btn btn-play p-resume">${ICONS.play}<span>RESUME</span></button>
      <div class="p-row">
        ${soundBtn('btn btn-ghost p-sound', true)}
        <button type="button" class="btn btn-ghost p-quit">${ICONS.home}<span>QUIT TO TITLE</span></button>
      </div>
      <div class="kb-hint">P / Esc to resume</div>
    </div>
  </section>`);

  const scrOver = frag(`<section class="scr scr-over" role="dialog" aria-modal="true" aria-label="Run over">
    <div class="scrim" aria-hidden="true"></div>
    <div class="panel glass p-over hit">
      <div class="o-a">
        <div class="lbl o-lbl">FINAL COMMISSION</div>
        <div class="o-cash">$0</div>
        <div class="o-cause"><b class="o-killer">CAUGHT BY A CHARGE BACK</b><span class="o-where"></span></div>
        <div class="o-pace" hidden></div>
        <form class="o-post" autocomplete="off" novalidate>
          <label class="sr" for="c3ui-name">Your name for the scoreboard</label>
          <input id="c3ui-name" class="o-name" type="text" maxlength="24" placeholder="YOUR NAME" enterkeyhint="send"
                 autocapitalize="words" autocomplete="nickname" autocorrect="off" spellcheck="false">
          <button type="submit" class="btn btn-blue o-postbtn">${ICONS.send}${ICONS.check.replace('class="ico ', 'class="ico i-done ')}<span>POST SCORE</span></button>
        </form>
        <div class="o-status" role="status" aria-live="polite"></div>
      </div>
      <div class="o-b">${boardHTML('TOP 5')}</div>
      <div class="o-c">
        <button type="button" class="btn btn-play o-retry">${ICONS.retry}<span>RETRY</span></button>
        <div class="kb-hint">SPACE or R to retry · ENTER to post</div>
      </div>
    </div>
  </section>`);

  for (const s of [scrLoad, scrTitle, scrHud, scrPause, scrOver]) root.appendChild(s);

  // ============================================================== element cache
  const E = {
    loadFill: q(scrLoad, '.load-bar i'), loadBar: q(scrLoad, '.load-bar'),
    loadLabel: q(scrLoad, '.load-label'), loadPct: q(scrLoad, '.load-pct'),
    playBtn: q(scrTitle, '.t-play'),
    cash: q(scrHud, '.cash'), cashV: q(scrHud, '.cash-v'), pill: q(scrHud, '.pill'),
    stageN: q(scrHud, '.stage-n'), route: q(scrHud, '.route i'),
    combo: q(scrHud, '.combo'), comboV: q(scrHud, '.combo-v'), comboL: q(scrHud, '.combo-l'),
    comboBar: q(scrHud, '.combo-bar i'), comboTag: q(scrHud, '.combo-tag'),
    pauseBtn: q(scrHud, '.pause-btn'),
    shields: qa(scrHud, '.shields i'), tsSeg: q(scrHud, '.ts-seg'), tsI: qa(scrHud, '.ts-seg i'), tsB: q(scrHud, '.ts-b'),
    chips: {}, band: q(scrHud, '.band'),
    toast: q(scrHud, '.toast'), toastLv: q(scrHud, '.toast-lv'), toastTier: q(scrHud, '.toast-tier'),
    toastK: q(scrHud, '.toast-k'), toastN: q(scrHud, '.toast-n'), toastBadge: q(scrHud, '.toast-badge'),
    callout: q(scrHud, '.callout'),
    pCash: q(scrPause, '.p-cash'), pLv: q(scrPause, '.p-lv'), pResume: q(scrPause, '.p-resume'), pQuit: q(scrPause, '.p-quit'),
    oPanel: q(scrOver, '.p-over'), oCash: q(scrOver, '.o-cash'), oKiller: q(scrOver, '.o-killer'), oWhere: q(scrOver, '.o-where'),
    oPace: q(scrOver, '.o-pace'), oForm: q(scrOver, '.o-post'), oName: q(scrOver, '.o-name'),
    oPostBtn: q(scrOver, '.o-postbtn'), oPostLbl: q(scrOver, '.o-postbtn span'), oStatus: q(scrOver, '.o-status'),
    oRetry: q(scrOver, '.o-retry'),
    sndBtns: qa(root, '.snd'),
  };
  for (const k of POWER_KEYS) {
    const el = q(scrHud, '.c-' + k);
    E.chips[k] = { el, fg: q(el, '.ring-fg'), on: false, q: -1, warn: false };
    E.chips[k].fg.style.strokeDasharray = RING_C.toFixed(2);
  }
  const titleBoard = createBoard(q(scrTitle, '.board'), LB);
  const overBoard = createBoard(q(scrOver, '.board'), LB);
  const floats = createFloats(q(scrHud, '.floats'), project, V3, 22);

  // ============================================================== state
  const listeners = {};
  let screen = 'none';
  let paused = false;
  let muted = readMuted();
  let clock = 0;
  let W = window.innerWidth || 390, H = window.innerHeight || 844;
  let loadAuto = 0, loadP = 0;
  let lastSim = null;
  const hud = { score: -1, disp: 0, x2: null, level: -1, theme: -1, prog: -1, combo: -1, heat: -1, bar: -1,
    ts: -1, tsFull: false, shield: -1, popAt: -1, tier: '' };
  let tsFlashT = 0;
  const toastS = { t: -1 };
  const calloutS = { t: -1 };
  let coinF = null, coinAt = -9, coinSum = 0;
  const tmpV = new V3();
  // game over
  const over = { score: 0, level: 1, runSeconds: 0, posted: false, posting: false, openedAt: 0, raf: 0 };

  function emit(name, arg) {
    const fns = listeners[name]; if (!fns) return;
    for (const fn of fns.slice()) { try { fn(arg); } catch (e) { console.error('[ui] listener', name, e); } }
  }

  function setScreen(name) {
    screen = name;
    scrLoad.classList.toggle('on', name === 'loading');
    scrTitle.classList.toggle('on', name === 'title');
    scrHud.classList.toggle('on', name === 'hud');
    scrOver.classList.toggle('on', name === 'over');
    if (name !== 'hud' && paused) setPaused(false);
    root.dataset.screen = name;
  }
  function setPaused(b) {
    paused = !!b;
    scrPause.classList.toggle('on', paused);
    root.classList.toggle('is-paused', paused);
  }
  function blurUI() {
    const a = document.activeElement;
    if (a && root.contains(a) && a.blur) a.blur();
  }

  // ============================================================== sound
  function paintMute() {
    for (const b of E.sndBtns) {
      b.classList.toggle('is-muted', muted);
      b.setAttribute('aria-pressed', muted ? 'false' : 'true');
      b.setAttribute('aria-label', muted ? 'Sound off — turn on' : 'Sound on — mute');
      const l = q(b, '.snd-l'); if (l) setText(l, muted ? 'SOUND OFF' : 'SOUND ON');
    }
  }
  function toggleMute() { muted = !muted; saveMuted(muted); paintMute(); emit('mute', muted); }
  paintMute();

  // ============================================================== actions
  function play() {
    if (screen !== 'title') return;
    blurUI();
    emit('play');
    if (screen === 'title') showHUD();
  }
  function retry() {
    if (screen !== 'over') return;
    if (performance.now() - over.openedAt < 450) return;     // a held jump key / stray tap can't insta-retry
    blurUI();
    emit('retry');
    if (screen === 'over') showHUD();
  }
  function doPause() {
    if (screen !== 'hud' || paused) return;
    showPause(true); emit('pause');
  }
  function doResume() {
    if (!paused) return;
    showPause(false); emit('resume');
  }
  function quit() {
    setPaused(false);
    emit('quit');
    if (screen !== 'title') showTitle();
  }

  const click = (el, fn) => el.addEventListener('click', e => { e.preventDefault(); fn(e); if (e.detail > 0 && el.blur) el.blur(); });
  click(E.playBtn, play);
  click(E.pauseBtn, doPause);
  click(E.pResume, doResume);
  click(E.pQuit, quit);
  click(E.oRetry, retry);
  for (const b of E.sndBtns) click(b, toggleMute);
  E.oForm.addEventListener('submit', e => { e.preventDefault(); post(); });
  E.oName.addEventListener('input', () => { refreshPostState(); });
  // the name field must never feed the game or the global key handlers
  E.oName.addEventListener('keydown', e => { e.stopPropagation(); if (e.key === 'Escape') E.oName.blur(); });

  window.addEventListener('keydown', e => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    if (isEditable(e.target)) return;
    const k = e.key;
    const onBtn = isButton(e.target) && root.contains(e.target);
    if ((k === 'm' || k === 'M') && !e.repeat) { toggleMute(); return; }
    if (paused) {
      if (k === 'Escape' || k === 'p' || k === 'P' || ((k === ' ' || k === 'Enter') && !onBtn)) {
        e.preventDefault(); if (!e.repeat) doResume();
      }
      return;
    }
    if (e.repeat) return;
    if (screen === 'hud') {
      if (k === 'Escape' || k === 'p' || k === 'P') { e.preventDefault(); doPause(); }
    } else if (screen === 'title') {
      if ((k === ' ' || k === 'Enter') && !onBtn) { e.preventDefault(); play(); }
    } else if (screen === 'over') {
      if (k === 'r' || k === 'R' || (k === ' ' && !onBtn)) { e.preventDefault(); retry(); }
      else if (k === 'Enter' && !onBtn) { e.preventDefault(); if (canPost()) post(); else retry(); }
    }
  });
  window.addEventListener('resize', () => { W = window.innerWidth || W; H = window.innerHeight || H; });
  // a phone call / app switch mid-run must never come back to a running game (idempotent with main's own handler)
  document.addEventListener('visibilitychange', () => { if (document.hidden && screen === 'hud' && !paused) doPause(); });

  // ============================================================== LOADING
  function setLoading(p, label) {
    if (screen === 'none') setScreen('loading');
    loadP = clamp01(+p || 0);
    E.loadFill.style.transform = `translateX(${((loadP - 1) * 100).toFixed(1)}%)`;
    setText(E.loadPct, Math.round(loadP * 100) + '%');
    E.loadBar.setAttribute('aria-valuenow', String(Math.round(loadP * 100)));
    if (label) setText(E.loadLabel, label);
    if (loadP >= 1 && screen === 'loading' && !loadAuto) {
      // never make anyone tap to get past loading
      loadAuto = setTimeout(() => { loadAuto = 0; if (screen === 'loading') showTitle(); }, 420);
    }
  }
  // a slow store Wi-Fi should read as "working", never "hung"
  setTimeout(() => { if (screen === 'loading' && loadP < 1) setText(E.loadLabel, 'Slow connection — still loading…'); }, 9000);

  // ============================================================== TITLE
  function identityName() { try { return (LB && LB.identity && LB.identity().name) || ''; } catch (e) { return ''; } }
  function showTitle() {
    if (loadAuto) { clearTimeout(loadAuto); loadAuto = 0; }
    setPaused(false);
    setScreen('title');
    floats.clear();
    titleBoard.refresh({ soft: identityName() });
  }

  // ============================================================== HUD
  function resetHudCache() {
    hud.score = -1; hud.x2 = null; hud.level = -1; hud.theme = -1; hud.prog = -1; hud.combo = -1; hud.heat = -1;
    hud.bar = -1; hud.ts = -1; hud.tsFull = false; hud.shield = -1; hud.tier = '';
    for (const k of POWER_KEYS) { const c = E.chips[k]; c.on = false; c.q = -1; c.warn = false; c.el.classList.remove('on', 'warn'); }
    toastS.t = -1; E.toast.style.opacity = '0';
    calloutS.t = -1; E.callout.style.opacity = '0';
    tsFlashT = 0; coinF = null;
    floats.clear();
  }
  function showHUD() {
    if (loadAuto) { clearTimeout(loadAuto); loadAuto = 0; }
    cancelAnimationFrame(over.raf);
    const wasHud = screen === 'hud';
    setScreen('hud');
    setPaused(false);
    blurUI();
    if (!wasHud) { resetHudCache(); hud.disp = 0; }
  }

  function popMoney(big) {
    if (clock - hud.popAt < 0.11) return;
    hud.popAt = clock;
    const s = big ? 1.22 : 1.12;
    anim(E.cashV, [{ transform: 'scale(1)' }, { transform: `scale(${s})`, offset: 0.3 }, { transform: 'scale(1)' }],
      { duration: big ? 360 : 220, easing: 'cubic-bezier(.2,.8,.3,1)' });
  }

  function updateHUD(sim, frame) {
    const dt = frame ? (frame.realDt != null ? frame.realDt : (frame.dt != null ? frame.dt : 1 / 60)) : 1 / 60;
    if (frame) {
      if (frame.camera) camera = frame.camera;
      if (frame.width) { W = frame.width; H = frame.height; }
    }
    if (sim) lastSim = sim;
    if (screen !== 'hud' || !sim || paused) return;
    clock += dt;

    // ---- commission: rolling count-up (text written only when the dollar value changes)
    const target = Math.floor(sim.score || 0);
    if (target < hud.disp) hud.disp = target;
    else {
      hud.disp += (target - hud.disp) * Math.min(1, dt * 11);
      if (target - hud.disp < 0.6) hud.disp = target;
    }
    const si = Math.floor(hud.disp);
    if (si !== hud.score) { hud.score = si; setText(E.cashV, fmtMoney(si)); }
    const x2 = !!(sim.power && sim.power.x2 > 0);
    if (x2 !== hud.x2) { hud.x2 = x2; E.cash.classList.toggle('x2', x2); }

    // ---- level pill + stage name + route progress
    const lv = sim.level || 1;
    if (lv !== hud.level) { hud.level = lv; hud.tier = tierOf(lv); setText(E.pill, `LVL ${lv} · ${hud.tier}`); }
    const ti = sim.themeIdx | 0;
    if (ti !== hud.theme) {
      const first = hud.theme < 0;
      hud.theme = ti;
      setText(E.stageN, (sim.theme && sim.theme.name) || (THEMES[ti] && THEMES[ti].name) || '');
      if (!first) anim(E.stageN, [{ opacity: 0, transform: 'translateY(6px)' }, { opacity: 1, transform: 'none' }], { duration: 380, easing: 'ease-out' });
    }
    const pq = Math.round(clamp01(sim.levelProgress || 0) * 240);
    if (pq !== hud.prog) { hud.prog = pq; E.route.style.transform = `scaleX(${(pq / 240).toFixed(4)})`; }

    // ---- combo
    const c = Math.max(1, sim.combo | 0);
    if (c !== hud.combo) {
      hud.combo = c;
      setText(E.comboV, 'x' + c);
      const heat = c >= 9 ? 3 : c >= 6 ? 2 : c >= 3 ? 1 : 0;
      if (heat !== hud.heat) {
        hud.heat = heat; E.combo.dataset.heat = String(heat);
        setText(E.comboL, heat >= 2 ? 'ON FIRE' : 'STREAK');
      }
    }
    const win = sim.comboWindow || COMBO_WINDOW;
    const bq = c > 1 ? Math.round(clamp01((sim.comboTimer || 0) / win) * 120) : 0;
    if (bq !== hud.bar) { hud.bar = bq; E.comboBar.style.transform = `scaleX(${(bq / 120).toFixed(3)})`; }

    // ---- T-sheets (n/5 -> $100) + shields
    if (tsFlashT > 0) tsFlashT -= dt;
    const full = tsFlashT > 0;
    const n = full ? 5 : ((sim.tsheets | 0) % 5);
    if (n !== hud.ts || full !== hud.tsFull) {
      hud.ts = n; hud.tsFull = full;
      for (let i = 0; i < 5; i++) E.tsI[i].classList.toggle('on', i < n);
      E.tsSeg.classList.toggle('full', full);
    }
    const sh = Math.max(0, Math.min(3, sim.shield | 0));
    if (sh !== hud.shield) {
      const prev = hud.shield; hud.shield = sh;
      for (let i = 0; i < 3; i++) E.shields[i].classList.toggle('on', i < sh);
      if (prev >= 0 && sh > prev) anim(E.shields[sh - 1], [{ transform: 'scale(1.9)' }, { transform: 'scale(1)' }], { duration: 380, easing: 'cubic-bezier(.2,1.4,.4,1)' });
    }

    // ---- power-up chips with countdown rings
    const pw = sim.power || {}, pm = sim.powerMax || {};
    for (const k of POWER_KEYS) {
      const chip = E.chips[k], v = pw[k] || 0, on = v > 0;
      if (on !== chip.on) {
        chip.on = on; chip.el.classList.toggle('on', on);
        if (on) anim(chip.el, [{ transform: 'scale(.3)', opacity: 0 }, { transform: 'scale(1.18)', opacity: 1, offset: 0.6 }, { transform: 'scale(1)' }], { duration: 380, easing: 'ease-out' });
        else { chip.warn = false; chip.el.classList.remove('warn'); }
      }
      if (on) {
        const frac = clamp01(v / (pm[k] || (POWERUPS[k] && POWERUPS[k].dur) || 10));
        const qv = Math.round(frac * 300);
        if (qv !== chip.q) { chip.q = qv; chip.fg.style.strokeDashoffset = (RING_C * (1 - qv / 300)).toFixed(2); }
        const warn = v <= 2;
        if (warn !== chip.warn) { chip.warn = warn; chip.el.classList.toggle('warn', warn); }
      }
    }

    // ---- toast + callout (JS-timed on the HUD clock so pause freezes them)
    if (toastS.t >= 0) {
      toastS.t += dt;
      const t = toastS.t;
      if (t >= TOAST_LIFE) { toastS.t = -1; E.toast.style.opacity = '0'; E.band.classList.remove('has-toast'); }
      else {
        let y = 0, s = 1, a = 1;
        if (t < 0.3) { const u = easeOutBack(t / 0.3); y = -14 * (1 - u); s = 0.9 + 0.1 * u; a = Math.min(1, t / 0.14); }
        else if (t > TOAST_LIFE - 0.3) { const u = (t - (TOAST_LIFE - 0.3)) / 0.3; y = -10 * u; a = 1 - u; }
        if (REDUCED) { y = 0; s = 1; }
        E.toast.style.transform = `translate3d(0,${y.toFixed(1)}px,0) scale(${s.toFixed(3)})`;
        E.toast.style.opacity = a.toFixed(3);
      }
    }
    if (calloutS.t >= 0) {
      calloutS.t += dt;
      const t = calloutS.t;
      if (t >= CALLOUT_LIFE) { calloutS.t = -1; E.callout.style.opacity = '0'; }
      else {
        let s = 1, a = 1, y = 0;
        if (t < 0.24) { const u = t / 0.24; s = 0.5 + 0.62 * u; a = Math.min(1, u * 2); }
        else if (t < 0.36) s = 1.12 - 0.12 * ((t - 0.24) / 0.12);
        else if (t > CALLOUT_LIFE - 0.3) { const u = (t - (CALLOUT_LIFE - 0.3)) / 0.3; a = 1 - u; y = -12 * u; }
        if (REDUCED) { s = 1; y = 0; }
        if (toastS.t < 0) y -= 52;              // no toast showing: use its slot, closer to the HUD
        E.callout.style.transform = `translate3d(0,${y.toFixed(1)}px,0) scale(${s.toFixed(3)})`;
        E.callout.style.opacity = a.toFixed(3);
      }
    }

    floats.update(dt, camera, W, H);
  }

  function showToast(ev) {
    const lv = ev.level || (lastSim && lastSim.level) || 1;
    const tier = ev.tier || tierOf(lv);
    const promo = !!hud.tier && tier !== tierOf(Math.max(1, lv - 1));
    setText(E.toastLv, 'LVL ' + lv);
    setText(E.toastTier, tier);
    setText(E.toastK, ev.lap > 1 ? `NOW ENTERING · LAP ${ev.lap}` : 'NOW ENTERING');
    setText(E.toastN, ev.name || (THEMES[ev.themeIdx] && THEMES[ev.themeIdx].name) || '');
    E.toastBadge.classList.toggle('promo', promo);
    // fit long stage names ("CUMBERLAND PLATEAU") on narrow phones: one layout read per level-up
    E.toastN.style.fontSize = '';
    for (let i = 0, fs = 1.1; i < 4 && E.toastN.scrollWidth > E.toastN.clientWidth + 1; i++) {
      fs -= 0.07; E.toastN.style.fontSize = fs.toFixed(2) + 'em';
    }
    E.band.classList.add('has-toast');
    toastS.t = 0;
  }
  function callout(text, kind) {
    setText(E.callout, text);
    E.callout.className = 'callout' + (kind ? ' k-' + kind : '');
    calloutS.t = 0;
  }

  // ============================================================== floats
  function floatAt(text, worldPos, style) {
    if (screen !== 'hud' || !worldPos) return null;
    let main = String(text), sub = '';
    const m = /^(.*\S)\s+(x\d+)$/.exec(main);
    if (m) { main = m[1]; sub = m[2]; }
    return floats.spawn(main, sub, worldPos, style || 'cash');
  }
  function fl(text, x, y, s, sim, style) {
    tmpV.set(x || 0, y || 0, sim && s != null ? zOf(s, sim.dist) : 0);
    // never let a float anchor sit behind the fox's camera or miles ahead
    if (tmpV.z > 1) tmpV.z = 1; else if (tmpV.z < -18) tmpV.z = -18;
    return floatAt(text, tmpV, style);
  }
  function coinFloat(ev, sim) {
    const x2 = !!(sim && sim.power && sim.power.x2 > 0);
    const style = x2 ? 'cash2x' : 'cash';
    const v = Math.floor(ev.value || 0);
    const sub = ev.combo > 1 ? 'x' + ev.combo : '';
    if (coinF && coinF.active && coinF.style === style && clock - coinAt < 0.2) {
      coinSum += v;
      floats.repop(coinF, '+' + fmtMoney(coinSum), sub);
      coinF.pos.set(ev.x || 0, (ev.y || 0.9) + 0.7, sim ? Math.min(1, Math.max(-18, zOf(ev.s, sim.dist))) : 0);
    } else {
      if (coinF && coinF.active) coinF.age = Math.max(coinF.age, coinF.life - 0.12);   // clear the stage for the new one
      coinSum = v;
      coinF = fl(`+${fmtMoney(v)}${sub ? ' ' + sub : ''}`, ev.x, (ev.y || 0.9) + 0.7, ev.s, sim, style);
    }
    coinAt = clock;
  }

  // ============================================================== events
  function comboFlare(cmb) {
    const big = cmb >= 9;
    anim(E.combo, [{ transform: 'scale(1)' }, { transform: `scale(${big ? 1.34 : 1.24})`, offset: 0.35 }, { transform: 'scale(1)' }],
      { duration: 420, easing: 'cubic-bezier(.2,1.3,.4,1)' });
    setText(E.comboTag, cmb >= 9 ? 'MAXED OUT!' : cmb >= 6 ? 'ON FIRE!' : 'HEATING UP!');
    E.comboTag.dataset.heat = cmb >= 9 ? '3' : cmb >= 6 ? '2' : '1';
    const a = anim(E.comboTag, [
      { opacity: 0, transform: 'translateY(-6px) scale(.6)' },
      { opacity: 1, transform: 'translateY(0) scale(1.1)', offset: 0.18 },
      { opacity: 1, transform: 'translateY(0) scale(1)', offset: 0.3 },
      { opacity: 1, transform: 'translateY(0) scale(1)', offset: 0.8 },
      { opacity: 0, transform: 'translateY(-4px) scale(1)' }], { duration: 1200, easing: 'ease-out' });
    if (!a) { E.comboTag.style.opacity = '1'; setTimeout(() => { E.comboTag.style.opacity = '0'; }, 1000); }
  }

  function onEvent(ev, sim) {
    if (!ev) return;
    if (sim) lastSim = sim;
    const p = sim && sim.player;
    switch (ev.type) {
      case 'start': if (screen === 'hud') { resetHudCache(); hud.disp = 0; } break;
      case 'coin': coinFloat(ev, sim); popMoney(false); break;
      case 'nearMiss': fl(`NEAR MISS +${fmtMoney(ev.bonus || 0)}`, ev.x != null ? ev.x : (p ? p.x : 0), 2.2, ev.s, sim, 'near'); popMoney(false); break;
      case 'hop': fl('HOP!', ev.x != null ? ev.x : (p ? p.x : 0), (p ? p.y : 0) + 2.1, ev.s, sim, 'hop'); break;
      case 'smash': fl('SMASH!', ev.x, (ev.y || 1) + 1.1, ev.s, sim, 'smash'); break;
      case 'bonus':
        fl(`+${fmtMoney(ev.amount || 100)} BONUS`, ev.x != null ? ev.x : (p ? p.x : 0), (ev.y || 1) + 1.2, ev.s, sim, 'bonus');
        callout(`T-SHEET BONUS +${fmtMoney(ev.amount || 100)}`, 'gold');
        tsFlashT = 0.8; popMoney(true);
        anim(E.tsSeg, [{ transform: 'scale(1.35)' }, { transform: 'scale(1)' }], { duration: 420, easing: 'cubic-bezier(.2,1.4,.4,1)' });
        break;
      case 'tsheet': {
        const n = (ev.count | 0) % 5 || 5;
        fl('T-SHEET', ev.x, (ev.y || 1) + 0.8, ev.s, sim, 'tsheet');
        const seg = E.tsI[n - 1];
        if (seg) anim(seg, [{ transform: 'skewX(-12deg) scale(2)' }, { transform: 'skewX(-12deg) scale(1)' }], { duration: 360, easing: 'cubic-bezier(.2,1.4,.4,1)' });
        break;
      }
      case 'powerup': {
        const k = ev.kind;
        fl(POWER_FLOAT[k] || 'POWER!', ev.x != null ? ev.x : (p ? p.x : 0), (ev.y || 1) + 0.6, ev.s, sim, 'p' + k);
        haptic(12);
        break;
      }
      case 'powerWarn': { const c = E.chips[ev.kind]; if (c && c.on) { c.warn = true; c.el.classList.add('warn'); } break; }
      case 'powerEnd': { const c = E.chips[ev.kind]; if (c) { c.warn = false; c.el.classList.remove('warn'); } break; }
      case 'combo': comboFlare(ev.combo | 0); if ((ev.combo | 0) >= 6) haptic([8, 30, 8]); break;
      case 'comboLost':
        if (hud.combo >= 3) anim(E.combo, [{ transform: 'translateX(0)' }, { transform: 'translateX(-5px)' }, { transform: 'translateX(4px)' }, { transform: 'translateX(-2px)' }, { transform: 'translateX(0)' }], { duration: 300 });
        break;
      case 'shieldBreak': {
        const i = Math.max(0, Math.min(2, (sim ? sim.shield | 0 : 0)));
        anim(E.shields[i], [{ transform: 'scale(2.2)', opacity: 1 }, { transform: 'scale(1)', opacity: 0.35 }], { duration: 500, easing: 'ease-out' });
        fl('SHIELD!', ev.x, (ev.y || 1) + 1.2, ev.s, sim, 'shield');
        callout('SHIELD SAVED YOU!', 'shield');
        haptic([14, 40, 14]);
        break;
      }
      case 'bump': fl('BUMP!', ev.x != null ? ev.x : (p ? p.x : 0), 2.0, ev.s, sim, 'bump'); haptic(16); break;
      case 'levelUp': showToast(ev); break;
      case 'hit': haptic([40, 60, 120]); break;
      default: break;
    }
  }

  // ============================================================== PAUSE
  function showPause(b) {
    b = !!b;
    if (b && screen !== 'hud') return;
    if (b) {
      setText(E.pCash, fmtMoney(Math.max(0, hud.score)));
      const s = lastSim;
      setText(E.pLv, s ? `LVL ${s.level || 1} · ${(s.theme && s.theme.name) || ''}` : '');
    }
    setPaused(b);
    if (!b) blurUI();
  }

  // ============================================================== GAME OVER
  function canPost() {
    return !over.posted && !over.posting && over.score >= 1 && !!trimName(E.oName.value);
  }
  function refreshPostState() {
    E.oPostBtn.disabled = !canPost();
  }
  function setStatus(text, kind) {
    setText(E.oStatus, text || '');
    E.oStatus.className = 'o-status' + (kind ? ' ' + kind : '');
  }
  function paintPace(list) {
    if (over.posted) { E.oPace.hidden = true; return; }
    const r = prospectiveRank(list, over.score, trimName(E.oName.value) || identityName());
    if (r > 0) {
      setText(E.oPace, r === 1 ? 'NEW #1 PACE — POST IT!' : `TOP 5 RUN · #${r} — POST IT!`);
      E.oPace.hidden = false;
    } else E.oPace.hidden = true;
  }

  function post() {
    if (!canPost()) {
      if (!trimName(E.oName.value) && over.score >= 1 && !over.posted) {
        E.oName.focus();
        anim(E.oName, [{ transform: 'translateX(0)' }, { transform: 'translateX(-6px)' }, { transform: 'translateX(5px)' }, { transform: 'translateX(0)' }], { duration: 260 });
        setStatus('Type your name to post', 'warn');
      }
      return;
    }
    const name = trimName(E.oName.value);
    over.posting = true;
    E.oPostBtn.disabled = true; E.oName.disabled = true;
    setText(E.oPostLbl, 'POSTING…');
    setStatus('', '');
    try { if (LB && LB.setIdentity) LB.setIdentity(name); } catch (e) {}
    let pr;
    try {
      pr = LB && LB.submit
        ? Promise.resolve(LB.submit({ name, score: Math.floor(over.score), level: over.level, runSeconds: Math.round(over.runSeconds) }))
        : Promise.resolve({ ok: true, remote: false, name, best: over.score, rank: 0 });
    } catch (e) { pr = Promise.resolve({ ok: false, error: 'Could not save — try again.' }); }
    const myOpen = over.openedAt;
    pr.then(res => {
      if (myOpen !== over.openedAt) return;      // a new game over replaced this one
      over.posting = false;
      if (res && res.ok) {
        over.posted = true;
        const shown = res.name || name;
        E.oForm.classList.add('done');
        setText(E.oPostLbl, res.remote ? 'POSTED' : 'SAVED');
        E.oPace.hidden = true;
        if (res.remote) {
          setStatus(res.rank > 0 ? `Posted as ${shown.toUpperCase()} — you're #${res.rank} on the board` : `Posted as ${shown.toUpperCase()}`, 'ok');
        } else {
          setStatus('Saved — will post when online', 'warn');
        }
        overBoard.refresh({ highlight: shown, youRank: res.rank | 0, youScore: Math.max(over.score, res.best | 0) });
      } else {
        E.oName.disabled = false;
        setText(E.oPostLbl, 'POST SCORE');
        setStatus((res && res.error) || 'Could not post — try again.', 'err');
        refreshPostState();
      }
    }, () => {
      over.posting = false; E.oName.disabled = false; setText(E.oPostLbl, 'POST SCORE');
      setStatus('Could not post — try again.', 'err'); refreshPostState();
    });
  }

  function countUp(el, to) {
    cancelAnimationFrame(over.raf);
    if (REDUCED || to <= 0) { setText(el, fmtMoney(to)); return; }
    const t0 = performance.now(), dur = 900;
    let last = -1;
    const step = now => {
      const u = clamp01((now - t0) / dur), e = 1 - Math.pow(1 - u, 3);
      const v = Math.floor(to * e);
      if (v !== last) { last = v; setText(el, fmtMoney(v)); }
      if (u < 1) over.raf = requestAnimationFrame(step);
      else anim(el, [{ transform: 'scale(1)' }, { transform: 'scale(1.1)', offset: 0.4 }, { transform: 'scale(1)' }], { duration: 320, easing: 'ease-out' });
    };
    over.raf = requestAnimationFrame(step);
    setText(el, fmtMoney(0));
  }

  function showGameOver(summary = {}) {
    const sm = summary || {};
    over.score = Math.max(0, Math.floor(sm.score || 0));
    over.level = Math.max(1, sm.level | 0 || 1);
    over.runSeconds = Math.max(0, +sm.runSeconds || 0);
    over.posted = false; over.posting = false;
    over.openedAt = performance.now();
    const where = [`LEVEL ${over.level}`];
    const tn = sm.themeName || (lastSim && lastSim.theme && lastSim.theme.name) || '';
    if (tn) where.push(tn);
    setText(E.oKiller, causeLine(sm.killer));
    setText(E.oWhere, where.join(' · '));
    E.oForm.classList.remove('done');
    E.oForm.hidden = over.score < 1;
    E.oName.disabled = false;
    E.oName.value = identityName();
    setText(E.oPostLbl, 'POST SCORE');
    setStatus(over.score < 1 ? 'No commission this run — go again!' : '', '');
    refreshPostState();
    E.oPace.hidden = true;
    setPaused(false);
    blurUI();
    setScreen('over');
    E.oPanel.classList.add('guard');
    setTimeout(() => E.oPanel.classList.remove('guard'), 450);
    try { scrOver.scrollTop = 0; } catch (e) {}
    countUp(E.oCash, over.score);
    const opened = over.openedAt;
    overBoard.refresh({ soft: identityName() }).then(list => { if (opened === over.openedAt) paintPace(list); });
  }

  function hideAll() {
    if (loadAuto) { clearTimeout(loadAuto); loadAuto = 0; }
    cancelAnimationFrame(over.raf);
    setPaused(false);
    setScreen('none');
    floats.clear();
  }

  // start on the loading screen: something alive is on screen from the first frame
  setScreen('loading');
  setLoading(0);

  return {
    setLoading, showTitle, showHUD, updateHUD, onEvent, floatAt, showPause, showGameOver, hideAll,
    on(name, fn) {
      (listeners[name] || (listeners[name] = [])).push(fn);
      return () => { const a = listeners[name]; const i = a ? a.indexOf(fn) : -1; if (i >= 0) a.splice(i, 1); };
    },
    // ---- extras (not in the contract, safe to ignore)
    get screen() { return screen; },
    get paused() { return paused; },
    get muted() { return muted; },
    /** Reflect an external mute state (no 'mute' emit). */
    setMuted(b) { muted = !!b; saveMuted(muted); paintMute(); },
    callout,
    toast: showToast,
    setCamera(c) { camera = c; },
    refreshBoard() { return (screen === 'over' ? overBoard : titleBoard).refresh({ soft: identityName() }); },
    root,
  };
}
