// C³ FOX RUN 3D — main wiring (orchestrator). See CONTRACT.md §5 for the module APIs.
//
// Flow: boot → LOADING (critical sprites) → TITLE (attract bot plays behind it) → PLAY →
//       hit → dying (slow-mo death cam) → death → GAME OVER (name + post, top 5, retry).
//
// Dev query flags (never needed by players):
//   ?tier=low|med|high   force a quality tier        ?autoplay=1  the sim bot plays the run
//   ?level=N             start the run at level N    ?god=1       can't die
//   ?lb=off              leaderboard offline (tests) ?debug=1     on-screen frame/asset stats
import * as THREE from 'three';
import { createApp } from './core/app.js';
import { BEND, applyBend, projectBent } from './core/bend.js';
import * as C from './core/constants.js';
import { THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL, tierOf } from './data/themes.js';
import { getTexture, getImage, preload, hasAsset, assetKeys, SPRITE_META, loadStats } from './core/assets.js';
import { createSim } from './sim/sim.js';
import { createWorld } from './render/world.js';
import { createActors } from './render/actors.js';
import { createFX } from './render/fx.js';
import { createCameraDirector } from './render/camera.js';
import { createFeel } from './render/feel.js';
import { createPost } from './render/post.js';
import { createQuality } from './render/quality.js';
import { createUI } from './ui/ui.js';
import { createInput } from './ui/input.js';
import { createAudio } from './audio/audio.js';
import { LB, LB_URL } from './vendor/lb-esm.js';

const Q = new URLSearchParams(location.search);
const DEV = { autoplay: Q.has('autoplay'), god: Q.has('god'), level: +(Q.get('level') || 0), debug: Q.has('debug') };

LB.configure({ url: Q.get('lb') === 'off' ? '' : LB_URL });

const newSeed = () => ((Math.random() * 0x7fffffff) | 0) + 1;

// ------------------------------------------------------------------ core
const app = createApp();
const { scene, camera, renderer } = app;
const quality = createQuality({ renderer, app });
app.setDprCap(quality.dprCap);

const ctx = {
  app, scene, camera, renderer,
  BEND, applyBend, projectBent, C,
  THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL,
  assets: { getTexture, getImage, preload, hasAsset, SPRITE_META },
  tier: quality.tier,
};

// ------------------------------------------------------------------ modules
const sim = createSim({ seed: newSeed(), attract: true });
const world = createWorld(ctx);
const actors = createActors(ctx);
const fx = createFX(ctx);
const cam = createCameraDirector(ctx);
const feel = createFeel();
const post = createPost(ctx);
const ui = createUI({ ...ctx, root: document.getElementById('ui'), LB, camera });
const input = createInput(app.canvas);
const audio = createAudio();
input.enabled = false;
try { audio.setMuted(!!ui.muted); } catch (e) {}

const frame = { time: 0, dt: 0, realDt: 0, camera, width: app.width, height: app.height, tier: quality.tier };
app.onResize((w, h, dpr) => { post.setSize(w, h, dpr); frame.width = w; frame.height = h; });
app.setRender(() => post.render(frame));

quality.onChange((tier, dpr) => {
  ctx.tier = frame.tier = tier;
  for (const m of [world, actors, fx, post]) { try { m.setQuality(tier); } catch (e) { console.warn('[main] setQuality', e); } }
  try { audio.setQuality && audio.setQuality(tier); } catch (e) {}
  app.setDprCap(dpr);
});

// audio must be unlocked by a real gesture (iOS)
let unlocked = false;
const unlock = () => { if (unlocked) return; unlocked = true; try { audio.unlock(); } catch (e) {} };
for (const t of ['pointerdown', 'touchend', 'keydown']) window.addEventListener(t, unlock, { capture: true, passive: true });
input.onAny(() => unlock());
// UI buttons click
document.getElementById('ui').addEventListener('click', e => {
  if (e.target && e.target.closest && e.target.closest('button')) { try { audio.click(); } catch (err) {} }
});

// ------------------------------------------------------------------ game flow
let phase = 'loading';            // loading | title | play | over
let paused = false;

function beginRun() {
  paused = false;
  sim.setAttract(false);
  sim.devGod = DEV.god;
  sim.autopilot = DEV.autoplay;
  sim.start();
  if (DEV.level > 1) sim.devSetLevel(DEV.level);
  phase = 'play';
  input.poll();                     // drop anything queued on the menu
  input.enabled = true;
  try { audio.setPaused(false); audio.toRun(); } catch (e) {}
  ui.showHUD();
}

function toTitle() {
  paused = false;
  phase = 'title';
  input.enabled = false;
  sim.reset(newSeed());
  sim.setAttract(true);
  try { audio.setPaused(false); audio.toTitle(); } catch (e) {}
  ui.showTitle();
}

function gameOver() {
  if (phase !== 'play') return;
  phase = 'over';
  input.enabled = false;
  try { audio.toGameOver(); } catch (e) {}
  ui.showGameOver({
    score: sim.score, level: sim.level, themeName: sim.theme.name, tier: tierOf(sim.level),
    killer: sim.killer, bestCombo: sim.bestCombo, orbs: sim.stats.orbs,
    distance: sim.dist, runSeconds: sim.runTime,
  });
}

ui.on('play', beginRun);
ui.on('retry', beginRun);
ui.on('quit', toTitle);
ui.on('pause', () => { if (phase !== 'play') return; paused = true; input.enabled = false; try { audio.setPaused(true); } catch (e) {} });
ui.on('resume', () => { paused = false; if (phase === 'play') input.enabled = true; input.poll(); try { audio.setPaused(false); } catch (e) {} });
ui.on('mute', m => { try { audio.setMuted(!!m); } catch (e) {} });

// ------------------------------------------------------------------ frame loop
const NO_ACTIONS = [];
const listeners = [world, actors, fx, cam, feel, audio, ui];
app.addTick((realDt) => {
  const simDt = paused ? 0 : feel.timeScale(realDt);
  const actions = input.poll();
  if (!paused) sim.step(simDt, phase === 'play' ? actions : NO_ACTIONS);

  const evs = sim.events;
  for (let i = 0; i < evs.length; i++) {
    const ev = evs[i];
    for (let j = 0; j < listeners.length; j++) {
      try { listeners[j].onEvent(ev, sim); } catch (e) { reportOnce(e, listeners[j] === ui ? 'ui' : 'module'); }
    }
  }
  let died = false;
  for (let i = 0; i < evs.length; i++) if (evs[i].type === 'death') died = true;

  frame.time += simDt; frame.dt = simDt; frame.realDt = realDt;
  frame.width = app.width; frame.height = app.height;
  world.update(sim, frame);
  actors.update(sim, frame);
  fx.update(sim, frame);
  cam.update(sim, frame);
  ui.updateHUD(sim, frame);
  audio.update(sim, frame);
  evs.length = 0;

  if (died || (phase === 'play' && sim.mode === 'over')) gameOver();
  if (debugEl) debugTick(realDt);
});
// quality watchdog samples real frame times (after render)
app.addTick(() => { if (app.lastFrameMs) quality.sample(app.lastFrameMs); });

const reported = new Set();
function reportOnce(e, where) {
  const k = where + ':' + (e && e.message);
  if (reported.has(k)) return;
  reported.add(k);
  console.error('[main] ' + where + ' error:', e);
}

// a hidden tab never comes back to a running game
document.addEventListener('visibilitychange', () => {
  try { audio.setPaused(document.hidden || paused); } catch (e) {}
});

// ------------------------------------------------------------------ loading
const CRITICAL = [
  'sprites/player_run', 'sprites/player_hit', 'sprites/fox_jump_back', 'sprites/fox_boost_back',
  ...MONSTERS.map(m => 'sprites/mon_' + m),
  'sprites/orb_xm', 'sprites/orb_tab', 'sprites/orb_watch', 'sprites/orb_tsheet', 'sprites/barrier_low',
  'ui/pow_magnet', 'ui/pow_x2', 'ui/pow_boost',
  THEMES[0].sky,
].filter(hasAsset);
const LATER = [
  ...assetKeys('sprites/scen_'), 'sprites/bg_smokies', 'sprites/bg_chicago',
  ...THEMES.slice(1).map(t => t.sky),
].filter(k => hasAsset(k) && !CRITICAL.includes(k));

async function boot() {
  ui.setLoading(0.02, 'Warming up the engine…');
  app.start();                       // the scene is alive behind the loading screen
  await preload(CRITICAL, (done, total) => ui.setLoading(0.05 + 0.85 * done / total, 'Loading the road trip…'));
  preload(LATER);                    // scenery + later skies stream in the background
  try { await Promise.race([actors.ready || Promise.resolve(), new Promise(r => setTimeout(r, 4000))]); } catch (e) {}
  phase = 'title';
  try { audio.toTitle(); } catch (e) {}
  ui.setLoading(1, 'Ready');         // UI advances to the title by itself
}
boot();

// ------------------------------------------------------------------ dev / test hooks
window.__game = {
  app, sim, ui, world, actors, fx, cam, feel, post, quality, audio, input, LB,
  get phase() { return phase; }, get paused() { return paused; },
  play: beginRun, toTitle, loadStats,
};

let debugEl = null, dbgAcc = 0, dbgN = 0, dbgT = 0;
if (DEV.debug) {
  debugEl = document.createElement('div');
  debugEl.style.cssText = 'position:fixed;left:6px;bottom:6px;z-index:99;font:11px/1.3 monospace;color:#9f9;background:rgba(0,0,0,.6);padding:4px 6px;pointer-events:none;white-space:pre';
  document.body.appendChild(debugEl);
}
function debugTick(dt) {
  dbgAcc += dt; dbgN++; dbgT += dt;
  if (dbgT < 0.5) return;
  const info = renderer.info.render;
  const st = loadStats(); const ok = Object.values(st).filter(s => s === 'ok').length;
  debugEl.textContent = `${(dbgN / dbgAcc).toFixed(0)} fps  ${quality.tier} dpr ${app.dpr}\n` +
    `calls ${info.calls}  tris ${(info.triangles / 1000).toFixed(0)}k\nassets ${ok}/${Object.keys(st).length}  L${sim.level} ${sim.speed.toFixed(1)} m/s`;
  dbgAcc = 0; dbgN = 0; dbgT = 0;
}

// A phone can drop the WebGL context (backgrounded app, GPU reset). three.js stops drawing;
// the cleanest recovery for a game is a fresh page once the context is back.
app.canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); paused = true; }, false);
app.canvas.addEventListener('webglcontextrestored', () => { location.reload(); }, false);
