// ASSET LOADER — images live as separate files in assets/ next to index.html.
//
// Lessons from the 2D build (do not regress these):
//  * NEVER one shared wall-clock timeout for a batch. Each request has a STALL
//    timeout that resets whenever bytes arrive, so a slow store Wi-Fi still finishes.
//  * A small pool (4) in PRIORITY order, one retry per file, then an <img> fallback.
//  * Never fail silently: a console receipt reports exactly what loaded.
//  * A missing texture never breaks the game — getTexture() always returns a
//    Texture immediately; its image fills in when it arrives.
//
// Keys are paths under assets/ without extension, e.g. 'sprites/player_run', 'sky/02_tennessee_sunrise'.
import * as THREE from 'three';
import MANIFEST from 'virtual:asset-manifest';

export const SPRITE_META = MANIFEST.sprites || {};   // frames, ax, ay, unitsHigh, aspect... keyed by sprite name (no 'sprites/')
const BY_KEY = new Map((MANIFEST.assets || []).map(a => [a.key, a]));
const BASE = (typeof window !== 'undefined' && window.ASSET_BASE) || '';

const STALL_MS = 9000;
const POOL = 4;
const entries = new Map();     // key -> { state, img, tex[], waiters[] }
const queue = [];
let active = 0;
let anisotropy = 4;

export function setMaxAnisotropy(n) { anisotropy = Math.max(1, Math.min(8, n | 0)); }
export function hasAsset(key) { return BY_KEY.has(key); }
export function assetKeys(prefix = '') { return [...BY_KEY.keys()].filter(k => k.startsWith(prefix)); }
export function assetInfo(key) { return BY_KEY.get(key) || null; }

function entry(key) {
  let e = entries.get(key);
  if (!e) { e = { key, state: 'idle', img: null, texs: [], waiters: [], tries: 0 }; entries.set(key, e); }
  return e;
}

function pump() {
  while (active < POOL && queue.length) {
    const e = queue.shift();
    if (e.state !== 'queued') continue;
    active++;
    e.state = 'loading';
    fetchImage(e).then(img => finish(e, img), () => finish(e, null));
  }
}

async function fetchWithStall(url) {
  const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  let timer = null;
  const arm = () => { clearTimeout(timer); timer = setTimeout(() => ctl && ctl.abort(), STALL_MS); };
  arm();
  try {
    const res = await fetch(url, ctl ? { signal: ctl.signal } : undefined);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    if (!res.body || !res.body.getReader) { const b = await res.blob(); clearTimeout(timer); return b; }
    const reader = res.body.getReader();
    const parts = [];
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      parts.push(value); arm();
    }
    clearTimeout(timer);
    return new Blob(parts, { type: res.headers.get('content-type') || 'image/webp' });
  } finally { clearTimeout(timer); }
}

function imgFromUrl(url) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.decoding = 'async';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('img error ' + url));
    img.src = url;
  });
}

async function fetchImage(e) {
  const info = BY_KEY.get(e.key);
  const url = BASE + info.url;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const blob = await fetchWithStall(url);
      const img = await imgFromUrl(URL.createObjectURL(blob));
      return img;
    } catch (err) { e.lastError = String(err && err.message || err); }
  }
  // last resort: let the browser fetch it the plain way (works on file:// too)
  return imgFromUrl(url);
}

function finish(e, img) {
  active--;
  e.img = img;
  e.state = img ? 'ok' : 'fail';
  if (!img) console.warn('[assets] FAILED', e.key, e.lastError || '');
  for (const t of e.texs) { t.image = img; if (img) t.needsUpdate = true; }
  const w = e.waiters; e.waiters = [];
  for (const fn of w) fn(img);
  pump();
}

function request(key, front = false) {
  const e = entry(key);
  if (e.state === 'idle') {
    if (!BY_KEY.has(key)) { e.state = 'fail'; return e; }
    e.state = 'queued';
    if (front) queue.unshift(e); else queue.push(e);
    pump();
  }
  return e;
}

/** Promise<HTMLImageElement|null>. Starts the load if needed. */
export function getImage(key) {
  const e = request(key);
  if (e.state === 'ok' || e.state === 'fail') return Promise.resolve(e.img);
  return new Promise(res => e.waiters.push(res));
}

/** Returns a THREE.Texture immediately (null only if the key is not in the manifest).
 *  The image arrives asynchronously; the texture updates itself.
 *  opts: { srgb=true, repeat=false, mipmaps=true, flipY=true }
 *  Each call returns a NEW Texture object sharing the same image, so you may set
 *  offset/repeat per use (sprite-sheet frames). */
export function getTexture(key, opts = {}) {
  if (!BY_KEY.has(key)) return null;
  const e = request(key);
  const t = new THREE.Texture();
  t.colorSpace = opts.srgb === false ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  t.anisotropy = anisotropy;
  t.generateMipmaps = opts.mipmaps !== false;
  t.minFilter = t.generateMipmaps ? THREE.LinearMipmapLinearFilter : THREE.LinearFilter;
  t.magFilter = THREE.LinearFilter;
  if (opts.flipY === false) t.flipY = false;
  if (opts.repeat) { t.wrapS = t.wrapT = THREE.RepeatWrapping; }
  if (e.img) { t.image = e.img; t.needsUpdate = true; }
  else e.texs.push(t);
  return t;
}

/** Load a set of keys in priority order. onProgress(done, total, key).
 *  Resolves (never rejects) with { loaded, failed, ms }. Prints a receipt. */
export function preload(keys, onProgress) {
  const t0 = performance.now();
  const want = keys.filter(k => BY_KEY.has(k));
  const missing = keys.filter(k => !BY_KEY.has(k));
  let done = 0;
  const loaded = [], failed = [...missing];
  // push in reverse with front=true so the FIRST key ends up first in line
  for (let i = want.length - 1; i >= 0; i--) request(want[i], true);
  return Promise.all(want.map(k => getImage(k).then(img => {
    (img ? loaded : failed).push(k);
    done++;
    if (onProgress) onProgress(done, want.length, k);
  }))).then(() => {
    const ms = Math.round(performance.now() - t0);
    const msg = `[assets] ${loaded.length}/${keys.length} loaded in ${ms} ms` + (failed.length ? ` — FAILED: ${failed.join(', ')}` : '');
    (failed.length ? console.warn : console.info)(msg);
    return { loaded, failed, ms };
  });
}

/** Debug receipt of every asset's state. */
export function loadStats() {
  const out = {};
  for (const [k, e] of entries) out[k] = e.state;
  return out;
}
