// RENDERER CORE — owns the WebGLRenderer, the Scene, the PerspectiveCamera, resize
// and the frame loop. Modules never create their own renderer or rAF loop.
//
//   const app = createApp();
//   app.addTick((dt, time) => {...});         // called every frame, in order added
//   app.setRender((dt) => post.render(dt));   // optional: replace the final draw
//   app.start();
//
// Headless / deterministic testing: app.advance(seconds, step=1/60) runs the ticks
// synchronously (no rAF) and renders ONE frame at the end. window.__app exposes it.
import * as THREE from 'three';
import { BEND } from './bend.js';
import { setMaxAnisotropy } from './assets.js';

export function createApp(opts = {}) {
  const canvas = opts.canvas || document.getElementById('gl') || (() => {
    const c = document.createElement('canvas'); c.id = 'gl'; document.body.prepend(c); return c;
  })();
  const renderer = new THREE.WebGLRenderer({
    canvas, antialias: true, alpha: false, powerPreference: 'high-performance',
    stencil: false, depth: true, preserveDrawingBuffer: !!opts.preserveDrawingBuffer,
  });
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.shadowMap.enabled = false;           // blob shadows only (see bend.js)
  setMaxAnisotropy(renderer.capabilities.getMaxAnisotropy());

  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#10182a');
  const camera = new THREE.PerspectiveCamera(62, 1, 0.1, 700);
  camera.position.set(0, 4.2, 6.8);
  camera.lookAt(0, 1.2, -14);

  const app = {
    renderer, scene, camera, canvas,
    width: 1, height: 1, dpr: 1, dprCap: opts.dprCap || 2,
    time: 0, frame: 0, running: false, paused: false,
    ticks: [], resizeFns: [],
    _render: null,
    addTick(fn) { this.ticks.push(fn); return fn; },
    removeTick(fn) { const i = this.ticks.indexOf(fn); if (i >= 0) this.ticks.splice(i, 1); },
    onResize(fn) { this.resizeFns.push(fn); fn(this.width, this.height, this.dpr); },
    setRender(fn) { this._render = fn; },
    setDprCap(cap) { this.dprCap = cap; this.resize(); },
    render(dt) { if (this._render) this._render(dt); else renderer.render(scene, camera); },
    resize() {
      const w = Math.max(1, window.innerWidth), h = Math.max(1, window.innerHeight);
      const dpr = Math.min(this.dprCap, window.devicePixelRatio || 1);
      this.width = w; this.height = h; this.dpr = dpr;
      renderer.setPixelRatio(dpr);
      renderer.setSize(w, h, true);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      for (const fn of this.resizeFns) fn(w, h, dpr);
    },
    step(dt) {
      this.time += dt; this.frame++;
      BEND.update(dt, this.time);
      for (const fn of this.ticks) fn(dt, this.time);
    },
    start() {
      if (this.running) return;
      this.running = true;
      let last = performance.now();
      const loop = (now) => {
        if (!this.running) return;
        requestAnimationFrame(loop);
        let dt = (now - last) / 1000; last = now;
        if (!(dt > 0)) dt = 1 / 60;
        dt = Math.min(dt, 0.05);                  // tab switches / hitches never teleport the sim
        this.lastFrameMs = dt * 1000;
        this.step(dt);
        this.render(dt);
      };
      requestAnimationFrame(loop);
    },
    stop() { this.running = false; },
    /** Deterministic fast-forward for tests: runs ticks without rendering, then renders once. */
    advance(seconds, step = 1 / 60) {
      const n = Math.max(1, Math.round(seconds / step));
      for (let i = 0; i < n; i++) this.step(step);
      this.render(step);
      return this.frame;
    },
  };
  window.addEventListener('resize', () => app.resize());
  window.addEventListener('orientationchange', () => setTimeout(() => app.resize(), 120));
  app.resize();
  if (typeof window !== 'undefined') window.__app = app;
  return app;
}

/** A plain chase camera for harnesses, used until the real camera director exists.
 *  (The FX agent's camera.js replaces this in the real game.) */
export function basicChaseCamera(camera, sim) {
  const p = sim.player;
  const sy = Math.max(p.surfaceY || 0, Math.min(p.y || 0, 5));
  // portrait needs a wide vertical FOV so all three lanes fit at the fox's depth
  const aspect = camera.aspect || 1;
  const fov = aspect < 1 ? THREE.MathUtils.radToDeg(2 * Math.atan(Math.tan(THREE.MathUtils.degToRad(24)) / aspect)) : 58;
  const f = Math.max(52, Math.min(90, fov));
  if (Math.abs(camera.fov - f) > 0.01) { camera.fov = f; camera.updateProjectionMatrix(); }
  camera.position.set(p.x * 0.55, 3.2 + sy * 0.9, 5.6);
  camera.lookAt(p.x * 0.65, 1.5 + sy * 0.95, -8);
}
