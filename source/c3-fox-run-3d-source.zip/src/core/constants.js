// Shared world constants. EVERY module uses these — never hard-code a lane position.
//
// COORDINATE SYSTEM (three.js, right-handed, metres)
//   +Y up, ground plane at y = 0.
//   The player runs toward -Z. The player's feet are always at z = 0 in RENDER space.
//   Track distance `s` (metres from run start) maps to render z by  z = -(s - sim.dist)
//   so something 40 m ahead of the fox renders at z = -40. Nothing ever uses absolute
//   world z, which keeps float precision perfect on a 50 km run.
//   Lanes: index 0 = left, 1 = centre, 2 = right.

export const LANE_W = 2.6;                         // centre-to-centre lane spacing (m)
export const LANE_X = [-LANE_W, 0, LANE_W];        // lateral centre of each lane
export const ROAD_HALF = 4.3;                      // half width of the drivable asphalt (m)
export const SHOULDER = 1.4;                       // gravel/verge strip beyond the asphalt (m)

export const VIEW_AHEAD = 150;                     // render / spawn horizon ahead of the player (m)
export const VIEW_BEHIND = 14;                     // keep things this far behind before recycling (m)

export const FOX_H = 1.75;                         // on-screen height of the fox sprite (m)
export const TRUCK_H = 3.1;                        // roof height of trucks / trains (m) — sim may override per entity
export const TRUCK_W = 2.25;                       // body width of trucks / trains (m)

/** Render-space z of something at track distance s. */
export function zOf(s, dist) { return -(s - dist); }

/** Lateral x of a (possibly fractional) lane index. */
export function laneX(i) { return (i - 1) * LANE_W; }

export const QUALITY_TIERS = ['low', 'med', 'high'];
