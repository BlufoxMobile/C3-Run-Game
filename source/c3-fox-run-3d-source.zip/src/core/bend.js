// CURVED WORLD — the Subway-Surfers horizon.
//
// Every vertex is bent in VIEW space after the model-view transform:
//     d = max(0, -viewZ - uBendStart)
//     viewY -= uBendY * d*d          (the road falls away over the horizon)
//     viewX += uBendX * d*d          (the road sweeps left / right)
// Because it happens in view space it is relative to the camera, which is exactly
// the look we want, and it costs two multiply-adds per vertex.
//
// RULE: every material that draws something in the 3D scene MUST go through
// applyBend() (built-in materials) or include BEND_GLSL_PARS + BEND_GLSL_APPLY
// (custom ShaderMaterial / RawShaderMaterial). One unbent material = one object
// floating in the sky. The only exception is the sky dome, which is infinitely far.
//
// Shadow maps are NOT used anywhere (a light-space pass would bend differently).
// Use blob shadows.
import * as THREE from 'three';

export const BEND = {
  uniforms: {
    uBendY: { value: 0.0013 },
    uBendX: { value: 0.0 },
    uBendStart: { value: 8.0 },
  },
  // Targets the world eases toward. The camera director / world may set these.
  targetY: 0.0013,
  targetX: 0.0,
  /** Default slow left/right sweep. Call once per frame (main loop does). */
  update(dt, time) {
    const u = this.uniforms;
    // gentle S-curves every ~22 s unless someone else drives targetX
    if (!this._external) this.targetX = 0.0011 * Math.sin(time * 0.285) * Math.sin(time * 0.117 + 1.3);
    const k = Math.min(1, dt * 1.5);
    u.uBendX.value += (this.targetX - u.uBendX.value) * k;
    u.uBendY.value += (this.targetY - u.uBendY.value) * k;
  },
  /** Call with true if your module drives targetX itself. */
  setExternal(b) { this._external = !!b; },
  _external: false,
};

export const BEND_GLSL_PARS = /* glsl */`
uniform float uBendY;
uniform float uBendX;
uniform float uBendStart;
`;

/** Operates on a vec4 named mvPosition (view-space position). */
export const BEND_GLSL_APPLY = /* glsl */`
{
  float bendD = max(0.0, -mvPosition.z - uBendStart);
  float bendD2 = bendD * bendD;
  mvPosition.y -= uBendY * bendD2;
  mvPosition.x += uBendX * bendD2;
}
`;

const GL_POS_LINE = 'gl_Position = projectionMatrix * mvPosition;';

/** Patch any built-in three.js material (Mesh*Material, PointsMaterial, SpriteMaterial,
 *  LineBasicMaterial...) so it bends with the world. Safe to call once per material.
 *  Composes with an existing onBeforeCompile. Returns the material. */
export function applyBend(material) {
  if (material.userData.__bent) return material;
  material.userData.__bent = true;
  const prev = material.onBeforeCompile;
  const prevKey = material.customProgramCacheKey ? material.customProgramCacheKey.bind(material) : null;
  material.onBeforeCompile = (shader, renderer) => {
    if (prev) prev.call(material, shader, renderer);
    shader.uniforms.uBendY = BEND.uniforms.uBendY;
    shader.uniforms.uBendX = BEND.uniforms.uBendX;
    shader.uniforms.uBendStart = BEND.uniforms.uBendStart;
    let vs = shader.vertexShader;
    vs = vs.replace('#include <project_vertex>', THREE.ShaderChunk.project_vertex);
    if (!vs.includes(GL_POS_LINE)) {
      console.warn('[bend] could not find projection line in', material.type);
    }
    vs = vs.split(GL_POS_LINE).join(BEND_GLSL_APPLY + '\n' + GL_POS_LINE);
    // declare uniforms at the top of main's scope
    vs = vs.replace('void main() {', BEND_GLSL_PARS + '\nvoid main() {');
    shader.vertexShader = vs;
  };
  material.customProgramCacheKey = () => (prevKey ? prevKey() : '') + '|bend1';
  material.needsUpdate = true;
  return material;
}

/** Apply bend to every material under an Object3D. */
export function bendTree(obj) {
  obj.traverse(o => {
    if (!o.material) return;
    if (Array.isArray(o.material)) o.material.forEach(applyBend); else applyBend(o.material);
  });
  return obj;
}

const _v = new THREE.Vector3();
/** CPU mirror of the shader: world position -> screen pixels (CSS px), bent.
 *  Use it to pin DOM text (floating +$25 etc.) to a 3D point.
 *  Returns {x, y, visible}. `out` optional. */
export function projectBent(worldPos, camera, cssW, cssH, out = {}) {
  _v.copy(worldPos).applyMatrix4(camera.matrixWorldInverse);
  const d = Math.max(0, -_v.z - BEND.uniforms.uBendStart.value);
  _v.y -= BEND.uniforms.uBendY.value * d * d;
  _v.x += BEND.uniforms.uBendX.value * d * d;
  const visible = _v.z < 0;
  _v.applyMatrix4(camera.projectionMatrix);
  out.x = (_v.x * 0.5 + 0.5) * cssW;
  out.y = (-_v.y * 0.5 + 0.5) * cssH;
  out.visible = visible && Math.abs(_v.x) < 1.2 && Math.abs(_v.y) < 1.2;
  return out;
}
