// LEVEL SCHEDULE + WORLD GENERATOR
//
// The generator designs the road in CHUNKS (an obstacle row, a truck set piece, a
// breather, an oncoming-truck lane ...) chosen by weighted random with level-dependent
// weights. Every chunk is PROVEN SOLVABLE before it is accepted: a lane-grid reachability
// pass (see dp*) runs over the chunk with the set of lanes the player could be in at its
// start, and rejects it if any of those lanes becomes a dead end or no lane survives.
// Coins are then laid only on cells that are both reachable and survivable, so a coin
// line is never bait into an unsolvable spot.
//
// Blueprints are queued in s order and turned into live entities by the sim when they
// come within TUNE.spawnAhead (so nothing pops in near the fox). Oncoming trucks are
// planned by their MEETING point and released when their start position reaches the
// spawn horizon.
import { LANE_X, TRUCK_H } from '../core/constants.js';
import { THEMES, MONSTERS } from '../data/themes.js';
import { TUNE, levelSpeed, levelLength, rowGapT, airtimeAt, gravityAt } from './sim-tune.js';
import { makeRng } from './sim-rng.js';

// =============================================================================== schedule
export function createSchedule() {
  const S = {
    runStart: 0, baseLevel: 1, attract: false, starts: [], _cL: 1,
    reset(runStart, baseLevel = 1, attract = false) {
      S.runStart = runStart; S.baseLevel = baseLevel; S.attract = attract;
      S.starts.length = 0; S.starts[baseLevel] = runStart; S._cL = baseLevel;
    },
    startOf(L) {
      if (L < S.baseLevel) return -Infinity;
      while (S.starts.length <= L) { const k = S.starts.length - 1; S.starts[k + 1] = S.starts[k] + levelLength(k); }
      return S.starts[L];
    },
    levelAt(s) {
      if (S.attract) return 1;
      let L = S._cL;
      while (L > S.baseLevel && S.startOf(L) > s) L--;
      while (S.startOf(L + 1) <= s) L++;
      S._cL = L;
      return L;
    },
    speedAt(s) {
      if (S.attract) return TUNE.attractSpeed;
      const L = S.levelAt(s), u = s - S.startOf(L), v1 = levelSpeed(L);
      const v0 = L === 1 ? TUNE.speedStart : levelSpeed(L - 1);
      const ramp = L === 1 ? TUNE.firstRampM : TUNE.levelRampM;
      if (u >= ramp || v0 === v1) return v1;
      const k = Math.max(0, u / ramp);
      return v0 + (v1 - v0) * k * k * (3 - 2 * k);
    },
    /** seconds to run from a to b at the scheduled speed */
    timeBetween(a, b) {
      if (b <= a) return 0;
      if (S.attract) return (b - a) / TUNE.attractSpeed;
      let t = 0, s = a;
      while (s < b) { const e = Math.min(b, s + 6); t += (e - s) / S.speedAt((s + e) * 0.5); s = e; }
      return t;
    },
  };
  return S;
}

// =============================================================================== lane-grid verifier
const MAXC = 2600;
const GB = 1, RF = 2, RLO = 4, RHI = 8, BR = 16, NS = 32;
const FL = [new Uint8Array(MAXC), new Uint8Array(MAXC), new Uint8Array(MAXC)];
const RUN_G = [new Int16Array(MAXC), new Int16Array(MAXC), new Int16Array(MAXC)];   // !GB
const RUN_L = [new Int16Array(MAXC), new Int16Array(MAXC), new Int16Array(MAXC)];   // lateral entry ok
const RUN_N = [new Int16Array(MAXC), new Int16Array(MAXC), new Int16Array(MAXC)];   // landing ok (!GB,!BR)
const RUN_R = [new Int16Array(MAXC), new Int16Array(MAXC), new Int16Array(MAXC)];   // roof
const REACH = new Uint8Array(MAXC), ALIVE = new Uint8Array(MAXC);
const DP = { s0: 0, n: 0, ds: 0.5, lc: 4, fall: 8 };
const bitG = l => 1 << (l * 2), bitR = l => 1 << (l * 2 + 1);

function dpInit(s0, s1) {
  DP.s0 = s0; DP.ds = TUNE.dpCell;
  DP.n = Math.max(2, Math.min(MAXC, Math.ceil((s1 - s0) / DP.ds) + 1));
  for (let l = 0; l < 3; l++) FL[l].fill(0, 0, DP.n);
}
function dpCellOf(s) { return Math.round((s - DP.s0) / DP.ds); }
function dpMark(l, a, b, f) {
  let i0 = Math.ceil((a - DP.s0) / DP.ds - 1e-6), i1 = Math.floor((b - DP.s0) / DP.ds + 1e-6);
  if (i1 < 0 || i0 >= DP.n) return;
  if (i0 < 0) i0 = 0; if (i1 > DP.n - 1) i1 = DP.n - 1;
  const A = FL[l];
  for (let i = i0; i <= i1; i++) A[i] |= f;
}
function dpRuns() {
  const n = DP.n;
  for (let l = 0; l < 3; l++) {
    const f = FL[l], g = RUN_G[l], la = RUN_L[l], nb = RUN_N[l], r = RUN_R[l];
    let cg = 0, cl = 0, cn = 0, cr = 0;
    for (let i = n - 1; i >= 0; i--) {
      const x = f[i];
      cg = (x & GB) ? 0 : cg + 1; g[i] = cg;
      cl = (x & (GB | RHI | RF)) ? 0 : cl + 1; la[i] = cl;
      cn = (x & (GB | BR)) ? 0 : cn + 1; nb[i] = cn;
      cr = (x & RF) ? cr + 1 : 0; r[i] = cr;
    }
  }
}
// transitions shared by the forward and backward passes. cb(targetIndex, targetBit)
function dpEach(i, st, cb) {
  const n = DP.n, last = n - 1, l = st >> 1, roof = st & 1, k = DP.lc, fall = DP.fall;
  const left = last - i;                     // cells remaining after i
  if (left <= 0) return;
  const f = FL[l];
  if (!roof) {
    // run on
    if (!(f[i + 1] & GB)) cb(i + 1, bitG(l));
    else if ((f[i + 1] & RF) && (f[i] & (RLO | RHI))) cb(i + 1, bitR(l));
    // lane change
    const need = Math.min(k, left), needO = Math.min((k + 1) >> 1, left);
    for (let d = -1; d <= 1; d += 2) {
      const l2 = l + d; if (l2 < 0 || l2 > 2) continue;
      if (RUN_G[l][i + 1] >= needO && RUN_L[l2][i + 1] >= need) cb(Math.min(last, i + k), bitG(l2));
    }
  } else {
    if (f[i + 1] & RF) cb(i + 1, bitR(l));
    else {
      // ran off the end: skip the truck's own tail cells, then the landing must be clear
      let j = i + 1, skip = 0;
      while (j < last && (f[j] & GB) && !(f[j] & RF) && skip < 3) { j++; skip++; }
      const need = Math.min(fall + 1 - skip, last - j + 1);
      if (!(f[j] & GB) && RUN_N[l][j] >= need) cb(Math.min(last, i + 1 + fall), bitG(l));
    }
    const need = Math.min(k, left);
    for (let d = -1; d <= 1; d += 2) {
      const l2 = l + d; if (l2 < 0 || l2 > 2) continue;
      if (RUN_R[l2][i + 1] >= need && (f[i + 1] & RF)) cb(Math.min(last, i + k), bitR(l2));
      const needD = Math.min(k + fall, left);
      if (RUN_N[l2][i + 1] >= needD) cb(Math.min(last, i + k + fall), bitG(l2));
    }
  }
}
function validBits(i) {
  let v = 0;
  for (let l = 0; l < 3; l++) { const x = FL[l][i]; if (!(x & GB)) v |= bitG(l); if (x & RF) v |= bitR(l); }
  return v;
}
let _alive = false, _reachI = 0;
function _aliveCb(t, b) { if (ALIVE[t] & b) _alive = true; }
function _reachCb(t, b) { REACH[t] |= b; }
/** Runs the reachability proof. Returns true when every entry lane survives. */
function dpSolve(entryMask) {
  const n = DP.n;
  dpRuns();
  ALIVE[n - 1] = validBits(n - 1);
  for (let i = n - 2; i >= 0; i--) {
    const v = validBits(i); let a = 0;
    for (let st = 0; st < 6; st++) {
      if (!(v & (1 << st))) continue;
      _alive = false; dpEach(i, st, _aliveCb);
      if (_alive) a |= 1 << st;
    }
    ALIVE[i] = a;
  }
  REACH.fill(0, 0, n);
  let e = 0;
  for (let l = 0; l < 3; l++) if (entryMask & (1 << l)) e |= bitG(l);
  REACH[0] = e & validBits(0);
  if ((ALIVE[0] & e) !== e) return false;            // an entry lane is a dead end
  for (let i = 0; i < n - 1; i++) {
    const r = REACH[i] & ALIVE[i]; if (!r) continue;
    for (let st = 0; st < 6; st++) if (r & (1 << st)) dpEach(i, st, _reachCb);
  }
  return true;
}
const okG = (i, l) => i >= 0 && i < DP.n && ((REACH[i] & ALIVE[i]) & bitG(l)) !== 0;
const okR = (i, l) => i >= 0 && i < DP.n && ((REACH[i] & ALIVE[i]) & bitR(l)) !== 0;

// =============================================================================== generator
const KIND_W = { watch: 0.5, tab: 0.32, xm: 0.18 };           // old build's orb mix
const ROOF_KIND_W = { watch: 0.45, tab: 0.4, xm: 0.15 };
const lanesOf = mask => [0, 1, 2].filter(l => mask & (1 << l));
const popcount = m => (m & 1) + ((m >> 1) & 1) + ((m >> 2) & 1);

export function createGen(sched) {
  const G = {
    sched, rng: makeRng(1), attract: false,
    prevEnd: 0, entryMask: 2, Tf: 0,
    queue: [], qHead: 0, oncoming: [], resv: [],
    lastJumpS: -1e9, debt: 0, sinceTruck: 9, levelSeen: 1, lastKind: '', nextPowerT: 0,
    nextTsheetT: 0,
    stats: { chunks: 0, retries: 0, fallbacks: 0, kinds: {} },
  };
  const R = () => G.rng;

  G.reset = (seed, startS, attract, startLane = 1) => {
    G.rng = makeRng(seed); G.attract = attract;
    G.prevEnd = startS; G.entryMask = 1 << startLane; G.Tf = 0;
    G.queue.length = 0; G.qHead = 0; G.oncoming.length = 0; G.resv.length = 0;
    G.lastJumpS = -1e9; G.debt = 0; G.sinceTruck = 9; G.levelSeen = sched.levelAt(startS); G.lastKind = '';
    G.nextPowerT = attract ? R().f(6, 9) : R().f(TUNE.powerFirstT[0], TUNE.powerFirstT[1]);
    G.stats = { chunks: 0, retries: 0, fallbacks: 0, kinds: {} };
    G.intro = true; G.startS = startS;
  };

  // ------------------------------------------------------------------ reservations
  function laneFree(l, a, b) {
    for (const r of G.resv) if (r.lane === l && r.nsB > a && r.nsA < b) return false;
    return true;
  }
  function allowedMask(a, b) { let m = 0; for (let l = 0; l < 3; l++) if (laneFree(l, a, b)) m |= 1 << l; return m; }
  function resvActive(a) { for (const r of G.resv) if (r.nsB > a - 40) return true; return false; }

  // ------------------------------------------------------------------ chunk building
  function newChunk(s0, L, v) {
    return { s0, L, v, items: [], end: s0, contentStart: Infinity, rows: [], trucks: [], barriers: [], kind: '' };
  }
  function themeIdxAt(L) { return (L - 1) % THEMES.length; }
  function monster(c, lane, s, driftTo) {
    const it = { k: 'mon', s, lane, kind: R().pick(MONSTERS), key: s };
    if (driftTo !== undefined) it.driftTo = driftTo;
    c.items.push(it); c.contentStart = Math.min(c.contentStart, s);
    c.end = Math.max(c.end, s + TUNE.monsterLen);
    return it;
  }
  function barrier(c, lane, s, gate) {
    const it = { k: 'bar', s, lane, gate: !!gate, key: s };
    c.items.push(it); c.barriers.push(it); c.contentStart = Math.min(c.contentStart, s);
    c.end = Math.max(c.end, s + TUNE.barrierLen);
    return it;
  }
  function truckKind(L) {
    const ti = themeIdxAt(L);
    if (ti >= TUNE.busFromTheme) return R().wpick({ bus: 0.42, semi: 0.33, box: 0.25 });
    return R().wpick({ semi: 0.55, box: 0.45 });
  }
  function truckLen(kind) {
    const r = kind === 'semi' ? TUNE.semiLen : kind === 'bus' ? TUNE.busLen : TUNE.boxLen;
    return Math.round(R().f(r[0], r[1]) * 2) / 2;
  }
  function truck(c, lane, s, kind, len, ramp) {
    const it = { k: 'truck', s, lane, kind, len, h: TUNE.truckH, ramp: !!ramp, rampLen: ramp ? TUNE.rampLen : 0,
                 livery: R().i(0, 7), key: s - (ramp ? TUNE.rampLen : 0) };
    c.items.push(it); c.trucks.push(it);
    c.contentStart = Math.min(c.contentStart, it.key);
    c.end = Math.max(c.end, s + len + fallDist(c.v) + 3);
    return it;
  }
  const fallDist = v => Math.sqrt(2 * TUNE.truckH / gravityAt(v)) * v;
  const CV = TUNE.curves;
  const twoTallP = L => CV.twoTall(L), driftP = L => CV.drift(L), dgateP = L => CV.doubleGate(L);
  // a drifter starts sliding this long before it reaches the fox (less warning later on)
  const driftTrig = L => CV.driftTrig(L);

  // jump-chain rule: a row that needs a jump is never within jumpChainGap of another
  function jumpSafeS(s, v) { return Math.max(s, G.lastJumpS + TUNE.jumpChainGap * v); }

  // ---- row templates -------------------------------------------------------------
  function rowMon(c, s, allowed, opts = {}) {
    const lanes = R().shuffle(lanesOf(allowed));
    if (lanes.length < 2) return false;
    // a drifting row is ONE monster that slides into a neighbouring lane while you read it
    // (two monsters + a slide into the only open lane would be unsolvable)
    const wantDrift = opts.drift !== false && lanes.length === 3 && R().chance(driftP(c.L));
    let k = wantDrift ? 1 : opts.k || (R().chance(twoTallP(c.L)) ? 2 : 1);
    k = Math.min(k, lanes.length - 1);
    const made = [];
    for (let i = 0; i < k; i++) made.push(monster(c, lanes[i], s));
    if (wantDrift) {
      // one monster slides into a neighbouring free lane while you read it
      const cand = made.filter(m => [m.lane - 1, m.lane + 1].some(t => t >= 0 && t <= 2 && (allowed & (1 << t)) && !made.some(o => o.lane === t)));
      if (cand.length) {
        const m = R().pick(cand);
        const tos = [m.lane - 1, m.lane + 1].filter(t => t >= 0 && t <= 2 && (allowed & (1 << t)) && !made.some(o => o.lane === t));
        m.driftTo = R().pick(tos); m.driftTrig = driftTrig(c.L);
      }
    }
    c.rows.push(s);
    return true;
  }
  function rowBar(c, s, allowed, count) {
    const lanes = R().shuffle(lanesOf(allowed));
    const k = Math.min(count, lanes.length);
    const gate = k === 3;
    for (let i = 0; i < k; i++) barrier(c, lanes[i], s, gate);
    c.rows.push(s); G.lastJumpS = Math.max(G.lastJumpS, s);
    return true;
  }
  function rowMonBar(c, s, allowed, mons) {
    const lanes = R().shuffle(lanesOf(allowed));
    if (lanes.length < mons + 1) return false;
    const made = [];
    for (let i = 0; i < mons; i++) made.push(monster(c, lanes[i], s));
    barrier(c, lanes[mons], s, false);
    // one monster + barrier + open lane: the monster may slide into the open lane (jump it is)
    if (mons === 1 && lanes.length === 3 && Math.abs(lanes[0] - lanes[2]) === 1 && R().chance(driftP(c.L) * 0.8)) {
      made[0].driftTo = lanes[2]; made[0].driftTrig = driftTrig(c.L);
    }
    c.rows.push(s); G.lastJumpS = Math.max(G.lastJumpS, s);
    return true;
  }

  // ---- chunk templates -------------------------------------------------------------
  const T = {};
  T.breather = (c, dur) => { c.end = c.s0 + dur * c.v; c.contentStart = c.end; c.breather = true; return true; };
  T.mon = (c, al) => rowMon(c, c.s0, al);
  // a lone monster that slides one lane over while you read it (telegraphed by the renderer)
  T.drift = (c, al) => {
    const lanes = lanesOf(al); if (lanes.length < 3) return false;
    const m = monster(c, R().pick(lanes), c.s0);
    const to = [m.lane - 1, m.lane + 1].filter(t => t >= 0 && t <= 2);
    m.driftTo = R().pick(to); m.driftTrig = driftTrig(c.L);
    // later: a second, static monster in the lane it slides away from closes that door too
    if (c.L >= TUNE.complexFrom && R().chance(0.4)) {
      const free = [0, 1, 2].filter(l => l !== m.lane && l !== m.driftTo);
      if (free.length === 1 && Math.abs(free[0] - m.driftTo) === 1) monster(c, m.lane, c.s0 + rowGapT(c.L) * c.v * 0.55);
    }
    c.rows.push(c.s0);
    return true;
  };
  T.bar = (c, al) => {
    const s = jumpSafeS(c.s0, c.v); c.s0 = s;
    const n = R().chance(CV.barPair(c.L)) ? 2 : 1;
    return rowBar(c, s, al, n);
  };
  T.gate = (c, al) => {
    if (popcount(al) < 3) return false;
    const s = jumpSafeS(c.s0, c.v); c.s0 = s;
    rowBar(c, s, 7, 3);
    if (R().chance(dgateP(c.L))) rowBar(c, s + TUNE.jumpChainGap * c.v * R().f(1.0, 1.12), 7, 3);
    return true;
  };
  T.monbar = (c, al) => { const s = jumpSafeS(c.s0, c.v); c.s0 = s; return rowMonBar(c, s, al, 1); };
  T.mixed = (c, al) => {
    if (popcount(al) < 3) return false;
    const s = jumpSafeS(c.s0, c.v); c.s0 = s;
    return rowMonBar(c, s, al, 2);
  };
  // zig-zag: rows in quick succession that each close a different lane
  T.stagger = (c, al) => {
    const lanes = R().shuffle(lanesOf(al));
    if (lanes.length < 2) return false;
    const tight = CV.staggerTight(c.L);
    const gap = rowGapT(c.L) * c.v * R().f(tight, tight + 0.14);
    const m0 = monster(c, lanes[0], c.s0);
    if (lanes.length === 3 && c.L >= 5 && R().chance(CV.staggerSide(c.L))) monster(c, lanes[2], c.s0);
    else if (lanes.length === 3 && R().chance(driftP(c.L) * 0.5)) {
      const to = [m0.lane - 1, m0.lane + 1].filter(t => t >= 0 && t <= 2 && t !== lanes[1]);
      if (to.length) { m0.driftTo = R().pick(to); m0.driftTrig = driftTrig(c.L); }
    }
    monster(c, lanes[1], c.s0 + gap);
    if (lanes.length === 3 && c.L >= 6 && R().chance(CV.staggerThird(c.L))) monster(c, lanes[0], c.s0 + gap * 2);
    c.rows.push(c.s0, c.s0 + gap);
    return true;
  };
  // single parked truck with a ramp: roof route (coins) or the other lanes
  T.rampTruck = (c, al) => {
    const lanes = lanesOf(al); if (!lanes.length) return false;
    const a = R().pick(lanes), kind = truckKind(c.L), len = truckLen(kind);
    const t = truck(c, a, c.s0 + TUNE.rampLen, kind, len, true);
    if (c.L >= 2 && R().chance(CV.truckAlongside(c.L))) {
      const others = lanes.filter(l => l !== a);
      if (others.length >= 2) {
        const s = t.s + len * R().f(0.25, 0.7);
        if (R().chance(0.3) && s > G.lastJumpS + TUNE.jumpChainGap * c.v) rowBar(c, s, (1 << others[0]) | (1 << others[1]), 1);
        else monster(c, R().pick(others), s);
      }
    }
    return true;
  };
  // two parked trucks side by side, one ramp: take the roofs or the third lane
  T.twin = (c, al) => {
    const pairs = [[0, 1], [1, 2]].filter(([a, b]) => (al & (1 << a)) && (al & (1 << b)));
    if (!pairs.length) return false;
    const pair = R().pick(pairs);
    const flip = R().chance(0.5), a = flip ? pair[1] : pair[0], b = flip ? pair[0] : pair[1];
    const kA = truckKind(c.L), kB = truckKind(c.L);
    const lenA = Math.max(12, truckLen(kA)), lenB = Math.max(12, truckLen(kB));
    const tA = truck(c, a, c.s0 + TUNE.rampLen, kA, lenA, true);
    const tB = truck(c, b, tA.s + R().f(-3, Math.min(6, lenA - 8)), kB, lenB, false);
    const third = 3 - pair[0] - pair[1];
    if ((al & (1 << third)) && c.L >= 3 && R().chance(CV.twinThird(c.L))) {
      const s = Math.min(tA.s, tB.s) + R().f(2, 10);
      if (R().chance(0.4) && s > G.lastJumpS + TUNE.jumpChainGap * c.v) rowBar(c, s, 1 << third, 1);
      else monster(c, third, s);
    }
    return true;
  };
  // a parked truck with no ramp walls one lane; rows run alongside in the other two
  T.wall = (c, al) => {
    const lanes = lanesOf(al); if (lanes.length < 3) return false;
    const a = R().pick(lanes), kind = R().chance(0.7) ? 'semi' : truckKind(c.L), len = truckLen(kind);
    const t = truck(c, a, c.s0 + 2, kind, len, false);
    const others = lanes.filter(l => l !== a), om = (1 << others[0]) | (1 << others[1]);
    const gap = rowGapT(c.L) * c.v;
    let s = t.s + gap * R().f(0.5, 0.8);
    while (s < t.s + len - 3) {
      if (R().chance(0.3) && s > G.lastJumpS + TUNE.jumpChainGap * c.v) rowBar(c, s, om, 1);
      else monster(c, R().pick(others), s);
      c.rows.push(s);
      s += gap * R().f(0.95, 1.2);
    }
    return true;
  };
  // staggered trucks across lanes: roof-hop or weave the ground
  T.maze = (c, al) => {
    if (popcount(al) < 3) return false;
    const n = Math.min(5, 3 + (c.L >= 9 ? R().i(0, 1) : 0) + (c.L >= 13 ? R().i(0, 1) : 0));
    let lane = R().i(0, 2);
    let kind = truckKind(c.L), len = Math.max(12, truckLen(kind));
    let t = truck(c, lane, c.s0 + TUNE.rampLen, kind, len, true);
    for (let i = 1; i < n; i++) {
      const choices = [lane - 1, lane + 1].filter(l => l >= 0 && l <= 2);
      kind = truckKind(c.L); len = Math.max(11, truckLen(kind));
      const start = t.s + t.len - R().f(5, 9);
      const ramp = R().chance(0.25);
      // never stack a truck (or its ramp) onto an earlier one in the same lane
      const fits = l => !c.trucks.some(x => x.lane === l && start - (ramp ? TUNE.rampLen : 0) < x.s + x.len + 4);
      const ok = choices.filter(fits);
      if (!ok.length) break;
      const nl = R().pick(ok);
      t = truck(c, nl, start, kind, len, ramp);
      lane = nl;
    }
    // ground hazards in the lanes the trucks leave open
    const ends = c.trucks.map(x => x.s + x.len), a0 = c.trucks[0].s, a1 = Math.max(...ends);
    const gap = rowGapT(c.L) * c.v * 1.1;
    for (let s = a0 + gap * 0.6; s < a1 - 2; s += gap * R().f(0.9, 1.3)) {
      const free = [0, 1, 2].filter(l => !c.trucks.some(x => x.lane === l && s > x.s - x.rampLen - 3 && s < x.s + x.len + 3));
      if (free.length >= 1 && R().chance(0.6)) monster(c, R().pick(free), s);
    }
    return true;
  };
  // an oncoming truck lane: plans 1..3 trucks by their meeting point, reserves the lane
  T.oncoming = (c, al) => {
    const lanes = lanesOf(al).filter(l => laneFree(l, c.s0, c.s0 + 260));
    if (lanes.length < 3) return false;
    const a = R().pick(lanes), v = c.v;
    const n = 1 + (c.L >= 4 && R().chance(0.6) ? 1 : 0) + (c.L >= 8 && R().chance(0.5) ? 1 : 0);
    let sm = c.s0 + v * R().f(0.9, 1.3);
    for (let i = 0; i < n; i++) {
      const vk = -R().f(-TUNE.oncomingV[0] + Math.min(3, c.L * 0.25), -TUNE.oncomingV[1]);
      const kind = truckKind(c.L), len = truckLen(kind);
      const rel = v + Math.abs(vk);
      const passLen = len * v / rel;
      const s0nom = sm + TUNE.spawnAhead * Math.abs(vk) / rel;
      G.oncoming.push({ sMeet: sm, v: vk, len, kind, lane: a, livery: R().i(0, 7) });
      G.resv.push({ lane: a, wallA: sm - 0.5 * v, wallB: sm + passLen + 0.3 * v, nsA: sm - 0.5 * v, nsB: s0nom + len + 12 });
      sm += v * R().f(1.3, 2.1);
    }
    c.end = c.s0; c.contentStart = c.s0; c.passive = true;
    return true;
  };

  // ------------------------------------------------------------------ weights
  function weights(L, Tf, al) {
    const w = {}, W = TUNE.weights;
    const trucksOK = G.attract ? Tf >= TUNE.introSafeT : Tf >= TUNE.introNoTruckT;
    const full = popcount(al) === 3;
    w.mon = W.mon(L);
    w.bar = W.bar(L);
    w.gate = full ? W.gate(L) : 0;
    w.monbar = W.monbar(L);
    w.mixed = full ? W.mixed(L) : 0;
    w.stagger = W.stagger(L);
    w.drift = full ? W.drift(L) : 0;
    if (trucksOK && G.sinceTruck >= 2) {
      w.rampTruck = W.rampTruck(L);
      w.twin = W.twin(L);
      w.wall = full ? W.wall(L) : 0;
      w.maze = full ? W.maze(L) : 0;
    }
    if (!G.attract && full && !resvActive(G.prevEnd) && G.lastKind !== 'oncoming') {
      const o = W.oncoming(L);
      if (o > 0) w.oncoming = o;
    }
    return w;
  }
  const COST = { mon: 1, drift: 1.2, bar: 1, gate: 1.5, monbar: 1.2, mixed: 1.6, stagger: 1.8, rampTruck: 2, twin: 2.5, wall: 2.5, maze: 4, oncoming: 0 };

  // ------------------------------------------------------------------ build + verify + commit
  function gapFor(kind, L, v) {
    let g = rowGapT(L) * v * R().f(TUNE.rowGapJitter[0], TUNE.rowGapJitter[1]);
    if (G.lastKind === 'rampTruck' || G.lastKind === 'twin' || G.lastKind === 'wall' || G.lastKind === 'maze') g *= 0.55;
    if (G.lastKind === 'breather' || G.lastKind === 'intro') g *= 0.4;
    return g;
  }

  function verify(c) {
    // speed never drops along a run, so sizing the lane-change span from the speed well
    // past this chunk keeps consecutive chunks consistent (a lane this chunk calls
    // escapable is still escapable for the next one)
    const v = Math.max(c.v, sched.speedAt(c.end + 160));
    DP.lc = Math.max(2, Math.ceil(TUNE.dpLaneT * v / TUNE.dpCell));
    DP.fall = Math.ceil(fallDist(v) / TUNE.dpCell) + 3;
    const tail = TUNE.dpLaneT * v + 12;
    dpInit(G.prevEnd, c.end + tail);
    const PL = TUNE.playerHalfL, M = TUNE.dpMargin;
    for (const it of c.items) {
      if (it.k === 'mon') {
        dpMark(it.lane, it.s - PL - M, it.s + TUNE.monsterLen + PL + M, GB);
        if (it.driftTo !== undefined) dpMark(it.driftTo, it.s - PL - M - 1, it.s + TUNE.monsterLen + PL + M, GB);
      } else if (it.k === 'bar') {
        dpMark(it.lane, it.s - PL - M, it.s + TUNE.barrierLen + PL + M, BR);
      } else if (it.k === 'truck') {
        if (it.ramp) {
          const lowEnd = it.s - it.rampLen + it.rampLen * (TUNE.rampStep / TUNE.truckH) - 0.4;
          dpMark(it.lane, it.s - it.rampLen, lowEnd, RLO);
          dpMark(it.lane, lowEnd + 1e-3, it.s - 1e-3, RHI);
          dpMark(it.lane, it.s, it.s + it.len + PL, GB);
        } else dpMark(it.lane, it.s - PL - M, it.s + it.len + PL, GB);
        dpMark(it.lane, it.s, it.s + it.len - 0.3, RF);
      }
    }
    for (const r of G.resv) {
      dpMark(r.lane, r.wallA, r.wallB, GB);
      dpMark(r.lane, r.nsA, r.nsB, NS);
    }
    const ok = dpSolve(G.entryMask);
    if (!ok) return false;
    const ei = Math.min(DP.n - 1, dpCellOf(c.end));
    let exit = 0;
    for (let l = 0; l < 3; l++) if (okG(ei, l)) exit |= 1 << l;
    if (!exit) return false;
    c.exitMask = exit; c.endCell = ei;
    return true;
  }

  // ---- coins & pickups on proven cells --------------------------------------------
  function orb(c, lane, s, y, kind, x) {
    c.items.push({ k: 'orb', s, lane, y, kind, x: x === undefined ? LANE_X[lane] : x, key: s });
  }
  function segOK(l, a, b, roof) {
    const i0 = dpCellOf(a), i1 = dpCellOf(b);
    if (i0 < 0 || i1 >= DP.n) return false;
    for (let i = i0; i <= i1; i++) {
      if (roof ? !okR(i, l) : !okG(i, l)) return false;
      const f = FL[l][i];
      if (f & NS) return false;
      if (!roof && (f & (BR | RLO | RHI | RF))) return false;
    }
    return true;
  }
  function pickKind() { return R().wpick(KIND_W); }
  function placePickups(c) {
    const gapA = G.prevEnd + 1.5, gapB = (c.passive ? c.end : c.contentStart) - 2.5;
    const gl = TUNE.coinGap;
    // rows come faster at higher levels: pickups are per row gap, so scale them by the gap
    // to keep coins per SECOND (and the leaderboard economy) on the 2D build's curve
    const gs = G.attract ? 1 : rowGapT(c.L) / rowGapT(1);
    // (1) a coin line in the approach gap, on a lane that is reachable AND survivable
    if (gapB - gapA > gl * 2 && (R().chance(TUNE.coinLineP * gs) || G.intro)) {
      const want = R().i(TUNE.coinLineLen[0], TUNE.coinLineLen[1]);
      const n = Math.max(2, Math.min(want, Math.floor((gapB - gapA) / gl) + 1));
      const len = (n - 1) * gl;
      const a = gapA + R().f(0, Math.max(0, gapB - gapA - len));
      const lanes = R().shuffle([0, 1, 2]).filter(l => segOK(l, a - 1, a + len + 1, false));
      if (G.intro && lanes.includes(1)) lanes.unshift(1);
      if (lanes.length) {
        const l = lanes[0], kind = pickKind();
        const high = !G.intro && c.L >= 2 && R().chance(0.12);
        for (let i = 0; i < n; i++) orb(c, l, a + i * gl, high ? TUNE.orbHighY : TUNE.orbY, kind);
        c.coinLine = true;
      }
    }
    // (2) roof highways + ramp coins
    for (const t of c.trucks) {
      const l = t.lane;
      if (!R().chance(TUNE.roofCoinP * (0.35 + 0.65 * gs))) continue;
      let any = false;
      for (let s = t.s + 1.5; s <= t.s + t.len - 1.2; s += TUNE.roofCoinGap) {
        if (!okR(dpCellOf(s), l)) continue;
        orb(c, l, s, t.h + TUNE.orbY, R().wpick(ROOF_KIND_W)); any = true;
      }
      if (any && t.ramp && okG(dpCellOf(t.s - t.rampLen + 1), l)) {
        for (let k = 1; k <= 2; k++) {
          const s = t.s - t.rampLen + k * (t.rampLen / 3);
          orb(c, l, s, t.h * (s - (t.s - t.rampLen)) / t.rampLen + TUNE.orbY, 'watch');
        }
      }
    }
    // (3) arcs over barriers teach the jump
    if (c.barriers.length && R().chance(TUNE.arcP * gs)) {
      const b = R().pick(c.barriers);
      if (okG(dpCellOf(b.s - 4), b.lane) || okG(dpCellOf(b.s + 4), b.lane)) {
        const D = airtimeAt(c.v) * c.v, kind = pickKind();
        for (let k = -2; k <= 2; k++) {
          const off = k * D * 0.18, tau = 0.5 + off / D;
          const s = b.s + TUNE.barrierLen * 0.5 + off;
          const y = TUNE.orbY + 4 * TUNE.jumpApex * tau * (1 - tau);
          if (!FL[b.lane][dpCellOf(s)] || (FL[b.lane][dpCellOf(s)] & NS) === 0) orb(c, b.lane, s, y, kind);
        }
      }
    }
    // (4) a single pickup / T-sheet / power-up somewhere proven
    const wantPower = G.Tf >= G.nextPowerT;
    const wantSingle = R().chance(TUNE.singleP * gs) || wantPower;
    if (wantSingle) {
      let placed = false;
      if (wantPower && c.trucks.length && R().chance(TUNE.powerOnRoof)) {
        const t = R().pick(c.trucks), s = t.s + t.len * R().f(0.35, 0.7);
        if (okR(dpCellOf(s), t.lane) && !c.items.some(o => o.k === 'orb' && o.lane === t.lane && Math.abs(o.s - s) < 1.5)) {
          c.items.push({ k: 'pow', s, lane: t.lane, y: t.h + TUNE.powerY, kind: pickPower(), key: s });
          placed = true;
        }
      }
      if (!placed) {
        for (let tries = 0; tries < 6 && !placed; tries++) {
          const s = gapA + R().f(0, Math.max(0.1, gapB - gapA));
          const l = R().i(0, 2);
          if (!segOK(l, s - 1.2, s + 1.2, false)) continue;
          if (c.items.some(o => o.k === 'orb' && o.lane === l && Math.abs(o.s - s) < 1.5)) continue;
          if (wantPower) c.items.push({ k: 'pow', s, lane: l, y: TUNE.powerY, kind: pickPower(), key: s });
          else orb(c, l, s, TUNE.orbY, R().chance(TUNE.tsheetShare) ? 'tsheet' : pickKind());
          placed = true;
        }
      }
      if (placed && wantPower) {
        const ev = G.attract ? [10, 16] : TUNE.powerEvery;
        G.nextPowerT = G.Tf + R().f(ev[0], ev[1]);
      }
    }
  }
  function pickPower() { return R().wpick(TUNE.powerWeights); }

  function commit(c, kind) {
    if (G.debugCommit) G.debugCommit(c, kind, G.prevEnd, G.entryMask);
    placePickups(c);
    for (const it of c.items) it.ck = kind;
    c.items.sort((a, b) => a.key - b.key);
    const q = G.queue;
    for (const it of c.items) {                 // insert keeping the queue sorted by key
      let i = q.length;
      while (i > G.qHead && q[i - 1].key > it.key) i--;
      q.splice(i, 0, it);
    }
    const newEnd = c.end;
    G.Tf += sched.timeBetween(G.prevEnd, newEnd);
    G.prevEnd = newEnd;
    if (c.exitMask) G.entryMask = c.exitMask;
    G.lastKind = kind;
    G.sinceTruck = c.trucks.length ? 0 : G.sinceTruck + 1;
    G.debt = kind === 'breather' ? 0 : G.debt + (COST[kind] || 0);
    G.stats.chunks++; G.stats.kinds[kind] = (G.stats.kinds[kind] || 0) + 1;
    // drop reservations that are fully behind the design front
    for (let i = G.resv.length - 1; i >= 0; i--) if (G.resv[i].nsB < G.prevEnd - 300) G.resv.splice(i, 1);
  }

  function tryBuild(kind, L, v, al) {
    // templates have side effects (reservations, pending oncoming trucks, the jump-chain
    // marker): a rejected attempt must leave no trace
    const nResv = G.resv.length, nOn = G.oncoming.length, lastJump = G.lastJumpS;
    const undo = () => { G.resv.length = nResv; G.oncoming.length = nOn; G.lastJumpS = lastJump; return null; };
    const s0 = G.prevEnd + gapFor(kind, L, v);
    const c = newChunk(s0, L, v); c.kind = kind;
    if (kind === 'breather') T.breather(c, R().f(0.9, 1.5));
    else if (!T[kind](c, al)) return undo();
    if (c.end <= G.prevEnd) c.end = G.prevEnd + 1;
    const okv = verify(c);
    if (G.debugVerify) G.debugVerify(c, kind, okv);
    return okv ? c : undo();
  }

  function genChunk() {
    const s = G.prevEnd, L = sched.levelAt(s + 20), v = sched.speedAt(s + 20);
    // intro: nothing deadly for the first seconds, just a coin line to grab
    if (G.intro) {
      const c = newChunk(s, L, v); c.kind = 'intro';
      const dur = G.attract ? 2.5 : TUNE.introSafeT;
      c.end = s + Math.max(30, dur * v * 0.95); c.contentStart = c.end;
      if (verify(c)) { commit(c, 'intro'); G.intro = false; return; }
    }
    if (L !== G.levelSeen) {                    // arriving somewhere new: a short breath
      G.levelSeen = L;
      const c = newChunk(s + 2, L, v); c.kind = 'breather'; T.breather(c, R().f(0.6, 0.9));
      if (verify(c)) { commit(c, 'breather'); return; }
    }
    const al = allowedMask(s, s + 90);
    const debtMax = CV.breatherDebt(L);
    let kind = G.debt >= debtMax ? 'breather' : R().wpick(weights(L, G.Tf, al)) || 'mon';
    for (let attempt = 0; attempt < 10; attempt++) {
      const c = tryBuild(kind, L, v, al);
      if (c) {
        commit(c, kind);
        if (kind === 'oncoming') genChunk();    // the lane alongside is designed right away
        return;
      }
      G.stats.retries++;
      kind = attempt < 6 ? (R().wpick(weights(L, G.Tf, al)) || 'mon') : attempt < 8 ? 'mon' : 'breather';
    }
    // fallback: an empty stretch always verifies unless the entry state is already lost
    G.stats.fallbacks++;
    const c = newChunk(G.prevEnd + v * 0.5, L, v); T.breather(c, 1.2);
    if (!verify(c)) {
      // an entry lane is trapped by a planned oncoming truck: cancel the ones not yet on the road
      let dropped = false;
      for (let i = G.resv.length - 1; i >= 0; i--) {
        const r = G.resv[i];
        if (r.wallA > G.prevEnd - 1 && r.wallA < G.prevEnd + 80) {
          const k = G.oncoming.findIndex(o => o.lane === r.lane && Math.abs(o.sMeet - (r.wallA + 0.5 * v)) < 0.6 * v + 1);
          if (k >= 0) { G.oncoming.splice(k, 1); G.resv.splice(i, 1); dropped = true; }
        }
      }
      if (dropped && verify(c)) { commit(c, 'breather'); return; }
      G.stats.badFallbacks = (G.stats.badFallbacks || 0) + 1;
      if (G.debug) G.debug('fallback-fail', { prevEnd: G.prevEnd, entry: G.entryMask, resv: G.resv.map(r => ({ ...r })), last: G.lastKind });
      c.exitMask = 7;
    }
    commit(c, 'breather');
  }

  /** Design the road until the design front is `ahead` metres past dist. With maxChunks the
   *  work is spread over frames (one chunk per step keeps the design front far past the
   *  spawn horizon), unless the front is about to fall inside it. */
  G.ensure = (dist, ahead = TUNE.designAhead, maxChunks = 200) => {
    let n = 0;
    while (G.prevEnd < dist + ahead && (n < maxChunks || G.prevEnd < dist + TUNE.spawnAhead + 30) && n < 200) { genChunk(); n++; }
  };

  /** Pop blueprints whose footprint starts within reach; cb(bp) builds the entity. */
  G.release = (dist, cb) => {
    const q = G.queue, lim = dist + TUNE.spawnAhead;
    while (G.qHead < q.length && q[G.qHead].key <= lim) cb(q[G.qHead++]);
    if (G.qHead > 256) { q.splice(0, G.qHead); G.qHead = 0; }
  };

  return G;
}

/** verifier internals for tools/sim-test.mjs (not part of the runtime API) */
export const _dp = { dpInit, dpMark, dpSolve, okG, okR, DP, FL, REACH, ALIVE, GB, RF, RLO, RHI, BR, NS };
