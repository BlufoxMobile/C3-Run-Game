// SIM TUNE — every gameplay number in one commented block. Re-exported by sim.js as TUNE.
// Units: metres, seconds, m/s, $. Nothing here is read by renderers except through the
// sim state (CONTRACT §3); change freely, then re-run `node tools/sim-bot.mjs` and
// `node tools/sim-test.mjs`.
import { TRUCK_H, TRUCK_W, VIEW_AHEAD, VIEW_BEHIND, LANE_W } from '../core/constants.js';

export const TUNE = {
  // ---------------------------------------------------------------- integration
  substep:        1 / 60,   // physics never integrates more than this per substep
  dtMax:          0.1,      // a single step() never simulates more than this (tab switch)

  // ---------------------------------------------------------------- speed schedule (m/s)
  // Busy from the first second (Jeff: "make something happen"): 19 m/s at L1, +1.5 per
  // level, capped at 34 m/s from L11.
  speedStart:     17,       // at the very start of a run ...
  firstRampM:     50,       // ... easing up to speedL1 over this many metres (~3 s)
  speedL1:        19,
  speedStep:      1.5,      // per level
  speedCap:       34,       // reached at L11
  levelRampM:     60,       // speed eases from the old level speed to the new one over this
  attractSpeed:   19,       // title-screen bot speed (level 1 forever)

  // ---------------------------------------------------------------- level length
  // Each level lasts levelSec(L) seconds at that level's speed; the length in metres is
  // fixed when the level begins, so sim.nextLevelAt is known a whole level ahead.
  levelSecStart:  22,
  levelSecStep:   0.3,
  levelSecMin:    19,

  // ---------------------------------------------------------------- lane change (old feel)
  laneTime:       0.110,    // fixed tween
  laneOvershoot:  1.15,     // ease-out-back
  laneBuffer:     0.16,     // input buffer; only ages once the tween has settled
  leanRate:       14,       // lean easing (1/s)
  bounceTime:     0.13,     // tween back to the origin lane after a truck side-swipe

  // ---------------------------------------------------------------- jump
  jumpApex:       1.5,      // m above the take-off surface
  airtimeSlow:    0.62,     // airtime at speedL1 ...
  airtimeFast:    0.55,     // ... and at speedCap (gravity scales, apex stays)
  coyoteTime:     0.10,
  jumpBuffer:     0.18,
  jumpLagMax:     0.15,     // tap latency compensation cap ({a:'jump', lag} actions)
  landAnimT:      0.14,     // 'land' anim hold after touching down

  // ---------------------------------------------------------------- player box (generous)
  playerHalfW:    0.35,
  playerHalfL:    0.35,
  playerHalfLBarrier: 0.2,  // shorter body for barrier checks (forgiving hops)
  playerH:        1.6,

  // ---------------------------------------------------------------- obstacles (published)
  monsterW:       1.4,  monsterH: 2.1, monsterLen: 0.8,
  barrierW:       2.1,  barrierH: 1.0, barrierLen: 0.5,
  barrierClearTol: 0.6,     // feet this far under the top still clear (0.4 m clears a 1 m
                            // barrier, like the 2D build's ~15%-of-jump rule): the takeoff
                            // window spans ~0.43-0.46 s of travel at every speed
  driftTime:      0.45,     // a drifting monster slides one lane over this long ...
  driftTriggerT:  1.10,     // ... starting when it is this many seconds from the fox ...
  driftTriggerMin: 0.75,    // ... shrinking 0.05 s per level to this

  // ---------------------------------------------------------------- trucks
  truckH:         TRUCK_H,  truckW: TRUCK_W,
  rampLen:        7,
  roofTol:        0.45,     // reaching a truck front this close under the roof = mantle up
  rampStep:       0.9,      // sideways onto a ramp: allowed while the ramp is this low
  semiLen:        [16, 24], boxLen: [9, 12], busLen: [12, 14],
  busFromTheme:   8,        // city stages (themeIdx >= 8) run buses
  oncomingV:      [-8, -14],
  bumpStumble:    0.6,

  // ---------------------------------------------------------------- pickups
  orbY:           0.9,      // centre height of a ground orb (fox body centre)
  orbHighY:       2.55,     // "jump for it" orbs
  orbReachX:      1.1,
  orbReachY:      1.0,
  coinGap:        2.4,
  powerY:         1.0,
  powerReach:     1.2,
  magnetRange:    30,       // orbs this far ahead fly to the fox
  magnetBehind:   2,
  magnetFlyT:     0.32,

  // ---------------------------------------------------------------- scoring (old economy)
  // passive $/s = (passiveBase + passivePerSpeed * oldSpeed) * passiveScale, where
  // oldSpeed maps this build's speedL1..speedCap onto the 2D build's 4.4..12.
  passiveBase:    2,   passivePerSpeed: 0.6,
  oldSpeedLo:     4.4, oldSpeedHi: 12,
  passiveScale:   0.62,     // levels last ~1.8x longer than in 2D: keep $/level comparable
  // The faster/denser 9/25 pace roughly 2.5x'd the $ per level. payScale brings orb, near-miss
  // and passive pay back so the shared leaderboard stays comparable with scores already posted.
  payScale:       0.39,
  comboMax:       9,
  comboWindow:    1.6,
  orbLevelMult:   0.15,
  nearMissPay:    25,       // x combo
  nearMissWindow: 0.30,     // obstacle passes the lane you left within this of the swipe
  nearMissBand:   0.45,     // ...or passes laterally this close outside the hit box
  shieldMax:      3,
  tsheetBonusEvery: 5, tsheetBonus: 100,
  shieldInvuln:   0.9,

  // ---------------------------------------------------------------- power-ups
  powerFirstT:    [9, 11],  // first one lands in this window of run time
  powerEvery:     [18, 28],
  powerWeights:   { magnet: 0.38, x2: 0.32, boost: 0.30 },
  powerOnRoof:    0.55,     // chance to put it on a roof when a roof route exists
  powerWarnAt:    2,
  boostY:         4.8,
  boostMult:      1.55,
  boostRise:      9,        // rise rate (1/s, exponential)
  boostSpeedRate: 6,        // speed multiplier easing (1/s)
  boostDescendG:  0.6,      // gravity scale on the way down
  boostInvuln:    1.0,
  boostLandInvuln: 0.35,    // minimum invuln left on touchdown
  riverDt:        0.13,     // one river coin per this many seconds of boost flight
  riverRun:       [5, 9],   // coins per lane before the river swings

  // ---------------------------------------------------------------- death
  deathTime:      1.0,      // 'dying' lasts this long (sim time) before 'over'
  deathStopT:     0.4,      // forward speed eases to 0 over this

  // ---------------------------------------------------------------- spawning
  spawnAhead:     146,      // entities appear this far ahead (fog hides VIEW_AHEAD)
  designAhead:    250,      // the generator designs this far ahead
  viewBehind:     VIEW_BEHIND,
  rowGapStart:    0.75,     // seconds between obstacle rows at L1 ...
  rowGapStep:     0.0675,   // ... shrinking per level ...
  rowGapMin:      0.48,     // ... to this floor (L5; then speed, and after L11 COMPLEXITY, climb)
  rowGapJitter:   [0.92, 1.18],
  jumpChainGap:   0.74,     // two rows that both need a jump are at least this far apart (s)
  introSafeT:     2,        // nothing deadly in the first 2 s (a coin line at once)
  introNoTruckT:  8,        // no trucks in the first 8 s
  oncomingFrom:   3,        // oncoming trucks from this level
  mixedFrom:      3,        // monster+monster+barrier rows
  mazeFrom:       4,        // staggered truck mazes
  driftFrom:      5,        // drifting monsters
  dgateFrom:      5,        // double gates
  complexFrom:    11,       // speed caps here; complexity keeps climbing after it
  // verifier (every generated chunk is proven solvable on a lane grid)
  dpCell:         0.5,      // m
  dpLaneT:        0.15,     // s of track a lane change is given (tween is 0.11)
  dpMargin:       0.5,      // m of clearance around blockers
  // economy of the layout
  coinLineP:      0.85,     // chance of a coin line in a row gap (x rowGapT(L)/rowGapT(1))
  zigzagP:        0.45,     // share of coin lines that swing across a lane (pull the fox over)
  arcP:           0.75,     // chance of a coin arc over a barrier in a chunk (x the same)
  coinLineLen:    [4, 7],
  breatherT:      [0.45, 0.75],   // a breather's length (s) — always carries a coin line
  singleP:        0.065,    // chance of a single pickup in a row gap (x gap scale)
  tsheetShare:    0.16,     // of single pickups (old build)
  roofCoinP:      0.85,     // chance a reachable roof carries a coin highway ...
  roofCoinGap:    4.8,      // ... one coin every this many metres

  // ---------------------------------------------------------------- the road's pattern mix
  // Chunk-template weights by level L (0 = not yet). The generator additionally requires all
  // three lanes free (no oncoming-truck lane) for gate/mixed/drift/wall/maze/oncoming, and
  // trucks only after introNoTruckT with two non-truck chunks between set pieces.
  weights: {
    mon:       L => 27,                                                    // 1-2 monsters
    bar:       L => 8 + Math.min(7, L * 0.8),                              // 1-2 barriers
    gate:      L => L >= 2 ? 3 + Math.min(5, L * 0.6) : 0,                 // 3 barriers (double later)
    monbar:    L => L >= 2 ? 7 + Math.min(10, L) : 0,                      // monster + barrier
    mixed:     L => L >= TUNE.mixedFrom ? Math.min(18, (L - TUNE.mixedFrom + 1) * 3) : 0,   // 2 monsters + barrier
    stagger:   L => L >= 2 ? Math.min(30, 6 + (L - 2) * 3.4) : 0,          // zig-zag rows
    drift:     L => L >= TUNE.driftFrom ? Math.min(26, 8 + (L - TUNE.driftFrom) * 2.5) : 0,  // sliding monster
    rampTruck: L => 6.5,                                                   // parked truck + ramp
    twin:      L => L >= 2 ? 4.5 : 0,                                      // two trucks, one ramp
    wall:      L => L >= 2 ? 3 + Math.min(4, L * 0.4) : 0,                 // truck wall + rows alongside
    maze:      L => L >= TUNE.mazeFrom ? Math.min(14, 5 + (L - TUNE.mazeFrom) * 2) : 0,     // staggered trucks
    oncoming:  L => L >= TUNE.oncomingFrom ? 6 + Math.min(14, (L - TUNE.oncomingFrom) * 2) : 0,
  },
  // Row-composition / complexity curves by level L
  curves: {
    twoTall:       L => 0.38 + Math.min(0.5, L * 0.07),                    // P(monster row blocks 2 lanes)
    drift:         L => L < TUNE.driftFrom ? 0 : Math.min(0.7, 0.3 + (L - TUNE.driftFrom) * 0.06),  // P(a row's monster slides)
    doubleGate:    L => L < TUNE.dgateFrom ? 0 : Math.min(0.5, 0.15 + (L - TUNE.dgateFrom) * 0.04),
    driftTrig:     L => Math.max(TUNE.driftTriggerMin, TUNE.driftTriggerT - Math.max(0, L - TUNE.driftFrom) * 0.05),
    barPair:       L => Math.min(0.45, 0.12 + L * 0.03),                   // P(barrier row has 2 barriers)
    staggerTight:  L => Math.max(0.4, 0.7 - (L - 2) * 0.05),              // 2nd zig-zag row at this x row gap
    staggerSide:   L => Math.min(0.6, 0.15 + L * 0.05),                    // P(zig-zag row 1 blocks 2 lanes), L>=5
    staggerThird:  L => Math.min(0.6, 0.25 + (L - 6) * 0.06),              // P(third zig-zag row), L>=6
    truckAlongside: L => Math.min(0.8, 0.35 + L * 0.05),                   // P(a row beside a ramp truck), L>=2
    twinThird:     L => Math.min(0.7, 0.25 + L * 0.04),                    // P(hazard in the twin set's 3rd lane), L>=3
    breatherDebt:  L => 24 + Math.min(16, L * 1.5),                        // row "cost" before a breather
  },
};

// derived helpers --------------------------------------------------------------
export const LANES = 3;
export { LANE_W, VIEW_AHEAD };

export function levelSpeed(L) { return Math.min(TUNE.speedCap, TUNE.speedL1 + (L - 1) * TUNE.speedStep); }
export function levelSec(L) { return Math.max(TUNE.levelSecMin, TUNE.levelSecStart - (L - 1) * TUNE.levelSecStep); }
export function levelLength(L) { return Math.round(levelSec(L) * levelSpeed(L)); }
export function rowGapT(L) { return Math.max(TUNE.rowGapMin, TUNE.rowGapStart - (L - 1) * TUNE.rowGapStep); }
/** Airtime of a jump at forward speed v (gravity scales so the apex stays jumpApex). */
export function airtimeAt(v) {
  const u = Math.max(0, Math.min(1, (v - TUNE.speedL1) / (TUNE.speedCap - TUNE.speedL1)));
  return TUNE.airtimeSlow + (TUNE.airtimeFast - TUNE.airtimeSlow) * u;
}
export function gravityAt(v) { const T = airtimeAt(v); return 8 * TUNE.jumpApex / (T * T); }
export function jumpVelAt(v) { return 4 * TUNE.jumpApex / airtimeAt(v); }
/** Passive commission $/s at forward speed v (before x2). */
export function passiveRate(v) {
  const u = (v - TUNE.speedL1) / (TUNE.speedCap - TUNE.speedL1);
  const old = TUNE.oldSpeedLo + (TUNE.oldSpeedHi - TUNE.oldSpeedLo) * Math.max(-0.4, Math.min(1, u));
  return (TUNE.passiveBase + TUNE.passivePerSpeed * old) * TUNE.passiveScale;
}
