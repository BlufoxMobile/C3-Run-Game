// PLAYER PHYSICS + COLLISION GEOMETRY — shared by the live sim (sim.js) and the bot's
// look-ahead ghost (sim-bot.js), so a plan the bot proves safe is safe in the real sim.
// Pure functions over plain objects; no allocation in the hot path.
import { LANE_X } from '../core/constants.js';
import { TUNE, gravityAt, jumpVelAt } from './sim-tune.js';

export const AIR_NONE = 0, AIR_JUMP = 1, AIR_FALL = 2, AIR_BOOST = 3;
export const SURF_ROAD = 0, SURF_RAMP = 1, SURF_ROOF = 2;
// stepVertical() result flags
export const V_LAND = 1, V_DROP = 2, V_RAMP = 4, V_ROOF = 8, V_JUMP = 16;
// probeTruck() results
export const T_NONE = 0, T_FRONT = 1, T_SIDE = 2, T_OVER = 3, T_INSIDE = 4;

const PW = () => TUNE.playerHalfW;

/** ease-out-back, the lane tween curve (overshoot TUNE.laneOvershoot) */
export function easeBack(p) {
  const u = p - 1, c1 = TUNE.laneOvershoot, c3 = c1 + 1;
  return 1 + c3 * u * u * u + c1 * u * u;
}
export function laneOfX(x) { return x < -1.3 ? 0 : x > 1.3 ? 2 : 1; }

export function newPlayerState() {
  return {
    lane: 1, fromLane: 1, laneT: 1, x: 0, x0: 0, prevX: 0, laneDur: TUNE.laneTime,
    bufDir: 0, bufT: 0, bouncing: false,
    y: 0, vy: 0, grounded: true, g: gravityAt(TUNE.speedL1), air: AIR_NONE,
    surfY: 0, surfKind: SURF_ROAD, surfTruck: null,
    jumpBuf: 0, coyote: 0,
    stumbleT: 0, lcAge: 99, lcFrom: 1,
    boost: 0,            // 0 none, 1 flying, 2 descending after a boost
    landT: 0, impact: 0,
  };
}

export function copyPlayerState(dst, src) {
  dst.lane = src.lane; dst.fromLane = src.fromLane; dst.laneT = src.laneT; dst.x = src.x; dst.x0 = src.x0;
  dst.prevX = src.prevX; dst.laneDur = src.laneDur; dst.bufDir = src.bufDir; dst.bufT = src.bufT;
  dst.bouncing = src.bouncing; dst.y = src.y; dst.vy = src.vy; dst.grounded = src.grounded; dst.g = src.g;
  dst.air = src.air; dst.surfY = src.surfY; dst.surfKind = src.surfKind; dst.surfTruck = src.surfTruck;
  dst.jumpBuf = src.jumpBuf; dst.coyote = src.coyote; dst.stumbleT = src.stumbleT; dst.lcAge = src.lcAge;
  dst.lcFrom = src.lcFrom; dst.boost = src.boost; dst.landT = src.landT; dst.impact = src.impact;
  return dst;
}

// ------------------------------------------------------------------------ lateral
function startLane(ps, n) {
  ps.fromLane = ps.lane; ps.lcFrom = ps.lane; ps.lane = n;
  ps.x0 = ps.x; ps.laneT = 0; ps.laneDur = TUNE.laneTime; ps.bouncing = false;
  ps.bufDir = 0; ps.bufT = 0; ps.lcAge = 0;
}
/** A lane press. Returns 1 moved, 2 buffered (mid-tween), 0 blocked by the road edge. */
export function pressLane(ps, dir) {
  if (ps.laneT < 1) { ps.bufDir = dir; ps.bufT = TUNE.laneBuffer; return 2; }
  const n = Math.max(0, Math.min(2, ps.lane + dir));
  if (n === ps.lane) return 0;
  startLane(ps, n);
  return 1;
}
/** Bounce back to the origin lane after a side-swipe. */
export function bounceBack(ps) {
  const origin = ps.fromLane;
  ps.fromLane = ps.lane; ps.lane = origin;
  ps.x0 = ps.x; ps.laneT = 0; ps.laneDur = TUNE.bounceTime; ps.bouncing = true;
  ps.bufDir = 0; ps.bufT = 0;
}
/** Advance the lane tween. Returns +-1 when a BUFFERED press starts a lane change this
 *  substep, +-2 when a buffered press hit the road edge (sign = direction), else 0. */
export function stepLateral(ps, dt) {
  ps.prevX = ps.x;
  ps.lcAge += dt;
  if (ps.laneT < 1) {
    ps.laneT = Math.min(1, ps.laneT + dt / ps.laneDur);
    ps.x = ps.x0 + (LANE_X[ps.lane] - ps.x0) * easeBack(ps.laneT);
    if (ps.laneT >= 1) {
      ps.x = LANE_X[ps.lane]; ps.bouncing = false;
      if (ps.bufDir !== 0 && ps.bufT > 0) {
        const d = ps.bufDir; ps.bufDir = 0; ps.bufT = 0;
        return pressLane(ps, d) === 1 ? d : 2 * d;
      }
    }
  } else {
    ps.x = LANE_X[ps.lane];
    if (ps.bufT > 0) { ps.bufT -= dt; if (ps.bufT <= 0) { ps.bufT = 0; ps.bufDir = 0; } }
  }
  return 0;
}

// ------------------------------------------------------------------------ surfaces
export const SURF = { h: 0, kind: SURF_ROAD, truck: null };
/** Height of the walkable surface in lane li at track position s (road 0, ramp, roof). */
export function surfaceAt(trucks, li, s) {
  let h = 0, kind = SURF_ROAD, tr = null;
  for (let i = 0; i < trucks.length; i++) {
    const t = trucks[i];
    if (t.lane !== li) continue;
    if (s >= t.s && s <= t.s + t.len) { if (t.h >= h) { h = t.h; kind = SURF_ROOF; tr = t; } }
    else if (t.ramp && s >= t.s - t.rampLen && s < t.s) {
      const rh = t.h * (s - (t.s - t.rampLen)) / t.rampLen;
      if (rh > h) { h = rh; kind = SURF_RAMP; tr = t; }
    }
  }
  SURF.h = h; SURF.kind = kind; SURF.truck = tr;
  return h;
}

// ------------------------------------------------------------------------ vertical
/** Consume a buffered jump if allowed. Returns true when a jump starts. */
export function tryJump(ps, speed) {
  if (ps.jumpBuf <= 0 || ps.boost !== 0) return false;
  if (!ps.grounded && ps.coyote <= 0) return false;
  ps.vy = jumpVelAt(speed); ps.g = gravityAt(speed);
  ps.grounded = false; ps.air = AIR_JUMP; ps.coyote = 0; ps.jumpBuf = 0;
  ps.surfTruck = null; ps.surfKind = SURF_ROAD;
  return true;
}

/** Vertical integration against the surface under the fox. Returns V_* flags. */
export function stepVertical(ps, dt, trucks, dist, speed) {
  let flags = 0;
  if (ps.jumpBuf > 0) ps.jumpBuf = Math.max(0, ps.jumpBuf - dt);
  if (ps.coyote > 0) ps.coyote = Math.max(0, ps.coyote - dt);
  if (ps.landT > 0) ps.landT = Math.max(0, ps.landT - dt);
  if (ps.boost === 1) {                                     // Gig Boost flight
    const k = 1 - Math.exp(-TUNE.boostRise * dt);
    const ny = ps.y + (TUNE.boostY - ps.y) * k;
    ps.vy = (ny - ps.y) / dt; ps.y = ny;
    ps.grounded = false; ps.air = AIR_BOOST; ps.surfTruck = null; ps.surfKind = SURF_ROAD;
    surfaceAt(trucks, laneOfX(ps.x), dist); ps.surfY = SURF.h;
    return 0;
  }
  if (tryJump(ps, speed)) flags |= V_JUMP;
  const H = surfaceAt(trucks, laneOfX(ps.x), dist);
  ps.surfY = H;
  if (ps.grounded) {
    if (H < ps.y - 0.05) {                                  // support fell away (roof end)
      ps.grounded = false; ps.vy = 0; ps.g = gravityAt(speed); ps.air = AIR_FALL;
      ps.coyote = TUNE.coyoteTime;
      if (ps.y > 1) flags |= V_DROP;
      ps.surfTruck = null; ps.surfKind = SURF_ROAD;
    } else if (H <= ps.y + TUNE.rampStep) {                 // follow it (ramps rise gently)
      ps.y = H;
      if (SURF.truck !== ps.surfTruck || SURF.kind !== ps.surfKind) {
        if (SURF.kind === SURF_RAMP && ps.surfKind !== SURF_RAMP) flags |= V_RAMP;
        if (SURF.kind === SURF_ROOF && (ps.surfKind !== SURF_ROOF || SURF.truck !== ps.surfTruck)) flags |= V_ROOF;
        ps.surfTruck = SURF.truck; ps.surfKind = SURF.kind;
      }
    }
    // else: a wall higher than a step is beside us — probeTruck() reports the side-swipe
  } else {
    ps.vy -= ps.g * dt; ps.y += ps.vy * dt;
    if (SURF.kind === SURF_RAMP && ps.y < H && ps.y >= H - TUNE.rampStep - 0.6) {
      // at speed a ramp rises faster than a jump: it carries the fox up (and catches it
      // when it outruns the jump) instead of letting it sink into the ramp
      const rise = (SURF.truck.h / SURF.truck.rampLen) * speed;
      ps.y = H;
      if (ps.vy <= rise) {
        ps.impact = Math.max(0, rise - ps.vy);
        ps.vy = 0; ps.grounded = true; ps.air = AIR_NONE; ps.landT = TUNE.landAnimT;
        if (ps.boost === 2) ps.boost = 0;
        flags |= V_LAND | V_RAMP; ps.surfTruck = SURF.truck; ps.surfKind = SURF_RAMP;
      }
      return flags;
    }
    if (ps.vy <= 0 && ps.y <= H && ps.y >= H - TUNE.roofTol) {
      ps.impact = -ps.vy;
      ps.y = H; ps.vy = 0; ps.grounded = true; ps.air = AIR_NONE; ps.landT = TUNE.landAnimT;
      if (ps.boost === 2) ps.boost = 0;
      flags |= V_LAND;
      if (SURF.kind === SURF_RAMP) flags |= V_RAMP;
      if (SURF.kind === SURF_ROOF) flags |= V_ROOF;
      ps.surfTruck = SURF.truck; ps.surfKind = SURF.kind;
    } else if (ps.y <= 0 && ps.vy <= 0) {                   // floor (inside a bounce-out)
      ps.impact = -ps.vy;
      ps.y = 0; ps.vy = 0; ps.grounded = true; ps.air = AIR_NONE; ps.landT = TUNE.landAnimT;
      if (ps.boost === 2) ps.boost = 0;
      flags |= V_LAND; ps.surfTruck = null; ps.surfKind = SURF_ROAD;
    }
  }
  return flags;
}

/** Snap onto a truck roof (mantle / shield vault). */
export function snapToRoof(ps, t) {
  ps.y = t.h; ps.vy = 0; ps.grounded = true; ps.air = AIR_NONE;
  ps.surfTruck = t; ps.surfKind = SURF_ROOF; ps.surfY = t.h;
  if (ps.boost === 2) ps.boost = 0;
}

// ------------------------------------------------------------------------ collision probes
/** Monster / barrier vs the fox over one substep (swept in s).
 *  0 no contact, 1 contact (hit), 2 passing above it (barrier hopped). */
export function probeObstacle(o, ps, prevDist, dist) {
  const PL = TUNE.playerHalfL;
  if (o.s > dist + PL || o.s + o.len < prevDist - PL) return 0;
  if (Math.abs(o.x - ps.x) >= o.w * 0.5 + TUNE.playerHalfW) return 0;
  const top = o.type === 'barrier' ? o.h - TUNE.barrierClearTol : o.h;
  return ps.y >= top ? 2 : 1;
}

/** Truck body vs the fox over one substep. t._ps is the truck's near end last substep.
 *  T_FRONT: ran into its face below roof level (fatal); T_SIDE: swerved into its flank
 *  (bump); T_OVER: overlapping at roof level (mantle / on top); T_INSIDE: already overlapping. */
export function probeTruck(t, ps, prevDist, dist) {
  const PL = TUNE.playerHalfL, half = t.w * 0.5 + TUNE.playerHalfW;
  const latNow = Math.abs(t.x - ps.x) < half;
  if (!latNow) return T_NONE;
  const latPrev = Math.abs(t.x - ps.prevX) < half;
  if (t.ramp && !latPrev && dist >= t.s - t.rampLen && dist < t.s) {     // ramp flank
    const rh = t.h * (dist - (t.s - t.rampLen)) / t.rampLen;
    if (rh > ps.y + TUNE.rampStep) return T_SIDE;
  }
  if (dist - PL >= t.s + t.len || dist + PL <= t.s) return T_NONE;      // not alongside
  if (ps.y >= t.h - TUNE.roofTol) return T_OVER;
  const sPrev = prevDist + PL > t._ps && prevDist - PL < t._ps + t.len;
  if (!sPrev) return T_FRONT;            // its face reached us (even mid-swerve)
  return latPrev ? T_INSIDE : T_SIDE;
}
