// THE BOT — plays the real sim through the real physics. Used for the title-screen attract
// mode (profile 'perfect') and by tools/sim-bot.mjs to prove every level is solvable and to
// tune difficulty against human-like profiles.
//
// Each plan is a depth-first search over actions {none, left, right, jump} every DT seconds
// through a GHOST of the player that runs the same sim-phys.js functions as the sim, against
// the entities the bot currently KNOWS (within `vis` metres, seen for >= `reaction` s).
// The world timeline (distance, speed, boost, truck motion, drifts) does not depend on the
// player's actions, so it is precomputed once per plan. Failures are memoised per
// (decision, player state), so a plan costs a few hundred ghost substeps on average.
//
// Human profiles add: reaction delay on new information, a shorter planning horizon,
// Gaussian timing jitter, attention lapses (no new information for a moment), wrong-way and
// missed swipes, and a preference for the lane that stays open longest (early dodges).
import { LANE_X } from '../core/constants.js';
import { TUNE, gravityAt } from './sim-tune.js';
import * as P from './sim-phys.js';
import { makeRng } from './sim-rng.js';

export const BOT_PROFILES = {
  // reaction: s to understand ONE new thing (a row, a truck, a drift starting), serially
  // vis:      readable distance (m)        planT: how far ahead a plan looks (s)
  // margin:   s of clearance wanted before touching a hazard (zero-margin plans only as a fallback)
  // jitter:   s.d. of swipe/tap timing     lapse*: freezes (nothing pressed, nothing new seen)
  // wrongP / missP: per-swipe chance of the wrong direction / an unregistered swipe
  perfect: { name: 'perfect', reaction: 0,    vis: 70, planT: 2.6, margin: 0.03, jitter: 0,     lapseRate: 0,    lapseT: [0, 0],       wrongP: 0,     missP: 0,     safeW: 0.15, greed: 1,   roofLove: 3, replan: 0.12 },
  // the title-screen bot: perfect play with a lighter search (a phone must not hitch on it)
  attract: { name: 'attract', reaction: 0,    vis: 70, planT: 2.0, margin: 0.03, jitter: 0,     lapseRate: 0,    lapseT: [0, 0],       wrongP: 0,     missP: 0,     safeW: 0.15, greed: 1,   roofLove: 3, replan: 0.15, maxNodes: 900 },
  good:    { name: 'good',    driftTelegraph: true, reaction: 0.25, vis: 70, planT: 1.4, margin: 0.10, jitter: 0.040, lapseRate: 0.05, lapseT: [0.25, 0.45], wrongP: 0.015, missP: 0.020, safeW: 1.0,  greed: 1,   roofLove: 1, replan: 0.18 },
  casual:  { name: 'casual',  driftTelegraph: true, reaction: 0.40, vis: 70, planT: 0.9, margin: 0.15, jitter: 0.070, lapseRate: 0.10, lapseT: [0.3, 0.6],   wrongP: 0.035, missP: 0.050, safeW: 1.0,  greed: 0.7, roofLove: 0.5, replan: 0.22 },
};

const A_NONE = 0, A_LEFT = 1, A_RIGHT = 2, A_JUMP = 4;
const H = 1 / 60;                 // ghost substep (matches the sim's TUNE.substep)
const DSUB = 2;                   // substeps per decision
const DT = H * DSUB;
const MAXD = 170;                 // max decisions per plan
const MAXN = MAXD * DSUB + 2;
const MAX_NODES = 5000;             // default search budget per plan (profile.maxNodes overrides)

export function createBot(sim, profile = BOT_PROFILES.perfect, seed = 12345) {
  const prof = Object.assign({}, BOT_PROFILES.perfect, profile);
  const maxNodes = prof.maxNodes || MAX_NODES;
  const rng = makeRng(seed);
  const seen = new Map();          // entity id -> sim time first within vis
  const noticed = new Map();       // drifter id -> time the drift was noticed
  const out = [];
  // plan
  const plan = new Int8Array(MAXD); let planLen = 0, planT0 = -1, planOk = false, lastPlanT = -1, planSig = -1;
  const pending = [];              // human execution queue {t, a}
  let lapseUntil = -1, nextLapseT = -1, dirty = false, lastKnownCount = 0;

  // ---------------------------------------------------------------- ghost world (per plan)
  const gTr = [], gOb = [], gOrbs = [];
  const tl = {
    n: 0, prev: new Float64Array(MAXN), dist: new Float64Array(MAXN), base: new Float64Array(MAXN),
    inv: new Float64Array(MAXN), fly: new Uint8Array(MAXN), bend: new Uint8Array(MAXN), speed: new Float64Array(MAXN),
  };
  const truckPool = [], obPool = [];
  const driftX = [];               // per ghost obstacle: Float64Array or null
  const gp = P.newPlayerState();   // ghost player
  const snaps = []; for (let i = 0; i <= MAXD + 1; i++) snaps.push({ ps: P.newPlayerState(), landInv: 0 });
  // failure memo: open-addressing hash set over Float64Array keys, cleared by bumping a stamp
  const FCAP = 16384, fKeys = new Float64Array(FCAP), fStamp = new Uint32Array(FCAP);
  let fGen = 1, fCount = 0;
  const fails = {
    clear() { fGen++; fCount = 0; if (fGen > 0xfffffff0) { fStamp.fill(0); fGen = 1; } },
    _slot(key) { let h = (key * 2654435761) % FCAP; if (h < 0) h += FCAP; return h | 0; },
    has(key) {
      let i = this._slot(key);
      for (let n = 0; n < FCAP; n++) { if (fStamp[i] !== fGen) return false; if (fKeys[i] === key) return true; i = (i + 1) & (FCAP - 1); }
      return false;
    },
    add(key) {
      if (fCount > FCAP * 0.7) return;          // full enough: stop memoising (search is bounded anyway)
      let i = this._slot(key);
      for (let n = 0; n < FCAP; n++) { if (fStamp[i] !== fGen) { fStamp[i] = fGen; fKeys[i] = key; fCount++; return; } if (fKeys[i] === key) return; i = (i + 1) & (FCAP - 1); }
    },
    get size() { return fCount; },
  };
  let nodes = 0, bestDepth = 0, gLandInv = 0, distLimit = 0, K = 0, gMarginM = 0;
  const bestPath = new Int8Array(MAXD), curPath = new Int8Array(MAXD);

  function known(e) { return seen.has(e.id); }
  // Serial attention: a human understands one new thing (an obstacle row, a truck, a drift
  // starting) per `reaction` seconds, nearest first. Coins are peripheral (known at once).
  let attnItem = null, attnT = 0;
  const attnScratch = [];
  function updateKnowledge(now, dt) {
    const lim = sim.dist + prof.vis;
    if (prof.reaction <= 0) {
      let cnt = 0;
      for (const o of sim.obstacles) if (o.s - sim.dist <= prof.vis) { if (!seen.has(o.id)) { seen.set(o.id, now); cnt++; } if (o.drift && o.drift.armed && !noticed.has(o.id)) { noticed.set(o.id, { t: now, used: true }); cnt++; } }
      for (const t of sim.trains) if (t.s - (t.ramp ? t.rampLen : 0) <= lim && !seen.has(t.id)) { seen.set(t.id, now); cnt++; }
      if (cnt) dirty = true;
    } else {
      // the nearest thing not yet understood (a drift that started counts as a new thing)
      if (!attnItem) {
        let best = null, bestS = Infinity, kind = 0;
        for (const o of sim.obstacles) {
          if (o.s - sim.dist > prof.vis || o.s + o.len < sim.dist) continue;
          if (!seen.has(o.id)) { if (o.s < bestS) { bestS = o.s; best = o; kind = 1; } }
          else if (o.drift && o.drift.armed && !noticed.has(o.id) && o.s < bestS) { bestS = o.s; best = o; kind = 2; }
        }
        for (const t of sim.trains) {
          const k = t.s - (t.ramp ? t.rampLen : 0);
          if (k > lim || t.s + t.len < sim.dist || seen.has(t.id)) continue;
          if (k < bestS) { bestS = k; best = t; kind = 3; }
        }
        if (best) { attnItem = { e: best, kind, s: bestS }; attnT = 0; }
      }
      if (attnItem) {
        attnT += dt;
        if (attnT >= prof.reaction - 1e-9) {
          const it = attnItem; attnItem = null;
          if (it.kind === 2) noticed.set(it.e.id, { t: now - prof.reaction, used: true });
          else if (it.kind === 3) seen.set(it.e.id, now - prof.reaction);
          else {                                   // the whole row at once
            attnScratch.length = 0;
            for (const o of sim.obstacles) if (!seen.has(o.id) && Math.abs(o.s - it.s) < 4) seen.set(o.id, now - prof.reaction);
          }
          dirty = true;
        }
      }
    }
    if (seen.size > 600) { for (const [id, t] of seen) if (now - t > 30) seen.delete(id); }
    if (noticed.size > 200) { for (const [id, n] of noticed) if (now - n.t > 30) noticed.delete(id); }
  }

  function buildGhost(now) {
    const ps = sim._ps, sched = sim._sched;
    const horizonT = Math.min(prof.planT, (MAXD - 1) * DT);
    K = Math.max(4, Math.floor(horizonT / DT));
    const N = K * DSUB;
    // timeline (independent of the player's actions)
    let d = sim.dist, bm = sim._boostMul ? sim._boostMul() : 1, pb = sim.power.boost, inv = sim.invuln;
    tl.n = N; tl.dist[0] = d;
    for (let i = 1; i <= N; i++) {
      const base = sim.devSpeed > 0 ? sim.devSpeed : sched.speedAt(d), want = pb > 0 ? TUNE.boostMult : 1;
      bm += (want - bm) * (1 - Math.exp(-TUNE.boostSpeedRate * H));
      const sp = base * bm;
      tl.prev[i] = d; d += sp * H; tl.dist[i] = d; tl.base[i] = base; tl.speed[i] = sp;
      tl.inv[i] = inv; tl.fly[i] = pb > 0 ? 1 : 0; tl.bend[i] = 0;
      inv = Math.max(0, inv - H);
      if (pb > 0) { pb = Math.max(0, pb - H); if (pb === 0) { tl.bend[i] = 1; inv = Math.max(inv, TUNE.boostInvuln); } }
    }
    distLimit = sim.dist + prof.vis - 2;
    P.jumpWindow(tl.speed[1], tl.base[1], JW);
    // known trucks
    gTr.length = 0;
    const lim = sim.dist + prof.vis;
    for (const t of sim.trains) {
      if (t.s + t.len < sim.dist - 3) continue;
      if (t.s - (t.ramp ? t.rampLen : 0) > lim || !known(t, now)) continue;
      const g = truckPool[gTr.length] || (truckPool[gTr.length] = {});
      g.id = t.id; g.lane = t.lane; g.x = t.x; g.s0 = t.s; g.s = t.s; g._ps = t.s; g.v = t.v; g.len = t.len;
      g.h = t.h; g.w = t.w; g.ramp = t.ramp; g.rampLen = t.rampLen; g.kind = t.kind;
      gTr.push(g);
    }
    // known obstacles (+ drift timelines)
    gOb.length = 0;
    for (const o of sim.obstacles) {
      if (o.hit || o.smashed || o.s + o.len < sim.dist - 2 || o.s - sim.dist > prof.vis || !known(o, now)) continue;
      const i = gOb.length;
      const g = obPool[i] || (obPool[i] = {});
      g.id = o.id; g.type = o.type; g.lane = o.lane; g.x = o.x; g.s = o.s; g.w = o.w; g.h = o.h; g.len = o.len;
      g.x0 = o.x; g.dr = 0;
      const d0 = o.drift;
      const perfectKnows = prof.reaction === 0;
      // the renderer telegraphs a drifter (chevrons) from the moment it appears, so a human
      // who has read the row knows it will slide; the reaction delay covers reading it
      const humanKnows = !!d0 && (prof.driftTelegraph ? true : d0.armed && noticed.has(o.id));
      if (d0 && d0.t < d0.dur && (perfectKnows || humanKnows)) {
        let arr = driftX[i]; if (!arr) arr = driftX[i] = new Float64Array(MAXN);
        let armed = d0.armed, t = d0.t;
        arr[0] = o.x;
        for (let k = 1; k <= N; k++) {
          if (!armed && (o.s - tl.dist[k]) <= d0.trig * Math.max(8, tl.speed[k])) armed = true;
          if (armed && t < d0.dur) t = Math.min(d0.dur, t + H);
          const u = t / d0.dur, e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
          arr[k] = armed ? LANE_X[d0.from] + (LANE_X[d0.to] - LANE_X[d0.from]) * e : o.x;
        }
        g.dr = 1;
      }
      gOb.push(g);
    }
    // orbs for greed (visible, not collected)
    gOrbs.length = 0;
    for (const o of sim.orbs) {
      if (o.got || o.magnet) continue;
      const ds = o.s - sim.dist;
      if (ds < 0 || ds > Math.min(prof.vis, 45)) continue;
      gOrbs.push(o);
    }
    for (const u of sim.powerups) {
      if (u.got) continue;
      const ds = u.s - sim.dist;
      if (ds >= 0 && ds <= Math.min(prof.vis, 50)) gOrbs.push(u);
    }
  }

  // ---------------------------------------------------------------- ghost substep
  // returns false when the fox would be hit / bumped
  function gSub(i, act) {
    if (act & A_JUMP) gp.jumpBuf = TUNE.jumpBuffer;
    if (act & A_LEFT) P.pressLane(gp, -1);
    else if (act & A_RIGHT) P.pressLane(gp, 1);
    const prev = tl.prev[i], dist = tl.dist[i], base = tl.base[i];
    for (let j = 0; j < gTr.length; j++) {
      const t = gTr[j];
      if (t.v !== 0) { t._ps = t.s0 + t.v * (i - 1) * H; t.s = t.s0 + t.v * i * H; }
    }
    for (let j = 0; j < gOb.length; j++) { const o = gOb[j]; if (o.dr) o.x = driftX[j][i]; }
    P.stepLateral(gp, H);
    const wasB2 = gp.boost === 2;
    const vf = P.stepVertical(gp, H, gTr, dist, base);
    if ((vf & P.V_LAND) && wasB2) gLandInv = Math.max(gLandInv, i + Math.round(TUNE.boostLandInvuln / H));
    const prot = tl.inv[i] > 0 || gp.boost === 1 || gLandInv >= i;
    for (let j = 0; j < gTr.length; j++) {
      const t = gTr[j];
      const c = P.probeTruck(t, gp, prev, dist);
      if (c === P.T_FRONT) { if (prot) P.snapToRoof(gp, t); else return false; }
      else if (c === P.T_SIDE) return false;
      else if (c === P.T_OVER && !gp.grounded && gp.vy <= 0 && gp.y < t.h && dist >= t.s && dist <= t.s + t.len) P.snapToRoof(gp, t);
    }
    if (!prot) {
      for (let j = 0; j < gOb.length; j++) {
        const o = gOb[j];
        if (o.s > dist + 1 + gMarginM || o.s + o.len < prev - 1) continue;
        if (P.probeObstacle(o, gp, prev, dist) === 1) return false;
        // careful mode: also clear it as if we were gMarginM further down the road
        if (gMarginM > 0 && P.probeObstacle(o, gp, prev + gMarginM, dist + gMarginM) === 1) return false;
      }
      if (gMarginM > 0) for (let j = 0; j < gTr.length; j++) {
        const t = gTr[j];
        if (t.ramp && t.v === 0) continue;
        if (P.probeTruck(t, gp, prev + gMarginM, dist + gMarginM) === P.T_FRONT && gp.y < 0.5) return false;
      }
    }
    if (gp.stumbleT > 0) gp.stumbleT = Math.max(0, gp.stumbleT - H);
    if (tl.bend[i]) { gp.boost = 2; gp.vy = 0; gp.g = gravityAt(base) * TUNE.boostDescendG; gp.air = P.AIR_FALL; }
    return true;
  }

  // ---------------------------------------------------------------- preferences
  // how much the bot wants to be in lane l right now: coins it can collect BEFORE the lane's
  // first blocker, plus (for humans) how long the lane stays open
  function laneScore(l, gd, onRoofLane, sp) {
    let first = 60;
    for (let j = 0; j < gOb.length; j++) {
      const o = gOb[j];
      if (o.lane !== l || o.s + o.len < gd) continue;
      if (o.type === 'barrier') { if (o.s - gd < 1.5 && o.s - gd < first) first = Math.max(0.1, o.s - gd); continue; }
      if (o.s - gd < first) first = o.s - gd;
    }
    for (let j = 0; j < gTr.length; j++) {
      const t = gTr[j];
      if (t.lane !== l || t.s + t.len < gd) continue;
      if (t.ramp && t.v === 0 && gd < t.s - t.rampLen + 1) continue;       // a ramp is a route
      if (onRoofLane === l && t.v === 0 && gd >= t.s - t.rampLen - 1) continue;   // we're on it
      const d = t.v < 0 ? Math.max(0, (t.s - gd) * sp / (sp - t.v)) : Math.max(0, t.s - gd);
      if (d < first) first = d;
    }
    let v = 0;
    const lo = gd + 1.2, hi = Math.min(gd + 32, gd + first - 0.5);
    for (let j = 0; j < gOrbs.length; j++) {
      const o = gOrbs[j];
      if (o.s < lo || o.s > hi || Math.abs(o.x - LANE_X[l]) > 1.2) continue;
      const w = 1 / (1 + (o.s - gd) * 0.06);
      const val = o.kind === 'magnet' || o.kind === 'x2' || o.kind === 'boost' ? 12 : o.kind === 'tsheet' ? 8 : 1;
      // roof coins are only worth chasing if a roof route exists in that lane
      if (o.y > TUNE.truckH && onRoofLane !== l && !rampAhead(l, gd, o.s)) continue;
      v += val * w;
    }
    v *= prof.greed;
    // trucks are fun: a ramp just ahead (or the roof we're on) pulls the bot up top
    if (prof.roofLove) for (let j = 0; j < gTr.length; j++) {
      const t = gTr[j];
      if (t.lane !== l || !t.ramp || t.v !== 0) continue;
      const foot = t.s - t.rampLen - gd;
      if (foot > 1 && foot < 30) { v += prof.roofLove; break; }
    }
    if (first < sp * 0.7) v -= 20;                  // never steer INTO something that close
    if (prof.safeW > 0) v += prof.safeW * Math.min(first, 45) * 0.08;
    return v;
  }
  function onTruckRoute(l, s) {
    for (let j = 0; j < gTr.length; j++) {
      const t = gTr[j];
      if (t.lane === l && t.v === 0 && s >= t.s - t.rampLen - 0.5 && s <= t.s + t.len + 0.5) return true;
    }
    return false;
  }
  function rampAhead(l, gd, s) {
    for (let j = 0; j < gTr.length; j++) {
      const t = gTr[j];
      if (t.lane === l && t.ramp && t.v === 0 && t.s - t.rampLen >= gd - 0.5 && t.s <= s) return true;
    }
    return false;
  }
  const JW = { near: 0, far: 0, ideal: 0 };
  function jumpWanted(gd, sp) {
    // a barrier in the current lane close to the ideal takeoff (the sim's own jump window),
    // or high coins at the right distance for the apex
    const x = gp.x;
    for (let j = 0; j < gOb.length; j++) {
      const o = gOb[j];
      if (o.type !== 'barrier' || Math.abs(o.x - x) > 1.3) continue;
      const D = o.s - gd;
      if (D <= JW.ideal + 0.06 * sp && D >= JW.near + 0.1 * sp) return true;
    }
    for (let j = 0; j < gOrbs.length; j++) {
      const o = gOrbs[j];
      if (o.y < gp.y + 1.9 || o.y > gp.y + 3 || Math.abs(o.x - x) > 1.0) continue;
      if (onTruckRoute(o.lane, o.s)) continue;          // a ramp carries you up to those
      const tt = (o.s - gd) / sp;
      if (tt > 0.18 && tt < 0.3) return true;
    }
    return false;
  }

  // ---------------------------------------------------------------- DFS
  const ORD = new Int8Array(4 * (MAXD + 2));
  function stateKey(k) {
    const lt = gp.laneT < 1 ? 1 + Math.min(14, Math.round(gp.laneT * 14)) : 0;
    const yq = Math.max(0, Math.min(255, Math.round(gp.y * 40)));
    const vq = Math.max(0, Math.min(511, Math.round((gp.vy + 25) * 10)));
    const sIdx = gp.surfTruck ? (gTr.indexOf(gp.surfTruck) + 1) & 63 : 0;
    let key = k;
    key = key * 4 + gp.lane; key = key * 4 + gp.fromLane; key = key * 16 + lt;
    key = key * 256 + yq; key = key * 512 + vq; key = key * 2 + (gp.grounded ? 1 : 0);
    key = key * 64 + sIdx; key = key * 2 + (gp.stumbleT > 0 ? 1 : 0); key = key * 4 + gp.boost;
    return key + (gp.coyote > 0 ? 0.5 : 0);
  }
  function dfs(k) {
    if (k >= K || tl.dist[k * DSUB] >= distLimit) { bestDepth = k; return true; }
    if (++nodes > maxNodes) return false;
    if (prof.maxMs && (nodes & 31) === 0 && performance.now() - planStart > prof.maxMs) { nodes = maxNodes + 1; return false; }
    const key = stateKey(k);
    if (fails.has(key)) return false;
    if (k > bestDepth) { bestDepth = k; for (let j = 0; j < k; j++) bestPath[j] = curPath[j]; }
    const snap = snaps[k];
    P.copyPlayerState(snap.ps, gp); snap.landInv = gLandInv;
    // ordering
    const o0 = k * 4; let no = 0;
    const gd = tl.dist[k * DSUB], sp = Math.max(5, tl.speed[k * DSUB + 1] || tl.speed[1]);
    const settled = gp.laneT >= 1;
    const canJump = gp.boost === 0 && (gp.grounded || gp.coyote > 0);
    let tgt = gp.lane;
    if (settled) {
      // on a truck's route: on its ramp/roof, or in the air above one
      const roofLane = gp.surfKind === P.SURF_ROOF || gp.surfKind === P.SURF_RAMP || (gp.surfY > 0.1 && gp.y >= gp.surfY - 0.3) ? gp.lane : -1;
      let best = -1e9;
      for (let l = 0; l <= 2; l++) {
        const s = laneScore(l, gd, roofLane, sp) - Math.abs(l - gp.lane) * 0.25 + (l === gp.lane ? 0.35 : 0);
        if (s > best) { best = s; tgt = l; }
      }
    }
    const wantJ = canJump && jumpWanted(gd, sp);
    if (wantJ) ORD[o0 + no++] = A_JUMP;
    if (settled && tgt !== gp.lane) ORD[o0 + no++] = tgt < gp.lane ? A_LEFT : A_RIGHT;
    ORD[o0 + no++] = A_NONE;
    if (canJump && !wantJ) ORD[o0 + no++] = A_JUMP;
    if (settled) {
      if (gp.lane > 0 && !(tgt < gp.lane)) ORD[o0 + no++] = A_LEFT;
      if (gp.lane < 2 && !(tgt > gp.lane)) ORD[o0 + no++] = A_RIGHT;
    }
    for (let a = 0; a < no; a++) {
      const act = ORD[o0 + a];
      if (a > 0) { P.copyPlayerState(gp, snap.ps); gLandInv = snap.landInv; }
      let ok = true;
      for (let s = 0; s < DSUB && ok; s++) ok = gSub(k * DSUB + s + 1, s === 0 ? act : A_NONE);
      if (!ok) continue;
      curPath[k] = act;
      if (dfs(k + 1)) { plan[k] = act; return true; }
      if (nodes > maxNodes) return false;
    }
    P.copyPlayerState(gp, snap.ps); gLandInv = snap.landInv;
    fails.add(key);
    return false;
  }

  let planStart = 0;
  function makePlan(now) {
    const t0 = bot.profileTime ? performance.now() : 0;
    if (prof.maxMs) planStart = performance.now();
    buildGhost(now);
    planOk = false;
    if (prof.margin > 0) {                          // careful plan first
      gMarginM = prof.margin * Math.max(8, sim.speed);
      P.copyPlayerState(gp, sim._ps);
      gLandInv = -1; nodes = 0; bestDepth = 0; fails.clear();
      planOk = dfs(0);
      if (!planOk) stats.riskyPlans++;
    }
    if (!planOk) {
      gMarginM = 0;
      P.copyPlayerState(gp, sim._ps);
      gLandInv = -1; nodes = 0; bestDepth = 0; fails.clear();
      planOk = dfs(0);
    }
    if (planOk) planLen = K;
    else { planLen = Math.max(1, bestDepth); for (let j = 0; j < planLen; j++) plan[j] = bestPath[j]; }
    planT0 = now; lastPlanT = now; dirty = false;
    if (bot.debug) bot.dbg = { t: now.toFixed(3), ok: planOk, len: planLen, nodes, K, fails: fails.size, trucks: gTr.map(t => t.lane + '@' + (t.s - sim.dist).toFixed(1) + '+' + t.len).join(' '), margin: gMarginM.toFixed(1), plan: Array.from(plan.subarray(0, Math.min(planLen, 24))).join(''), known: gOb.length, lapse: now < lapseUntil };
    stats.plans++; stats.nodes += nodes; if (!planOk) stats.failedPlans++;
    if (bot.profileTime) { const ms = performance.now() - t0; if (ms > (stats.planMsMax || 0)) { stats.planMsMax = ms; stats.planMaxNodes = nodes; stats.planMaxK = K; stats.planMaxOb = gOb.length; stats.planMaxTr = gTr.length; } }
  }

  // ---------------------------------------------------------------- per-step
  const stats = { plans: 0, nodes: 0, failedPlans: 0, riskyPlans: 0, lapses: 0, wrong: 0, missed: 0 };
  function push(a) {
    if (a & A_JUMP) out.push('jump');
    if (a & A_LEFT) out.push('left');
    else if (a & A_RIGHT) out.push('right');
  }
  function humanize(a, t) {
    // split into lane / jump parts, each with its own timing noise and error chances
    const parts = [];
    if (a & A_JUMP) parts.push(A_JUMP);
    if (a & (A_LEFT | A_RIGHT)) parts.push(a & (A_LEFT | A_RIGHT));
    for (let p of parts) {
      if (prof.missP && rng.chance(p === A_JUMP ? prof.missP * 0.3 : prof.missP)) { stats.missed++; continue; }
      if (p !== A_JUMP && prof.wrongP && rng.chance(prof.wrongP)) { p = p === A_LEFT ? A_RIGHT : A_LEFT; stats.wrong++; }
      let jit = 0;
      if (prof.jitter) { const u = rng.next() || 1e-9, v = rng.next(); jit = prof.jitter * Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * v); }
      pending.push({ t: t + jit, a: p });
    }
  }

  const bot = {
    profile: prof, stats,
    reset() {
      seen.clear(); noticed.clear(); pending.length = 0; planLen = 0; planT0 = -1; lastPlanT = -1; attnItem = null;
      lapseUntil = -1; nextLapseT = -1; dirty = true; lastKnownCount = 0;
    },
    /** actions for this sim step (dt already added to sim.time by the sim). */
    act(dt, nowIn) {
      out.length = 0;
      // the state the actions apply to is the one at the START of the step: inside sim.step()
      // sim.time has already been advanced, external callers pass sim.time before stepping.
      const now = nowIn === undefined ? sim.time - dt : nowIn;
      if (nextLapseT < 0) nextLapseT = now + (prof.lapseRate > 0 ? -Math.log(rng.next() || 1e-9) / prof.lapseRate : 1e9);
      if (now >= nextLapseT) {
        lapseUntil = now + rng.f(prof.lapseT[0], prof.lapseT[1]); stats.lapses++;
        nextLapseT = lapseUntil + (prof.lapseRate > 0 ? -Math.log(rng.next() || 1e-9) / prof.lapseRate : 1e9);
      }
      const lapsing = now < lapseUntil;
      if (!lapsing) updateKnowledge(now, dt);
      const age = now - planT0;
      const idx = Math.round(age / DT - 1e-6);
      const need = planT0 < 0 || dirty || age >= prof.replan || idx >= planLen - 2 || !planOk;
      // a human mid-gesture finishes the gesture before re-reading the road. Plans start on a
      // fixed global decision grid so a replan never loses a path that needed an exact moment.
      const onGrid = Math.abs(now / DT - Math.round(now / DT)) < 0.25;
      if (!lapsing && need && pending.length === 0 && (onGrid || planT0 < 0) && (now - lastPlanT >= DT - 1e-6 || planT0 < 0 || dirty)) {
        makePlan(now);
      }
      // execute the plan's decision for this moment
      const k = Math.round((now - planT0) / DT - 1e-6);
      const onBoundary = Math.abs((now - planT0) - k * DT) < H * 0.5;
      if (onBoundary && k >= 0 && k < planLen && plan[k] !== A_NONE) {
        if (lapsing) { plan[k] = A_NONE; dirty = true; }
        else if (prof.jitter || prof.missP || prof.wrongP) { humanize(plan[k], now); plan[k] = A_NONE; }
        else { push(plan[k]); plan[k] = A_NONE; }
      }
      // a lapse is a freeze: nothing is pressed while it lasts; coming out of it the player
      // re-reads the road (stale intentions are dropped and the bot replans)
      if (lapsing) { if (pending.length) { pending.length = 0; dirty = true; } }
      for (let i = pending.length - 1; i >= 0; i--) {
        if (pending[i].t <= now + H * 0.5) { push(pending[i].a); pending.splice(i, 1); }
      }
      return out;
    },
  };
  return bot;
}
