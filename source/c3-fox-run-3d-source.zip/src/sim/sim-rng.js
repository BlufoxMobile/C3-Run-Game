// Seeded RNG (mulberry32) + helpers. Every random decision in the sim goes through one
// of these, so a seed reproduces a run exactly.
export function mulberry32(seed) {
  let a = (seed >>> 0) || 0x9e3779b9;
  const r = () => {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return r;
}

export function makeRng(seed) {
  const r = mulberry32(seed);
  const rng = {
    next: r,
    f: (lo, hi) => lo + (hi - lo) * r(),
    i: (lo, hi) => lo + Math.floor(r() * (hi - lo + 1)),      // inclusive
    chance: p => r() < p,
    pick: arr => arr[Math.floor(r() * arr.length)],
    /** weighted pick from {key: weight} (weights <= 0 skipped); returns key or null */
    wpick(w) {
      let tot = 0;
      for (const k in w) if (w[k] > 0) tot += w[k];
      if (tot <= 0) return null;
      let x = r() * tot;
      for (const k in w) if (w[k] > 0) { x -= w[k]; if (x < 0) return k; }
      for (const k in w) if (w[k] > 0) return k;
      return null;
    },
    shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); const v = a[i]; a[i] = a[j]; a[j] = v; } return a; },
  };
  return rng;
}

/** Mix two ints into a new seed (for independent streams). */
export function mixSeed(a, b) {
  let h = (a ^ 0x9e3779b9) >>> 0;
  h = Math.imul(h ^ (h >>> 16), 0x85ebca6b) >>> 0;
  h = (h + Math.imul(b | 0, 0xc2b2ae35)) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 0x27d4eb2f) >>> 0;
  return (h ^ (h >>> 16)) >>> 0;
}
