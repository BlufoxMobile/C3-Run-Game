// C³ FOX RUN 3D — GAMEPLAY SIMULATION (SIM agent). Pure JS: no three.js, no DOM.
//
//   import { createSim, TUNE } from './sim/sim.js';
//   const sim = createSim({ seed, attract: true });   // mode 'ready', road pre-populated
//   every frame:  sim.step(simDt, actions)            // ALSO in 'ready': the attract bot plays
//                 ...dispatch sim.events, then sim.events.length = 0 (the sim never clears them)
//   PLAY:   sim.start()        -> mode 'play' + 'start' (the road is regenerated if the attract
//                                 bot had been playing: do it under the title fade)
//   'hit' -> mode 'dying' (~1 s of sim time) -> 'death' -> mode 'over' (show game over)
//   RETRY:  sim.start()        -> a fresh road (seed derived from the reset seed + retry count)
//           sim.start(seed)    -> exactly that road.    TITLE again: sim.reset(newSeed)
//
// State shape: CONTRACT.md §3 (identical field names/units to src/dev/fakeSim.js).
// Assumptions / additions (all additive, documented in the report):
//   * extra event `edge {dir}` when a lane press hits the road edge (old build "bumped the wall").
//   * `comboLost {combo, reason}` is emitted for a truck bump only (timeouts are silent).
//   * obstacle.hopped (bool) marks a barrier that was jumped; obstacle.drift.armed marks the slide.
//   * a shield/invuln hit on a TRUCK front cannot smash a truck: the fox vaults onto its roof
//     ('shieldBreak' when a shield was spent, then 'roof'); no 'smash' for trucks.
//   * sim.autopilot = true lets the built-in bot play in 'play' mode too (demos / screenshots).
import { LANE_X } from '../core/constants.js';
import { THEMES, tierOf, KINDS, POWERUPS } from '../data/themes.js';
import { TUNE, passiveRate, gravityAt } from './sim-tune.js';
import { makeRng, mixSeed } from './sim-rng.js';
import * as P from './sim-phys.js';
import { createSchedule, createGen } from './sim-gen.js';
import { createBot, BOT_PROFILES } from './sim-bot.js';

export { TUNE, BOT_PROFILES };

const POWER_KINDS = ['magnet', 'x2', 'boost'];

export function createSim(opts = {}) {
  const sched = createSchedule();
  const gen = createGen(sched);
  const ps = P.newPlayerState();
  let nextId = 1;
  let rng = makeRng(1);                       // misc run randomness (river pattern, ...)
  let genIsAttract = false;                   // content currently on the road was designed for attract
  let runStartDist = 0;
  let deathT = 0, speedAtHit = 0, boostMul = 1, seed = (opts.seed >>> 0) || 1, runCount = 0;
  let bot = null;
  const noActs = [];

  const sim = {
    mode: 'ready', time: 0, runTime: 0, dist: 0, speed: 0, baseSpeed: TUNE.speedL1,
    level: 1, lap: 1, themeIdx: 0, theme: THEMES[0], nextThemeIdx: 1,
    levelStart: 0, nextLevelAt: 0, levelProgress: 0,
    score: 0, combo: 1, comboTimer: 0, bestCombo: 1,
    tsheets: 0, shield: 0,
    power: { magnet: 0, x2: 0, boost: 0 },
    powerMax: { magnet: POWERUPS.magnet.dur, x2: POWERUPS.x2.dur, boost: POWERUPS.boost.dur },
    invuln: 0, timeScaleHint: 1,
    player: { lane: 1, fromLane: 1, laneT: 1, x: 0, y: 0, vy: 0, grounded: true, onRoof: null,
              surfaceY: 0, anim: 'idle', animT: 0, lean: 0, stumbleT: 0 },
    obstacles: [], trains: [], orbs: [], powerups: [],
    events: [], killer: null,
    stats: { orbs: 0, nearMisses: 0, hops: 0, smashed: 0, distance: 0, maxCombo: 1 },
    attract: !!opts.attract, devGod: false, autopilot: false, seed, runSeed: seed,
    // internals for tools / the bot (read-only for everyone else)
    _ps: ps, _sched: sched, _gen: gen, _boostMul: () => boostMul, _bot: () => bot, _setBot: b => { bot = b; },
  };
  const emit = e => { sim.events.push(e); };

  // ------------------------------------------------------------------ entities
  function spawn(bp) {
    const id = nextId++;
    if (bp.k === 'mon' || bp.k === 'bar') {
      const mon = bp.k === 'mon';
      sim.obstacles.push({
        id, type: mon ? 'monster' : 'barrier', kind: mon ? bp.kind : 'barrier', lane: bp.lane, x: LANE_X[bp.lane], s: bp.s,
        w: mon ? TUNE.monsterW : TUNE.barrierW, h: mon ? TUNE.monsterH : TUNE.barrierH, len: mon ? TUNE.monsterLen : TUNE.barrierLen,
        drift: bp.driftTo !== undefined ? { from: bp.lane, to: bp.driftTo, t: 0, dur: TUNE.driftTime, armed: false, trig: bp.driftTrig || TUNE.driftTriggerT } : null,
        hit: false, smashed: false, near: false, gateRow: !!bp.gate, hopped: false, _ck: bp.ck,
      });
    } else if (bp.k === 'truck') {
      sim.trains.push({ id, kind: bp.kind, lane: bp.lane, x: LANE_X[bp.lane], s: bp.s, len: bp.len,
        h: TUNE.truckH, w: TUNE.truckW, v: 0, ramp: bp.ramp, rampLen: bp.rampLen, livery: bp.livery,
        lights: false, _ps: bp.s, _near: false, _ck: bp.ck });
    } else if (bp.k === 'orb') {
      sim.orbs.push({ id, kind: bp.kind, lane: bp.lane, x: bp.x, s: bp.s, y: bp.y, got: false, magnet: false,
        _t: 0, _x0: 0, _y0: 0, _d0: 0 });
    } else if (bp.k === 'pow') {
      let kind = bp.kind;
      const busy = k => sim.power[k] > 0 || sim.powerups.some(u => u.kind === k && !u.got);
      if (busy(kind)) {
        const free = POWER_KINDS.filter(k => !busy(k));
        if (!free.length) return;
        kind = free[Math.floor(rng.next() * free.length)];
      }
      sim.powerups.push({ id, kind, lane: bp.lane, x: LANE_X[bp.lane], s: bp.s, y: bp.y, got: false });
    }
  }
  function spawnOncoming() {
    const q = gen.oncoming;
    for (let i = q.length - 1; i >= 0; i--) {
      const o = q[i];
      if (o.sMeet - sim.dist < 12) { q.splice(i, 1); continue; }         // moment passed (boosted by)
      const tm = timeToReach(o.sMeet);
      const s0 = o.sMeet + Math.abs(o.v) * tm;
      if (s0 - sim.dist > TUNE.spawnAhead) continue;
      sim.trains.push({ id: nextId++, kind: o.kind, lane: o.lane, x: LANE_X[o.lane], s: s0, len: o.len,
        h: TUNE.truckH, w: TUNE.truckW, v: o.v, ramp: false, rampLen: 0, livery: o.livery, lights: true,
        _ps: s0, _near: false });
      q.splice(i, 1);
    }
  }
  function timeToReach(target) {
    const d = target - sim.dist;
    if (ps.boost === 1 && sim.power.boost > 0) {
      const vb = sim.baseSpeed * TUNE.boostMult, dFly = vb * sim.power.boost;
      if (d <= dFly) return d / vb;
      return sim.power.boost + sched.timeBetween(sim.dist + dFly, target);
    }
    return sched.timeBetween(sim.dist, target);
  }
  function compact(arr, keep) {
    let j = 0;
    for (let i = 0; i < arr.length; i++) { const e = arr[i]; if (keep(e)) arr[j++] = e; }
    arr.length = j;
  }
  const behind = () => sim.dist - TUNE.viewBehind;
  const keepObs = o => o.s + o.len > behind();
  const keepTrain = t => t.s + t.len > behind();
  const keepOrb = o => !o.got && o.s > behind();
  const keepPow = u => !u.got && u.s > behind();
  function populate(maxChunks) {
    gen.ensure(sim.dist, TUNE.designAhead, maxChunks);
    gen.release(sim.dist, spawn);
    if (!sched.attract) spawnOncoming();
  }
  function clearWorld() {
    sim.obstacles.length = 0; sim.trains.length = 0; sim.orbs.length = 0; sim.powerups.length = 0;
  }

  // ------------------------------------------------------------------ levels
  function setLevel(L, announce) {
    sim.level = L;
    sim.themeIdx = (L - 1) % THEMES.length; sim.theme = THEMES[sim.themeIdx];
    sim.nextThemeIdx = L % THEMES.length;
    sim.lap = 1 + Math.floor((L - 1) / THEMES.length);
    sim.levelStart = sched.startOf(L); sim.nextLevelAt = sched.startOf(L + 1);
    if (announce) emit({ type: 'levelUp', level: L, themeIdx: sim.themeIdx, lap: sim.lap,
      name: sim.theme.name, region: sim.theme.reg, tier: tierOf(L) });
  }

  // ------------------------------------------------------------------ scoring
  const x2 = () => (sim.power.x2 > 0 ? 2 : 1);
  function collectOrb(o) {
    o.got = true;
    if (o.kind === 'tsheet') {
      sim.tsheets++; sim.shield = Math.min(TUNE.shieldMax, sim.shield + 1);
      emit({ type: 'tsheet', count: sim.tsheets, shield: sim.shield, x: o.x, y: o.y, s: o.s });
      if (sim.tsheets % TUNE.tsheetBonusEvery === 0) {
        sim.score += TUNE.tsheetBonus;
        emit({ type: 'bonus', amount: TUNE.tsheetBonus, x: o.x, y: o.y, s: o.s });
      }
      return;
    }
    const prev = sim.combo;
    sim.combo = Math.min(TUNE.comboMax, sim.combo + 1);
    if (sim.combo > sim.bestCombo) sim.bestCombo = sim.combo;
    sim.comboTimer = TUNE.comboWindow;
    const value = Math.round(KINDS[o.kind].val * sim.combo * (1 + (sim.level - 1) * TUNE.orbLevelMult)) * x2();
    sim.score += value; sim.stats.orbs++;
    emit({ type: 'coin', kind: o.kind, value, combo: sim.combo, x: o.x, y: o.y, s: o.s });
    if (sim.combo !== prev && (sim.combo === 3 || sim.combo === 6 || sim.combo === 9)) emit({ type: 'combo', combo: sim.combo });
  }
  function nearMiss(ex, es) {
    const bonus = TUNE.nearMissPay * sim.combo * x2();
    sim.score += bonus; sim.stats.nearMisses++;
    emit({ type: 'nearMiss', bonus, x: ex, side: ex < ps.x ? -1 : 1, s: es });
  }
  function loseCombo(reason) {
    if (sim.combo > 1) emit({ type: 'comboLost', combo: sim.combo, reason });
    sim.combo = 1; sim.comboTimer = 0;
  }

  // ------------------------------------------------------------------ power-ups
  function activatePower(kind, x, y, s) {
    sim.power[kind] = sim.powerMax[kind];
    emit({ type: 'powerup', kind, x, y, s });
    if (kind === 'boost' && ps.boost !== 1) startBoost();
  }
  function startBoost() {
    ps.boost = 1; ps.grounded = false; ps.air = P.AIR_BOOST; ps.surfTruck = null; ps.surfKind = P.SURF_ROAD;
    ps.jumpBuf = 0; ps.coyote = 0;
    emit({ type: 'boostStart' });
    // the coin river along the flight line
    const vb = sim.baseSpeed * TUNE.boostMult, dur = sim.powerMax.boost;
    const y = TUNE.boostY + TUNE.orbY;
    let lane = ps.lane, run = rng.i(TUNE.riverRun[0], TUNE.riverRun[1]), k = 0;
    let fromX = LANE_X[lane], swing = 0, nextLane = lane;
    for (let t = 0.45; t < dur - 0.35; t += TUNE.riverDt) {
      const s = sim.dist + 3 + vb * t * 0.97;
      let x = LANE_X[lane], l = lane;
      if (swing > 0) {                                   // two coins on the diagonal
        const u = (3 - swing) / 3; x = fromX + (LANE_X[nextLane] - fromX) * u; l = u < 0.5 ? lane : nextLane;
        if (--swing === 0) lane = nextLane;
      } else if (++k >= run) {
        k = 0; run = rng.i(TUNE.riverRun[0], TUNE.riverRun[1]);
        nextLane = lane === 0 ? 1 : lane === 2 ? 1 : (rng.chance(0.5) ? 0 : 2);
        fromX = LANE_X[lane]; swing = 2;
      }
      sim.orbs.push({ id: nextId++, kind: rng.chance(0.2) ? 'xm' : rng.chance(0.5) ? 'tab' : 'watch', lane: l, x, s, y,
        got: false, magnet: false, _t: 0, _x0: 0, _y0: 0, _d0: 0 });
    }
  }
  function endBoost() {
    emit({ type: 'boostEnd' });
    ps.boost = 2; ps.vy = 0; ps.g = gravityAt(sim.baseSpeed) * TUNE.boostDescendG; ps.air = P.AIR_FALL;
    sim.invuln = Math.max(sim.invuln, TUNE.boostInvuln);
  }

  // ------------------------------------------------------------------ death / hits
  const protectedNow = () => sim.invuln > 0 || ps.boost === 1 || sim.devGod || sim.mode === 'ready';
  function die(type, kind, x, y, s) {
    sim.killer = { type, kind };
    emit({ type: 'hit', kind, x, y, s });
    sim.mode = 'dying'; deathT = 0; speedAtHit = sim.speed;
    sim.stats.distance = sim.dist - runStartDist; sim.stats.maxCombo = sim.bestCombo;
  }
  /** A fatal contact. Returns true if absorbed (shield / invuln / boost / god / attract). */
  function absorb(x, y, s, id) {
    if (protectedNow()) return true;
    if (sim.shield > 0) {
      sim.shield--; sim.invuln = TUNE.shieldInvuln;
      emit({ type: 'shieldBreak', x, y, s, id });
      return true;
    }
    return false;
  }
  function hitObstacle(o) {
    o.hit = true;
    if (absorb(o.x, o.h * 0.5, o.s, o.id)) {
      o.smashed = true; sim.stats.smashed++;
      emit({ type: 'smash', id: o.id, kind: o.kind, x: o.x, y: o.h * 0.5, s: o.s });
      return;
    }
    die(o.type, o.kind, o.x, o.h * 0.5, o.s);
  }
  function hitTruckFront(t) {
    if (absorb(t.x, 1.5, t.s, t.id)) {                   // can't smash a truck: vault onto it
      P.snapToRoof(ps, t); t._near = true;
      emit({ type: 'roof', trainId: t.id });
      return;
    }
    die('train', t.kind, t.x, 1.5, t.s);
  }
  function bump(t) {
    const dir = LANE_X[ps.lane] > LANE_X[ps.fromLane] ? 1 : -1;
    const second = sim.player.stumbleT > 0 || ps.stumbleT > 0;
    P.bounceBack(ps);
    ps.stumbleT = TUNE.bumpStumble;
    emit({ type: 'bump', dir, x: ps.x, s: sim.dist });
    loseCombo('bump');
    if (second && !absorb(ps.x, 1.2, sim.dist, t.id)) die('train', t.kind, ps.x, 1.2, sim.dist);
  }

  // ------------------------------------------------------------------ one fixed substep
  function substep(dt, acts) {
    const dying = sim.mode === 'dying', playing = sim.mode === 'play';
    if (acts && !dying) {
      for (let i = 0; i < acts.length; i++) {
        const a = acts[i];
        if (a === 'jump') { ps.jumpBuf = TUNE.jumpBuffer; continue; }
        const dir = a === 'left' ? -1 : a === 'right' ? 1 : 0;
        if (!dir) continue;
        const r = P.pressLane(ps, dir);
        if (r === 1) emit({ type: 'lane', dir, lane: ps.lane });
        else if (r === 0) emit({ type: 'edge', dir });
      }
    }
    // --- forward motion
    sim.baseSpeed = sched.speedAt(sim.dist);
    const want = sim.power.boost > 0 ? TUNE.boostMult : 1;
    boostMul += (want - boostMul) * (1 - Math.exp(-TUNE.boostSpeedRate * dt));
    if (dying) {
      deathT += dt;
      const u = Math.min(1, deathT / TUNE.deathStopT);
      sim.speed = speedAtHit * (1 - u) * (1 - u);
    } else sim.speed = sim.baseSpeed * boostMul;
    const prevDist = sim.dist;
    sim.dist += sim.speed * dt;
    const dist = sim.dist;

    // --- world motion
    const trains = sim.trains, obs = sim.obstacles;
    for (let i = 0; i < trains.length; i++) { const t = trains[i]; t._ps = t.s; t.s += t.v * dt; }
    for (let i = 0; i < obs.length; i++) {
      const o = obs[i], d = o.drift;
      if (!d || d.t >= d.dur) continue;
      if (!d.armed && (o.s - dist) <= d.trig * Math.max(8, sim.speed)) d.armed = true;
      if (d.armed) {
        d.t = Math.min(d.dur, d.t + dt);
        const u = d.t / d.dur, e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
        o.x = LANE_X[d.from] + (LANE_X[d.to] - LANE_X[d.from]) * e;
        o.lane = e < 0.5 ? d.from : d.to;
      }
    }

    // --- player
    const lr = P.stepLateral(ps, dt);
    if (lr === 1 || lr === -1) emit({ type: 'lane', dir: lr, lane: ps.lane });
    else if (lr === 2 || lr === -2) emit({ type: 'edge', dir: lr / 2 });
    const wasBoostDescent = ps.boost === 2;
    const vf = P.stepVertical(ps, dt, trains, dist, sim.baseSpeed);
    if (vf & P.V_JUMP) emit({ type: 'jump', x: ps.x, y: ps.y });
    if (vf & P.V_DROP) emit({ type: 'drop' });
    if (vf & P.V_RAMP) emit({ type: 'ramp', trainId: ps.surfTruck ? ps.surfTruck.id : null });
    if (vf & P.V_LAND) {
      emit({ type: 'land', x: ps.x, y: ps.y, onRoof: ps.surfKind === P.SURF_ROOF, impact: ps.impact });
      if (wasBoostDescent) sim.invuln = Math.max(sim.invuln, TUNE.boostLandInvuln);
    }
    if (vf & P.V_ROOF) emit({ type: 'roof', trainId: ps.surfTruck ? ps.surfTruck.id : null });

    // --- contacts
    if (!dying && sim.mode !== 'over') {
      for (let i = 0; i < trains.length && sim.mode !== 'dying'; i++) {
        const t = trains[i];
        const c = P.probeTruck(t, ps, prevDist, dist);
        if (c === P.T_FRONT) hitTruckFront(t);
        else if (c === P.T_SIDE) bump(t);
        else if (c === P.T_OVER && !ps.grounded && ps.vy <= 0 && ps.y < t.h && dist >= t.s && dist <= t.s + t.len) {
          P.snapToRoof(ps, t);                              // mantle up the last few cm
          emit({ type: 'land', x: ps.x, y: ps.y, onRoof: true, impact: 2 });
          emit({ type: 'roof', trainId: t.id });
        }
      }
      for (let i = 0; i < obs.length && sim.mode !== 'dying'; i++) {
        const o = obs[i];
        if (o.hit || o.smashed) continue;
        const c = P.probeObstacle(o, ps, prevDist, dist);
        if (c === 1) hitObstacle(o);
        else if (c === 2 && o.type === 'barrier' && !o.hopped) {
          o.hopped = true; sim.stats.hops++;
          emit({ type: 'hop', x: o.x, s: o.s });
        }
      }
    }

    // --- near misses & passing trucks (things whose front just passed the fox)
    if (sim.mode === 'play' || sim.mode === 'ready') {
      const PW = TUNE.playerHalfW;
      for (let i = 0; i < obs.length; i++) {
        const o = obs[i];
        if (o.near || o.hit || o.hopped) continue;
        const mid = o.s + o.len * 0.5;
        if (!(mid <= dist && mid > prevDist)) continue;
        const dx = Math.abs(o.x - ps.x), hitR = o.w * 0.5 + PW;
        if (dx < hitR) continue;
        const late = o.lane === ps.lcFrom && ps.lane !== o.lane && ps.lcAge <= TUNE.nearMissWindow;
        if (late || dx < hitR + TUNE.nearMissBand) { o.near = true; nearMiss(o.x, o.s); }
      }
      for (let i = 0; i < trains.length; i++) {
        const t = trains[i];
        if (!(t._ps > prevDist && t.s <= dist)) continue;
        const pl = P.laneOfX(ps.x);
        if (t.v < 0 && Math.abs(t.lane - pl) === 1) emit({ type: 'trainPass', id: t.id, side: t.x < ps.x ? -1 : 1 });
        if (!t._near && !t.ramp && t.lane === ps.lcFrom && ps.lane !== t.lane && ps.lcAge <= TUNE.nearMissWindow &&
            Math.abs(t.x - ps.x) >= t.w * 0.5 + PW && ps.y < t.h - TUNE.roofTol) {
          t._near = true; nearMiss(t.x, t.s);
        }
      }
    }

    // --- pickups
    if (!dying) {
      const PL = TUNE.playerHalfL, bodyY = ps.y + TUNE.orbY;
      const mag = sim.power.magnet > 0;
      const orbs = sim.orbs;
      for (let i = 0; i < orbs.length; i++) {
        const o = orbs[i];
        if (o.got) continue;
        if (o.magnet) {
          o._t += dt;
          const u = Math.min(1, o._t / TUNE.magnetFlyT), e = u * u;
          o.x = o._x0 + (ps.x - o._x0) * e; o.y = o._y0 + (bodyY - o._y0) * e;
          o.s = dist + o._d0 * (1 - e) + 0.3 * e;
          if (u >= 1) collectOrb(o);
          continue;
        }
        const ds = o.s - dist;
        if (mag && ds <= TUNE.magnetRange && ds >= -TUNE.magnetBehind) {
          o.magnet = true; o._t = 0; o._x0 = o.x; o._y0 = o.y; o._d0 = ds;
          continue;
        }
        if (o.s > dist + PL || o.s < prevDist - PL) continue;
        if (Math.abs(o.x - ps.x) < TUNE.orbReachX && Math.abs(bodyY - o.y) < TUNE.orbReachY) collectOrb(o);
      }
      const pu = sim.powerups;
      for (let i = 0; i < pu.length; i++) {
        const u = pu[i];
        if (u.got || u.s > dist + PL || u.s < prevDist - PL) continue;
        if (Math.abs(u.x - ps.x) < TUNE.powerReach && Math.abs(bodyY - u.y) < TUNE.powerReach) {
          u.got = true; activatePower(u.kind, u.x, u.y, u.s);
        }
      }
    }

    // --- timers
    if (sim.invuln > 0) sim.invuln = Math.max(0, sim.invuln - dt);
    if (ps.stumbleT > 0) ps.stumbleT = Math.max(0, ps.stumbleT - dt);
    if (!dying) {
      if (sim.comboTimer > 0) { sim.comboTimer -= dt; if (sim.comboTimer <= 0) { sim.comboTimer = 0; sim.combo = 1; } }
      for (let k = 0; k < 3; k++) {
        const kind = POWER_KINDS[k], t0 = sim.power[kind];
        if (t0 <= 0) continue;
        const t1 = Math.max(0, t0 - dt);
        sim.power[kind] = t1;
        if (t0 > TUNE.powerWarnAt && t1 <= TUNE.powerWarnAt) emit({ type: 'powerWarn', kind });
        if (t1 === 0) { emit({ type: 'powerEnd', kind }); if (kind === 'boost') endBoost(); }
      }
    }
    if (playing) {
      sim.runTime += dt;
      sim.score += passiveRate(sim.baseSpeed) * dt * x2();
      while (sim.dist >= sim.nextLevelAt) setLevel(sim.level + 1, true);
    }
    if (dying && deathT >= TUNE.deathTime) {
      sim.mode = 'over';
      emit({ type: 'death' });
    }
    animate(dt, dying);
  }

  function animate(dt, dying) {
    let a;
    if (dying || sim.mode === 'over') a = 'hit';
    else if (ps.boost === 1) a = 'boost';
    else if (!ps.grounded) a = ps.vy > 0 && ps.air === P.AIR_JUMP ? 'jump' : 'fall';
    else if (ps.stumbleT > 0) a = 'stumble';
    else if (ps.landT > 0) a = 'land';
    else if (sim.mode === 'ready' && !sim.attract) a = 'idle';
    else a = 'run';
    const p = sim.player;
    if (a !== p.anim) { p.anim = a; p.animT = 0; } else p.animT += dt;
    const lt = ps.laneT < 1 ? (LANE_X[ps.lane] > LANE_X[ps.fromLane] ? 1 : -1) : 0;
    p.lean += (lt - p.lean) * Math.min(1, dt * TUNE.leanRate);
  }

  function publish() {
    const p = sim.player;
    p.lane = ps.lane; p.fromLane = ps.fromLane; p.laneT = ps.laneT; p.x = ps.x; p.y = ps.y; p.vy = ps.vy;
    p.grounded = ps.grounded;
    p.onRoof = ps.grounded && ps.surfKind === P.SURF_ROOF && ps.surfTruck ? ps.surfTruck.id : null;
    p.surfaceY = ps.surfY; p.stumbleT = ps.stumbleT;
    sim.levelProgress = sim.mode === 'ready' ? 0 :
      Math.max(0, Math.min(1, (sim.dist - sim.levelStart) / Math.max(1, sim.nextLevelAt - sim.levelStart)));
    if (sim.mode !== 'dying' && sim.mode !== 'over') {
      sim.stats.distance = sim.dist - runStartDist; sim.stats.maxCombo = sim.bestCombo;
    }
  }

  // ------------------------------------------------------------------ public API
  function resetRunCounters() {
    sim.runTime = 0; sim.score = 0; sim.combo = 1; sim.comboTimer = 0; sim.bestCombo = 1;
    sim.tsheets = 0; sim.shield = 0; sim.invuln = 0; sim.killer = null;
    sim.power.magnet = 0; sim.power.x2 = 0; sim.power.boost = 0; boostMul = 1;
    const st = sim.stats; st.orbs = 0; st.nearMisses = 0; st.hops = 0; st.smashed = 0; st.distance = 0; st.maxCombo = 1;
    deathT = 0;
  }
  function groundPlayer() {
    ps.y = 0; ps.vy = 0; ps.grounded = true; ps.air = P.AIR_NONE; ps.boost = 0; ps.surfTruck = null;
    ps.surfKind = P.SURF_ROAD; ps.surfY = 0; ps.stumbleT = 0; ps.jumpBuf = 0; ps.coyote = 0; ps.landT = 0;
    ps.bufDir = 0; ps.bufT = 0;
    if (ps.laneT < 1) { ps.laneT = 1; ps.x = LANE_X[ps.lane]; }
  }
  /** Fresh road designed from the fox's current position (run rules or attract rules). */
  function regenerate(genSeed, attract, baseLevel) {
    clearWorld();
    runStartDist = sim.dist;
    sched.reset(sim.dist, baseLevel, attract);
    gen.reset(genSeed, sim.dist, attract, ps.lane);
    genIsAttract = attract;
    setLevel(baseLevel, false);
    sim.baseSpeed = sched.speedAt(sim.dist);
    populate();
  }

  sim.reset = (newSeed) => {
    if (newSeed !== undefined) seed = sim.seed = (newSeed >>> 0) || 1;
    runCount = 0;
    rng = makeRng(mixSeed(seed, 7)); sim.runSeed = seed;
    sim.mode = 'ready'; sim.time = 0; sim.dist = 0; sim.speed = 0;
    sim.events.length = 0;
    Object.assign(ps, P.newPlayerState());
    const p = sim.player; p.anim = 'idle'; p.animT = 0; p.lean = 0;
    resetRunCounters();
    regenerate(seed, sim.attract, 1);
    if (bot) bot.reset();
    publish();
    return sim;
  };

  /** Begin a run. start(seed) uses that seed; start() uses the reset seed for the first run
   *  and a fresh derived seed for every retry (a new road each time, still reproducible). */
  sim.start = (runSeedIn) => {
    const retry = sim.mode !== 'ready';
    const rs = runSeedIn !== undefined ? ((runSeedIn >>> 0) || 1) : retry ? mixSeed(seed, ++runCount) : (runCount === 0 ? seed : mixSeed(seed, runCount));
    const needFresh = retry || genIsAttract || sim.dist > 0.01 || rs !== sim.runSeed;
    sim.runSeed = rs;
    if (needFresh) {
      groundPlayer();
      rng = makeRng(mixSeed(rs, 7));
      regenerate(rs, false, 1);
    }
    resetRunCounters();
    sim.mode = 'play';
    if (bot) bot.reset();
    emit({ type: 'start' });
    publish();
  };

  sim.setAttract = (b) => {
    b = !!b;
    if (b === sim.attract) return;
    sim.attract = b;
    if (sim.mode === 'ready' && b && !genIsAttract) {         // re-design the title road as a showcase
      regenerate(mixSeed(seed, 99), true, 1);
      publish();
    }
  };

  sim.devSetLevel = (n) => {
    n = Math.max(1, Math.floor(n));
    if (sim.mode !== 'play') return;
    groundPlayer();
    regenerate(mixSeed(seed, n), false, n);
    emit({ type: 'levelUp', level: n, themeIdx: sim.themeIdx, lap: sim.lap, name: sim.theme.name,
      region: sim.theme.reg, tier: tierOf(n) });
    publish();
  };
  /** dev: grant a power-up now */
  sim.devPower = (kind) => { if (POWER_KINDS.includes(kind)) activatePower(kind, ps.x, 1, sim.dist); };

  sim.step = (dt, actions) => {
    if (!(dt > 0)) { publish(); return; }
    dt = Math.min(dt, TUNE.dtMax);
    sim.time += dt;
    if (sim.mode === 'over') { animate(dt, false); publish(); return; }
    if (sim.mode === 'ready' && !sim.attract) { sim.speed = 0; animate(dt, false); publish(); return; }
    let acts = actions || noActs;
    if ((sim.mode === 'ready' || sim.autopilot) && sim.mode !== 'dying') {
      if (!bot) bot = createBot(sim, sim.mode === 'ready' ? BOT_PROFILES.attract : BOT_PROFILES.perfect);
      acts = bot.act(dt);
    }
    const n = Math.max(1, Math.ceil(dt / TUNE.substep - 1e-9)), h = dt / n;
    for (let i = 0; i < n; i++) {
      substep(h, i === 0 ? acts : null);
      if (sim.mode === 'over') break;
    }
    // world upkeep once per step
    compact(sim.obstacles, keepObs); compact(sim.trains, keepTrain);
    compact(sim.orbs, keepOrb); compact(sim.powerups, keepPow);
    if (sim.mode !== 'over') populate(1);
    publish();
  };

  sim.reset(seed);
  return sim;
}
