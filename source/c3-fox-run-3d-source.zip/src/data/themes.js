// THE ROUTE — 12 stages, south to north, dawn to night. Ported verbatim from the 2D
// build (palette + props + environment flags), plus the fields the 3D build adds:
//   sky:    asset key of the painted sky panorama (may be missing -> gradient fallback)
//   region: coarse region for audio flavour + prop sets
//   tod:    time of day: dawn | sunrise | day | golden | dusk | bluehour | night
//   night:  true when street lights / windows / headlights should glow
//
// Palette fields: skyT/skyM/skyB (sky top/mid/bottom), grT/grB (grass), rdT/rdB (road),
// far/mid/near (landform layer tints), amb/ambA (ambient light colour/strength),
// key/keyA/keyDir (sun/key light colour/strength/side), clouds, sun (sun disc colour).
// env flags: mist birds fireflies traffic turbines stacks ltrain water shimmer haze
//            wind rays fog stars moon sun sodium city lightning
// props: side-of-road set dressing for that stage:
//        pine tree sign flag barn fence corn turbine walkup stoop
export const THEMES = [
  /* 1 ------------------------------------------------- east Tennessee */
  {name:'SMOKY DAWN', reg:'EAST TENNESSEE', hero:'smokies', heroF:0.45,
   skyT:'#101a42',skyM:'#31456f',skyB:'#93a6bd', grT:'#2d4a44',grB:'#1a2f2d', rdT:'#383d48',rdB:'#4e535e',
   clouds:'#a8bccf', stars:1, fog:1, mist:1.0, wind:0.5,
   fark:'ridge', midk:'ridge', neark:'trees',
   props:['pine','pine','tree','sign'],
   amb:'#8fa8c8', ambA:0.22, key:'#cfe0ff', keyA:0.26, keyDir:-1,
   far:'#3b5375', mid:'#2b3f58', near:'#1e352c'},

  /* 2 ------------------------------------------------- the sun breaks */
  {name:'TENNESSEE SUNRISE', reg:'THE FOOTHILLS', hero:'smokies', heroF:0.40,
   skyT:'#39498a',skyM:'#d4794a',skyB:'#ffd7a2', grT:'#4f7a3e',grB:'#2f5029', rdT:'#584f47',rdB:'#736a5f',
   sun:'#fff0c8', sunLow:1, rays:1, clouds:'#ffd9b4', mist:0.55, birds:1, wind:0.7,
   fark:'ridge', midk:'hills', neark:'trees',
   props:['pine','tree','pine','flag'],
   amb:'#ffcf9a', ambA:0.18, key:'#fff2cc', keyA:0.42, keyDir:1,
   far:'#6b6a9c', mid:'#8c6b78', near:'#3d6a33'},

  /* 3 ------------------------------------------------ up on the plateau */
  {name:'CUMBERLAND PLATEAU', reg:'THE HIGH ROAD', heroF:0,
   skyT:'#1273c8',skyM:'#57a8e2',skyB:'#c8e2f0', grT:'#8fae4e',grB:'#5c7a34', rdT:'#6a6a70',rdB:'#8c8c92',
   sun:'#fff6c8', rays:1, clouds:'#ffffff', shimmer:1, birds:1, wind:0.8,
   fark:'plateau', midk:'plateau', neark:'trees',
   props:['pine','tree','sign','pine'],
   amb:'#d6ecff', ambA:0.10, key:'#fff8dc', keyA:0.32, keyDir:-1,
   far:'#93a8ae', mid:'#7b9077', near:'#4d7a38'},

  /* 4 ------------------------------------------------ horse country */
  {name:'KENTUCKY BLUEGRASS', reg:'HORSE COUNTRY', heroF:0,
   skyT:'#2a92e0',skyM:'#6cc3ef',skyB:'#ddf1ff', grT:'#63c47a',grB:'#347f4e', rdT:'#63656e',rdB:'#83858e',
   clouds:'#ffffff', birds:1, wind:1.0,
   fark:'hills', midk:'hills', neark:'fence',
   props:['barn','tree','fence','sign'],
   amb:'#d6ecff', ambA:0.11, key:'#fffbe8', keyA:0.30, keyDir:1,
   far:'#7fb0cc', mid:'#5f9e78', near:'#2f7d46'},

  /* 5 ------------------------------------------------ river city outskirts */
  {name:'LOUISVILLE HAZE', reg:'OHIO VALLEY', heroF:0,
   skyT:'#3f7fb8',skyM:'#8fb2c8',skyB:'#e3cfa8', grT:'#6f9a46',grB:'#476b32', rdT:'#5e594c',rdB:'#7a7565',
   clouds:'#e8dcc4', haze:1, traffic:1, city:1, birds:1, wind:0.7,
   fark:'city', midk:'hills', neark:'trees',
   props:['barn','tree','sign','flag'],
   amb:'#e8d0a8', ambA:0.16, key:'#fff4d8', keyA:0.32, keyDir:1,
   far:'#8a94a0', mid:'#6f8574', near:'#42642f'},

  /* 6 ------------------------------------------------ the crossing */
  {name:'OHIO RIVER', reg:'THE CROSSING', heroF:0,
   skyT:'#1f86d6',skyM:'#63b8ea',skyB:'#d2e8f4', grT:'#5aa86a',grB:'#3a7a52', rdT:'#5f6672',rdB:'#7d8490',
   clouds:'#ffffff', water:1, birds:1, wind:0.8,
   fark:'hills', midk:'ridge', neark:'trees',
   props:['tree','sign','flag','tree'],
   amb:'#cfe8ff', ambA:0.12, key:'#fdfff0', keyA:0.30, keyDir:-1,
   far:'#87b6cf', mid:'#6f9fbe', near:'#3d7f55'},

  /* 7 ------------------------------------------------ flat farmland */
  {name:'INDIANA CORN', reg:'HOOSIER FARMLAND', heroF:0,
   skyT:'#3f8fd0',skyM:'#a3c8e2',skyB:'#ffe6b8', grT:'#b3ab48',grB:'#7c8734', rdT:'#6b6152',rdB:'#8a8070',
   sun:'#fff0c0', sunLow:1, rays:1, clouds:'#ffe8c8', wind:1.4, birds:1,
   fark:'flat', midk:'flat', neark:'corn',
   props:['barn','corn','barn','sign'],
   amb:'#ffe3ac', ambA:0.17, key:'#fff4cc', keyA:0.40, keyDir:1,
   far:'#c3bb90', mid:'#a8a862', near:'#8a8f3c'},

  /* 8 ------------------------------------------------ turbines at dusk */
  {name:'HOOSIER DUSK', reg:'NORTHERN INDIANA', heroF:0,
   skyT:'#2a2f68',skyM:'#7a5a8e',skyB:'#f0a172', grT:'#3d5240',grB:'#223126', rdT:'#464852',rdB:'#5c5e68',
   sun:'#ffd7a0', sunLow:1, clouds:'#c8869a', stars:1, turbines:1, fireflies:1, wind:1.2,
   fark:'flat', midk:'flat', neark:'corn',
   props:['turbine','barn','corn','turbine'],
   amb:'#6b5a92', ambA:0.22, key:'#ffc79a', keyA:0.34, keyDir:1,
   far:'#4a4272', mid:'#39325a', near:'#2a3a2c'},

  /* 9 ------------------------------------------------ the steel belt */
  {name:'GARY STEEL', reg:'THE LAKE PLAIN', heroF:0,
   skyT:'#151a3c',skyM:'#3b3050',skyB:'#8a5a52', grT:'#2e3230',grB:'#1a1d1c', rdT:'#3a3a42',rdB:'#50505a',
   stars:1, sodium:1, stacks:1, traffic:1, city:1, wind:0.8,
   fark:'stacks', midk:'city', neark:'trees',
   props:['turbine','sign','walkup','turbine'],
   amb:'#4a3a52', ambA:0.24, key:'#ffb070', keyA:0.36, keyDir:1,
   far:'#2f2a48', mid:'#231f38', near:'#242826'},

  /* 10 ----------------------------------------------- blue hour on the lake */
  {name:'LAKESHORE', reg:'LAKE MICHIGAN', heroF:0,
   skyT:'#0d1638',skyM:'#263c70',skyB:'#7386ac', grT:'#25384a',grB:'#131f29', rdT:'#33353f',rdB:'#484a54',
   stars:1, moon:1, water:1, haze:1, traffic:1, clouds:'#5a6f96', wind:0.9,
   fark:'city', midk:'ridge', neark:'trees',
   props:['tree','sign','flag','tree'],
   amb:'#2c3f6e', ambA:0.24, key:'#bcd6ff', keyA:0.30, keyDir:-1,
   far:'#1d2c52', mid:'#15203a', near:'#1a2a33'},

  /* 11 ----------------------------------------------- the skyline appears */
  {name:'CHICAGO SKYLINE', reg:'THE CITY AHEAD', hero:'chicago', heroF:0.82,
   skyT:'#060c22',skyM:'#141d44',skyB:'#333a66', grT:'#1d2a2a',grB:'#101818', rdT:'#32343e',rdB:'#464853',
   stars:1, moon:1, city:1, traffic:1, sodium:1,
   fark:'city', midk:'city', neark:'trees',
   props:['walkup','sign','tree','walkup'],
   amb:'#28336a', ambA:0.24, key:'#cfe0ff', keyA:0.28, keyDir:-1,
   far:'#101836', mid:'#0c1229', near:'#16211f'},

  /* 12 ----------------------------------------------- downtown, tracks overhead */
  {name:'THE LOOP', reg:'DOWNTOWN CHICAGO', heroF:0,
   skyT:'#04081c',skyM:'#0e1432',skyB:'#20264c', grT:'#22262e',grB:'#14171d', rdT:'#2a2c36',rdB:'#3d3f4a',
   stars:1, city:1, sodium:1, ltrain:1, traffic:1,
   fark:'city', midk:'city', neark:'stoop',
   props:['walkup','walkup','sign','walkup'],
   amb:'#1c2450', ambA:0.26, key:'#ffcf9a', keyA:0.32, keyDir:1,
   far:'#0d1230', mid:'#141a3a', near:'#171c22'}
];

const EXTRA = [{'sky': 'sky/01_smoky_dawn', 'region': 'smokies', 'tod': 'dawn', 'night': false}, {'sky': 'sky/02_tennessee_sunrise', 'region': 'smokies', 'tod': 'sunrise', 'night': false}, {'sky': 'sky/03_cumberland_plateau', 'region': 'smokies', 'tod': 'day', 'night': false}, {'sky': 'sky/04_kentucky_bluegrass', 'region': 'bluegrass', 'tod': 'day', 'night': false}, {'sky': 'sky/05_louisville_haze', 'region': 'ohio', 'tod': 'day', 'night': false}, {'sky': 'sky/06_ohio_river', 'region': 'ohio', 'tod': 'day', 'night': false}, {'sky': 'sky/07_indiana_corn', 'region': 'hoosier', 'tod': 'golden', 'night': false}, {'sky': 'sky/08_hoosier_dusk', 'region': 'hoosier', 'tod': 'dusk', 'night': false}, {'sky': 'sky/09_gary_steel', 'region': 'steel', 'tod': 'dusk', 'night': false}, {'sky': 'sky/10_lakeshore', 'region': 'chicago', 'tod': 'bluehour', 'night': true}, {'sky': 'sky/11_chicago_skyline', 'region': 'chicago', 'tod': 'night', 'night': true}, {'sky': 'sky/12_the_loop', 'region': 'chicago', 'tod': 'night', 'night': true}];
THEMES.forEach((t, i) => Object.assign(t, EXTRA[i], { idx: i }));

/** Rank ladder — separate from the place. */
export const TIERS = ['ROOKIE','SPECIALIST','CLOSER','TOP PERFORMER','DISTRICT MGR','REGIONAL','LEGEND','HALL OF FAME'];
export const tierOf = lv => TIERS[Math.min(TIERS.length - 1, Math.floor((lv - 1) / 2))];

/** Theme for a (1-based) level. Wraps after 12 (lap 2, 3...). */
export const themeIndexForLevel = lv => (lv - 1) % THEMES.length;
export const lapForLevel = lv => 1 + Math.floor((lv - 1) / THEMES.length);

/** Commission-killer monsters and their display names. */
export const MONSTERS = ['exception', 'falloff', 'chargeback', 'nonusage', 'retail360'];
export const MONSTER_LABEL = { exception: 'EXCEPTION', falloff: 'FALL-OFF', chargeback: 'CHARGE BACK', nonusage: 'NON-USAGE', retail360: 'RETAIL 360' };

/** Collectibles. val = base $ per pickup (x combo x level factor). tsheet = shield, 5 = +$100. */
export const KINDS = {
  xm:     { label: 'XM',      val: 20, c: '#ffce4d', cd: '#c47c00' },
  tab:    { label: 'TABLET',  val: 15, c: '#7fd1ff', cd: '#1d7fb8' },
  watch:  { label: 'WATCH',   val: 10, c: '#7CE7A8', cd: '#1f9e5c' },
  tsheet: { label: 'T-SHEET', val: 0,  c: '#c9a7ff', cd: '#7b46c9' },
};

/** Power-ups (Subway-Surfers style). dur = seconds. */
export const POWERUPS = {
  magnet: { label: 'MAGNET',    dur: 10, c: '#ff5a6e' },
  x2:     { label: '2X CASH',   dur: 12, c: '#ffd23f' },
  boost:  { label: 'GIG BOOST', dur: 5,  c: '#4fd8ff' },
};
