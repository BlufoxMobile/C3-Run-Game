// OLD-BUILD ECONOMY MODEL — a headless port of the 2D game's spawning (§10) and simulation
// (§12) in its own z-space units (C3-Run-Game/index.html), played by a look-ahead bot, so the
// new sim's dollars-per-level can be compared with the leaderboard's existing scores.
//
//   node tools/sim-oldecon.mjs [runs=60] [maxLevel=16] [--god]
//
// Faithful: speed ramp, level length, passive rate, orb spawn cadence/mix/lines/high/T-sheets,
// combo window + cap, orb value (val x combo x (1+(L-1)x0.15)), near-miss pay, obstacle spawn
// groups incl. mixed/drift/double gates, collision windows, jump physics, lane tween.
// The bot sees everything (like a player who reads the whole road) and chases orbs.
import { makeRng } from '../src/sim/sim-rng.js';

const TUNE = {
  jumpV: 2.62, gravity: 11.4, airborneAt: 0.150, coyoteTime: 0.10, jumpBuffer: 0.18,
  laneTime: 0.110, laneOvershoot: 1.15,
  baseSpeedStart: 3.6, baseSpeedMax: 4.4, baseSpeedRamp: 0.055,
  levelBonusStep: 0.55, levelBonusMax: 8.5, speedMax: 12,
  levelLenBase: 3800, levelLenStep: 280, vzBase: 0.42, vzPerSpeed: 0.14,
  passiveBase: 2, passivePerSpeed: 0.6, comboMax: 9, comboWindow: 1.6, orbLevelMult: 0.15,
  nearMissPay: 25, nearMissBand: 0.34,
  complexFrom: 18, driftChance: 0.34, driftStep: 0.025, driftMax: 0.62, driftTime: 0.45,
  gateChance: 0.30, gateStep: 0.020, gateMax: 0.50, gateGap: 0.28, mixedFrom: 6, mixedStep: 0.045, mixedMax: 0.80,
};
const LANEX = [-0.62, 0, 0.62];
const COL = { hitObstacle: 0.213, hitOrb: 0.285, zFar: 0.90, zNear: 1.04 };
const KINDV = { xm: 20, tab: 15, watch: 10 };

function run(seed, maxLevel, god) {
  const R = makeRng(seed);
  const rand = R.next;
  let commission = 0, combo = 1, comboTimer = 0, baseSpeed = TUNE.baseSpeedStart, levelBonus = 0, speed = baseSpeed;
  let level = 1, levelDist = 0, t = 0, invuln = 0, shield = 0, tsheets = 0;
  let lane = 1, playerX = 0, laneT = 1, laneFrom = 0, prevLane = 1, jumpY = 0, jumpV = 0, coyote = TUNE.coyoteTime, jumpBuf = 0;
  let obstacles = [], orbs = [], spawnT = 0.55, orbT = 0.8, deaths = 0, deathLevel = 0;
  const perLevel = [0]; const orbsPerLevel = [0]; let orbCount = 0;
  const shuffle = a => R.shuffle(a);
  const addObs = (ln, low, z) => { const o = { nx: LANEX[ln], lane: ln, z, pz: z, hit: false, low, near: false, drift: 0, driftT: 0, driftFrom: 0, driftTo: 0 }; obstacles.push(o); return o; };
  function spawnGroup(z) {
    const lanes = shuffle([0, 1, 2]), r = rand();
    const lowChance = 0.18 + Math.min(0.16, level * 0.012), twoTall = 0.18 + Math.min(0.50, level * 0.045);
    const mixed = level >= TUNE.mixedFrom ? Math.min(TUNE.mixedMax, (level - TUNE.mixedFrom + 1) * TUNE.mixedStep) : 0;
    const made = [];
    if (r < lowChance) { const cnt = 1 + Math.floor(rand() * (level >= 4 ? 3 : 2)); for (let i = 0; i < cnt; i++) made.push(addObs(lanes[i], true, z)); }
    else if (mixed > 0 && rand() < mixed) { made.push(addObs(lanes[0], false, z)); made.push(addObs(lanes[1], false, z)); made.push(addObs(lanes[2], true, z)); }
    else { made.push(addObs(lanes[0], false, z)); if (rand() < twoTall) made.push(addObs(lanes[1], false, z)); }
    return made;
  }
  function spawnObstacle() {
    const made = spawnGroup(0);
    if (level < TUNE.complexFrom) return;
    const over = level - TUNE.complexFrom;
    const driftP = Math.min(TUNE.driftMax, TUNE.driftChance + over * TUNE.driftStep);
    const gateP = Math.min(TUNE.gateMax, TUNE.gateChance + over * TUNE.gateStep);
    if (rand() < driftP) {
      const tall = made.filter(o => !o.low && (o.lane === 0 || o.lane === 2 || made.length === 1));
      if (tall.length) { const o = tall[Math.floor(rand() * tall.length)]; const dir = o.lane === 0 ? 1 : o.lane === 2 ? -1 : (rand() < 0.5 ? -1 : 1); o.drift = TUNE.driftTime; o.driftT = 0; o.driftFrom = o.lane; o.driftTo = o.lane + dir; }
    }
    if (rand() < gateP) {
      const second = spawnGroup(-TUNE.gateGap);
      const blocked = new Set(); for (const o of made) if (!o.low) blocked.add(o.lane); for (const o of second) if (!o.low) blocked.add(o.lane);
      if (blocked.size >= 3) for (let i = second.length - 1; i >= 0; i--) if (!second[i].low) { obstacles.splice(obstacles.indexOf(second[i]), 1); second.splice(i, 1); break; }
    }
  }
  function freeLane() { const busy = new Set(); for (const o of obstacles) if (o.z < 0.55 && !o.low) busy.add(o.lane); const f = [0, 1, 2].filter(l => !busy.has(l)); const src = f.length ? f : [0, 1, 2]; return src[Math.floor(rand() * src.length)]; }
  const pickKind = () => { const r = rand(); return r < 0.5 ? 'watch' : r < 0.82 ? 'tab' : 'xm'; };
  function spawnOrb() {
    const ln = freeLane();
    if (rand() < 0.5) { const n = 3 + Math.floor(rand() * 3), k = pickKind(), high = rand() < 0.22; for (let i = 0; i < n; i++) orbs.push({ nx: LANEX[ln], lane: ln, z: -i * 0.11, pz: -i * 0.11, got: false, kind: k, high }); }
    else { const k = rand() < 0.16 ? 'tsheet' : pickKind(); orbs.push({ nx: LANEX[ln], lane: ln, z: 0, pz: 0, got: false, kind: k, high: false }); }
  }
  const ease = u0 => { const u = u0 - 1, c1 = TUNE.laneOvershoot, c3 = c1 + 1; return 1 + c3 * u * u * u + c1 * u * u; };
  function moveLane(d) { if (laneT < 1) return; const n = Math.max(0, Math.min(2, lane + d)); if (n === lane) return; prevLane = lane; lane = n; laneFrom = playerX; laneT = 0; }

  // ---- bot: short look-ahead over lane choices using the true z kinematics
  function laneDanger(l, horizon, vzps) {
    // earliest time a tall (or low, if we can't be airborne) obstacle reaches the player in lane l
    let tmin = Infinity;
    for (const o of obstacles) {
      if (o.hit) continue;
      const ol = o.drift > 0 ? o.driftTo : o.lane;
      if (ol !== l && o.lane !== l) continue;
      const tt = (COL.zFar - o.z) / vzps;
      if (tt < -0.15 || tt > horizon) continue;
      if (o.low) continue;
      tmin = Math.min(tmin, tt);
    }
    return tmin;
  }
  function botThink(vzps) {
    const H = 1.6;
    // value of each lane: orbs arriving within the horizon, minus danger
    let best = lane, bestV = -1e9;
    for (let l = 0; l < 3; l++) {
      const steps = Math.abs(l - lane);
      const tReach = steps * 0.13;
      const dang = laneDanger(l, H, vzps);
      // must also be able to pass through intermediate lanes
      let passOK = true;
      for (let m = Math.min(l, lane); m <= Math.max(l, lane); m++) if (m !== lane && laneDanger(m, tReach + 0.05, vzps) < tReach + 0.05) passOK = false;
      if (!passOK || dang < tReach + (l === lane ? 0.02 : 0.1)) continue;
      let v = Math.min(dang, H) * 2;
      for (const o of orbs) {
        if (o.got || o.lane !== l) continue;
        const tt = (COL.zFar - o.z) / vzps;
        if (tt < tReach || tt > H) continue;
        v += (o.kind === 'tsheet' ? 6 : 3) / (1 + tt);
      }
      if (l === lane) v += 0.2;
      if (v > bestV) { bestV = v; best = l; }
    }
    if (best !== lane) moveLane(best > lane ? 1 : -1);
    // jump: low obstacle about to enter the window in our lane, or high orbs arriving
    const airT = 0.10;   // reach 0.15 height ~0.06 s after takeoff; stay > 0.15 for ~0.33 s
    for (const o of obstacles) {
      if (!o.low || o.hit || o.lane !== lane) continue;
      const tt = (COL.zFar - o.z) / vzps;
      if (tt > airT - 0.02 && tt < airT + 0.08) jumpBuf = TUNE.jumpBuffer;
    }
    for (const o of orbs) {
      if (!o.high || o.got || o.lane !== lane) continue;
      const tt = (COL.zFar - o.z) / vzps;
      if (tt > 0.08 && tt < 0.14) jumpBuf = TUNE.jumpBuffer;
    }
  }

  const dt = 1 / 60;
  let hits = 0;
  while (level <= maxLevel) {
    t += dt;
    baseSpeed = Math.min(TUNE.baseSpeedMax, baseSpeed + dt * TUNE.baseSpeedRamp);
    speed = Math.min(TUNE.speedMax, baseSpeed + levelBonus);
    const vzps = TUNE.vzBase + speed * TUNE.vzPerSpeed, vz = vzps * dt;
    levelDist += speed * dt * 60;
    commission += dt * (TUNE.passiveBase + speed * TUNE.passivePerSpeed);
    const levelLen = TUNE.levelLenBase + level * TUNE.levelLenStep;
    if (levelDist >= levelLen) {
      levelDist -= levelLen; perLevel[level] = commission; orbsPerLevel[level] = orbCount;
      level++; levelBonus = Math.min(TUNE.levelBonusMax, levelBonus + TUNE.levelBonusStep);
    }
    if (invuln > 0) invuln -= dt;
    botThink(vzps);
    if (laneT < 1) { laneT = Math.min(1, laneT + dt / TUNE.laneTime); playerX = laneFrom + (LANEX[lane] - laneFrom) * ease(laneT); if (laneT >= 1) { playerX = LANEX[lane]; prevLane = lane; } }
    else { playerX = LANEX[lane]; prevLane = lane; }
    const groundedBefore = jumpY <= 0.02;
    if (groundedBefore && jumpV === 0) coyote = TUNE.coyoteTime; else coyote = Math.max(0, coyote - dt);
    const tryJ = () => { if (jumpBuf <= 0) return; if (!(jumpY <= 0.02 || coyote > 0)) return; jumpV = TUNE.jumpV; coyote = 0; jumpBuf = 0; };
    if (jumpBuf > 0) { jumpBuf -= dt; tryJ(); }
    if (jumpV !== 0 || jumpY > 0) { jumpV -= TUNE.gravity * dt; jumpY += jumpV * dt; if (jumpY < 0) { jumpY = 0; jumpV = 0; tryJ(); } }
    const airborne = jumpY > TUNE.airborneAt;
    if (comboTimer > 0) { comboTimer -= dt; if (comboTimer <= 0) combo = 1; }
    spawnT -= dt;
    const gapZ = Math.max(0.56, 1.02 - (level - 1) * 0.045), interval = Math.max(0.38, gapZ / vzps);
    if (spawnT <= 0) { spawnObstacle(); spawnT = interval; }
    orbT -= dt;
    if (orbT <= 0) { spawnOrb(); orbT = Math.max(0.50, 1.00 - level * 0.02) + rand() * 0.50; }
    const transiting = laneT < 1;
    for (let i = obstacles.length - 1; i >= 0; i--) {
      const o = obstacles[i]; o.pz = o.z; o.z += vz;
      if (o.drift > 0) { o.driftT = Math.min(o.drift, o.driftT + dt); const u = o.driftT / o.drift, e = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2; o.nx = LANEX[o.driftFrom] + (LANEX[o.driftTo] - LANEX[o.driftFrom]) * e; o.lane = e < 0.5 ? o.driftFrom : o.driftTo; if (o.driftT >= o.drift) o.drift = 0; }
      const dx = Math.abs(o.nx - playerX);
      const laneOK = !transiting || o.lane === lane || o.lane === prevLane || o.drift > 0;
      if (!o.hit && !o.near && o.pz < 1 && o.z >= 1 && dx >= COL.hitObstacle && dx < TUNE.nearMissBand) { o.near = true; commission += TUNE.nearMissPay * combo; }
      if (!o.hit && laneOK && o.pz < COL.zNear && o.z > COL.zFar && dx < COL.hitObstacle) {
        if (o.low && airborne) o.hit = true;
        else if (invuln > 0) o.hit = true;
        else if (shield > 0) { o.hit = true; shield--; invuln = 0.9; }
        else { o.hit = true; hits++; if (!deathLevel) deathLevel = level; if (!god) { perLevel[level] = commission; return { perLevel, orbsPerLevel, deathLevel, hits, t }; } invuln = 0.9; }
      }
      if (o.z >= 1.18) obstacles.splice(i, 1);
    }
    for (let i = orbs.length - 1; i >= 0; i--) {
      const o = orbs[i]; o.pz = o.z; o.z += vz;
      if (!o.got && o.pz < COL.zNear && o.z > COL.zFar && Math.abs(o.nx - playerX) < COL.hitOrb && (!o.high || airborne)) {
        o.got = true;
        if (o.kind === 'tsheet') { tsheets++; shield = Math.min(shield + 1, 3); if (tsheets % 5 === 0) commission += 100; }
        else { combo = Math.min(combo + 1, TUNE.comboMax); comboTimer = TUNE.comboWindow; commission += Math.round(KINDV[o.kind] * combo * (1 + (level - 1) * TUNE.orbLevelMult)); orbCount++; }
      }
      if (o.z >= 1.12 || o.got) orbs.splice(i, 1);
    }
  }
  return { perLevel, orbsPerLevel, deathLevel, hits, t };
}

export function oldEconomy(runs = 60, maxLevel = 16, god = true) {
  const sums = [], orbSums = [], cnt = [];
  let hits = 0, dl = [];
  for (let r = 0; r < runs; r++) {
    const res = run(1000 + r * 7919, maxLevel, god);
    hits += res.hits; if (res.deathLevel) dl.push(res.deathLevel);
    for (let L = 1; L < res.perLevel.length; L++) if (res.perLevel[L] !== undefined) {
      sums[L] = (sums[L] || 0) + res.perLevel[L]; orbSums[L] = (orbSums[L] || 0) + (res.orbsPerLevel[L] || 0); cnt[L] = (cnt[L] || 0) + 1;
    }
  }
  const cum = []; for (let L = 1; L < sums.length; L++) if (cnt[L]) cum[L] = { score: sums[L] / cnt[L], orbs: orbSums[L] / cnt[L] };
  return { cum, hitsPerRun: hits / runs, deathLevels: dl };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const runs = +(process.argv[2] || 60), maxL = +(process.argv[3] || 16), god = !process.argv.includes('--nogod');
  const t0 = Date.now();
  const r = oldEconomy(runs, maxL, god);
  console.log(`OLD 2D BUILD — look-ahead bot, ${runs} runs, god=${god}  (${((Date.now() - t0) / 1000).toFixed(1)} s)`);
  console.log('cumulative $ at the END of each level (mean):');
  let prev = 0, prevO = 0;
  for (let L = 1; L < r.cum.length; L++) if (r.cum[L]) {
    const c = r.cum[L];
    console.log(`  L${String(L).padStart(2)}  end $${Math.round(c.score).toString().padStart(8)}   level $${Math.round(c.score - prev).toString().padStart(7)}   orbs ${Math.round(c.orbs - prevO)}`);
    prev = c.score; prevO = c.orbs;
  }
  console.log('bot hits per run (absorbed by god mode):', r.hitsPerRun.toFixed(2));
  if (r.deathLevels.length) { const d = r.deathLevels.sort((a, b) => a - b); console.log('first-hit level median', d[d.length >> 1]); }
}
