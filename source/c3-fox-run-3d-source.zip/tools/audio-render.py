#!/usr/bin/env python3
"""Offline-render the procedural soundtrack + every SFX in headless Chromium and MEASURE it.

  python3 tools/audio-render.py            # everything (music, title, structure, sfx, jitter, realtime)
  python3 tools/audio-render.py --only music,sfx --bars 16 --no-png

Builds harness/audio.js -> scratch/audio/audio.html, drives window.__audioLab.render(spec)
(an OfflineAudioContext running the SAME engine code as the game), then reports:
  peak / true-peak (4x) dBFS, RMS dBFS, integrated loudness (BS.1770 LUFS, gated),
  per-band energy, 2-5 kHz spike detection, onset timing jitter, realtime scheduling margins,
  CPU (offline render speed, main-thread scheduling cost, nodes/s).
Writes WAVs + spectrogram PNGs to scratch/audio/ and report.json.
"""
import argparse, base64, functools, http.server, json, os, socketserver, subprocess, sys, threading, time, wave

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'scratch', 'audio')
STYLES = ['smokies', 'funk', 'hoosier', 'steel', 'house']
BPM = {'smokies': 116, 'funk': 106, 'hoosier': 118, 'steel': 122, 'house': 124, 'title': 100}
SFX = [
    ('coin_xm', 'coin', ['xm', 1]), ('coin_xm_c9', 'coin', ['xm', 9]), ('coin_tab', 'coin', ['tab', 4]),
    ('coin_watch', 'coin', ['watch', 2]), ('tsheet', 'tsheet', [3, 2]), ('bonus', 'bonus', []),
    ('combo3', 'combo', [3]), ('combo6', 'combo', [6]), ('combo9', 'combo', [9]), ('comboLost', 'comboLost', []),
    ('jump', 'jump', []), ('land', 'land', [6, False]), ('land_roof', 'land', [7, True]), ('lane', 'lane', [1]),
    ('bump', 'bump', [1]), ('ramp', 'ramp', []), ('roof', 'roof', []), ('drop', 'drop', []),
    ('nearMiss', 'nearMiss', [1]), ('hop', 'hop', []), ('shieldBreak', 'shieldBreak', []), ('smash', 'smash', []),
    ('pow_magnet', 'powerup', ['magnet']), ('pow_x2', 'powerup', ['x2']), ('pow_boost', 'powerup', ['boost']),
    ('powerTick', 'powerTick', ['x2', False]), ('powerEnd', 'powerEnd', ['x2']), ('boostStart', 'boostStart', []),
    ('boostEnd', 'boostEnd', []), ('trainPass', 'trainPass', [1]), ('levelUp', 'levelUp', []), ('hit', 'hit', []),
    ('gameOverSting', 'gameOverSting', []), ('click', 'click', []),
]

# ------------------------------------------------------------------ http + browser
def serve():
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a, **k): pass
    handler = functools.partial(Quiet, directory=ROOT)
    class TS(socketserver.ThreadingMixIn, http.server.HTTPServer):
        daemon_threads = True; allow_reuse_address = True
    httpd = TS(('127.0.0.1', 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd

TAG = '--audio-lab-probe=%d' % os.getpid()

def _tree_cpu():
    """CPU seconds (user+sys) of the Chromium instance launched with TAG and all its descendants."""
    tick = os.sysconf('SC_CLK_TCK')
    procs = {}
    for d in os.listdir('/proc'):
        if not d.isdigit(): continue
        try:
            st = open(f'/proc/{d}/stat').read()
            rest = st[st.rindex(')') + 2:].split()
            procs[int(d)] = (int(rest[1]), (int(rest[11]) + int(rest[12])) / tick)
        except Exception: pass
    root = None
    for pid in procs:
        try:
            if TAG in open(f'/proc/{pid}/cmdline').read().replace('\0', ' '): root = pid; break
        except Exception: pass
    if root is None: return None
    kids = {root}; changed = True
    while changed:
        changed = False
        for pid, (pp, _) in procs.items():
            if pp in kids and pid not in kids: kids.add(pid); changed = True
    return sum(procs[p][1] for p in kids)

def f32(b64):
    return np.frombuffer(base64.b64decode(b64), dtype=np.float32).astype(np.float64)

# ------------------------------------------------------------------ analysis
def db(x): return 20 * np.log10(max(float(x), 1e-12))

def kweight(x, sr):
    from scipy.signal import lfilter, bilinear
    # BS.1770 K-weighting designed for any sample rate (pre-filter shelf + RLB highpass)
    import math
    f0, G, Q = 1681.974450955533, 3.999843853973347, 0.7071752369554196
    K = math.tan(math.pi * f0 / sr); Vh = 10 ** (G / 20); Vb = Vh ** 0.4996667741545416
    a0 = 1 + K / Q + K * K
    b1 = [(Vh + Vb * K / Q + K * K) / a0, 2 * (K * K - Vh) / a0, (Vh - Vb * K / Q + K * K) / a0]
    a1 = [1, 2 * (K * K - 1) / a0, (1 - K / Q + K * K) / a0]
    f0, Q = 38.13547087602444, 0.5003270373238773
    K = math.tan(math.pi * f0 / sr)
    b2 = [1, -2, 1]; a2 = [1, 2 * (K * K - 1) / (1 + K / Q + K * K), (1 - K / Q + K * K) / (1 + K / Q + K * K)]
    return lfilter(b2, a2, lfilter(b1, a1, x))

def lufs(L, R, sr):
    zl, zr = kweight(L, sr) ** 2, kweight(R, sr) ** 2
    blk, hop = int(0.4 * sr), int(0.1 * sr)
    if len(zl) < blk: return -99.0
    n = 1 + (len(zl) - blk) // hop
    cl = np.cumsum(np.concatenate([[0], zl])); cr = np.cumsum(np.concatenate([[0], zr]))
    idx = np.arange(n) * hop
    ms = ((cl[idx + blk] - cl[idx]) + (cr[idx + blk] - cr[idx])) / blk
    lk = -0.691 + 10 * np.log10(np.maximum(ms, 1e-12))
    g = ms[lk > -70]
    if not len(g): return -99.0
    rel = -0.691 + 10 * np.log10(g.mean()) - 10
    g2 = ms[(lk > -70) & (lk > rel)]
    return float(-0.691 + 10 * np.log10(g2.mean()))

BANDS = [('sub', 20, 60), ('bass', 60, 250), ('lowmid', 250, 1000), ('mid', 1000, 2000),
         ('pres', 2000, 5000), ('high', 5000, 10000), ('air', 10000, 20000)]

def spectrum(mono, sr):
    from scipy.signal import welch
    f, p = welch(mono, sr, nperseg=8192, noverlap=4096)
    return f, p

def bands(f, p):
    tot = p[(f >= 20) & (f <= 20000)].sum() + 1e-30
    return {n: float(100 * p[(f >= a) & (f < b)].sum() / tot) for n, a, b in BANDS}

def third_octaves(f, p):
    fc = 1000 * 2 ** (np.arange(-15, 14) / 3)            # 31.5 Hz .. 16 kHz
    lv = []
    for c in fc:
        m = (f >= c / 2 ** (1 / 6)) & (f < c * 2 ** (1 / 6))
        lv.append(10 * np.log10(p[m].sum() + 1e-30))
    return fc, np.array(lv)

def spike_2_5k(f, p):
    """Harshness check: the largest excess (dB) of any 1/3-octave band in 2-5 kHz over the
    mix's own spectral tilt (least-squares line through the 100 Hz-10 kHz bands in dB/octave).
    Musical mixes slope down; a band sticking > ~4 dB above that slope reads as harsh."""
    fc, lv = third_octaves(f, p)
    fit = (fc >= 100) & (fc <= 10000)
    k, c = np.polyfit(np.log2(fc[fit]), lv[fit], 1)
    ex = lv - (k * np.log2(fc) + c)
    sel = (fc >= 2000) & (fc <= 5000)
    i = int(np.argmax(np.where(sel, ex, -1e9)))
    return float(ex[i]), float(fc[i])

def tilt(f, p):
    fc, lv = third_octaves(f, p)
    fit = (fc >= 100) & (fc <= 10000)
    return float(np.polyfit(np.log2(fc[fit]), lv[fit], 1)[0])

def true_peak(x):
    from scipy.signal import resample_poly
    return float(np.max(np.abs(resample_poly(x, 4, 1))))

def analyse(L, R, sr, name):
    mono = 0.5 * (L + R)
    f, p = spectrum(mono, sr)
    sp, spf = spike_2_5k(f, p)
    pk = max(np.max(np.abs(L)), np.max(np.abs(R)))
    tp = max(true_peak(L), true_peak(R))
    rms = np.sqrt(np.mean(np.concatenate([L, R]) ** 2))
    return {'name': name, 'peak_db': round(db(pk), 2), 'tpeak_db': round(db(tp), 2), 'rms_db': round(db(rms), 2),
            'lufs': round(lufs(L, R, sr), 2), 'bands': {k: round(v, 1) for k, v in bands(f, p).items()},
            'spike_db': round(sp, 1), 'spike_hz': round(spf), 'tilt_db_oct': round(tilt(f, p), 2), 'corr': round(float(np.corrcoef(L, R)[0, 1]) if np.std(L) > 0 and np.std(R) > 0 else 1.0, 3)}

def write_wav(path, L, R, sr):
    x = np.stack([L, R], 1)
    x = np.clip(x, -1, 1)
    with wave.open(path, 'wb') as w:
        w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
        w.writeframes((x * 32767).astype('<i2').tobytes())

def spectrogram(path, L, R, sr, title, bar=None, t0=0.06, marks=()):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    mono = 0.5 * (L + R)
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(14, 6.2), gridspec_kw={'height_ratios': [1, 3]}, sharex=True)
    t = np.arange(len(mono)) / sr
    step = max(1, len(mono) // 6000)
    env = np.abs(mono[:len(mono) // step * step].reshape(-1, step)).max(1)
    a1.fill_between(t[::step][:len(env)], -env, env, color='#2a7fff', lw=0)
    a1.set_ylim(-1, 1); a1.set_ylabel('amp'); a1.set_title(title)
    a2.specgram(mono, NFFT=2048, Fs=sr, noverlap=1536, cmap='magma', vmin=-130, vmax=-20, scale='dB')
    a2.set_yscale('symlog', linthresh=500); a2.set_ylim(30, 16000); a2.set_ylabel('Hz'); a2.set_xlabel('s')
    if bar:
        k = 0
        while t0 + k * bar < t[-1]:
            for a in (a1, a2): a.axvline(t0 + k * bar, color='#7fffd4' if k % 4 == 0 else '#ffffff', alpha=0.55 if k % 4 == 0 else 0.18, lw=1)
            k += 1
    for (mt, lab) in marks:
        for a in (a1, a2): a.axvline(mt, color='#ff4040', lw=1.5, ls='--')
        a1.text(mt, 0.85, ' ' + lab, color='#ff4040', fontsize=8)
    plt.tight_layout(); plt.savefig(path, dpi=80); plt.close(fig)

def onset_jitter(L, R, sr, times):
    """detect kick onsets (energy rise) and compare with the scheduled times."""
    x = np.abs(0.5 * (L + R))
    thr = 0.02
    errs = []
    for t in times:
        i0 = int(t * sr) - int(0.003 * sr); i1 = int(t * sr) + int(0.03 * sr)
        if i0 < 0 or i1 >= len(x): continue
        seg = x[i0:i1]
        k = np.argmax(seg > thr)
        if seg[k] <= thr: continue
        errs.append((i0 + k) / sr - t)
    e = np.array(errs)
    if not len(e): return None
    d = e - np.median(e)
    return {'n': len(e), 'latency_ms': round(float(np.median(e)) * 1000, 3), 'jitter_std_ms': round(float(d.std()) * 1000, 4),
            'jitter_max_ms': round(float(np.abs(d).max()) * 1000, 4)}

def grid_residual(times, beat):
    t = np.array(sorted(times))
    k = np.round((t - t[0]) / beat)
    res = t - (t[0] + k * beat)
    return float(np.abs(res).max() * 1000)

# ------------------------------------------------------------------ specs
def bar_dur(style): return 240.0 / BPM[style]

def music_spec(style, layers, bars, lift=0):
    return {'dur': 0.06 + bars * bar_dur(style) + 1.2, 'events': [{'t': 0, 'do': 'run', 'style': style, 'layers': layers, 'lift': lift, 'level': 5}]}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--only', default='music,title,structure,power,death,stress,sfx,jitter,realtime,api,cpu')
    ap.add_argument('--bars', type=int, default=16)
    ap.add_argument('--no-png', action='store_true')
    ap.add_argument('--nobuild', action='store_true')
    a = ap.parse_args()
    only = set(a.only.split(','))
    os.makedirs(OUT, exist_ok=True)
    if not a.nobuild:
        r = subprocess.run(['node', 'build.mjs', 'harness/audio.js', 'scratch/audio/audio.html', '--dev'], cwd=ROOT, capture_output=True, text=True)
        print(r.stdout.strip())
        if r.returncode: print(r.stderr); sys.exit(1)
    httpd = serve()
    url = f'http://127.0.0.1:{httpd.server_address[1]}/scratch/audio/audio.html'
    from playwright.sync_api import sync_playwright
    report = {'music': [], 'sfx': [], 'misc': {}}
    logs = []
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium',
                              args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--autoplay-policy=no-user-gesture-required', TAG])
        pg = b.new_page()
        pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}') if m.type in ('error', 'warning') else None)
        pg.on('pageerror', lambda e: logs.append(f'[PAGEERROR] {e}'))
        pg.goto(url); pg.wait_for_function('window.__audioLab'); time.sleep(0.3)

        def R(spec, name):
            t0 = time.time()
            res = pg.evaluate('s => window.__audioLab.render(s)', spec)
            L, Rr = f32(res['L']), f32(res['R'])
            res['wall'] = time.time() - t0
            return res, L, Rr

        def music_row(name, spec, style, png=True, marks=()):
            res, L, Rr = R(spec, name)
            an = analyse(L, Rr, res['sr'], name)
            an.update({'rt_x': round(res['dur'] / (res['renderMs'] / 1000), 1), 'sched_ms_per_s': round(res['schedMs'] / res['dur'], 2),
                       'nodes_per_s': round(res['nodes'] / res['dur'], 1), 'late': res['meta']['lateSkips']})
            write_wav(os.path.join(OUT, f'audio_{name}.wav'), L, Rr, res['sr'])
            if png and not a.no_png:
                spectrogram(os.path.join(OUT, f'audio_{name}.png'), L, Rr, res['sr'], f'{name}  ({style} {BPM.get(style, 0)} bpm)', bar=bar_dur(style), marks=marks)
            print(f"  {name:22s} peak {an['peak_db']:6.2f}  tp {an['tpeak_db']:6.2f}  rms {an['rms_db']:6.2f}  LUFS {an['lufs']:6.2f}  "
                  f"spike {an['spike_db']:4.1f}dB@{an['spike_hz']}  x{an['rt_x']}  {an['nodes_per_s']} nodes/s  bands {an['bands']}", flush=True)
            return an, res, L, Rr

        if 'music' in only:
            print('== music (16 bars each, low = L1 drums+bass, high = L5 all layers)')
            for s in STYLES:
                for lvl, tag in ((1, 'low'), (5, 'high')):
                    an, *_ = music_row(f'{s}_{tag}', music_spec(s, lvl, a.bars), s, png=(tag == 'high' or s == 'smokies'))
                    an.update({'style': s, 'layers': lvl}); report['music'].append(an)
        if 'title' in only:
            print('== title')
            spec = {'dur': 0.06 + a.bars * bar_dur('title') + 1, 'events': [{'t': 0, 'do': 'title'}]}
            an, *_ = music_row('title', spec, 'title'); an['style'] = 'title'; report['music'].append(an)
        if 'structure' in only:
            print('== structure: L1 -> (level 3 set mid-phrase at bar 6.5) -> levelUp to funk at bar 13.3')
            bd = bar_dur('smokies'); t0 = 0.06
            ev = [{'t': 0, 'do': 'run', 'style': 'smokies', 'level': 1},
                  {'t': t0 + 6.5 * bd, 'do': 'game', 'level': 3},
                  {'t': t0 + 13.3 * bd, 'do': 'levelUp', 'themeIdx': 3, 'level': 4}]
            spec = {'dur': t0 + 22 * bd, 'events': ev, 'log': True}
            an, res, L, Rr = music_row('structure', spec, 'smokies', marks=[(t0 + 6.5 * bd, 'level3 set'), (t0 + 13.3 * bd, 'levelUp')])
            # when did each part first play?
            first = {}
            for n in res['log']:
                first.setdefault(n['part'], (n['bar'], n['step']))
            report['misc']['structure_first'] = first
            print('   first note per part (bar, step):', first)
        if 'power' in only:
            print('== power colour: house L5, boost bar 2-4.5, 2x sparkle bar 5-9')
            bd = bar_dur('house'); t0 = 0.06
            ev = [{'t': 0, 'do': 'run', 'style': 'house', 'layers': 5, 'level': 5},
                  {'t': t0 + 2 * bd - 0.05, 'do': 'boost', 'on': True}, {'t': t0 + 4.5 * bd, 'do': 'boost', 'on': False},
                  {'t': t0 + 5 * bd, 'do': 'x2', 'on': True}, {'t': t0 + 9 * bd, 'do': 'x2', 'on': False}]
            an, *_ = music_row('power', {'dur': t0 + 10 * bd, 'events': ev}, 'house', marks=[(t0 + 2 * bd, 'boost'), (t0 + 4.5 * bd, 'boostEnd'), (t0 + 5 * bd, '2x'), (t0 + 9 * bd, '2x end')])
            report['misc']['power'] = an
        if 'death' in only:
            print('== death: smokies L4, hit at bar 3.3, game over at +1.1 s')
            bd = bar_dur('smokies'); t0 = 0.06
            ev = [{'t': 0, 'do': 'run', 'style': 'smokies', 'layers': 4, 'level': 4},
                  {'t': t0 + 3.3 * bd, 'do': 'hit'}, {'t': t0 + 3.3 * bd + 1.1, 'do': 'gameover'}]
            an, *_ = music_row('death', {'dur': t0 + 3.3 * bd + 5, 'events': ev}, 'smokies', marks=[(t0 + 3.3 * bd, 'hit'), (t0 + 3.3 * bd + 1.1, 'game over')])
            report['misc']['death'] = an
        if 'stress' in only:
            print('== stress: house L5 + lift + boost + 2x + coin spam + trucks + fanfare (limiter check)')
            bd = bar_dur('house'); t0 = 0.06
            ev = [{'t': 0, 'do': 'run', 'style': 'house', 'layers': 5, 'lift': 2, 'level': 8},
                  {'t': 0.5, 'do': 'boost', 'on': True}, {'t': 0.5, 'do': 'x2', 'on': True}, {'t': 0.1, 'do': 'bed', 'speed': 30, 'boost': True}]
            k = 0; t = 0.6
            while t < 8 * bd:
                ev.append({'t': t, 'do': 'sfx', 'name': 'coin', 'args': [['xm', 'tab', 'watch'][k % 3], 1 + k % 9]}); t += 0.09; k += 1
            for tt in (1.5, 3.0, 4.5, 6.0): ev.append({'t': tt, 'do': 'sfx', 'name': 'trainPass', 'args': [1 if tt % 3 else -1]})
            for tt in (2.2, 5.2): ev.append({'t': tt, 'do': 'sfx', 'name': 'shieldBreak'}); ev.append({'t': tt + 0.1, 'do': 'sfx', 'name': 'bonus'})
            ev.append({'t': 3.7, 'do': 'sfx', 'name': 'levelUp'}); ev.append({'t': 3.9, 'do': 'sfx', 'name': 'combo', 'args': [9]})
            an, *_ = music_row('stress', {'dur': t0 + 8 * bd, 'events': ev}, 'house')
            report['misc']['stress'] = an
        if 'sfx' in only:
            print('== sfx (each alone, through the master chain)')
            for name, fn, args in SFX:
                dur = 3.2 if name in ('gameOverSting',) else 2.2 if name in ('trainPass', 'boostStart', 'hit', 'levelUp', 'bonus') else 1.2
                ev = [{'t': 0.05, 'do': 'sfx', 'name': fn, 'args': args}]
                if name == 'boostStart': ev.append({'t': 1.4, 'do': 'sfx', 'name': 'boostEnd'})
                res, L, Rr = R({'dur': dur, 'events': ev}, name)
                an = analyse(L, Rr, res['sr'], name)
                x = np.abs(0.5 * (L + Rr)); on = np.where(x > 10 ** (-50 / 20))[0]
                an['len_ms'] = round((on[-1] - on[0]) / res['sr'] * 1000) if len(on) else 0
                an['nodes'] = res['nodes']
                an['pan'] = round(float(np.sqrt(np.mean(Rr ** 2)) - np.sqrt(np.mean(L ** 2))) / max(1e-9, float(np.sqrt(np.mean(0.5 * (L ** 2 + Rr ** 2))))), 2)
                report['sfx'].append(an)
                write_wav(os.path.join(OUT, f'audio_sfx_{name}.wav'), L, Rr, res['sr'])
                print(f"  {name:14s} peak {an['peak_db']:6.2f}  rms {an['rms_db']:6.2f}  LUFS {an['lufs']:6.2f}  len {an['len_ms']:5d}ms  "
                      f"nodes {an['nodes']:3d}  pan {an['pan']:+.2f}  spike {an['spike_db']:4.1f}@{an['spike_hz']}  pres {an['bands']['pres']:.0f}%", flush=True)
                if not a.no_png:
                    spectrogram(os.path.join(OUT, f'audio_sfx_{name}.png'), L, Rr, res['sr'], f'SFX {name}')
            if not a.no_png: sfx_sheet(report['sfx'])
        if 'jitter' in only:
            print('== onset jitter (kick solo, 8 bars per style) + grid residual of scheduled times')
            jit = {}
            for s in STYLES:
                spec = {'dur': 0.06 + 8 * bar_dur(s) + 0.5, 'log': True, 'events': [
                    {'t': 0, 'do': 'run', 'style': s, 'layers': 1, 'level': 5}, {'t': 0, 'do': 'solo', 'parts': ['kick']}]}
                res, L, Rr = R(spec, 'jit_' + s)
                kt = [n['t'] for n in res['log'] if n['part'] == 'kick']
                j = onset_jitter(L, Rr, res['sr'], kt)
                allt = [n['t'] for n in res['log'] if n['part'] in ('kick', 'snare', 'hat', 'bass') and n['step'] % 2 == 0]
                j['grid_residual_ms'] = round(grid_residual(allt, res['meta']['stepDur'] * 2), 6)
                jit[s] = j
                print(f'  {s:8s} {j}')
            report['misc']['jitter'] = jit
        if 'api' in only:
            print('== API integration (createAudio through a fake-sim run)')
            api = {}
            # 1) no WebAudio at all: every call must be a silent no-op
            pg2 = b.new_page()
            pg2.add_init_script('delete window.AudioContext; delete window.webkitAudioContext; delete window.OfflineAudioContext;')
            errs2 = []
            pg2.on('pageerror', lambda e: errs2.append(str(e)))
            pg2.goto(url); pg2.wait_for_function('window.__audio')
            api['no_webaudio'] = pg2.evaluate('''() => { const a = window.__audio; const sim = window.__createFakeSim({});
                try { const u = a.unlock(); a.toTitle(); a.toRun(); a.onEvent({type:'coin', kind:'xm', combo:3}, sim); a.update(sim, {dt:0.016});
                      a.setMuted(true); a.setMuted(false); a.setPaused(true); a.setPaused(false); a.click(); a.toGameOver();
                      return {ok:true, unlock:u, muted:a.muted}; } catch (e) { return {ok:false, err:String(e)}; } }''')
            api['no_webaudio']['pageerrors'] = errs2
            pg2.close()
            print('  no WebAudio:', api['no_webaudio'])
            # 2) real flow with a trusted gesture
            pg.evaluate("localStorage.removeItem('c3fox.muted'); window.__labPause = true")
            pg.click('text=START AUDIO')
            time.sleep(0.4)
            st = pg.evaluate("() => ({state: __audio.context && __audio.context.state, scene: __audio.scene})")
            print('  after gesture unlock:', st); api['unlock'] = st
            flow = pg.evaluate('''async () => {
              const a = window.__audio, E = () => a.engine, S = () => a.engine.music.S;
              const sim = window.__createFakeSim({ themeIdx: 0, speed: 17, levelLen: 100000 });
              const out = { samples: [], frameMs: [], events: 0 };
              const sleep = ms => new Promise(r => setTimeout(r, ms));
              let running = true;
              const loop = async () => { let last = performance.now();
                while (running) { await sleep(16); const now = performance.now(), dt = Math.min(0.05, (now - last) / 1000); last = now;
                  sim.step(dt); const t0 = performance.now();
                  for (const ev of sim.events) { a.onEvent(ev, sim); out.events++; }
                  a.update(sim, { dt, tier: 'high' }); out.frameMs.push(performance.now() - t0); sim.events.length = 0; } };
              const snap = tag => out.samples.push({ tag, scene: a.scene, eng: E().scene, style: S().styleId, bar: S().bar, layers: S().layers,
                   boost: S().boost, sparkle: S().sparkle, pending: !!S().pending, vol: E().graph.musicVol.gain.value, ctx: a.context.state,
                   boostLoop: E().sfx.boostActive(), late: S().lateSkips });
              a.toTitle(); await sleep(600); snap('title');
              a.toRun(); sim.events.push({ type: 'start' }); loop(); await sleep(2500); snap('run L1');
              sim.level = 4; sim.forceTheme(3); await sleep(150); snap('levelUp sent'); await sleep(3200); snap('after levelUp');
              sim.setPower('boost', 3); sim.setPower('x2', 4); await sleep(600); snap('boost+x2');
              await sleep(3200); snap('boost ended');
              a.setPaused(true); await sleep(400); snap('paused'); a.setPaused(false); await sleep(300); snap('resumed');
              Object.defineProperty(document, 'visibilityState', { value: 'hidden', configurable: true });
              document.dispatchEvent(new Event('visibilitychange')); await sleep(400); snap('hidden');
              Object.defineProperty(document, 'visibilityState', { value: 'visible', configurable: true });
              document.dispatchEvent(new Event('visibilitychange')); await sleep(400); snap('visible');
              sim.kill(); await sleep(300); snap('hit'); await sleep(1200); snap('death->over');
              running = false; a.toTitle(); await sleep(500); snap('title again');
              a.setMuted(true); await sleep(300); const mutedState = a.context.state; const stored = localStorage.getItem('c3fox.muted');
              a.setMuted(false); await sleep(300);
              const fm = out.frameMs.slice().sort((x, y) => x - y);
              return { samples: out.samples, events: out.events, frames: fm.length, frame_ms_avg: fm.reduce((s, v) => s + v, 0) / fm.length,
                       frame_ms_p99: fm[Math.floor(fm.length * 0.99)], frame_ms_max: fm[fm.length - 1], mutedState, stored, unmutedState: a.context.state,
                       nodes: E().I.stats.nodes };
            }''')
            for smp in flow['samples']: print('   ', smp)
            print('  events', flow['events'], 'frames', flow['frames'], 'update+onEvent ms/frame avg %.3f p99 %.3f max %.3f' % (flow['frame_ms_avg'], flow['frame_ms_p99'], flow['frame_ms_max']))
            print('  mute: ctx', flow['mutedState'], 'stored', flow['stored'], '-> unmuted ctx', flow['unmutedState'])
            api['flow'] = flow
            report['misc']['api'] = api
            pg.evaluate('() => window.__audio.dispose()')  # so later CPU baselines are really idle
        if 'cpu' in only:
            print('== CPU (seconds of CPU burned by this Chromium tree per second of audio; immune to machine load)')
            cpu = {}
            def probe(label, spec):
                c0 = _tree_cpu(); res = pg.evaluate('s => window.__audioLab.render(s)', dict(spec, noData=True)); c1 = _tree_cpu()
                cpu[label] = {'cpu_per_audio_s': round((c1 - c0) / res['dur'], 4), 'sched_ms_per_s': round(res['schedMs'] / res['dur'], 2),
                              'nodes_per_s': round(res['nodes'] / res['dur'], 1)}
                print(f'  {label:18s}', cpu[label], flush=True)
            probe('silence(graph)', {'dur': 20, 'events': []})
            for s_ in STYLES: probe(f'{s_}_L5', music_spec(s_, 5, 10))
            probe('house_L5_boost_x2', {'dur': 20, 'events': [{'t': 0, 'do': 'run', 'style': 'house', 'layers': 5, 'level': 5},
                  {'t': 0.2, 'do': 'boost', 'on': True}, {'t': 0.2, 'do': 'x2', 'on': True}, {'t': 0.1, 'do': 'bed', 'speed': 30}]})
            # realtime: an idle page vs the live engine for the same wall time
            c0 = _tree_cpu(); pg.evaluate('s => window.__audioLab.idle(s)', 6); c1 = _tree_cpu()
            rt = pg.evaluate('s => window.__audioLab.realtime(s)', {'seconds': 6, 'style': 'house'}); c2 = _tree_cpu()
            cpu['realtime_idle_page'] = round((c1 - c0) / 6, 4); cpu['realtime_house_L5'] = round((c2 - c1) / max(0.5, rt['ctxElapsed']), 4)
            print('   realtime: idle page', cpu['realtime_idle_page'], 'cpu/s   live engine', cpu['realtime_house_L5'], 'cpu/s  (ctx ran', round(rt['ctxElapsed'], 2), 's)')
            report['misc']['cpu'] = cpu
        if 'realtime' in only:
            print('== realtime AudioContext (setInterval pump 25 ms, lookahead 120 ms)')
            for jank in (False, True):
                rt = pg.evaluate('s => window.__audioLab.realtime(s)', {'seconds': 6, 'jank': jank, 'style': 'house'})
                m = np.array([n['margin'] for n in rt['log']]) if rt['log'] else np.array([0.0])
                kicks = sorted(n['t'] for n in rt['log'] if n['part'] == 'kick')
                beat = rt['stepDur'] * 4
                dev = np.abs(np.diff(kicks) - beat).max() * 1000 if len(kicks) > 2 else -1
                out = {'jank': jank, 'state': rt['state'], 'ctx_s': round(rt['ctxElapsed'], 2), 'wall_s': round(rt['wall'], 2),
                       'notes': len(rt['log']), 'margin_min_ms': round(float(m.min()) * 1000, 1), 'margin_med_ms': round(float(np.median(m)) * 1000, 1),
                       'late_notes': int((m < 0).sum()), 'late_skips': rt['lateSkips'], 'kick_interval_dev_ms': round(float(dev), 4),
                       'sched_ms_per_s': round(rt['schedMs'] / max(0.1, rt['ctxElapsed']), 2), 'janks': len(rt['janks'])}
                report['misc'][f'realtime_{"jank" if jank else "clean"}'] = out
                print('  ', out)
        b.close()
    httpd.shutdown()

    # ---------- summary
    mus = [m for m in report['music'] if m.get('style') in STYLES]
    if mus:
        hi = [m['lufs'] for m in mus if m['layers'] == 5]; lo = [m['lufs'] for m in mus if m['layers'] == 1]
        allpk = [m['tpeak_db'] for m in report['music']] + [s['tpeak_db'] for s in report['sfx']] + [v['tpeak_db'] for k, v in report['misc'].items() if isinstance(v, dict) and 'tpeak_db' in v]
        summ = {'lufs_spread_high': round(max(hi) - min(hi), 2) if hi else None, 'lufs_spread_low': round(max(lo) - min(lo), 2) if lo else None,
                'max_true_peak_db': round(max(allpk), 2)}
        report['summary'] = summ
        print('== SUMMARY', summ)
    errs = [l for l in logs if 'PAGEERROR' in l or l.startswith('[error]')]
    report['console'] = logs[:50]
    print(f'--- console: {len(errs)} errors, {len(logs)} warnings/errors total')
    for l in logs[:20]: print('  ', l)
    with open(os.path.join(OUT, 'report.json'), 'w') as fh: json.dump(report, fh, indent=1)
    print('wrote', os.path.relpath(os.path.join(OUT, 'report.json'), ROOT))

def sfx_sheet(rows):
    import matplotlib; matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import wave as wv
    n = len(rows); cols = 6; rws = (n + cols - 1) // cols
    fig, axs = plt.subplots(rws, cols, figsize=(cols * 3, rws * 2.1))
    for i, ax in enumerate(axs.flat):
        ax.set_xticks([]); ax.set_yticks([])
        if i >= n: ax.axis('off'); continue
        name = rows[i]['name']
        with wv.open(os.path.join(OUT, f'audio_sfx_{name}.wav')) as w:
            d = np.frombuffer(w.readframes(w.getnframes()), '<i2').reshape(-1, 2).mean(1) / 32767
            sr = w.getframerate()
        ax.specgram(d, NFFT=1024, Fs=sr, noverlap=768, cmap='magma', vmin=-130, vmax=-20, scale='dB')
        ax.set_ylim(40, 14000); ax.set_yscale('symlog', linthresh=500)
        ax.set_title(f"{name}  {rows[i]['peak_db']:.1f}dB", fontsize=8)
    plt.tight_layout(); plt.savefig(os.path.join(OUT, 'audio_sfx_sheet.png'), dpi=70); plt.close(fig)

if __name__ == '__main__':
    main()
