#!/usr/bin/env python3
"""Calibrate per-part music mix gains to loudness targets (measured, not guessed).

  python3 tools/audio-calibrate.py            # measure + print proposed mix tables
  python3 tools/audio-calibrate.py --write    # also patch the `mix: {...}` lines in src/audio/styles.js

Each part is rendered SOLO (layer 5, 4 bars) with the master dynamics bypassed; its BS.1770
loudness is compared with ROLE targets (+ per-style flavour offsets) and the style's mix gain
for that part is scaled by the difference.
"""
import argparse, importlib.util, os, re, subprocess, sys, time
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
spec = importlib.util.spec_from_file_location('ar', os.path.join(ROOT, 'tools', 'audio-render.py'))
ar = importlib.util.module_from_spec(spec); spec.loader.exec_module(ar)

# pre-master solo loudness targets (LUFS) -> full mix lands near -20 LUFS before the master chain,
# about -16.5 LUFS after it: the music sits a few dB under the SFX
BASE = {'kick': -26.5, 'bass': -27.5, 'snare': -29.5, 'hat': -34.5, 'ohat': -34.5, 'perc': -35.5,
        'lead': -26.5, 'chords': -31.5, 'pad': -34.5, 'arp': -32.5, 'counter': -34.5}
FLAVOUR = {
    'smokies': {'arp': 1.5, 'pad': -1, 'chords': -0.5, 'perc': -1, 'hat': 0.5},
    'funk':    {'bass': 1, 'chords': 0.5, 'pad': -0.5, 'arp': -1, 'snare': 0.5},
    'hoosier': {'snare': 1, 'chords': 0.5, 'arp': -0.5, 'lead': 0.5},
    'steel':   {'bass': 1, 'perc': 1, 'chords': -0.5},
    'house':   {'kick': 1, 'chords': 1, 'pad': -1, 'arp': -0.5, 'lead': -0.5, 'ohat': 1.5, 'hat': -2},
}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--write', action='store_true'); ap.add_argument('--styles', default=','.join(ar.STYLES))
    a = ap.parse_args()
    subprocess.run(['node', 'build.mjs', 'harness/audio.js', 'scratch/audio/audio.html', '--dev'], cwd=ROOT, capture_output=True)
    httpd = ar.serve(); url = f'http://127.0.0.1:{httpd.server_address[1]}/scratch/audio/audio.html'
    from playwright.sync_api import sync_playwright
    new = {}
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium', args=['--autoplay-policy=no-user-gesture-required'])
        pg = b.new_page(); pg.goto(url); pg.wait_for_function('window.__audioLab')
        info = pg.evaluate('window.__audioLab.styleInfo()')
        for st in a.styles.split(','):
            mix = dict(info[st]['mix'])
            out = dict(mix)
            print('==', st)
            for part in info[st]['parts']:
                if part not in BASE: continue
                ev = [{'t': 0, 'do': 'run', 'style': st, 'layers': 5, 'level': 5}, {'t': 0, 'do': 'bypass'}, {'t': 0, 'do': 'solo', 'parts': [part]}]
                res = pg.evaluate('s => window.__audioLab.render(s)', {'dur': 0.06 + 4 * ar.bar_dur(st), 'events': ev})
                L, R = ar.f32(res['L']), ar.f32(res['R'])
                lu = ar.lufs(L, R, res['sr'])
                tgt = BASE[part] + FLAVOUR.get(st, {}).get(part, 0)
                g = float(np.clip(mix[part] * 10 ** ((tgt - lu) / 20), 0.02, 6))
                out[part] = round(g, 3)
                print(f'  {part:8s} measured {lu:6.1f}  target {tgt:6.1f}  mix {mix[part]:.3f} -> {g:.3f}', flush=True)
            new[st] = out
        b.close()
    httpd.shutdown()
    if a.write:
        path = os.path.join(ROOT, 'src', 'audio', 'styles.js')
        src = open(path).read()
        for st, m in new.items():
            # find the style block by its id and replace its mix line
            i = src.index(f"id: '{st}'")
            j = src.index('  mix: {', i); k = src.index('},', j) + 2
            line = '  mix: { ' + ', '.join(f'{kk}: {vv}' for kk, vv in m.items()) + ' },'
            src = src[:j] + line + src[k:]
        open(path, 'w').write(src)
        print('patched', os.path.relpath(path, ROOT))

if __name__ == '__main__':
    main()
