#!/usr/bin/env python3
"""End-to-end playtest of dist/index.html in headless Chromium.

Drives the real game: loading -> title -> play (sim bot on autopilot) -> captures shots at
interesting moments (level-up gantry, truck roof, boost, magnet) -> lets the fox die ->
game over: types a name, posts (leaderboard OFFLINE via ?lb=off), checks the top-5 list ->
RETRY -> confirms a new run is live. Prints every console error.

  python3 tools/playtest.py [--w 390 --h 844] [--tier high] [--name pt] [--seconds 90]
"""
import argparse, os, sys, time, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from shot import serve, ROOT

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--w', type=int, default=390); ap.add_argument('--h', type=int, default=844)
    ap.add_argument('--tier', default='high'); ap.add_argument('--name', default='pt')
    ap.add_argument('--seconds', type=float, default=80); ap.add_argument('--touch', action='store_true')
    ap.add_argument('--extra', default='')
    a = ap.parse_args()
    out = os.path.join(ROOT, 'scratch', a.name); os.makedirs(out, exist_ok=True)
    httpd = serve()
    url = f'http://127.0.0.1:{httpd.server_address[1]}/dist/index.html?lb=off&autoplay=1&tier={a.tier}{a.extra}'
    from playwright.sync_api import sync_playwright
    logs = []
    shots = []
    def shot(pg, tag):
        p = os.path.join(out, f'{len(shots):02d}-{tag}.png'); pg.screenshot(path=p, timeout=120000); shots.append(p); print('shot', os.path.relpath(p, ROOT))
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium',
                              args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--autoplay-policy=no-user-gesture-required'])
        ctx = b.new_context(viewport={'width': a.w, 'height': a.h}, has_touch=a.touch, is_mobile=a.touch)
        pg = ctx.new_page()
        pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}') if m.type in ('error', 'warning') else None)
        pg.on('pageerror', lambda e: logs.append(f'[PAGEERROR] {e}'))
        pg.goto(url)
        t0 = time.time()
        while time.time() - t0 < 60:
            ph = pg.evaluate('window.__game && __game.phase')
            scr = pg.evaluate('window.__game && __game.ui.screen')
            if ph == 'title' and scr == 'title': break
            time.sleep(0.5)
        print('title after %.1fs' % (time.time() - t0))
        pg.evaluate('__app.advance(0.6)'); shot(pg, 'title')
        pg.click('.t-play')
        pg.evaluate('__app.stop()')   # SwiftShader: drive frames with advance() only
        pg.evaluate('__app.advance(0.5)')
        print('phase', pg.evaluate('__game.phase'), 'screen', pg.evaluate('__game.ui.screen'))
        shot(pg, 'start')
        want = {'gantry': False, 'roof': False, 'boost': False, 'magnet': False, 'x2': False, 'L3': False, 'truck': False}
        simt = 0.0
        step = 0.25
        while simt < a.seconds:
            st = pg.evaluate('''(() => { const s = __game.sim; const p = s.player;
              const ahead = s.nextLevelAt - s.dist;
              const tr = s.trains.find(t => t.s - s.dist > 8 && t.s - s.dist < 26);
              return { mode: s.mode, lvl: s.level, ahead, roof: !!p.onRoof, y: p.y, boost: s.power.boost, magnet: s.power.magnet, x2: s.power.x2, truck: !!tr, score: Math.floor(s.score) }; })()''')
            if st['mode'] != 'play': break
            if not want['gantry'] and 14 < st['ahead'] < 30: shot(pg, f'gantry-L{st["lvl"]}'); want['gantry'] = True
            elif not want['roof'] and st['roof']: shot(pg, 'roof'); want['roof'] = True
            elif not want['boost'] and st['boost'] > 1 and st['y'] > 3: shot(pg, 'boost'); want['boost'] = True
            elif not want['magnet'] and st['magnet'] > 1: shot(pg, 'magnet'); want['magnet'] = True
            elif not want['truck'] and st['truck'] and st['lvl'] >= 2: shot(pg, 'truck'); want['truck'] = True
            elif not want['L3'] and st['lvl'] >= 3: shot(pg, 'L3'); want['L3'] = True
            pg.evaluate(f'__app.advance({step})'); simt += step
        st = pg.evaluate('({lvl: __game.sim.level, score: Math.floor(__game.sim.score), dist: Math.floor(__game.sim.dist), mode: __game.sim.mode})')
        print('after run', st, 'sim seconds', simt)
        # die: stop the bot and let the road kill us
        pg.evaluate('__game.sim.autopilot = false')
        for i in range(80):
            pg.evaluate('__app.advance(0.25)')
            if pg.evaluate('__game.sim.mode') in ('dying', 'over'): break
        pg.evaluate('__app.advance(0.35)'); shot(pg, 'dying')
        for i in range(30):
            pg.evaluate('__app.advance(0.25)')
            if pg.evaluate('__game.ui.screen') == 'over': break
        time.sleep(1.2); pg.evaluate('__app.advance(0.1)')
        print('killer', pg.evaluate('JSON.stringify(__game.sim.killer)'), 'screen', pg.evaluate('__game.ui.screen'))
        shot(pg, 'over')
        # post a name
        inp = pg.query_selector('.scr-over input')
        if inp:
            inp.fill(''); inp.type('PLAYTEST BOT'); pg.keyboard.press('Enter')
            time.sleep(1.5); pg.evaluate('__app.advance(0.1)')
            shot(pg, 'posted')
            rows = pg.evaluate('Array.from(document.querySelectorAll(".scr-over .lb-row, .scr-over li")).map(e => e.innerText.replace(/\\s+/g," ")).slice(0,8)')
            print('board rows', rows)
        else:
            print('NO NAME INPUT FOUND')
        time.sleep(0.6)
        btn = pg.query_selector('.scr-over .o-retry, .scr-over button.btn-retry, .scr-over [class*=retry]')
        if btn: btn.click()
        else: print('NO RETRY BUTTON FOUND')
        pg.evaluate('__app.advance(1.0)')
        print('after retry phase', pg.evaluate('__game.phase'), 'screen', pg.evaluate('__game.ui.screen'), 'mode', pg.evaluate('__game.sim.mode'))
        shot(pg, 'retry')
        b.close()
    httpd.shutdown()
    errs = [l for l in logs if l.startswith('[error]') or l.startswith('[PAGEERROR]')]
    for l in logs[:40]: print(l)
    print(f'--- {len(errs)} errors, {len(logs)} warnings+errors')

if __name__ == '__main__':
    main()
