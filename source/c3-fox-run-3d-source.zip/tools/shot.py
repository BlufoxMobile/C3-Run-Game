#!/usr/bin/env python3
"""Build an entry and screenshot it in headless Chromium (SwiftShader WebGL2).

  python3 tools/shot.py --entry harness/world.js --name world --w 390 --h 844 \
      --wait 6 --advance 3.0 --shots 3 --gap 1.5 [--eval "js to run before shots"] [--dpr 2]

Writes scratch/<name>/<name>.html and scratch/<name>/shot-<i>.png, prints console
errors/warnings. Pages are served over http (WebGL refuses file:// textures).

--advance S : before each shot call window.__app.advance(S) (deterministic sim time;
              SwiftShader rAF is only a few fps, so don't rely on real time).
--noadvance : don't call advance; just wait --gap seconds of real time between shots.
--nobuild   : reuse the existing html.
--url       : screenshot an arbitrary path under the project root instead of building.
"""
import argparse, http.server, os, socketserver, subprocess, sys, threading, time, functools

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def serve():
    class Quiet(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a, **k): pass
        def end_headers(self):
            self.send_header('Cache-Control', 'no-store'); super().end_headers()
    handler = functools.partial(Quiet, directory=ROOT)
    class TS(socketserver.ThreadingMixIn, http.server.HTTPServer):
        daemon_threads = True
        allow_reuse_address = True
    httpd = TS(('127.0.0.1', 0), handler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--entry'); ap.add_argument('--name', default='shot'); ap.add_argument('--url')
    ap.add_argument('--w', type=int, default=390); ap.add_argument('--h', type=int, default=844)
    ap.add_argument('--dpr', type=float, default=1)
    ap.add_argument('--wait', type=float, default=5); ap.add_argument('--advance', type=float, default=1.0)
    ap.add_argument('--noadvance', action='store_true'); ap.add_argument('--nobuild', action='store_true')
    ap.add_argument('--shots', type=int, default=1); ap.add_argument('--gap', type=float, default=1.0)
    ap.add_argument('--eval', default=None); ap.add_argument('--query', default='')
    ap.add_argument('--prod', action='store_true', help='minified build')
    ap.add_argument('--touch', action='store_true', help='emulate a touch phone')
    a = ap.parse_args()
    outdir = os.path.join(ROOT, 'scratch', a.name); os.makedirs(outdir, exist_ok=True)
    if a.url:
        rel = a.url
    else:
        html = os.path.join('scratch', a.name, a.name + '.html')
        if not a.nobuild:
            cmd = ['node', 'build.mjs', a.entry, html] + ([] if a.prod else ['--dev'])
            r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
            print(r.stdout.strip());
            if r.returncode: print(r.stderr); sys.exit(1)
        rel = html
    httpd = serve()
    url = f'http://127.0.0.1:{httpd.server_address[1]}/{rel}{a.query}'
    from playwright.sync_api import sync_playwright
    logs = []
    with sync_playwright() as p:
        b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium',
                              args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist',
                                    '--autoplay-policy=no-user-gesture-required'])
        ctx = b.new_context(viewport={'width': a.w, 'height': a.h}, device_scale_factor=a.dpr,
                            has_touch=a.touch, is_mobile=a.touch)
        pg = ctx.new_page()
        pg.on('console', lambda m: logs.append(f'[{m.type}] {m.text}') if m.type in ('error', 'warning', 'info', 'log') else None)
        pg.on('pageerror', lambda e: logs.append(f'[PAGEERROR] {e}'))
        pg.goto(url)
        time.sleep(a.wait)
        if a.eval:
            try: print('eval ->', pg.evaluate(a.eval))
            except Exception as e: print('eval failed', e)
        for i in range(a.shots):
            if not a.noadvance:
                try: pg.evaluate(f'window.__app && window.__app.advance({a.advance})')
                except Exception as e: logs.append(f'[advance failed] {e}')
            else:
                time.sleep(a.gap)
            path = os.path.join(outdir, f'shot-{i}.png')
            pg.screenshot(path=path)
            print('wrote', os.path.relpath(path, ROOT))
        b.close()
    httpd.shutdown()
    errs = [l for l in logs if l.startswith('[error]') or l.startswith('[PAGEERROR]')]
    for l in logs[:60]: print(l)
    print(f'--- {len(errs)} errors, {len(logs)} console lines')

if __name__ == '__main__':
    main()
