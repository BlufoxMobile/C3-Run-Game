import sys, glob
from PIL import Image
files = sys.argv[2:]; out = sys.argv[1]
ims = [Image.open(f).convert('RGB') for f in files]
h = max(i.height for i in ims); sc = 700 / h
ims = [i.resize((int(i.width*sc), int(i.height*sc))) for i in ims]
W = sum(i.width for i in ims) + 8*(len(ims)-1)
s = Image.new('RGB', (W, ims[0].height), 'black'); x = 0
for i in ims: s.paste(i, (x, 0)); x += i.width + 8
s.save(out)
