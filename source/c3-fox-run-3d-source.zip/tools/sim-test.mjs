// SIM TESTS — node tools/sim-test.mjs   (exit code 1 on any failure)
// State shape vs CONTRACT §3 / fakeSim, ids, cleanup, events, determinism, cost, attract mode,
// power-ups, bump rules, ramp/roof/drop, oncoming trucks, shields, levels, spawn distance.
import { createSim, TUNE } from '../src/sim/sim.js';
import { _dp } from '../src/sim/sim-gen.js';
import { createFakeSim } from '../src/dev/fakeSim.js';
import { THEMES, KINDS, tierOf } from '../src/data/themes.js';
import { LANE_X, VIEW_BEHIND, TRUCK_H } from '../src/core/constants.js';

let fails = 0, passes = 0;
const ok = (cond, msg) => { if (cond) passes++; else { fails++; console.log('  FAIL ' + msg); } };
const section = name => console.log('- ' + name);
const isNum = v => typeof v === 'number' && Number.isFinite(v);
const isInt = v => Number.isInteger(v);
const isBool = v => typeof v === 'boolean';

// ------------------------------------------------------------------ shape
const SHAPE = {
  top: { mode: 'string', time: 'number', runTime: 'number', dist: 'number', speed: 'number', baseSpeed: 'number',
    level: 'int', lap: 'int', themeIdx: 'int', theme: 'object', levelStart: 'number', nextLevelAt: 'number',
    levelProgress: 'number', nextThemeIdx: 'int', score: 'number', combo: 'int', comboTimer: 'number', bestCombo: 'int',
    tsheets: 'int', shield: 'int', power: 'object', powerMax: 'object', invuln: 'number', player: 'object',
    obstacles: 'array', trains: 'array', orbs: 'array', powerups: 'array', events: 'array', stats: 'object',
    devGod: 'boolean' },
  player: { lane: 'int', fromLane: 'int', laneT: 'number', x: 'number', y: 'number', vy: 'number', grounded: 'boolean',
    onRoof: 'idOrNull', surfaceY: 'number', anim: 'string', animT: 'number', lean: 'number', stumbleT: 'number' },
  obstacle: { id: 'int', type: 'string', kind: 'string', lane: 'int', x: 'number', s: 'number', w: 'number', h: 'number',
    len: 'number', drift: 'objOrNull', hit: 'boolean', smashed: 'boolean', near: 'boolean' },
  train: { id: 'int', kind: 'string', lane: 'int', x: 'number', s: 'number', len: 'number', h: 'number', w: 'number',
    v: 'number', ramp: 'boolean', rampLen: 'number', livery: 'int', lights: 'boolean' },
  orb: { id: 'int', kind: 'string', lane: 'int', x: 'number', s: 'number', y: 'number', got: 'boolean', magnet: 'boolean' },
  powerup: { id: 'int', kind: 'string', lane: 'int', x: 'number', s: 'number', y: 'number', got: 'boolean' },
  stats: { orbs: 'int', nearMisses: 'int', hops: 'int', smashed: 'int', distance: 'number', maxCombo: 'int' },
};
function typeOk(v, t) {
  switch (t) {
    case 'number': return isNum(v); case 'int': return isInt(v); case 'string': return typeof v === 'string';
    case 'boolean': return isBool(v); case 'object': return v && typeof v === 'object' && !Array.isArray(v);
    case 'array': return Array.isArray(v); case 'idOrNull': return v === null || isInt(v);
    case 'objOrNull': return v === null || (v && typeof v === 'object');
  }
  return false;
}
function checkShape(obj, shape, label, errs) {
  for (const k in shape) if (!(k in obj) || !typeOk(obj[k], shape[k])) errs.push(`${label}.${k} (${JSON.stringify(obj[k])}) should be ${shape[k]}`);
}
function shapeErrors(sim) {
  const e = [];
  checkShape(sim, SHAPE.top, 'sim', e);
  checkShape(sim.player, SHAPE.player, 'player', e);
  checkShape(sim.stats, SHAPE.stats, 'stats', e);
  for (const k of ['magnet', 'x2', 'boost']) { if (!isNum(sim.power[k]) || sim.power[k] < 0) e.push('power.' + k); if (!isNum(sim.powerMax[k])) e.push('powerMax.' + k); }
  if (!['ready', 'play', 'dying', 'over'].includes(sim.mode)) e.push('mode ' + sim.mode);
  if (sim.theme !== THEMES[sim.themeIdx]) e.push('theme != THEMES[themeIdx]');
  if (sim.themeIdx < 0 || sim.themeIdx > 11 || sim.nextThemeIdx < 0 || sim.nextThemeIdx > 11) e.push('themeIdx range');
  if (sim.levelProgress < 0 || sim.levelProgress > 1) e.push('levelProgress ' + sim.levelProgress);
  if (sim.combo < 1 || sim.combo > 9) e.push('combo ' + sim.combo);
  if (sim.shield < 0 || sim.shield > 3) e.push('shield ' + sim.shield);
  if (![0, 1, 2].includes(sim.player.lane) || ![0, 1, 2].includes(sim.player.fromLane)) e.push('lane range');
  if (!['idle', 'run', 'jump', 'fall', 'land', 'stumble', 'hit', 'boost'].includes(sim.player.anim)) e.push('anim ' + sim.player.anim);
  if (sim.player.lean < -1.001 || sim.player.lean > 1.001) e.push('lean');
  if (sim.killer !== null && !(sim.killer && ['monster', 'barrier', 'train'].includes(sim.killer.type) && typeof sim.killer.kind === 'string')) e.push('killer');
  for (const o of sim.obstacles) {
    checkShape(o, SHAPE.obstacle, 'obstacle', e);
    if (!['monster', 'barrier'].includes(o.type)) e.push('obstacle.type ' + o.type);
    if (o.drift && !(isInt(o.drift.from) && isInt(o.drift.to) && isNum(o.drift.t) && isNum(o.drift.dur))) e.push('drift shape');
  }
  for (const t of sim.trains) { checkShape(t, SHAPE.train, 'train', e); if (!['semi', 'box', 'bus'].includes(t.kind)) e.push('train.kind ' + t.kind); if (t.v < 0 && (t.ramp || !t.lights)) e.push('oncoming with ramp / no lights'); }
  for (const o of sim.orbs) { checkShape(o, SHAPE.orb, 'orb', e); if (!(o.kind in KINDS)) e.push('orb.kind ' + o.kind); }
  for (const u of sim.powerups) { checkShape(u, SHAPE.powerup, 'powerup', e); if (!['magnet', 'x2', 'boost'].includes(u.kind)) e.push('powerup.kind ' + u.kind); }
  return e;
}

// ------------------------------------------------------------------ events
const EV = {
  start: {}, lane: { dir: 'int', lane: 'int' }, bump: { dir: 'int', x: 'number', s: 'number' }, jump: { x: 'number', y: 'number' },
  land: { x: 'number', y: 'number', onRoof: 'boolean', impact: 'number' }, ramp: { trainId: 'idOrNull' }, roof: { trainId: 'idOrNull' },
  drop: {}, coin: { kind: 'string', value: 'number', combo: 'int', x: 'number', y: 'number', s: 'number' },
  tsheet: { count: 'int', shield: 'int', x: 'number', y: 'number', s: 'number' }, bonus: { amount: 'number', x: 'number', y: 'number', s: 'number' },
  combo: { combo: 'int' }, comboLost: {}, nearMiss: { bonus: 'number', x: 'number', side: 'int', s: 'number' }, hop: { x: 'number', s: 'number' },
  shieldBreak: { x: 'number', y: 'number', s: 'number', id: 'int' }, smash: { id: 'int', kind: 'string', x: 'number', y: 'number', s: 'number' },
  powerup: { kind: 'string', x: 'number', y: 'number', s: 'number' }, powerWarn: { kind: 'string' }, powerEnd: { kind: 'string' },
  boostStart: {}, boostEnd: {}, levelUp: { level: 'int', themeIdx: 'int', lap: 'int', name: 'string', region: 'string', tier: 'string' },
  trainPass: { id: 'int', side: 'int' }, hit: { kind: 'string', x: 'number', y: 'number', s: 'number' }, death: {},
  edge: { dir: 'int' },                 // addition: lane press against the road edge
};
function eventErrors(ev) {
  const spec = EV[ev.type];
  if (!spec) return ['unknown event ' + ev.type];
  const e = [];
  checkShape(ev, spec, 'event ' + ev.type, e);
  return e;
}

// ------------------------------------------------------------------ helpers
function runSteps(sim, n, actsFn, onEvents) {
  for (let i = 0; i < n; i++) {
    const acts = actsFn ? actsFn(sim, i) : [];
    sim.step(1 / 60, acts);
    if (onEvents) onEvents(sim.events, sim, i);
    sim.events.length = 0;
  }
}
/** An empty stretch of road in front of the fox for scripted scenarios. */
function clearRoad(sim) {
  sim.obstacles.length = 0; sim.trains.length = 0; sim.orbs.length = 0; sim.powerups.length = 0;
  sim._gen.queue.length = 0; sim._gen.qHead = 0; sim._gen.oncoming.length = 0;
  sim._gen.prevEnd = sim.dist + 400;           // nothing new within reach for a while
}
let tid = 900000;
function addTruck(sim, lane, s, len, opts = {}) {
  const t = { id: tid++, kind: opts.kind || 'semi', lane, x: LANE_X[lane], s, len, h: TRUCK_H, w: TUNE.truckW, v: opts.v || 0,
    ramp: !!opts.ramp, rampLen: opts.ramp ? TUNE.rampLen : 0, livery: 0, lights: (opts.v || 0) < 0, _ps: s, _near: false };
  sim.trains.push(t); return t;
}
function addObs(sim, type, lane, s) {
  const m = type === 'monster';
  const o = { id: tid++, type, kind: m ? 'chargeback' : 'barrier', lane, x: LANE_X[lane], s, w: m ? TUNE.monsterW : TUNE.barrierW,
    h: m ? TUNE.monsterH : TUNE.barrierH, len: m ? TUNE.monsterLen : TUNE.barrierLen, drift: null, hit: false, smashed: false, near: false, gateRow: false, hopped: false };
  sim.obstacles.push(o); return o;
}
function fresh(seed = 7) { const sim = createSim({ seed }); sim.start(); sim.events.length = 0; runSteps(sim, 30); clearRoad(sim); return sim; }
const types = evs => evs.map(e => e.type);

// ================================================================== tests
section('state shape (CONTRACT §3) — ready, play, dying, over; every step of a long bot run');
{
  const sim = createSim({ seed: 3, attract: false });
  let e = shapeErrors(sim); ok(!e.length, 'ready shape: ' + e.slice(0, 5).join('; '));
  ok(sim.mode === 'ready' && sim.obstacles.length + sim.orbs.length > 0, 'reset() pre-populates the road');
  ok(sim.nextLevelAt > sim.dist + 300, 'nextLevelAt known a level ahead at reset');
  sim.autopilot = true; sim.start();
  const seen = new Map(); let shapeBad = null, evBad = null, idBad = null, behindBad = null, dup = null, popIn = null, inside = null;
  const firstSeenS = new Map();
  for (const arr of [sim.obstacles, sim.trains, sim.orbs, sim.powerups]) for (const x of arr) firstSeenS.set(x.id, x.s);   // pre-populated
  let levelUps = 0, hits = 0;
  for (let i = 0; i < 60 * 240 && sim.mode === 'play'; i++) {
    sim.step(1 / 60, []);
    for (const ev of sim.events) { const ee = eventErrors(ev); if (ee.length && !evBad) evBad = ee.join('; '); if (ev.type === 'levelUp') levelUps++; if (ev.type === 'hit') hits++; }
    sim.events.length = 0;
    if (i % 7 === 0) { const se = shapeErrors(sim); if (se.length && !shapeBad) shapeBad = `step ${i}: ` + se.slice(0, 4).join('; '); }
    const ids = new Set();
    for (const arr of [sim.obstacles, sim.trains, sim.orbs, sim.powerups]) for (const x of arr) {
      if (ids.has(x.id) && !dup) dup = `dup id ${x.id}`;
      ids.add(x.id);
      const prev = seen.get(x.id);
      if (prev && prev !== x && !idBad) idBad = `id ${x.id} re-used for another object`;
      seen.set(x.id, x);
      if (!firstSeenS.has(x.id)) {
        firstSeenS.set(x.id, x.s);
        const ahead = x.s - (x.rampLen || 0) - sim.dist;
        const isRiver = arr === sim.orbs && x.y > TUNE.boostY;
        if (!isRiver && ahead < TUNE.spawnAhead - 4 && !popIn) popIn = `${x.id} appeared only ${ahead.toFixed(1)} m ahead`;
        // coins never inside obstacles / trucks
        if (arr === sim.orbs && !x.magnet) {
          for (const o of sim.obstacles) if (o.lane === x.lane && x.s > o.s - 0.4 && x.s < o.s + o.len + 0.4 && x.y < o.h + 0.3 && !inside) inside = `orb ${x.id} inside ${o.type} ${o.id}`;
          for (const t of sim.trains) if (t.lane === x.lane && x.s > t.s - 0.3 && x.s < t.s + t.len + 0.3 && x.y < t.h + 0.4 && !inside) inside = `orb ${x.id} inside truck ${t.id}`;
        }
      }
    }
    const lim = sim.dist - VIEW_BEHIND - 2;
    for (const o of sim.obstacles) if (o.s + o.len < lim && !behindBad) behindBad = `obstacle ${o.id} ${(sim.dist - o.s).toFixed(1)} m behind`;
    for (const t of sim.trains) if (t.s + t.len < lim && !behindBad) behindBad = `train ${t.id} behind`;
    for (const o of sim.orbs) if ((o.got || o.s < lim) && !behindBad) behindBad = `orb ${o.id} collected/behind still listed`;
  }
  ok(!shapeBad, 'shape during play: ' + shapeBad);
  ok(!evBad, 'events well formed: ' + evBad);
  ok(!dup, 'ids unique among live entities: ' + dup);
  ok(!idBad, 'ids stable (one object per id): ' + idBad);
  ok(!behindBad, 'entities removed behind / when collected: ' + behindBad);
  ok(!popIn, 'nothing pops in near the fox: ' + popIn);
  ok(!inside, 'coins never inside obstacles or trucks: ' + inside);
  ok(levelUps >= 7, `levels advance (${levelUps} level-ups in 240 s)`);
  ok(hits === 0, 'autopilot survives 240 s');
}

section('verifier (lane-grid proof) unit checks');
{
  const { dpInit, dpMark, dpSolve, okG, DP, GB, RF, RHI, RLO } = _dp;
  DP.lc = 8; DP.fall = 10;
  dpInit(0, 60); dpMark(0, 20, 60, GB);
  ok(dpSolve(7) && !okG(Math.round(40 / 0.5), 0) && okG(Math.round(40 / 0.5), 1), 'a wall ahead: lane 0 must be left, others survive');
  dpInit(0, 40); dpMark(0, 1.5, 40, GB);
  ok(!dpSolve(1), 'a wall 1.5 m ahead of an entry lane is a dead end (chunk rejected)');
  dpInit(0, 40); for (const l of [0, 1, 2]) dpMark(l, 20, 21, GB);
  ok(!dpSolve(7), 'a full row of monsters is unsolvable (rejected)');
  dpInit(0, 60); dpMark(0, 20, 21, GB); dpMark(1, 20, 21, GB);
  ok(dpSolve(1) && okG(Math.round(30 / 0.5), 2), 'two monsters: the fox in lane 0 can reach lane 2 in time');
  // truck in lane 1 with ramp, trucks walling lanes 0 and 2: only the roof route exists
  dpInit(0, 90); dpMark(1, 20, 22, RLO); dpMark(1, 22.001, 26.999, RHI); dpMark(1, 27, 60, GB); dpMark(1, 27, 59.7, RF);
  dpMark(0, 26, 62, GB); dpMark(2, 26, 62, GB);
  ok(dpSolve(2) && okG(Math.round(80 / 0.5), 1), 'the ramp -> roof route is found when the ground is walled');
}

section('nothing spawns inside a truck (or its ramp); oncoming lanes are kept clear');
{
  let bad = null, checked = 0;
  for (let seed = 1; seed <= 12 && !bad; seed++) {
    const sim = createSim({ seed }); sim.devGod = true; sim.start();
    for (let i = 0; i < 60 * 200 && !bad; i++) {
      sim.step(1 / 60, []); sim.events.length = 0;
      if (i % 20) continue;
      for (const t of sim.trains) for (const o of sim.obstacles) {
        checked++;
        if (o.lane !== t.lane && !(o.drift && o.drift.to === t.lane)) continue;
        const a = t.s - (t.ramp ? t.rampLen : 0) - 0.5, b = t.s + t.len + 0.5;
        if (o.s + o.len > a && o.s < b && o.s + o.len > sim.dist) bad = `seed ${seed}: ${o.type} ${o.id} lane ${o.lane} @${(o.s - sim.dist).toFixed(1)} inside truck ${t.id}${t.v < 0 ? ' (oncoming)' : ''} lane ${t.lane} @${(t.s - sim.dist).toFixed(1)}+${t.len}`;
      }
      for (const t of sim.trains) for (const u of sim.trains) {
        if (t === u || t.lane !== u.lane) continue;
        const a0 = t.s - (t.ramp ? t.rampLen : 0), a1 = t.s + t.len, b0 = u.s - (u.ramp ? u.rampLen : 0), b1 = u.s + u.len;
        if (a0 < b1 && b0 < a1 && Math.max(a0, b0) > sim.dist) bad = `seed ${seed}: trucks ${t.id} and ${u.id} overlap in lane ${t.lane}`;
      }
    }
  }
  ok(!bad, 'no overlaps: ' + bad);
}

section('fakeSim fields are all present in the real sim');
{
  const fake = createFakeSim({}), sim = createSim({ seed: 1 });
  const miss = [];
  for (const k in fake) if (typeof fake[k] !== 'function' && !(k in sim) && k !== 'autopilot') miss.push('sim.' + k);
  for (const k in fake.player) if (!(k in sim.player)) miss.push('player.' + k);
  for (const k in fake.stats) if (!(k in sim.stats)) miss.push('stats.' + k);
  sim.autopilot = true; sim.start();
  for (let i = 0; i < 60 * 60; i++) { sim.step(1 / 60, []); sim.events.length = 0; }
  const f2 = createFakeSim({}); for (let i = 0; i < 400; i++) { f2.step(1 / 60); f2.events.length = 0; }
  const cmp = (a, b, label) => { if (a && b) for (const k in a) if (!(k in b)) miss.push(label + '.' + k); };
  cmp(f2.obstacles[0], sim.obstacles[0], 'obstacle'); cmp(f2.trains[0], sim.trains[0], 'train'); cmp(f2.orbs[0], sim.orbs[0], 'orb');
  ok(!miss.length, 'missing: ' + miss.join(', '));
}

section('determinism');
{
  const script = (s, i) => (i % 97 === 5 ? ['left'] : i % 131 === 9 ? ['right'] : i % 61 === 0 ? ['jump'] : []);
  const hash = sim => [sim.dist.toFixed(6), sim.score.toFixed(4), sim.mode, sim.level, sim.player.x.toFixed(6), sim.player.y.toFixed(6),
    sim.obstacles.map(o => o.id + ':' + o.s.toFixed(4) + o.lane).join(','), sim.trains.map(t => t.id + ':' + t.s.toFixed(4)).join(','),
    sim.orbs.length, sim.powerups.map(u => u.kind).join()].join('|');
  const run = () => { const sim = createSim({ seed: 1234 }); sim.start(); runSteps(sim, 60 * 90, script); return hash(sim); };
  const a = run(), b = run();
  ok(a === b, 'same seed + same inputs -> identical state');
  const sim = createSim({ seed: 1235 }); sim.start(); runSteps(sim, 60 * 90, script);
  ok(hash(sim) !== a, 'different seed -> different road');
  const c = createSim({ seed: 1234, attract: true }); runSteps(c, 60 * 20); c.start();
  const c2 = createSim({ seed: 1234, attract: true }); runSteps(c2, 60 * 20); c2.start();
  ok(hash(c) === hash(c2), 'attract -> start() is deterministic too');
}

section('retry: start() after death gives a new (reproducible) road; start(seed) pins it');
{
  const a = createSim({ seed: 55 }); a.start();
  const road = s => s.obstacles.map(o => (o.s - s.dist).toFixed(2) + o.lane).join();
  const r1 = road(a), seed1 = a.runSeed;
  addObs(a, 'monster', a.player.lane, a.dist + 2); runSteps(a, 150);
  ok(a.mode === 'over', 'died');
  a.start();
  ok(a.mode === 'play' && a.score === 0 && a.runSeed !== seed1 && road(a) !== r1, 'retry -> fresh run, different road');
  const b = createSim({ seed: 55 }); b.start(); addObs(b, 'monster', b.player.lane, b.dist + 2); runSteps(b, 150); b.start();
  ok(b.runSeed === a.runSeed, 'retry roads are reproducible from the reset seed');
  a.start(4242); const c = createSim({ seed: 4242 }); c.start();
  ok(road(a) === road(c), 'start(seed) = the same road as a fresh sim with that seed');
}

section('step() cost');
{
  const sim = createSim({ seed: 99 }); sim.devGod = true; sim.start();
  const script = (s, i) => (i % 45 === 0 ? [['left', 'right', 'jump'][(i / 45) % 3]] : []);
  runSteps(sim, 600, script);
  const N = 60 * 300; const t0 = performance.now();
  runSteps(sim, N, script);
  const ms = (performance.now() - t0) / N;
  ok(ms < 0.3, `sim step avg ${ms.toFixed(4)} ms (< 0.3)`);
  console.log(`    sim.step() ${ms.toFixed(4)} ms avg over ${N} steps at 60 Hz (god mode, scripted input, level ${sim.level})`);
  const a = createSim({ seed: 5, attract: true });
  let worst = 0;
  const t1 = performance.now();
  for (let i = 0; i < 60 * 120; i++) { const q = performance.now(); a.step(1 / 60, []); a.events.length = 0; worst = Math.max(worst, performance.now() - q); }
  const ma = (performance.now() - t1) / (60 * 120);
  console.log(`    attract mode incl. bot ${ma.toFixed(4)} ms avg, worst frame ${worst.toFixed(2)} ms`);
  ok(ma < 0.5, `attract step incl. bot ${ma.toFixed(4)} ms`);
  if (global.gc) {
    const s2 = createSim({ seed: 8 }); s2.devGod = true; s2.start(); runSteps(s2, 600, script);
    global.gc(); const h0 = process.memoryUsage().heapUsed;
    runSteps(s2, 60 * 60, script); global.gc(); const h1 = process.memoryUsage().heapUsed;
    console.log(`    retained heap after 60 s: ${((h1 - h0) / 1024).toFixed(0)} KB`);
    ok(h1 - h0 < 2 * 1024 * 1024, 'no heap growth over a minute');
  }
}

section('attract mode: 10 minutes, never dies, stays level 1');
{
  const sim = createSim({ seed: 21, attract: true });
  let bad = 0, deaths = 0, coins = 0, trucks = 0, powers = 0, smashes = 0;
  const d0 = sim.dist;
  runSteps(sim, 60 * 600, null, evs => { for (const e of evs) { if (e.type === 'hit' || e.type === 'death') deaths++; if (e.type === 'coin') coins++; if (e.type === 'roof') trucks++; if (e.type === 'powerup') powers++; if (e.type === 'smash') smashes++; } });
  ok(sim.mode === 'ready' && deaths === 0, `attract never dies (${deaths} hits)`);
  ok(sim.level === 1 && sim.themeIdx === 0, 'attract stays on level 1');
  ok(sim.dist - d0 > 600 * TUNE.attractSpeed * 0.95, 'attract keeps running at base speed');
  ok(coins > 200 && trucks > 3 && powers > 3, `attract shows the game (coins ${coins}, roofs ${trucks}, power-ups ${powers})`);
  console.log(`    attract: ${coins} coins, ${trucks} roof runs, ${powers} power-ups, ${smashes} smashes (bot mistakes absorbed)`);
  sim.start();
  ok(sim.mode === 'play' && sim.score === 0 && sim.level === 1 && sim.stats.distance === 0, 'start() after attract begins a fresh run');
  let early = null;
  for (const o of sim.obstacles) if (o.s - sim.dist < TUNE.introSafeT * 12) early = o;
  ok(!early, 'no obstacle within the intro-safe stretch after start()');
  ok(!sim.trains.some(t => t.s - sim.dist < TUNE.introNoTruckT * 12), 'no trucks in the first 20 s');
  const s2 = createSim({ seed: 21, attract: false });
  runSteps(s2, 60);
  ok(s2.dist === 0 && s2.player.anim === 'idle', 'ready without attract: world holds still, fox idles');
}

section('scripted: jump clears a barrier (hop), lane change dodges a monster (near miss)');
{
  const sim = fresh();
  const b = addObs(sim, 'barrier', 1, sim.dist + 25);
  let evs = [];
  runSteps(sim, 180, (s) => (b.s - s.dist < s.speed * 0.3 && b.s - s.dist > s.speed * 0.25 ? ['jump'] : []), e => evs.push(...e));
  ok(types(evs).includes('jump') && types(evs).includes('hop') && sim.mode === 'play', 'jump -> hop, no hit');
  ok(evs.find(e => e.type === 'jump') && sim.player.y === 0, 'landed again');
  const m = addObs(sim, 'monster', 1, sim.dist + 20); evs = [];
  let pressed = false;
  runSteps(sim, 120, (s) => (!pressed && m.s - s.dist < s.speed * 0.12 ? (pressed = true, ['left']) : []), e => evs.push(...e));
  ok(sim.mode === 'play' && types(evs).includes('nearMiss'), 'late dodge -> nearMiss');
  const nm = evs.find(e => e.type === 'nearMiss');
  ok(nm && nm.bonus === TUNE.nearMissPay * sim.combo, 'near-miss pays 25 x combo');
  const m2 = addObs(sim, 'monster', 0, sim.dist + 20); evs = [];
  runSteps(sim, 120, null, e => evs.push(...e));
  ok(sim.mode === 'dying' || sim.mode === 'over', 'running into a monster is fatal');
  ok(types(evs).indexOf('hit') >= 0 && sim.killer && sim.killer.type === 'monster', 'hit event + killer monster');
  runSteps(sim, 60 * 2, null, e => evs.push(...e));
  ok(sim.mode === 'over' && types(evs).includes('death') && types(evs).indexOf('hit') < types(evs).indexOf('death'), "'hit' then 'death' -> mode over");
  ok(sim.stats.distance > 0 && sim.stats.maxCombo >= 1, 'stats filled');
}

section('scripted: dying lasts ~1 s of sim time and the fox stops');
{
  const sim = fresh();
  addObs(sim, 'monster', 1, sim.dist + 10);
  let tHit = -1, tDeath = -1;
  runSteps(sim, 200, null, (evs, s) => { for (const e of evs) { if (e.type === 'hit') tHit = s.time; if (e.type === 'death') tDeath = s.time; } });
  ok(tHit > 0 && Math.abs(tDeath - tHit - TUNE.deathTime) < 0.05, `dying lasted ${(tDeath - tHit).toFixed(2)} s`);
  ok(sim.speed === 0, 'speed eased to 0');
}

section('scripted: bump bounces back, second bump while stumbling kills');
{
  const sim = fresh();
  addTruck(sim, 0, sim.dist - 5, 40);
  let evs = [];
  runSteps(sim, 1, () => ['left'], e => evs.push(...e));
  runSteps(sim, 20, null, e => evs.push(...e));
  ok(types(evs).includes('bump') && sim.mode === 'play', 'side-swipe -> bump, alive');
  ok(sim.player.lane === 1 && Math.abs(sim.player.x) < 0.01, 'bounced back to the origin lane');
  ok(sim.player.stumbleT > 0 && sim.player.anim === 'stumble', 'stumbling');
  ok(evs.find(e => e.type === 'bump').dir === -1, 'bump.dir is the attempted direction');
  evs = [];
  runSteps(sim, 1, () => ['left'], e => evs.push(...e));
  runSteps(sim, 10, null, e => evs.push(...e));
  ok(types(evs).includes('bump') && types(evs).includes('hit') && sim.killer && sim.killer.type === 'train', 'second bump while stumbling is fatal');
  const s2 = fresh();
  s2.combo = 5; s2.comboTimer = 1.5;
  addTruck(s2, 2, s2.dist - 5, 40);
  evs = [];
  runSteps(s2, 1, () => ['right'], e => evs.push(...e));
  runSteps(s2, 60, null, e => evs.push(...e));
  ok(types(evs).includes('comboLost') && s2.combo === 1, 'bump loses the combo');
  runSteps(s2, 1, () => ['right'], e => evs.push(...e));
  runSteps(s2, 10, null, e => evs.push(...e));
  ok(s2.mode === 'play', 'a bump after the stumble ended is not fatal');
}

section('scripted: ramp -> roof -> drop -> land, lane change across roofs');
{
  const sim = fresh();
  const t = addTruck(sim, 1, sim.dist + 30, 18, { ramp: true });
  const t2 = addTruck(sim, 2, sim.dist + 34, 14);
  const order = []; let maxY = 0, crossed = false;
  runSteps(sim, 60 * 5, (s, i) => {
    if (!crossed && s.player.onRoof === t.id && s.dist > t.s + 6) { crossed = true; return ['right']; }
    return [];
  }, (evs, s) => { for (const e of evs) if (['ramp', 'roof', 'drop', 'land', 'bump', 'hit'].includes(e.type)) order.push(e.type + (e.trainId ? ':' + e.trainId : '')); maxY = Math.max(maxY, s.player.y); });
  ok(order[0] === 'ramp:' + t.id && order[1] === 'roof:' + t.id, 'ramp then roof: ' + order.join(' '));
  ok(order.includes('roof:' + t2.id), 'lane change onto the adjacent roof');
  ok(order.includes('drop') && order[order.length - 1] === 'land', 'ran off the end: drop then land');
  ok(Math.abs(maxY - TRUCK_H) < 0.05 && sim.player.y === 0 && sim.mode === 'play', `on the roof at ${maxY.toFixed(2)} m, back on the road, alive`);
  ok(!order.includes('bump') && !order.includes('hit'), 'no bump / hit on the roof route');
  const s2 = fresh();
  addTruck(s2, 1, s2.dist + 20, 12);
  runSteps(s2, 60 * 2);
  ok(s2.killer && s2.killer.type === 'train', 'running into a truck front below roof height is fatal');
  const s3 = fresh();
  const t3 = addTruck(s3, 1, s3.dist + 30, 16, { ramp: true });
  let jumpedOnRamp = false; const ev3 = [];
  runSteps(s3, 60 * 3, (s) => (!jumpedOnRamp && s.player.surfaceY > 1.2 && s.player.grounded ? (jumpedOnRamp = true, ['jump']) : []), e => ev3.push(...e));
  ok(jumpedOnRamp && s3.mode === 'play' && ev3.some(e => e.type === 'roof'), 'jumping on a ramp at speed still lands on the roof');
}

section('scripted: oncoming truck front kills, passing one emits trainPass');
{
  const sim = fresh();
  addTruck(sim, 1, sim.dist + 70, 14, { v: -11, kind: 'box' });
  runSteps(sim, 60 * 3);
  ok(sim.killer && sim.killer.type === 'train', 'oncoming truck in your lane is fatal');
  const s2 = fresh();
  const t = addTruck(s2, 0, s2.dist + 70, 14, { v: -11 });
  const evs = []; runSteps(s2, 60 * 3, null, e => evs.push(...e));
  const tp = evs.find(e => e.type === 'trainPass');
  ok(tp && tp.id === t.id && tp.side === -1 && s2.mode === 'play', 'trainPass {id, side:-1} for a truck in the left lane');
}

section('shield absorbs a hit; invulnerability smashes');
{
  const sim = fresh();
  sim.shield = 1;
  const m = addObs(sim, 'monster', 1, sim.dist + 15);
  const evs = []; runSteps(sim, 90, null, e => evs.push(...e));
  ok(sim.mode === 'play' && sim.shield === 0, 'shield spent, still running');
  ok(types(evs).includes('shieldBreak') && types(evs).includes('smash') && m.smashed, 'shieldBreak + smash, obstacle smashed');
  ok(sim.stats.smashed === 1, 'stats.smashed');
  const s2 = fresh(); s2.shield = 2;
  const t = addTruck(s2, 1, s2.dist + 15, 14);
  const e2 = []; runSteps(s2, 90, null, e => e2.push(...e));
  ok(s2.mode === 'play' && s2.shield === 1 && types(e2).includes('shieldBreak') && types(e2).includes('roof'), 'shield vs truck front: vault onto the roof');
}

section('power-ups: magnet, x2, boost');
{
  const sim = fresh();
  for (let i = 0; i < 6; i++) sim.orbs.push({ id: tid++, kind: 'xm', lane: i % 3, x: LANE_X[i % 3], s: sim.dist + 8 + i * 3, y: 0.9, got: false, magnet: false, _t: 0, _x0: 0, _y0: 0, _d0: 0 });
  sim.devPower('magnet');
  const evs = []; runSteps(sim, 60, null, e => evs.push(...e));
  ok(evs.filter(e => e.type === 'coin').length === 6, 'magnet pulls in coins from all lanes');
  runSteps(sim, 60 * 10, null, e => evs.push(...e));
  ok(types(evs).includes('powerWarn') && types(evs).includes('powerEnd') && sim.power.magnet === 0, 'powerWarn then powerEnd after 10 s');
  const s2 = fresh();
  s2.devPower('x2');
  s2.combo = 1; s2.comboTimer = 0;
  s2.orbs.push({ id: tid++, kind: 'tab', lane: 1, x: 0, s: s2.dist + 5, y: 0.9, got: false, magnet: false, _t: 0, _x0: 0, _y0: 0, _d0: 0 });
  const e2 = []; runSteps(s2, 30, null, e => e2.push(...e));
  const c = e2.find(e => e.type === 'coin');
  ok(c && c.value === Math.round(KINDS.tab.val * 2 * (1 + (s2.level - 1) * TUNE.orbLevelMult)) * 2, `x2 doubles coin value (${c && c.value})`);
  const s3 = fresh();
  const base = s3.baseSpeed;
  s3.devPower('boost');
  const e3 = []; let maxY = 0, maxV = 0, invAtLand = -1;
  const steer = (s) => {               // follow the river like a player would
    if (s.player.laneT < 1) return [];
    let best = null; for (const o of s.orbs) if (o.y > 4 && o.s > s.dist + 3 && (!best || o.s < best.s)) best = o;
    if (!best) return [];
    return best.lane < s.player.lane ? ['left'] : best.lane > s.player.lane ? ['right'] : [];
  };
  runSteps(s3, 60 * 7, steer, (evs, s) => { e3.push(...evs); maxY = Math.max(maxY, s.player.y); maxV = Math.max(maxV, s.speed); for (const e of evs) if (e.type === 'land') invAtLand = s.invuln; });
  ok(types(e3).includes('boostStart') && types(e3).includes('boostEnd'), 'boostStart / boostEnd');
  ok(Math.abs(maxY - TUNE.boostY) < 0.15, `flies at ~${TUNE.boostY} m (${maxY.toFixed(2)})`);
  ok(maxV > base * 1.5, `flies at ~1.55x speed (${(maxV / base).toFixed(2)}x)`);
  ok(e3.filter(e => e.type === 'coin').length > 20, `coin river collected (${e3.filter(e => e.type === 'coin').length})`);
  ok(invAtLand > 0 && s3.player.y === 0, 'lands with invulnerability left');
  const s4 = fresh(); s4.devPower('boost');
  const e4 = []; runSteps(s4, 30, null, e => e4.push(...e));
  runSteps(s4, 1, () => ['left'], e => e4.push(...e)); runSteps(s4, 20);
  ok(s4.player.lane === 0 && s4.player.y > 2, 'lane changes work in the air');
  const s5 = fresh(); s5.devPower('boost'); runSteps(s5, 60);
  addObs(s5, 'monster', s5.player.lane, s5.dist + 20); addTruck(s5, s5.player.lane, s5.dist + 40, 20);
  runSteps(s5, 90);
  ok(s5.mode === 'play', 'flies over monsters and trucks');
  const s6 = fresh(); s6.power.boost = 3; s6.powerMax.boost = 5;
  s6._gen.queue.push({ k: 'pow', s: s6.dist + 100, lane: 1, y: 1, kind: 'boost', key: s6.dist + 100 });
  runSteps(s6, 2);
  ok(!s6.powerups.some(u => u.kind === 'boost'), 'never spawns a power-up of a kind that is already active');
}

section('levels: nextLevelAt, levelUp fields, lap 2 after 12');
{
  const sim = createSim({ seed: 4 }); sim.devGod = true; sim.start();
  const next = sim.nextLevelAt, evs = [];
  runSteps(sim, 60 * 40, null, e => evs.push(...e));
  const lu = evs.find(e => e.type === 'levelUp');
  ok(lu && lu.level === 2 && lu.themeIdx === 1 && lu.name === THEMES[1].name && lu.region === THEMES[1].reg && lu.tier === tierOf(2), 'levelUp fields');
  ok(sim.levelStart === next, 'levelStart = the old nextLevelAt');
  const t1 = next / sim.speed;
  ok(t1 > 24 && t1 < 34, `level 1 lasts ~${(next / 14).toFixed(0)} s`);
  sim.devSetLevel(12);
  ok(sim.level === 12 && sim.themeIdx === 11, 'devSetLevel(12)');
  const e2 = []; runSteps(sim, 60 * 30, null, e => e2.push(...e));
  const l13 = e2.find(e => e.type === 'levelUp' && e.level === 13);
  ok(l13 && l13.lap === 2 && l13.themeIdx === 0 && sim.lap === 2, 'L13 = lap 2, theme 0');
  ok(Math.abs(sim.baseSpeed - TUNE.speedCap) < 0.01, 'speed capped');
  const lens = []; const sc = createSim({ seed: 1 }); sc.start();
  for (let L = 1; L <= 14; L++) lens.push(((sc._sched.startOf(L + 1) - sc._sched.startOf(L)) / Math.min(TUNE.speedCap, TUNE.speedL1 + (L - 1) * TUNE.speedStep)).toFixed(1));
  console.log('    level durations (s): ' + lens.join(' '));
}

section('first seconds of a run: nothing deadly for 4 s, a coin line to grab, no power-up before 15 s');
{
  let bad = 0, noCoins = 0, earlyPow = 0;
  for (let seed = 1; seed <= 40; seed++) {
    const sim = createSim({ seed }); sim.start();
    const d0 = sim.dist;
    if (sim.obstacles.some(o => o.s - d0 < TUNE.speedStart * TUNE.introSafeT)) bad++;
    if (!sim.orbs.some(o => o.s - d0 < 60)) noCoins++;
    sim.devGod = true;
    runSteps(sim, 60 * 15, null, (evs) => { for (const e of evs) if (e.type === 'powerup') earlyPow++; });
    if (sim.powerups.some(u => u.s - sim.dist < 0)) earlyPow++;
  }
  ok(bad === 0, `no obstacle in the first 4 s (${bad} seeds)`);
  ok(noCoins === 0, `a coin line in the opening (${noCoins} seeds without)`);
  ok(earlyPow === 0, `no power-up in the first 15 s (${earlyPow})`);
}

console.log(`\n${passes} passed, ${fails} failed`);
process.exit(fails ? 1 : 0);
