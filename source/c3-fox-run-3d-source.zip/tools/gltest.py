from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/opt/pw-browsers/chromium', args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    pg = b.new_page()
    pg.set_content('<canvas id=c></canvas><script>const g=document.getElementById("c").getContext("webgl2");document.title=g?("gl2 "+g.getParameter(g.VERSION)+" | "+g.getParameter(g.MAX_TEXTURE_SIZE)):"nogl";</script>')
    print(pg.title())
    b.close()
