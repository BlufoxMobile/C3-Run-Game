// BOT PROOF — plays the real sim with bot profiles over many seeds and prints distributions.
//
//   node tools/sim-bot.mjs                         # all profiles, 200 seeds each
//   node tools/sim-bot.mjs --profile perfect --seeds 300 --maxLevel 21
//   node tools/sim-bot.mjs --profile good --seeds 50 --verbose
//   node tools/sim-bot.mjs --econ                  # also compare $/level with the 2D build
//   node tools/sim-bot.mjs --workers 2             # split seeds across worker threads
//
// PERFECT (0 ms reaction, exact timing) must essentially never die before L20: any such death
// is printed with a layout dump (generator bug hunting). GOOD ~250 ms, CASUAL ~400 ms reaction
// with human noise (see BOT_PROFILES in src/sim/sim-bot.js).
import { Worker, isMainThread, parentPort, workerData } from 'node:worker_threads';
import { createSim } from '../src/sim/sim.js';
import { createBot, BOT_PROFILES } from '../src/sim/sim-bot.js';
import { mixSeed } from '../src/sim/sim-rng.js';

const argv = process.argv.slice(2);
const arg = (k, d) => { const i = argv.indexOf('--' + k); return i >= 0 ? argv[i + 1] : d; };
const flag = k => argv.includes('--' + k);

export function playOne(profileName, seed, maxLevel = 30, maxTime = 1500, verbose = false) {
  const sim = createSim({ seed, attract: false });
  sim.start();
  const bot = createBot(sim, BOT_PROFILES[profileName], mixSeed(seed, 31337));
  const dt = 1 / 60;
  const levelEnd = [];            // cumulative score at the end of each level
  const lastActs = [];
  let shieldsUsed = 0, bumps = 0, boosts = 0, stepMs = 0, steps = 0;
  sim.events.length = 0;
  while (sim.mode !== 'over' && sim.level <= maxLevel && sim.runTime < maxTime) {
    const acts = bot.act(dt, sim.time);
    if (acts.length) { lastActs.push(sim.time.toFixed(2) + ':' + acts.join('+')); if (lastActs.length > 12) lastActs.shift(); }
    const t0 = performance.now();
    sim.step(dt, acts);
    stepMs += performance.now() - t0; steps++;
    for (const e of sim.events) {
      if (e.type === 'levelUp') levelEnd[e.level - 1] = sim.score;
      else if (e.type === 'shieldBreak') shieldsUsed++;
      else if (e.type === 'bump') bumps++;
      else if (e.type === 'boostStart') boosts++;
    }
    sim.events.length = 0;
    if (sim.mode === 'dying' && sim.killer && !sim._dumped) {
      sim._dumped = true;
      let kc = null, bd = 1e9;
      for (const o of sim.obstacles) if (o.hit && !o.smashed && Math.abs(o.s - sim.dist) < bd) { bd = Math.abs(o.s - sim.dist); kc = o._ck; }
      if (!kc) for (const t of sim.trains) { const d = Math.abs(t.s - sim.dist); if (d < bd && d < t.len + 3) { bd = d; kc = t._ck || 'oncoming'; } }
      sim._killChunk = kc;
      if (verbose || profileName === 'perfect') {
        const p = sim.player, near = [];
        for (const o of sim.obstacles) if (o.s > sim.dist - 5 && o.s < sim.dist + 45) near.push(`${o.type[0]}${o.lane}@${(o.s - sim.dist).toFixed(1)}${o.drift ? '~' + o.drift.to : ''}${o.hit ? '!' : ''}[${o._ck}]`);
        for (const t of sim.trains) if (t.s + t.len > sim.dist - 5 && t.s < sim.dist + 60) near.push(`T${t.lane}@${(t.s - sim.dist).toFixed(1)}+${t.len}${t.ramp ? 'R' : ''}${t.v ? 'v' + t.v.toFixed(0) : ''}[${t._ck || 'oncoming'}]`);
        sim._dump = `seed ${seed} L${sim.level} t=${sim.runTime.toFixed(2)} killer=${sim.killer.type}/${sim.killer.kind} player lane ${p.lane}(from ${p.fromLane}) x=${p.x.toFixed(2)} y=${p.y.toFixed(2)} vy=${p.vy.toFixed(1)} anim=${p.anim} speed=${sim.baseSpeed.toFixed(1)}\n      near: ${near.join(' ')}\n      acts: ${lastActs.join(' ')}\n      plans ${bot.stats.plans} failed ${bot.stats.failedPlans} lapses ${bot.stats.lapses} wrong ${bot.stats.wrong} missed ${bot.stats.missed}`;
      }
    }
  }
  return {
    seed, died: sim.mode === 'over' || sim.mode === 'dying', level: sim.level, score: Math.round(sim.score), orbs: sim.stats.orbs,
    time: sim.runTime, killer: sim.killer ? `${sim.killer.type}:${sim.killer.kind}` : null,
    killerType: sim.killer ? sim.killer.type : null, killChunk: sim._killChunk || null, levelEnd, shieldsUsed, bumps, boosts,
    nearMisses: sim.stats.nearMisses, dump: sim._dump || null, stepMs: stepMs / Math.max(1, steps),
    botNodes: bot.stats.nodes / Math.max(1, bot.stats.plans), gen: sim._gen.stats,
  };
}

function pct(arr, p) { if (!arr.length) return NaN; const a = [...arr].sort((x, y) => x - y); return a[Math.min(a.length - 1, Math.floor(p * (a.length - 1) + 0.5))]; }
function row(label, arr, fmt = x => x) { return `  ${label.padEnd(8)} p10 ${fmt(pct(arr, .1))}  p25 ${fmt(pct(arr, .25))}  MEDIAN ${fmt(pct(arr, .5))}  p75 ${fmt(pct(arr, .75))}  p90 ${fmt(pct(arr, .9))}`; }

function report(name, results, maxLevel) {
  const died = results.filter(r => r.died);
  console.log(`\n=== ${name.toUpperCase()}  (${results.length} seeds, cap L${maxLevel})  died ${died.length}/${results.length}`);
  const lv = results.map(r => r.died ? r.level : maxLevel + 1);
  console.log(row('level', lv, x => x > maxLevel ? `>${maxLevel}` : x));
  console.log(row('score', results.map(r => r.score), x => '$' + Math.round(x).toLocaleString('en-US')));
  console.log(row('orbs', results.map(r => r.orbs)));
  console.log(row('time s', results.map(r => r.time), x => x.toFixed(0)));
  const hist = {};
  for (const r of died) hist[r.level] = (hist[r.level] || 0) + 1;
  console.log('  death level histogram: ' + Object.keys(hist).sort((a, b) => a - b).map(k => `L${k}:${hist[k]}`).join(' '));
  const causes = {}, ctype = {};
  for (const r of died) { causes[r.killer] = (causes[r.killer] || 0) + 1; ctype[r.killerType] = (ctype[r.killerType] || 0) + 1; }
  console.log('  death cause: ' + Object.entries(ctype).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${(100 * v / Math.max(1, died.length)).toFixed(0)}%`).join(', '));
  const cks = {}; for (const r of died) cks[r.killChunk] = (cks[r.killChunk] || 0) + 1;
  console.log('  killed in pattern: ' + Object.entries(cks).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k} ${v}`).join(', '));
  const avg = (f) => (results.reduce((s, r) => s + f(r), 0) / results.length);
  console.log(`  per run: shields used ${avg(r => r.shieldsUsed).toFixed(2)}, bumps ${avg(r => r.bumps).toFixed(2)}, boosts ${avg(r => r.boosts).toFixed(2)}, near misses ${avg(r => r.nearMisses).toFixed(1)}`);
  console.log(`  step() ${avg(r => r.stepMs).toFixed(4)} ms avg (sim incl. nothing of the bot);  bot nodes/plan ${avg(r => r.botNodes).toFixed(0)}`);
  const g = results.reduce((s, r) => { s.c += r.gen.chunks; s.r += r.gen.retries; s.f += r.gen.fallbacks; return s; }, { c: 0, r: 0, f: 0 });
  console.log(`  generator: ${g.c} chunks, ${g.r} rejected by the verifier and redrawn, ${g.f} fallbacks`);
  if (name === 'perfect' || flag('verbose')) {
    const early = died.filter(r => r.level < 20);
    for (const r of early.slice(0, 25)) console.log('  DEATH ' + r.dump);
  }
}

function econTable(results) {
  const sums = [], cnt = [];
  for (const r of results) r.levelEnd.forEach((v, L) => { if (v !== undefined) { sums[L] = (sums[L] || 0) + v; cnt[L] = (cnt[L] || 0) + 1; } });
  const out = [];
  for (let L = 1; L < sums.length; L++) if (cnt[L]) out[L] = sums[L] / cnt[L];
  return out;
}

async function runProfile(name, seeds, maxLevel, workers) {
  const base = +(arg('base', 1));
  const list = Array.from({ length: seeds }, (_, i) => base + i * 104729);
  if (workers <= 1) return list.map(s => playOne(name, s, maxLevel, 1500, flag('verbose')));
  const chunks = Array.from({ length: workers }, (_, w) => list.filter((_, i) => i % workers === w));
  const parts = await Promise.all(chunks.map(c => new Promise((res, rej) => {
    const wk = new Worker(new URL(import.meta.url), { workerData: { name, seeds: c, maxLevel, verbose: flag('verbose') } });
    wk.on('message', res); wk.on('error', rej);
  })));
  return parts.flat();
}

if (!isMainThread) {
  const { name, seeds, maxLevel, verbose } = workerData;
  parentPort.postMessage(seeds.map(s => playOne(name, s, maxLevel, 1500, verbose)));
} else if (import.meta.url === `file://${process.argv[1]}`) {
  const which = arg('profile', 'all');
  const seeds = +arg('seeds', 200);
  const workers = +arg('workers', 1);
  const names = which === 'all' ? ['perfect', 'good', 'casual'] : which.split(',');
  const econ = {};
  for (const n of names) {
    const maxLevel = +arg('maxLevel', n === 'perfect' ? 21 : 30);
    const t0 = Date.now();
    const res = await runProfile(n, seeds, maxLevel, workers);
    report(n, res, maxLevel);
    console.log(`  (${((Date.now() - t0) / 1000).toFixed(1)} s wall)`);
    econ[n] = econTable(res);
  }
  if (flag('econ')) {
    const { oldEconomy } = await import('./sim-oldecon.mjs');
    const old = oldEconomy(80, 16, true).cum;
    console.log('\n=== ECONOMY — mean cumulative COMMISSION at the end of each level');
    console.log('  level   old2D(look-ahead bot)   ' + names.map(n => n.padStart(10)).join(' ') + '   new/old(' + names[0] + ')');
    for (let L = 1; L <= 16; L++) {
      const o = old[L] ? old[L].score : NaN;
      const cells = names.map(n => (econ[n][L] ? '$' + Math.round(econ[n][L]).toLocaleString('en-US') : '-').padStart(10));
      const ratio = econ[names[0]][L] && o ? (econ[names[0]][L] / o).toFixed(2) : '-';
      console.log(`  L${String(L).padStart(2)}   ${('$' + Math.round(o).toLocaleString('en-US')).padStart(12)}           ${cells.join(' ')}   ${ratio}`);
    }
  }
}
