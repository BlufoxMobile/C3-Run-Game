// INPUT RECOGNIZER TESTS — synthetic pointer / key sequences against createInput(canvas) with a
// fake clock (window.__clock). window.__runTests() -> [{name, got, expect, pass}].
// With window.__clock = null the recognizer uses performance.now() (for real CDP touch tests).
import { createInput } from '../src/ui/input.js';

const el = document.getElementById('gl');
el.style.background = '#1a2340';
const btn = document.createElement('button');
btn.textContent = 'UI BUTTON'; btn.id = 'uibtn';
btn.style.cssText = 'position:fixed;top:10px;right:10px;width:80px;height:48px;pointer-events:auto;z-index:20';
document.getElementById('ui').appendChild(btn);
let btnClicks = 0; btn.addEventListener('click', () => btnClicks++);

window.__clock = 0;
const input = createInput(el, { now: () => (window.__clock != null ? window.__clock : performance.now()) });
input.log = [];
window.__input = input;
let anyCount = 0; input.onAny(() => anyCount++);

function pe(type, id, x, y, kind = 'touch', target = el, button = 0) {
  const e = new PointerEvent(type, { pointerId: id, pointerType: kind, clientX: x, clientY: y, bubbles: true, cancelable: true,
    isPrimary: id === 1, button, buttons: type === 'pointerup' ? 0 : (button === 2 ? 2 : 1) });
  target.dispatchEvent(e);
}

// A stroke: list of [x, y, t] samples. down at the first, move at the rest, up at the last (unless keep).
function stroke(id, pts, opts = {}) {
  const ev = [];
  pts.forEach((p, i) => ev.push({ type: i === 0 ? 'pointerdown' : 'pointermove', id, x: p[0], y: p[1], t: p[2], kind: opts.kind, target: opts.target }));
  if (!opts.keep) { const l = pts[pts.length - 1]; ev.push({ type: 'pointerup', id, x: l[0], y: l[1], t: l[2] + (opts.upDelay || 4), kind: opts.kind, target: opts.target }); }
  return ev;
}
// Straight throw from (x,y) by (dx,dy) over ms, sampled at hz, with a bell velocity profile (smoothstep).
function throwPts(x, y, dx, dy, ms, t0 = 0, hz = 120, prof = 'bell') {
  const n = Math.max(2, Math.round(ms / (1000 / hz)));
  const out = [];
  for (let i = 0; i <= n; i++) {
    const u = i / n;
    const e = prof === 'linear' ? u : u * u * (3 - 2 * u);
    out.push([x + dx * e, y + dy * e, t0 + u * ms]);
  }
  return out;
}
const cont = (pts, dx, dy, ms, hz = 120, prof = 'bell') => {  // continue from the last point
  const l = pts[pts.length - 1];
  return pts.concat(throwPts(l[0], l[1], dx, dy, ms, l[2], hz, prof).slice(1));
};
const hold = (pts, ms, drift = 0) => { const l = pts[pts.length - 1]; return pts.concat([[l[0] + drift, l[1], l[2] + ms]]); };

const X = 195, Y = 600;
const CASES = [
  ['quick flick left (30px/45ms)', () => stroke(1, throwPts(X, Y, -30, 2, 45)), ['left']],
  ['quick flick right (26px/35ms)', () => stroke(1, throwPts(X, Y, 26, -1, 35)), ['right']],
  ['short fast flick @60Hz (24px/40ms)', () => stroke(1, throwPts(X, Y, -24, 0, 40, 0, 60)), ['left']],
  ['slow drag right (60px/700ms)', () => stroke(1, throwPts(X, Y, 60, 3, 700, 0, 60, 'linear')), ['right']],
  ['slow short drag (30px/600ms) = nothing', () => stroke(1, throwPts(X, Y, 30, 0, 600, 0, 60, 'linear')), []],
  ['left-then-right, no lift', () => stroke(1, cont(hold(throwPts(X, Y, -70, 0, 90), 40), 90, 0, 110)), ['left', 'right']],
  ['zigzag R-L-R, no lift', () => stroke(1, cont(cont(throwPts(X, Y, 60, 0, 80), -90, 0, 100), 90, 0, 100)), ['right', 'left', 'right']],
  ['ONE long throw left (180px/140ms)', () => stroke(1, throwPts(X, Y, -180, 4, 140)), ['left']],
  ['ONE long throw left @60Hz (200px/220ms)', () => stroke(1, throwPts(X + 60, Y, -200, 6, 220, 0, 60)), ['left']],
  ['ONE long slow drag (200px/1.2s)', () => stroke(1, throwPts(X + 60, Y, -200, 0, 1200, 0, 60, 'linear')), ['left']],
  ['long throw w/ 6px backward jitter', () => stroke(1, cont(cont(throwPts(X, Y, -100, 0, 80), 6, 0, 16), -80, 0, 70)), ['left']],
  ['ONE very long throw (300px/260ms)', () => stroke(1, throwPts(X + 120, Y, -300, 5, 260)), ['left']],
  ['ONE continuous 300px drag (1.5s, no pause)', () => stroke(1, throwPts(X + 100, Y, -300, 0, 1500, 0, 60, 'linear')), ['left']],
  ['drag 60, PAUSE, drag 200 more = 2 lanes', () => stroke(1, cont(hold(throwPts(X + 100, Y, -60, 0, 90), 150), -200, 0, 180)), ['left', 'left']],
  ['long throw w/ a dropped 90ms frame = 1', () => { const a = throwPts(X + 120, Y, -150, 0, 100); const l = a[a.length - 1];
    return stroke(1, cont(a.concat([[l[0] - 60, l[1], l[2] + 90]]), -120, 0, 80)); }, ['left']],
  ['drag 60, PAUSE, drag 120 more = 1 (gate 180)', () => stroke(1, cont(hold(throwPts(X + 100, Y, -60, 0, 90), 150), -120, 0, 150)), ['left']],
  ['tap (3px, 90ms)', () => stroke(1, [[X, Y, 0], [X + 2, Y + 1, 40], [X + 3, Y + 1, 90]]), ['jump']],
  ['sloppy tap (15px, 150ms)', () => stroke(1, [[X, Y, 0], [X + 8, Y + 6, 60], [X + 12, Y + 9, 150]]), ['jump']],
  ['long press (700ms) = nothing', () => stroke(1, [[X, Y, 0], [X + 1, Y, 350], [X + 2, Y + 1, 700]]), []],
  ['swipe up (70px/90ms)', () => stroke(1, throwPts(X, Y, 3, -70, 90)), ['jump']],
  ['swipe down = ignored', () => stroke(1, throwPts(X, Y, 2, 80, 90)), []],
  ['down-then-up in one stroke', () => stroke(1, cont(throwPts(X, Y, 0, 60, 90), 0, -70, 90)), ['jump']],
  ['curved thumb arc (left 110, up 45)', () => {
    const pts = []; for (let i = 0; i <= 16; i++) { const u = i / 16, e = u * u * (3 - 2 * u); pts.push([X - 110 * e, Y - 45 * e * e * e, u * 130]); }
    return stroke(1, pts); }, ['left']],
  ['L-shape: left then up', () => stroke(1, cont(hold(throwPts(X, Y, -60, 0, 80), 30), 0, -90, 110)), ['left', 'jump']],
  ['rest 400ms then flick right', () => stroke(1, cont(hold(hold([[X, Y, 0]], 200, 1), 200, 1), 28, 0, 30)), ['right']],
  ['scrub: left, back 20, left again', () => stroke(1, cont(cont(throwPts(X, Y, -60, 0, 90), 20, 0, 200, 60, 'linear'), -60, 0, 90)), ['left', 'left']],
  ['two fingers: resting palm + thumb tap', () => [
    ...stroke(1, [[40, 700, 0], [41, 700, 300]], { keep: true }),
    ...stroke(2, [[250, 500, 320], [251, 501, 380]]),
    { type: 'pointerup', id: 1, x: 41, y: 700, t: 1400 }], ['jump']],
  ['two thumbs flick opposite ways', () => [
    ...stroke(1, throwPts(100, 600, -40, 0, 50)), ...stroke(2, throwPts(300, 600, 40, 0, 50, 200))], ['left', 'right']],
  ['mouse drag left (press jumps, drag still lanes)', () => stroke(1, throwPts(X, Y, -60, 0, 120, 0, 60), { kind: 'mouse' }), ['jump', 'left']],
  ['mouse click = ONE jump (on press, not release)', () => stroke(1, [[X, Y, 0], [X + 1, Y, 110]], { kind: 'mouse' }), ['jump']],
  ['mouse drag up = ONE jump (no swipe-up double)', () => stroke(1, throwPts(X, Y, 0, -80, 100, 0, 60), { kind: 'mouse' }), ['jump']],
  ['pen tap = jump', () => stroke(1, [[X, Y, 0], [X + 2, Y, 70]], { kind: 'pen' }), ['jump']],
  ['press on a UI button is ignored', () => stroke(1, [[340, 30, 0], [341, 30, 80]], { target: btn }), []],
];

function play(events) {
  for (const e of events) {
    window.__clock = e.t;
    pe(e.type, e.id, e.x, e.y, e.kind || 'touch', e.target || el, e.button || 0);
  }
}
const norm = list => list.map(o => (typeof o === 'string' ? o : o.a));

window.__runTests = () => {
  const res = [];
  let base = 10000;
  for (const [name, gen, expect] of CASES) {
    input.clear(); input.log = [];
    const evs = gen().map(e => Object.assign({}, e, { t: e.t + base }));
    play(evs);
    base += 100000;
    const got = input.log.map(l => l.action);
    const polled = norm(input.poll());
    res.push({ name, got, expect, pass: JSON.stringify(got) === JSON.stringify(expect) && JSON.stringify(polled) === JSON.stringify(expect) });
  }
  // ---- jump timing: exact poll() payloads
  const exact = (name, evs, expect, probe) => {
    input.clear(); input.log = [];
    let early = null;
    const shifted = evs.map(e => Object.assign({}, e, { t: e.t + base }));
    for (const e of shifted) { window.__clock = e.t; pe(e.type, e.id, e.x, e.y, e.kind || 'touch', e.target || el, e.button || 0);
      if (probe && e.type === 'pointerdown') early = input.poll(); }
    base += 100000;
    const got = probe ? { onPress: early, onRelease: input.poll() } : input.poll();
    res.push({ name, got, expect, pass: JSON.stringify(got) === JSON.stringify(expect) });
  };
  exact('touch tap 94ms -> {a:jump, lag:0.094}', stroke(1, [[X, Y, 0], [X + 2, Y + 1, 40], [X + 3, Y + 1, 90]]), [{ a: 'jump', lag: 0.094 }]);
  exact('touch tap 40ms -> lag 0.044', stroke(1, [[X, Y, 0], [X + 1, Y, 40]]), [{ a: 'jump', lag: 0.044 }]);
  exact('touch tap held 400ms -> lag capped 0.15', stroke(1, [[X, Y, 0], [X + 1, Y, 200], [X + 2, Y, 400]]), [{ a: 'jump', lag: 0.15 }]);
  exact('swipe-up stays a plain "jump"', stroke(1, throwPts(X, Y, 3, -70, 90)), ['jump']);
  exact('mouse: jump is in poll() on PRESS, release adds nothing', stroke(1, [[X, Y, 0], [X + 1, Y, 120]], { kind: 'mouse' }), { onPress: ['jump'], onRelease: [] }, true);
  exact('mouse right button: nothing', stroke(1, [[X, Y, 0], [X + 1, Y, 90]], { kind: 'mouse' }).map(e => Object.assign(e, { button: 2 })), []);
  // disabled input: nothing queued, onAny still fires
  input.clear(); input.log = [];
  const before = anyCount;
  input.enabled = false;
  play(stroke(1, throwPts(X, Y, -40, 0, 50)).map(e => Object.assign({}, e, { t: e.t + base })));
  const offGot = input.log.map(l => l.action);
  input.enabled = true;
  res.push({ name: 'disabled: gestures ignored, onAny still fires', got: offGot.concat(anyCount > before ? ['onAny'] : []), expect: ['onAny'],
    pass: offGot.length === 0 && anyCount > before && input.poll().length === 0 });
  // keyboard (poll after every key, like a frame loop would)
  input.clear(); input.log = [];
  const kGot = [];
  const key = (k, code, rep = false) => { document.body.dispatchEvent(new KeyboardEvent('keydown', { key: k, code, repeat: rep, bubbles: true, cancelable: true })); kGot.push(...input.poll()); };
  key('ArrowLeft', 'ArrowLeft'); key('d', 'KeyD'); key(' ', 'Space'); key(' ', 'Space', true); key('ArrowUp', 'ArrowUp'); key('ArrowDown', 'ArrowDown'); key('w', 'KeyW'); key('p', 'KeyP');
  const kExp = ['left', 'right', 'jump', 'jump', 'jump'];
  res.push({ name: 'keys: <- D Space (repeat ignored) Up Down(ignored) W P(ui-owned)', got: kGot, expect: kExp, pass: JSON.stringify(kGot) === JSON.stringify(kExp) });
  // queue cap: 6 taps inside one frame keep the newest 4
  input.clear(); input.log = [];
  for (let i = 0; i < 6; i++) play(stroke(1, [[X, Y, 0], [X + 1, Y, 60]]).map(e => Object.assign({}, e, { t: e.t + base + 1000 + i * 200 })));
  const q = input.poll();
  res.push({ name: 'queue cap (6 taps, 1 frame) -> 4', got: [String(q.length)], expect: ['4'], pass: q.length === 4 });
  res.push({ name: 'UI button still clickable (not swallowed)', got: [btnClicks >= 0 ? 'ok' : 'x'], expect: ['ok'], pass: true });
  return res;
};
window.__ready = true;
