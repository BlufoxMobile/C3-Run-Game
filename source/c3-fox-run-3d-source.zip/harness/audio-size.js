import { createAudio, click } from '../src/audio/audio.js';
window.__a = createAudio(); window.__c = click;
