// ACTORS harness: fake sim + a stand-in road/sky/lights (the WORLD agent builds the real one)
// + createActors. Camera modes: ?cam=chase (default) | close | side | truck | far | orbit
//   window.__sim, __actors, __cam(mode), __calls(), __theme(i)
import * as THREE from 'three';
import { createApp, basicChaseCamera } from '../src/core/app.js';
import { BEND, applyBend, projectBent } from '../src/core/bend.js';
import * as C from '../src/core/constants.js';
import { THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL } from '../src/data/themes.js';
import { getTexture, getImage, preload, hasAsset, SPRITE_META } from '../src/core/assets.js';
import { createFakeSim } from '../src/dev/fakeSim.js';
import { createActors } from '../src/render/actors.js';

const Q = new URLSearchParams(location.search);
const app = createApp();
const { scene, camera, renderer } = app;
const sim = createFakeSim({ themeIdx: +(Q.get('theme') || 1), speed: +(Q.get('speed') || 18) });
window.__sim = sim;

// ---------------- stand-in world
const hemi = new THREE.HemisphereLight('#ffffff', '#445544', 1.4); scene.add(hemi);
const sun = new THREE.DirectionalLight('#ffffff', 2.2); sun.position.set(6, 12, 4); scene.add(sun);
scene.fog = new THREE.Fog('#9ab', 60, 175);
function roadTex() {
  const c = document.createElement('canvas'); c.width = 256; c.height = 256; const g = c.getContext('2d');
  g.fillStyle = '#5a5e66'; g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 3000; i++) { g.fillStyle = `rgba(${Math.random() < 0.5 ? '0,0,0' : '255,255,255'},${Math.random() * 0.08})`; g.fillRect(Math.random() * 256, Math.random() * 256, 2, 2); }
  g.fillStyle = '#e9e9e2';
  for (const x of [256 * (1.3 + 4.3) / 8.6, 256 * (-1.3 + 4.3) / 8.6]) g.fillRect(x - 2, 0, 4, 128);
  g.fillStyle = '#f2c230'; g.fillRect(3, 0, 4, 256); g.fillRect(249, 0, 4, 256);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  t.repeat.set(1, 180 / 12);
  return t;
}
const rt = roadTex();
const road = new THREE.Mesh(new THREE.PlaneGeometry(8.6, 180, 1, 120), applyBend(new THREE.MeshStandardMaterial({ map: rt, roughness: 0.92 })));
road.rotation.x = -Math.PI / 2; road.position.set(0, 0, -80); scene.add(road);
const grassMat = applyBend(new THREE.MeshStandardMaterial({ color: '#4f7a3e', roughness: 1 }));
const grass = new THREE.Mesh(new THREE.PlaneGeometry(260, 180, 8, 120), grassMat);
grass.rotation.x = -Math.PI / 2; grass.position.set(0, -0.03, -80); scene.add(grass);
const shoulderMat = applyBend(new THREE.MeshStandardMaterial({ color: '#8a8272', roughness: 1 }));
for (const s of [-1, 1]) {
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 180, 1, 120), shoulderMat);
  sh.rotation.x = -Math.PI / 2; sh.position.set(s * (4.3 + 0.7), -0.01, -80); scene.add(sh);
}
// a few roadside posts for depth
const postMat = applyBend(new THREE.MeshStandardMaterial({ color: '#d8dde2' }));
const posts = new THREE.InstancedMesh(new THREE.BoxGeometry(0.12, 1.1, 0.12), postMat, 40); scene.add(posts);
function setTheme(i) {
  const th = THEMES[i];
  scene.background = new THREE.Color(th.skyB);
  scene.fog.color.set(th.skyB);
  hemi.color.set(th.skyM).lerp(new THREE.Color('#ffffff'), 0.5); hemi.groundColor.set(th.grB);
  hemi.intensity = th.night ? 0.8 : 1.5;
  sun.color.set(th.key); sun.intensity = th.night ? 0.9 : 2.3; sun.position.set(6 * (th.keyDir || 1), 12, 4);
  grassMat.color.set(th.grT);
  road.material.color.set(th.rdB).lerp(new THREE.Color('#ffffff'), 0.55);
}
let themeShown = -1;
const bg = document.createElement('div');
// sky gradient behind the canvas-cleared background
window.__theme = i => sim.forceTheme(i);

// ---------------- actors
const ctx = { THREE, app, scene, camera, renderer, BEND, applyBend, projectBent, C, THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL,
  assets: { getTexture, getImage, preload, hasAsset, SPRITE_META }, tier: Q.get('tier') || 'high' };
const actors = createActors(ctx);
window.__actors = actors;
preload(['sprites/player_run', 'sprites/player_hit', ...MONSTERS.map(m => 'sprites/mon_' + m)]);

// ---------------- cameras
let camMode = Q.get('cam') || 'chase';
let orbitA = +(Q.get('a') || 0.6);
window.__cam = (m, a) => { camMode = m; if (a != null) orbitA = a; };
window.__actorCalls = () => { let n = 0; const names = {}; scene.traverseVisible(o => { if ((o.isMesh || o.isPoints) && /^actors\./.test(o.name || (o.parent && o.parent.name) || '')) { n++; names[o.name] = (names[o.name] || 0) + 1; } }); return { n, names }; };
window.__calls = () => ({ calls: renderer.info.render.calls, tris: renderer.info.render.triangles, geos: renderer.info.memory.geometries, tex: renderer.info.memory.textures });
const lookT = new THREE.Vector3();
function placeCamera() {
  const p = sim.player;
  const fp = actors.foxPos;
  if (camMode === 'close') {
    camera.fov = 40; camera.updateProjectionMatrix();
    camera.position.set(fp.x + 0.2, fp.y + 1.5, fp.z + 3.4);
    camera.lookAt(fp.x, fp.y + 0.9, fp.z);
  } else if (camMode === 'orbit') {
    camera.fov = 45; camera.updateProjectionMatrix();
    camera.position.set(fp.x + Math.sin(orbitA) * 4.2, fp.y + 1.6, fp.z + Math.cos(orbitA) * 4.2);
    camera.lookAt(fp.x, fp.y + 0.9, fp.z);
  } else if (camMode === 'at') {
    const A = window.__camAt || [4, 3, 6, 0, 1, -10, 50];
    camera.fov = A[6] || 50; camera.updateProjectionMatrix();
    camera.position.set(A[0], A[1], A[2]); camera.lookAt(A[3], A[4], A[5]);
  } else if (camMode === 'side') {
    camera.fov = 50; camera.updateProjectionMatrix();
    camera.position.set(7.5, 3.2, 1); camera.lookAt(0, 1.2, -12);
  } else if (camMode === 'truck') {
    // nearest truck ahead: look at its near face
    let best = null;
    for (const t of sim.trains) { const z = C.zOf(t.s, sim.dist); if (z < -4 && (!best || z > C.zOf(best.s, sim.dist))) best = t; }
    camera.fov = 50; camera.updateProjectionMatrix();
    if (best) {
      const z = C.zOf(best.s, sim.dist);
      camera.position.set(best.x + 3.8, 2.6, z + 7.5); lookT.set(best.x, 1.6, z - 2); camera.lookAt(lookT);
    }
  } else if (camMode === 'mon') {
    let best = null;
    for (const o of sim.obstacles) { const z = C.zOf(o.s, sim.dist); if (o.type === 'monster' && z < -3 && (!best || z > C.zOf(best.s, sim.dist))) best = o; }
    camera.fov = 45; camera.updateProjectionMatrix();
    if (best) { const z = C.zOf(best.s, sim.dist); camera.position.set(best.x + 1.5, 1.8, z + 5.5); camera.lookAt(best.x, 1.2, z); }
  } else {
    basicChaseCamera(camera, sim);
  }
}

// ---------------- staging: __solo() empties the scripted road; __add*() pins entities at a
// fixed distance ahead of the fox (s = dist + d every frame) so close-ups are deterministic.
let solo = Q.get('solo') === '1';
const pinned = [];
let pid = 100000;
window.__solo = (b = true) => { solo = b; if (b) { sim.obstacles.length = 0; sim.trains.length = 0; sim.orbs.length = 0; sim.powerups.length = 0; } };
const pin = (list, e, d) => { e.id = pid++; e._d = d; e._list = list; pinned.push(e); return e.id; };
window.__addMonster = (kind, lane, d, extra = {}) => pin('obstacles', Object.assign({ type: 'monster', kind, lane, x: C.LANE_X[lane], s: 0, w: 1.5, h: 2.1, len: 0.8, drift: null, hit: false, smashed: false, near: false }, extra), d);
window.__addBarrier = (lane, d, gateRow = false) => pin('obstacles', { type: 'barrier', kind: 'barrier', lane, x: C.LANE_X[lane], s: 0, w: 2.1, h: 1.0, len: 0.5, drift: null, hit: false, smashed: false, near: false, gateRow }, d);
window.__addTruck = (kind, lane, d, len, v = 0, ramp = false, livery = 0) => pin('trains', { kind, lane, x: C.LANE_X[lane], s: 0, len, h: 3.1, w: 2.25, v, ramp, rampLen: ramp ? 7 : 0, livery, lights: v < 0 }, d);
window.__addOrbs = (kind, lane, d, n = 5, y = 0.9, gap = 2.2) => { for (let i = 0; i < n; i++) pin('orbs', { kind, lane, x: C.LANE_X[lane], s: 0, y, got: false, magnet: false }, d + i * gap); };
window.__addPower = (kind, lane, d) => pin('powerups', { kind, lane, x: C.LANE_X[lane], s: 0, y: 1.0, got: false }, d);
window.__smash = id => { const e = pinned.find(p => p.id === id); if (e) { e.smashed = true; sim.events.push({ type: 'smash', id, kind: e.kind, x: e.x, y: 1, s: e.s }); } };
window.__player = (o) => Object.assign(sim.player, o);
window.__setShield = n => { sim.shield = n; };
// dump an atlas (fox | monsters) into a 2D canvas overlay to inspect the cleaned sheets
window.__showAtlas = (which = 'fox') => {
  const at = actors.parts[which].atlas, tex = at.tex; if (!tex) return 'no tex';
  const { width: W, height: H, data } = tex.image;
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d'); const id = g.createImageData(W, H);
  for (let y = 0; y < H; y++) id.data.set(data.subarray((H - 1 - y) * W * 4, (H - y) * W * 4), y * W * 4);
  g.putImageData(id, 0, 0);
  c.style.cssText = 'position:fixed;left:0;top:0;width:100%;background:#3a6;z-index:9';
  document.body.appendChild(c);
  return [W, H];
};

// ---------------- loop
const frame = { time: 0, dt: 0, realDt: 0, camera, width: 1, height: 1, tier: 'high' };
let freeze = Q.get('freeze') === '1';
window.__freeze = b => { freeze = b; };
app.addTick((dt, t) => {
  if (!freeze) sim.step(dt);
  if (solo) {
    sim.obstacles.length = 0; sim.trains.length = 0; sim.orbs.length = 0; sim.powerups.length = 0;
    for (const e of pinned) { if (!e.smashed || e._list !== 'obstacles' || true) { e.s = sim.dist + e._d; sim[e._list].push(e); } }
  }
  // fake sim has no flight: fly the fox during GIG BOOST so the look can be judged
  if (sim.power.boost > 0) { const p = sim.player; p.y += (4.8 - p.y) * Math.min(1, dt * 5); p.vy = 0; p.grounded = false; p.anim = 'boost'; }
  if (window.__hold) Object.assign(sim.player, window.__hold);
  if (sim.themeIdx !== themeShown) { themeShown = sim.themeIdx; setTheme(themeShown); }
  rt.offset.y = (sim.dist / 12) % 1;
  for (let i = 0; i < 40; i++) {
    const s = Math.floor(sim.dist / 12) * 12 + i * 12 - 12;
    const z = C.zOf(s, sim.dist);
    posts.setMatrixAt(i, new THREE.Matrix4().makeTranslation((i % 2 ? 1 : -1) * 5.9, 0.55, z));
  }
  posts.instanceMatrix.needsUpdate = true;
  for (const ev of sim.events) actors.onEvent(ev, sim);
  frame.time = t; frame.dt = dt; frame.realDt = dt; frame.width = app.width; frame.height = app.height;
  actors.update(sim, frame);
  placeCamera();
  sim.events.length = 0;
});
app.start();
