// FX harness — camera director + feel + post + fx + quality on the fake sim, with a
// placeholder world (road, lane dashes, roadside lamps & buildings, gantry) and entity
// boxes so bloom / grading / particles / framing can be judged in isolation.
// Query: ?tier=low|med|high  ?theme=N  ?speed=m/s  ?mode=ready  ?boost=1  ?reduced=1
// Window: __app __sim __fx __post __cam __feel __q __ev(type, extra) __coin() __frame
import * as THREE from 'three';
import { createApp } from '../src/core/app.js';
import { BEND, applyBend, projectBent } from '../src/core/bend.js';
import * as C from '../src/core/constants.js';
import { zOf, LANE_X } from '../src/core/constants.js';
import { getTexture, getImage, preload, hasAsset, SPRITE_META } from '../src/core/assets.js';
import { THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL } from '../src/data/themes.js';
import { createFakeSim } from '../src/dev/fakeSim.js';
import { createCameraDirector } from '../src/render/camera.js';
import { createFeel } from '../src/render/feel.js';
import { createPost } from '../src/render/post.js';
import { createFX } from '../src/render/fx.js';
import { createQuality } from '../src/render/quality.js';

const Q = new URLSearchParams(location.search);
const app = createApp();
const { scene, camera, renderer } = app;
const quality = createQuality({ renderer, forceTier: Q.get('tier') ? null : 'high' });
app.setDprCap(quality.dprCap);
const ctx = { THREE, app, scene, camera, renderer, BEND, applyBend, projectBent, C,
  THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL,
  assets: { getTexture, getImage, preload, hasAsset, SPRITE_META }, tier: quality.tier };

const sim = createFakeSim({ themeIdx: +(Q.get('theme') || 1), speed: +(Q.get('speed') || 19) });
if (Q.get('mode') === 'ready') sim.mode = 'ready';

// ------------------------------------------------------------ placeholder world
const hemi = new THREE.HemisphereLight('#ffe7c4', '#2a3a2a', 1.5); scene.add(hemi);
const sun = new THREE.DirectionalLight('#fff2d8', 1.8); sun.position.set(5, 10, 4); scene.add(sun);
scene.fog = new THREE.Fog('#e9b98e', 45, 150);
const std = (c, o = {}) => applyBend(new THREE.MeshStandardMaterial({ color: c, roughness: 0.85, ...o }));
const basic = (c, k = 1) => { const m = applyBend(new THREE.MeshBasicMaterial({ color: c })); m.color.multiplyScalar(k); return m; };

const roadMat = std('#555a66');
const road = new THREE.Mesh(new THREE.PlaneGeometry(8.6, 190, 1, 95), roadMat);
road.rotation.x = -Math.PI / 2; road.position.z = -80; scene.add(road);
const grassMat = std('#4f7a3e');
const grass = new THREE.Mesh(new THREE.PlaneGeometry(260, 190, 1, 95), grassMat);
grass.rotation.x = -Math.PI / 2; grass.position.set(0, -0.03, -80); scene.add(grass);
const shoulderMat = std('#8a8175');
for (const x of [-5.0, 5.0]) { const m = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 190, 1, 95), shoulderMat); m.rotation.x = -Math.PI / 2; m.position.set(x, -0.01, -80); scene.add(m); }
for (const x of [-4.25, 4.25]) { const m = new THREE.Mesh(new THREE.PlaneGeometry(0.14, 190, 1, 95), basic('#f2f2f2', 0.9)); m.rotation.x = -Math.PI / 2; m.position.set(x, 0.01, -80); scene.add(m); }
// lane dashes: one instanced mesh, scrolled
const DASH_N = 40;
const dashes = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.13, 2.4), basic('#f4f4f4', 0.9), DASH_N * 2);
dashes.frustumCulled = false; scene.add(dashes);
// roadside lamps (emissive heads bloom at night) + buildings/trees, recycled by modulo
const PROP_N = 16, PROP_GAP = 11;
const poleGeo = new THREE.CylinderGeometry(0.08, 0.1, 6, 6); poleGeo.translate(0, 3, 0);
const headGeo = new THREE.SphereGeometry(0.28, 10, 8);
const poles = new THREE.InstancedMesh(poleGeo, std('#3d4350', { metalness: 0.5 }), PROP_N * 2);
const heads = new THREE.InstancedMesh(headGeo, basic('#fff1c9', 1), PROP_N * 2);
const bldGeo = new THREE.BoxGeometry(1, 1, 1); bldGeo.translate(0, 0.5, 0);
const blds = new THREE.InstancedMesh(bldGeo, std('#7d8796'), PROP_N * 2);
const winGeo = new THREE.PlaneGeometry(1, 1);
const wins = new THREE.InstancedMesh(winGeo, basic('#ffd48a', 1), PROP_N * 2);
const treeGeo = new THREE.ConeGeometry(1.3, 4.2, 7); treeGeo.translate(0, 2.6, 0);
const trees = new THREE.InstancedMesh(treeGeo, std('#2e5a33'), PROP_N * 2);
for (const m of [poles, heads, blds, wins, trees]) { m.frustumCulled = false; scene.add(m); }
// level gantry at nextLevelAt
const gantry = new THREE.Group();
const gMat = std('#5b6270', { metalness: 0.6, roughness: 0.4 });
for (const x of [-5.6, 5.6]) { const l = new THREE.Mesh(new THREE.BoxGeometry(0.35, 7, 0.35), gMat); l.position.set(x, 3.5, 0); gantry.add(l); }
const beam = new THREE.Mesh(new THREE.BoxGeometry(11.6, 0.5, 0.5), gMat); beam.position.y = 6.8; gantry.add(beam);
const sign = new THREE.Mesh(new THREE.BoxGeometry(6.5, 1.6, 0.2), basic('#1b7a3d', 1)); sign.position.y = 5.6; gantry.add(sign);
const signLight = new THREE.Mesh(new THREE.BoxGeometry(6.3, 0.08, 0.1), basic('#fff6d8', 5)); signLight.position.set(0, 6.45, 0.2); gantry.add(signLight);
scene.add(gantry);

// ------------------------------------------------------------ entity boxes
const pool = new Map();
const mats = {
  monster: std('#c0392b'), barrier: std('#f1c40f'),
  train: std('#dfe6ee', { metalness: 0.3, roughness: 0.5 }),
  power: std('#4fd8ff', { emissive: '#4fd8ff', emissiveIntensity: 1.8 }),
};
const orbMats = {}; for (const k in KINDS) orbMats[k] = std(KINDS[k].c, { emissive: KINDS[k].c, emissiveIntensity: 1.9, roughness: 0.3, metalness: 0.2 });
const lampMat = basic('#fff8e0', 6), tailMat = basic('#ff2a2a', 3);
const box = new THREE.BoxGeometry(1, 1, 1), orbGeo = new THREE.OctahedronGeometry(0.34, 0);
function sync(list, kind, sizeFn, seen) {
  for (const e of list) {
    seen.add(e.id);
    let m = pool.get(e.id);
    if (!m) {
      if (kind === 'orb') m = new THREE.Mesh(orbGeo, orbMats[e.kind] || orbMats.xm);
      else m = new THREE.Mesh(box, mats[kind]);
      if (kind === 'train') {
        for (const x of [-0.35, 0.35]) {
          const l = new THREE.Mesh(box, e.lights ? lampMat : tailMat); l.scale.set(0.16, 0.05, 0.02);
          l.position.set(x, -0.35, -0.51); m.add(l);
        }
      }
      if (kind === 'power') m.material = std(POWERUPS[e.kind].c, { emissive: POWERUPS[e.kind].c, emissiveIntensity: 1.8 });
      pool.set(e.id, m); scene.add(m);
    }
    const [w, h, l, y] = sizeFn(e);
    if (kind === 'orb') { m.position.set(e.x, e.y, zOf(e.s, sim.dist)); m.rotation.y = sim.time * 4 + e.id; m.visible = !e.got; }
    else { m.scale.set(w, h, l); m.position.set(e.x, y + h / 2, zOf(e.s + l / 2, sim.dist)); }
  }
}
// fox sprite
const foxTex = getTexture('sprites/player_run');
const foxMat = applyBend(new THREE.MeshBasicMaterial({ transparent: true, alphaTest: 0.05, color: '#ffffff' }));
if (foxTex) { foxTex.repeat.set(1 / 6, 1); foxMat.map = foxTex; foxMat.needsUpdate = true; }
const FOXH = 2.4;                                  // sprite cell height (content ~1.75 m)
const fox = new THREE.Mesh(new THREE.PlaneGeometry(FOXH * 0.627, FOXH), foxMat);
fox.geometry.translate(0, FOXH / 2 - 0.02, 0);
scene.add(fox);
const blobMat = applyBend(new THREE.MeshBasicMaterial({ color: '#000', transparent: true, opacity: 0.32, depthWrite: false }));
const blob = new THREE.Mesh(new THREE.CircleGeometry(0.55, 20), blobMat); blob.rotation.x = -Math.PI / 2; scene.add(blob);
preload(['sprites/player_run']);

// ------------------------------------------------------------ theme application
let appliedTheme = -1;
const col = new THREE.Color();
function applyTheme(t) {
  scene.background = new THREE.Color(t.skyB);
  scene.fog.color.set(t.skyB);
  hemi.color.set(t.amb); hemi.groundColor.set(t.grB); hemi.intensity = 0.9 + t.ambA * 3;
  sun.color.set(t.key); sun.intensity = 0.6 + t.keyA * 4.2; sun.position.set(6 * (t.keyDir || 1), 10, 4);
  roadMat.color.set(t.rdB); grassMat.color.set(t.grT);
  blds.material.color.set(t.mid).lerp(col.set('#8a93a3'), 0.4);
  trees.material.color.set(t.near);
  const night = !!t.night || t.tod === 'dusk';
  heads.material.color.set('#fff1c9').multiplyScalar(night ? 5 : 1.1);
  wins.visible = night;
}

// ------------------------------------------------------------ FX modules
const cam = createCameraDirector(ctx);
const feel = createFeel();
const fx = createFX(ctx);
const post = createPost(ctx);
quality.onChange((tier, dpr) => { post.setQuality(tier); fx.setQuality(tier); app.setDprCap(dpr); });
app.onResize((w, h, dpr) => post.setSize(w, h, dpr));
const frame = { time: 0, dt: 0, realDt: 0, camera, width: app.width, height: app.height, tier: quality.tier };

const M4 = new THREE.Matrix4(), Q4 = new THREE.Quaternion(), V3 = new THREE.Vector3(), S3 = new THREE.Vector3(1, 1, 1), YAXIS = new THREE.Vector3(0, 1, 0), XAXIS = new THREE.Vector3(1, 0, 0);
function tickWorld() {
  const d = sim.dist;
  if (sim.themeIdx !== appliedTheme) { appliedTheme = sim.themeIdx; applyTheme(sim.theme); }
  // dashes
  const off = d % 6;
  for (let i = 0; i < DASH_N; i++) {
    const z = -(i * 6 - off) + 3;
    for (let j = 0; j < 2; j++) {
      Q4.setFromAxisAngle(XAXIS, -Math.PI / 2);
      M4.compose(V3.set(j ? 1.3 : -1.3, 0.012, z), Q4, S3); dashes.setMatrixAt(i * 2 + j, M4);
    }
  }
  dashes.instanceMatrix.needsUpdate = true;
  // props
  const po = d % PROP_GAP;
  Q4.identity();
  for (let i = 0; i < PROP_N; i++) {
    const z = -(i * PROP_GAP - po) + 8;
    const k = Math.floor((d + i * PROP_GAP) / PROP_GAP);          // stable per-prop seed
    for (let j = 0; j < 2; j++) {
      const side = j ? 1 : -1, idx = i * 2 + j, seed = (k * 7 + j * 13) % 11;
      M4.compose(V3.set(side * 6.2, 0, z), Q4, S3.set(1, 1, 1)); poles.setMatrixAt(idx, M4);
      M4.compose(V3.set(side * 5.4, 6.0, z), Q4, S3.set(1, 1, 1)); heads.setMatrixAt(idx, M4);
      const bh = 6 + seed * 1.6, bw = 5 + (seed % 3) * 1.5, bx = side * (12 + (seed % 4) * 2);
      M4.compose(V3.set(bx, 0, z - 3), Q4, S3.set(bw, bh, 7)); blds.setMatrixAt(idx, M4);
      Q4.setFromAxisAngle(YAXIS, -side * Math.PI / 2);
      M4.compose(V3.set(bx - side * (bw / 2 + 0.03), bh * 0.55, z - 3), Q4, S3.set(4.5, bh * 0.5, 1)); wins.setMatrixAt(idx, M4);
      Q4.identity();
      M4.compose(V3.set(side * (8.5 + (seed % 3)), 0, z + 4), Q4, S3.set(1, 0.8 + (seed % 4) * 0.15, 1)); trees.setMatrixAt(idx, M4);
    }
  }
  for (const m of [poles, heads, blds, wins, trees]) m.instanceMatrix.needsUpdate = true;
  gantry.position.set(0, 0, zOf(sim.nextLevelAt, d));
  // entities
  const seen = new Set();
  sync(sim.obstacles, 'monster', e => [e.w, e.h, e.len, 0], seen);
  for (const e of sim.obstacles) { const m = pool.get(e.id); if (m && e.type === 'barrier') m.material = mats.barrier; }
  sync(sim.trains, 'train', e => [e.w, e.h, e.len, 0], seen);
  sync(sim.orbs, 'orb', e => [1, 1, 1, 0], seen);
  sync(sim.powerups, 'power', e => [0.8, 0.8, 0.8, e.y - 0.4], seen);
  for (const [id, m] of pool) if (!seen.has(id)) { scene.remove(m); pool.delete(id); }
  // fox
  const p = sim.player;
  if (foxTex) foxTex.offset.x = Math.floor(sim.time * 12) % 6 / 6;
  fox.position.set(p.x, p.y, 0);
  fox.rotation.z = -p.lean * 0.12;
  blob.position.set(p.x, (p.surfaceY || 0) + 0.02, 0);
}

let flyY = 0;
app.addTick((realDt) => {
  const simDt = feel.timeScale(realDt);
  sim.step(simDt);
  // the fake sim doesn't fly during GIG BOOST — emulate the real one (~4.8 m flight)
  const p = sim.player;
  flyY += ((sim.power.boost > 0 ? 4.8 : 0) - flyY) * Math.min(1, simDt * (sim.power.boost > 0 ? 3 : 5));
  if (flyY > 0.05 && p.y < flyY) { p.y = flyY; p.vy = 0; if (sim.power.boost > 0) { p.grounded = false; p.anim = 'boost'; } }
  for (const ev of sim.events) { fx.onEvent(ev, sim); cam.onEvent(ev, sim); feel.onEvent(ev, sim); }
  frame.time += simDt; frame.dt = simDt; frame.realDt = realDt;
  frame.width = app.width; frame.height = app.height; frame.tier = quality.tier;
  tickWorld();
  fx.update(sim, frame);
  cam.update(sim, frame);
  sim.events.length = 0;
});
app.setRender(() => post.render(frame));
let lastT = performance.now();
app.addTick(() => { const now = performance.now(); if (!window.__noQuality) quality.sample(now - lastT); lastT = now; });

if (Q.get('boost') === '1') sim.setPower('boost');

// ------------------------------------------------------------ debug handles
window.__sim = sim; window.__fx = fx; window.__post = post; window.__cam = cam; window.__feel = feel; window.__q = quality; window.__frame = frame;
window.__noQuality = true;  // headless SwiftShader is slow; the watchdog would (correctly) step down
window.__ev = (type, extra = {}) => {
  const p = sim.player;
  const ev = Object.assign({ type, x: p.x, y: p.y + 1, s: sim.dist + 0.3 }, extra);
  fx.onEvent(ev, sim); cam.onEvent(ev, sim); feel.onEvent(ev, sim);
  return type;
};
window.__coin = (kind = 'xm') => window.__ev('coin', { kind, value: 20, combo: 5 });
// framing probe: % from top of feet / head (1.75 m) / road crest, and lane visibility at the fox's depth
window.__framing = () => {
  const o = {}, v = new THREE.Vector3(), p = sim.player, W = app.width, H = app.height;
  const pct = (x, y, z) => { projectBent(v.set(x, y, z), camera, W, H, o); return o; };
  const feet = pct(p.x, p.y, 0).y / H * 100, head = pct(p.x, p.y + 1.75, 0).y / H * 100;
  let crest = 1e9; for (let z = 4; z < 150; z += 2) crest = Math.min(crest, pct(p.x * 0.45, 0, -z).y / H * 100);
  const lanes = [-2.6, 0, 2.6].map(x => { const q = pct(x, 0, 0); return Math.round(q.x); });
  const edgeL = pct(-4.3, 0, 0).x, edgeR = pct(4.3, 0, 0).x;
  return { feet: feet.toFixed(1), head: head.toFixed(1), foxPct: (feet - head).toFixed(1), crest: crest.toFixed(1), lanesPx: lanes.join(','), roadEdgesPx: [Math.round(edgeL), Math.round(edgeR)].join(','), W, H, fov: camera.fov.toFixed(1) };
};
// whole-frame cost (all passes): draw calls, triangles, post passes
window.__stats = () => {
  const inf = renderer.info; inf.autoReset = false; inf.reset();
  const t0 = performance.now(); app.render(1 / 60); const ms = performance.now() - t0;
  const r = { calls: inf.render.calls, tris: inf.render.triangles, postPasses: post.info.passes, tier: post.tier, cpuMs: ms.toFixed(1),
    buffer: renderer.domElement.width + 'x' + renderer.domElement.height, programs: inf.programs.length, textures: inf.memory.textures };
  inf.autoReset = true; return r;
};
window.__info = () => ({ calls: renderer.info.render.calls, tris: renderer.info.render.triangles, tier: post.tier, fov: camera.fov.toFixed(1),
  cam: camera.position.toArray().map(v => v.toFixed(2)).join(','), framing: cam.framing && { F: cam.framing.F.toFixed(1), H: cam.framing.H.toFixed(2), D: cam.framing.D.toFixed(2) } });
app.start();
