// UI HARNESS — the real UI + input over the _smoke-style placeholder scene driven by fakeSim.
//
//   ?screen=loading|title|hud|over|pause   open a state directly (default: loading -> title flow)
//   ?lb=stub|offline|empty|slow|real       leaderboard: in-memory stub (default), stub reporting offline,
//                                          empty board, 2.5 s latency, or the REAL lb.js in OFFLINE mode
//                                          (LB.configure({url:''}) — never the live Worker)
//   ?name=Jeff  preset identity   ?score=12480  game-over score   ?posted=1  auto-post on game over
//   ?manual=1   no autopilot in runs (for input tests)   ?theme=N   start theme
// Exposes window.__app, __sim (getter), __ui, __input, __LB, __harness.
// NEVER posts to the live leaderboard.
import * as THREE from 'three';
import { createApp, basicChaseCamera } from '../src/core/app.js';
import { applyBend, BEND, projectBent } from '../src/core/bend.js';
import * as C from '../src/core/constants.js';
import { zOf } from '../src/core/constants.js';
import { THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL, tierOf } from '../src/data/themes.js';
import { getTexture, preload, hasAsset, SPRITE_META } from '../src/core/assets.js';
import { createFakeSim } from '../src/dev/fakeSim.js';
import { createUI } from '../src/ui/ui.js';
import { createInput } from '../src/ui/input.js';
import { LB as REAL_LB } from '../src/vendor/lb-esm.js';   // stays unconfigured (offline) here

const QS = new URLSearchParams(location.search);
const qs = k => QS.get(k);

// ------------------------------------------------------------------ leaderboard stub (in-memory only)
function normKey(n) { return String(n || '').toLowerCase().replace(/[^a-z0-9]+/g, ''); }
function createStubLB(mode) {
  const seed = [
    ['Tasha M', 18420, 11], ['JEFF', 15210, 9], ['Marcus', 12980, 8], ['DeShawn', 9340, 7], ['Kenji', 7710, 6],
    ['Rosa', 6120, 5], ['Big Mike', 5480, 5], ['Aaliyah', 4410, 4], ['Priya', 3990, 4], ['Tom K', 3010, 3],
    ['Lena', 2780, 3], ['Carlos', 2290, 3], ['Bree', 1840, 2], ['Omar', 1430, 2], ['Sam', 980, 1],
  ];
  let rows = mode === 'empty' ? [] : seed.map(([name, score, level]) => ({ name, score, level, district: '' }));
  const ident = { name: qs('name') || '', district: '' };
  const online = mode !== 'offline';
  const delay = mode === 'slow' ? 2500 : 90;
  const ranked = () => rows.slice().sort((a, b) => b.score - a.score).map((r, i) => Object.assign({}, r, { rank: i + 1 }));
  const later = v => new Promise(res => setTimeout(() => res(v), delay));
  return {
    stub: true, submits: [],
    configure() {}, config: () => ({ url: '', district: '' }),
    isOnline: () => online,
    identity: () => ({ name: ident.name, district: ident.district }),
    setIdentity(n) { ident.name = String(n || '').trim().slice(0, 24); return this.identity(); },
    top(n) { return later(ranked().slice(0, n || 25)); },
    submit(v) {
      this.submits.push(Object.assign({}, v));
      const name = String(v.name || '').trim(); const score = Math.floor(+v.score || 0);
      if (!name) return later({ ok: false, error: 'Enter a name first.', remote: false });
      if (score <= 0) return later({ ok: false, error: 'Score must be greater than zero.', remote: false });
      const k = normKey(name);
      const ex = rows.find(r => normKey(r.name) === k);
      if (ex) { if (score > ex.score) { ex.score = score; ex.level = v.level; } } else rows.push({ name, score, level: v.level || 1, district: '' });
      const best = ex ? ex.score : score;
      const rank = ranked().findIndex(r => normKey(r.name) === k) + 1;
      return later({ ok: true, remote: online, offline: !online, name: ex ? ex.name : name, best, rank });
    },
    pendingCount: () => 0,
  };
}

function pickLB() {
  const m = qs('lb') || 'stub';
  if (m !== 'real') return createStubLB(m);
  // the REAL client, strictly offline. Its offline queue is scrubbed after every submit so a
  // test run can never drain into the live board later from this origin.
  const LB = REAL_LB;
  LB.configure({ url: '' });
  const submit = LB.submit.bind(LB);
  LB.submit = v => submit(v).then(r => { try { localStorage.removeItem('c3lb_queue_v1'); } catch (e) {} return r; });
  return LB;
}

// ------------------------------------------------------------------ scene (the _smoke placeholder world)
const app = createApp();
const { scene, camera } = app;
let sim = createFakeSim({ themeIdx: +(qs('theme') || 1) });
Object.defineProperty(window, '__sim', { get: () => sim, configurable: true });

scene.add(new THREE.HemisphereLight('#ffe7c4', '#2a3a2a', 1.6));
const sun = new THREE.DirectionalLight('#fff2d8', 2.0); sun.position.set(5, 10, 4); scene.add(sun);
scene.fog = new THREE.Fog('#e9b98e', 40, 160);
scene.background = new THREE.Color('#e9b98e');
const roadMat = applyBend(new THREE.MeshStandardMaterial({ color: '#555a66', roughness: 0.9 }));
const road = new THREE.Mesh(new THREE.PlaneGeometry(8.6, 180, 1, 90), roadMat);
road.rotation.x = -Math.PI / 2; road.position.z = -75; scene.add(road);
const grass = new THREE.Mesh(new THREE.PlaneGeometry(200, 180, 1, 90), applyBend(new THREE.MeshStandardMaterial({ color: '#4f7a3e' })));
grass.rotation.x = -Math.PI / 2; grass.position.set(0, -0.02, -75); scene.add(grass);
for (const x of [-1.3, 1.3]) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 180, 1, 90), applyBend(new THREE.MeshBasicMaterial({ color: '#ffffff' })));
  m.rotation.x = -Math.PI / 2; m.position.set(x, 0.01, -75); scene.add(m);
}
const pool = new Map();
const mats = {
  monster: applyBend(new THREE.MeshStandardMaterial({ color: '#c0392b' })),
  barrier: applyBend(new THREE.MeshStandardMaterial({ color: '#f1c40f' })),
  train: applyBend(new THREE.MeshStandardMaterial({ color: '#dfe6ee', metalness: 0.3, roughness: 0.5 })),
  orb: applyBend(new THREE.MeshStandardMaterial({ color: '#ffce4d', emissive: '#8a5a00' })),
  power: applyBend(new THREE.MeshStandardMaterial({ color: '#4fd8ff', emissive: '#0a4a66' })),
};
const box = new THREE.BoxGeometry(1, 1, 1);
function sync(list, kind, sizeFn, seen) {
  for (const e of list) {
    seen.add(e.id);
    let m = pool.get(e.id);
    if (!m) { m = new THREE.Mesh(box, mats[kind]); pool.set(e.id, m); scene.add(m); }
    const [w, h, l, y] = sizeFn(e);
    m.scale.set(w, h, l);
    m.position.set(e.x, y + h / 2, zOf(e.s + l / 2, sim.dist));
  }
}
const fox = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.75), applyBend(new THREE.MeshBasicMaterial({ transparent: true, alphaTest: 0.1 })));
const tex = getTexture('sprites/player_run');
if (tex) { tex.repeat.set(1 / 6, 1); fox.material.map = tex; fox.material.needsUpdate = true; }
scene.add(fox);

// ------------------------------------------------------------------ UI + input
const LB = pickLB();
window.__LB = LB;
const ctx = { THREE, app, scene, camera, renderer: app.renderer, BEND, applyBend, projectBent, C,
  THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL, assets: { getTexture, preload, hasAsset, SPRITE_META }, tier: 'high' };
const ui = createUI(Object.assign({}, ctx, { root: document.getElementById('ui'), LB, camera }));
const input = createInput(app.canvas, { now: () => (window.__clock != null ? window.__clock : performance.now()) });
input.log = [];
window.__ui = ui; window.__input = input;

const H = window.__harness = { paused: false, events: [], emitted: [], manual: qs('manual') === '1', runs: 0 };
for (const n of ['play', 'retry', 'pause', 'resume', 'mute', 'quit']) ui.on(n, v => H.emitted.push(v === undefined ? n : n + ':' + v));

function newRun() {
  sim = createFakeSim({ themeIdx: 0 });
  sim.autopilot = !H.manual;
  H.runs++;
  input.enabled = true;
  H.paused = false;
  ui.showHUD();
}
function toAttract() { sim = createFakeSim({ themeIdx: +(qs('theme') || 1) }); input.enabled = false; ui.showTitle(); }
function summary() {
  const lv = sim.level || 1;
  return { score: +(qs('score') || sim.score), level: lv, themeName: sim.theme.name, tier: tierOf(lv),
    killer: sim.killer, bestCombo: sim.bestCombo || 1, orbs: sim.stats.orbs, distance: sim.dist, runSeconds: sim.runTime };
}
ui.on('play', newRun);
ui.on('retry', newRun);
ui.on('quit', toAttract);
ui.on('pause', () => { H.paused = true; input.enabled = false; });
ui.on('resume', () => { H.paused = false; input.enabled = true; });

app.addTick((dt, t) => {
  if (!H.paused) {
    const acts = input.poll();
    for (const a of acts) { if (a === 'left') sim.moveLane(-1); else if (a === 'right') sim.moveLane(1); else if (a === 'jump') sim.jump(); }
    sim.step(dt);
    for (const ev of sim.events) {
      H.events.push(ev.type);
      if (H.events.length > 400) H.events.splice(0, 200);
      ui.onEvent(ev, sim);
      if (ev.type === 'death') { input.enabled = false; ui.showGameOver(summary()); }
    }
  }
  const seen = new Set();
  sync(sim.obstacles, 'monster', e => [e.type === 'barrier' ? 2.1 : e.w, e.h, e.len, 0], seen);
  sync(sim.trains, 'train', e => [e.w, e.h, e.len, 0], seen);
  sync(sim.orbs, 'orb', e => [0.6, 0.6, 0.12, e.y - 0.3], seen);
  sync(sim.powerups, 'power', e => [0.8, 0.8, 0.8, e.y - 0.4], seen);
  for (const [id, m] of pool) if (!seen.has(id)) { scene.remove(m); pool.delete(id); }
  for (const [id, m] of pool) { const o = sim.obstacles.find(x => x.id === id); if (o) m.material = o.type === 'barrier' ? mats.barrier : mats.monster; }
  if (tex) tex.offset.x = Math.floor(t * 12) % 6 / 6;
  fox.position.set(sim.player.x, sim.player.y + 0.875, 0);
  basicChaseCamera(camera, sim);
  ui.updateHUD(sim, { time: t, dt, realDt: dt, camera, width: app.width, height: app.height, tier: 'high' });
  sim.events.length = 0;
});
app.start();
preload(['sprites/player_run']);

// ------------------------------------------------------------------ open the requested state
const screen = qs('screen') || '';
function seedHud() {
  sim.score = 1465; sim.tsheets = 3; sim.shield = 2; sim.combo = 4; sim.comboTimer = 1.1;
  sim.setPower('magnet', 7.5); sim.setPower('x2', 3.2);
}
if (screen === 'loading') {
  ui.setLoading(0.64, 'Loading sprites 14 / 22');
} else if (screen === 'title') {
  input.enabled = false; ui.showTitle();
} else if (screen === 'hud' || screen === 'toast') {
  newRun(); seedHud();
} else if (screen === 'pause') {
  newRun(); seedHud(); sim.step(0.2); ui.updateHUD(sim, { dt: 0.2, realDt: 0.2, camera, width: app.width, height: app.height });
  ui.showPause(true); H.paused = true; input.enabled = false;
} else if (screen === 'over') {
  newRun(); sim.level = 7; sim.themeIdx = 6; sim.theme = THEMES[6]; sim.score = 12480; sim.runTime = 181;
  sim.killer = { type: 'monster', kind: qs('killer') || 'chargeback' };
  input.enabled = false;
  ui.showGameOver(summary());
  if (qs('posted') === '1') setTimeout(() => { document.querySelector('.o-name').value = qs('name') || 'Jeff B'; document.querySelector('.o-post button').click(); }, 700);
} else {
  // the real boot flow: a loading bar that fills, then auto-advances to TITLE (no gesture needed)
  input.enabled = false;
  let p = 0;
  const iv = setInterval(() => { p = Math.min(1, p + 0.12); ui.setLoading(p, p < 1 ? `Loading sprites ${Math.round(p * 22)} / 22` : 'Ready'); if (p >= 1) clearInterval(iv); }, 120);
}
