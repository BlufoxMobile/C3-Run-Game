// WORLD harness: createApp + createWorld + fake sim + a chase camera approximating the FX
// agent's framing (portrait: horizon ~1/3 from the top, fox near the bottom) + placeholder boxes
// for entities so obstacle readability against the scenery can be judged.
//   ?theme=N   start stage (0..11)      ?tier=high|med|low     ?len=metres per level
//   ?cam=low   use core basicChaseCamera instead
// window.__sim, window.__world, window.__app; __gantry(sec) jumps to `sec` seconds before the
// next level gantry; __stats() returns renderer.info.
import * as THREE from 'three';
import { createApp, basicChaseCamera } from '../src/core/app.js';
import { BEND, applyBend, projectBent } from '../src/core/bend.js';
import * as C from '../src/core/constants.js';
import { zOf } from '../src/core/constants.js';
import { THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL } from '../src/data/themes.js';
import { getTexture, getImage, preload, hasAsset, SPRITE_META } from '../src/core/assets.js';
import { createFakeSim } from '../src/dev/fakeSim.js';
import { createWorld } from '../src/render/world.js';

const q = new URLSearchParams(location.search);
const themeIdx = +(q.get('theme') || 0);
const tier = q.get('tier') || 'high';
const app = createApp();
const { scene, camera, renderer } = app;
const ctx = {
  THREE, app, scene, camera, renderer, BEND, applyBend, projectBent, C,
  THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL,
  assets: { getTexture, getImage, preload, hasAsset, SPRITE_META }, tier,
};
const sim = createFakeSim({ themeIdx, levelLen: +(q.get('len') || 420), speed: +(q.get('speed') || 18) });
const world = createWorld(ctx);
if (q.get('nopano')) world.setPanoramas(false);
world.setTheme(themeIdx, true);
if (q.get('pause')) sim.autopilot = false;

// ---- placeholder entities (as in harness/_smoke.js)
const pool = new Map();
const mats = {
  monster: applyBend(new THREE.MeshStandardMaterial({ color: '#d0392b', roughness: 0.6 })),
  barrier: applyBend(new THREE.MeshStandardMaterial({ color: '#f1c40f', roughness: 0.6 })),
  train: applyBend(new THREE.MeshStandardMaterial({ color: '#dfe6ee', metalness: 0.3, roughness: 0.5 })),
  orb: applyBend(new THREE.MeshStandardMaterial({ color: '#ffce4d', emissive: '#8a5a00' })),
  power: applyBend(new THREE.MeshStandardMaterial({ color: '#4fd8ff', emissive: '#0a4a66' })),
};
const box = new THREE.BoxGeometry(1, 1, 1);
function sync(list, kind, sizeFn, seen) {
  for (const e of list) {
    seen.add(e.id);
    let m = pool.get(e.id);
    if (!m) { m = new THREE.Mesh(box, mats[e.type === 'barrier' ? 'barrier' : kind]); pool.set(e.id, m); scene.add(m); }
    const [w, h, l, y] = sizeFn(e);
    m.scale.set(w, h, l);
    m.position.set(e.x, y + h / 2, zOf(e.s + l / 2, sim.dist));
  }
}
const fox = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 1.75), applyBend(new THREE.MeshBasicMaterial({ transparent: true, alphaTest: 0.1 })));
const tex = getTexture('sprites/player_run');
if (tex) { tex.repeat.set(1 / 6, 1); fox.material.map = tex; fox.material.needsUpdate = true; }
scene.add(fox);
preload(['sprites/player_run', 'sprites/scen_pine', 'sprites/scen_tree', 'sprites/scen_barn', 'sprites/scen_sign']);

// ---- camera approximating the target framing
function chase(cam, s) {
  if (q.get('cam') === 'low') return basicChaseCamera(cam, s);
  const p = s.player;
  const sy = Math.max(p.surfaceY || 0, Math.min(p.y || 0, 5));
  const aspect = cam.aspect || 1;
  const fov = aspect < 1 ? THREE.MathUtils.radToDeg(2 * Math.atan(Math.tan(THREE.MathUtils.degToRad(25)) / aspect)) : 60;
  const f = Math.max(55, Math.min(92, fov));
  if (Math.abs(cam.fov - f) > 0.01) { cam.fov = f; cam.updateProjectionMatrix(); }
  cam.position.set(p.x * 0.5, 6.2 + sy * 0.85, 8.0);
  cam.lookAt(p.x * 0.55, -0.4 + sy * 0.9, -13);
}

app.addTick((dt, t) => {
  sim.step(dt);
  if (q.get('clear')) { sim.trains.length = 0; }
  if (q.get('fly')) { sim.player.y = +q.get('fly'); sim.player.surfaceY = 0; }
  for (const ev of sim.events) world.onEvent(ev, sim);
  world.update(sim, { time: t, dt, realDt: dt, camera, width: app.width, height: app.height, tier });
  const seen = new Set();
  sync(sim.obstacles, 'monster', e => [e.w, e.h, e.len, 0], seen);
  sync(sim.trains, 'train', e => [e.w, e.h, e.len, 0], seen);
  sync(sim.orbs, 'orb', e => [0.6, 0.6, 0.12, e.y - 0.3], seen);
  sync(sim.powerups, 'power', e => [0.8, 0.8, 0.8, e.y - 0.4], seen);
  for (const [id, m] of pool) if (!seen.has(id)) { scene.remove(m); pool.delete(id); }
  if (tex) tex.offset.x = Math.floor(t * 12) % 6 / 6;
  fox.position.set(sim.player.x, sim.player.y + 0.875, 0);
  chase(camera, sim);
  sim.events.length = 0;
});

window.__sim = sim;
window.__world = world;
window.__gantry = (sec = 2.5) => { sim.dist = sim.nextLevelAt - sim.speed * sec; return sim.dist; };
window.__stats = () => {
  const r = renderer.info.render;
  let tris = 0, calls = 0;
  const byName = {};
  scene.traverseVisible(o => { if (o.isMesh || o.isPoints) { byName[o.name || o.type] = (byName[o.name || o.type] || 0) + 1; } });
  return JSON.stringify({ calls: r.calls, triangles: r.triangles, points: r.points, geometries: renderer.info.memory.geometries, textures: renderer.info.memory.textures, programs: renderer.info.programs.length });
};
window.__worldInfo = () => {
  const hidden = [];
  for (const o of scene.children) if (o !== world.root && o !== world.sky.mesh && !o.isLight && o.visible) { o.visible = false; hidden.push(o); }
  renderer.info.autoReset = false; renderer.info.reset();
  renderer.render(scene, camera);
  const r = { calls: renderer.info.render.calls, triangles: renderer.info.render.triangles, points: renderer.info.render.points };
  renderer.info.autoReset = true;
  for (const o of hidden) o.visible = true;
  return JSON.stringify(r);
};
window.__worldCalls = () => {
  // draw calls attributable to the world (everything under world.root + sky)
  let n = 0; const names = [];
  const walk = o => { if (!o.visible) return; if ((o.isMesh || o.isPoints) && (o.count === undefined || o.count > 0)) { n++; names.push(o.name || o.type); } o.children.forEach(walk); };
  walk(world.root); if (world.sky.mesh.visible) { n++; names.push('sky'); }
  return JSON.stringify({ n, names });
};
if (!q.get('norun')) app.start(); else app.advance(0.05);
