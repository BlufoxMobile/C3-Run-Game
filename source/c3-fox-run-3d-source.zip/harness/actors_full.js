// ACTORS integration harness: the real WORLD + camera director + feel + FX + post (bloom)
// around createActors, on the fake sim, in the CONTRACT main-loop order. Lets the actors be
// judged in the shipped lighting/framing. Other agents' modules are work-in-progress, so each
// is optional (?noworld=1 ?nopost=1 ?nofx=1 or a failed import falls back gracefully).
//   ?theme=N ?tier=high|med|low ?mode=ready
//   window.__sim __actors __app __stats() __solo() __add*(...) (same staging API as harness/actors.js)
import * as THREE from 'three';
import { createApp } from '../src/core/app.js';
import { BEND, applyBend, projectBent } from '../src/core/bend.js';
import * as C from '../src/core/constants.js';
import { THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL } from '../src/data/themes.js';
import { getTexture, getImage, preload, hasAsset, SPRITE_META } from '../src/core/assets.js';
import { createFakeSim } from '../src/dev/fakeSim.js';
import { createWorld } from '../src/render/world.js';
import { createCameraDirector } from '../src/render/camera.js';
import { createFeel } from '../src/render/feel.js';
import { createPost } from '../src/render/post.js';
import { createFX } from '../src/render/fx.js';
import { createActors } from '../src/render/actors.js';

const Q = new URLSearchParams(location.search);
const tier = Q.get('tier') || 'high';
const app = createApp();
const { scene, camera, renderer } = app;
const ctx = { THREE, app, scene, camera, renderer, BEND, applyBend, projectBent, C, THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL,
  assets: { getTexture, getImage, preload, hasAsset, SPRITE_META }, tier };
const themeIdx = +(Q.get('theme') || 1);
const sim = createFakeSim({ themeIdx, speed: +(Q.get('speed') || 18), levelLen: 600 });
if (Q.get('mode') === 'ready') sim.mode = 'ready';
window.__sim = sim;

const safe = (name, fn) => { try { return fn(); } catch (e) { console.warn('[actors_full] ' + name + ' unavailable:', e && e.message); return null; } };
const world = Q.get('noworld') ? null : safe('world', () => { const w = createWorld(ctx); w.setTheme(themeIdx, true); return w; });
if (!world) { scene.add(new THREE.HemisphereLight('#fff', '#445', 1.5)); const d = new THREE.DirectionalLight('#fff', 2); d.position.set(5, 10, 4); scene.add(d); }
const cam = safe('camera', () => createCameraDirector(ctx));
const feel = safe('feel', () => createFeel());
const fx = Q.get('nofx') ? null : safe('fx', () => createFX(ctx));
const post = Q.get('nopost') ? null : safe('post', () => createPost(ctx));
const actors = createActors(ctx);
window.__actors = actors;
preload(['sprites/player_run', 'sprites/player_hit', ...MONSTERS.map(m => 'sprites/mon_' + m)]);
if (post) { app.onResize((w, h, dpr) => post.setSize(w, h, dpr)); app.setRender(() => post.render(frame)); }

// staging (see harness/actors.js)
let solo = false; const pinned = []; let pid = 100000;
window.__solo = (b = true) => { solo = b; };
const pin = (list, e, d) => { e.id = pid++; e._d = d; e._list = list; pinned.push(e); return e.id; };
window.__addMonster = (kind, lane, d, extra = {}) => pin('obstacles', Object.assign({ type: 'monster', kind, lane, x: C.LANE_X[lane], s: 0, w: 1.5, h: 2.1, len: 0.8, drift: null, hit: false, smashed: false, near: false }, extra), d);
window.__addBarrier = (lane, d, gateRow = false) => pin('obstacles', { type: 'barrier', kind: 'barrier', lane, x: C.LANE_X[lane], s: 0, w: 2.1, h: 1.0, len: 0.5, drift: null, hit: false, smashed: false, near: false, gateRow }, d);
window.__addTruck = (kind, lane, d, len, v = 0, ramp = false, livery = 0) => pin('trains', { kind, lane, x: C.LANE_X[lane], s: 0, len, h: 3.1, w: 2.25, v, ramp, rampLen: ramp ? 7 : 0, livery, lights: v < 0 }, d);
window.__addOrbs = (kind, lane, d, n = 5, y = 0.9, gap = 2.2) => { for (let i = 0; i < n; i++) pin('orbs', { kind, lane, x: C.LANE_X[lane], s: 0, y, got: false, magnet: false }, d + i * gap); };
window.__addPower = (kind, lane, d) => pin('powerups', { kind, lane, x: C.LANE_X[lane], s: 0, y: 1.0, got: false }, d);
window.__actorCalls = () => { let n = 0; const names = {}; scene.traverseVisible(o => { if ((o.isMesh || o.isPoints) && /^actors\./.test(o.name || (o.parent && o.parent.name) || '')) { n++; names[o.name] = (names[o.name] || 0) + 1; } }); return { n, names }; };
window.__stats = () => ({ calls: renderer.info.render.calls, tris: renderer.info.render.triangles, textures: renderer.info.memory.textures, geos: renderer.info.memory.geometries });

const frame = { time: 0, dt: 0, realDt: 0, camera, width: app.width, height: app.height, tier };
let flyY = 0;
app.addTick((realDt) => {
  const simDt = feel ? feel.timeScale(realDt) : realDt;
  sim.step(simDt);
  if (solo) {
    sim.obstacles.length = 0; sim.trains.length = 0; sim.orbs.length = 0; sim.powerups.length = 0;
    for (const e of pinned) { e.s = sim.dist + e._d; sim[e._list].push(e); }
  }
  const p = sim.player;
  flyY += ((sim.power.boost > 0 ? 4.8 : 0) - flyY) * Math.min(1, simDt * (sim.power.boost > 0 ? 3 : 5));
  if (flyY > 0.05 && p.y < flyY) { p.y = flyY; p.vy = 0; if (sim.power.boost > 0) { p.grounded = false; p.anim = 'boost'; } }
  if (window.__hold) Object.assign(p, window.__hold);
  for (const ev of sim.events) {
    if (world) world.onEvent(ev, sim);
    actors.onEvent(ev, sim);
    if (fx) fx.onEvent(ev, sim);
    if (cam) cam.onEvent(ev, sim);
    if (feel) feel.onEvent(ev, sim);
  }
  frame.time += simDt; frame.dt = simDt; frame.realDt = realDt; frame.width = app.width; frame.height = app.height;
  if (world) world.update(sim, frame);
  actors.update(sim, frame);
  if (fx) fx.update(sim, frame);
  if (cam) cam.update(sim, frame);
  sim.events.length = 0;
});
app.start();
