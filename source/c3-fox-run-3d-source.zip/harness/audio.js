// AUDIO LAB — interactive preview page for every SFX and every region/level of music,
// plus the offline-render API used by tools/audio-render.py (window.__audioLab).
//   node build.mjs harness/audio.js scratch/audio/audio.html --dev
import { createAudio } from '../src/audio/audio.js';
import { createEngine, styleForTheme } from '../src/audio/engine.js';
import { PERF } from '../src/audio/instruments.js';
import { STYLES, STYLE_ORDER } from '../src/audio/styles.js';
import { THEMES } from '../src/data/themes.js';
import { createFakeSim } from '../src/dev/fakeSim.js';

// ======================================================================= offline renderer
function f32ToB64(f) {
  const u8 = new Uint8Array(f.buffer, f.byteOffset, f.byteLength);
  let s = '';
  const CH = 0x8000;
  for (let i = 0; i < u8.length; i += CH) s += String.fromCharCode.apply(null, u8.subarray(i, i + CH));
  return btoa(s);
}

function applyOp(eng, e) {
  const S = eng.music.S;
  switch (e.do) {
    case 'title': eng.toTitle(); break;
    case 'run': eng.music.setGame(e.level || 1, e.lap || 1, 0); eng.toRun(e.style || 'smokies');
      if (e.layers != null) S.forceLayers = e.layers; if (e.lift != null) S.forceLift = e.lift; break;
    case 'layers': S.forceLayers = e.n; break;
    case 'lift': S.forceLift = e.n; break;
    case 'game': eng.music.setGame(e.level, e.lap || 1, e.progress || 0); S.forceLayers = null; S.forceLift = null; break;
    case 'levelUp': eng.music.setGame(e.level || S.game.level + 1, 1, 0); eng.levelUp({ themeIdx: e.themeIdx }); break;
    case 'boost': eng.boost(!!e.on); break;
    case 'x2': eng.setSparkle(!!e.on); break;
    case 'comboHot': S.comboHot = !!e.on; break;
    case 'hit': eng.hitStop(); break;
    case 'gameover': eng.toGameOver(); break;
    case 'muffle': eng.muffle(!!e.on); break;
    case 'bed': eng.sfx.bed(e.speed || 20, e.on !== false, !!e.boost); break;
    case 'sfx': eng.sfx[e.name](...(e.args || [])); break;
    case 'noVerb': eng.graph.verbIn.disconnect(); break;
    case 'noOS': eng.graph.sat.oversample = 'none'; break;
    case 'noComp': eng.graph.master.disconnect(); eng.graph.master.connect(eng.graph.limiter); break;
    case 'noPan': for (const k in eng.music.bus) { const b = eng.music.bus[k]; if (b.pan) { b.pump.disconnect(); b.pump.connect(eng.graph.music); b.pump.connect(b.send); } } break;
    case 'bypass': eng.graph.master.disconnect(); eng.graph.master.connect(eng.graph.out); break;
    case 'solo': // mute every music part except the listed ones (for onset/jitter analysis)
      for (const k in eng.music.bus) eng.music.bus[k].pump.disconnect();
      for (const k of e.parts) eng.music.bus[k].pump.connect(eng.graph.music);
      eng.graph.verbRet.gain.value = 0; break;
  }
}

async function render(spec) {
  const sr = spec.sr || 48000, dur = spec.dur || 10;
  Object.assign(PERF, { noSweep: false, noVibrato: false }, spec.perf || {});
  const ctx = new OfflineAudioContext(2, Math.ceil(sr * dur), sr);
  const eng = createEngine(ctx, { seed: spec.seed || 1234, forceSting: true });
  let simT = 0;
  eng.music.nowFn = () => simT;
  eng.music.log = spec.log ? [] : null;
  const ev = (spec.events || []).slice().sort((a, b) => a.t - b.t);
  let ei = 0;
  const n0 = eng.I.stats.nodes;
  let schedMs = 0;
  const tick = T => {
    const a = performance.now();
    simT = T;
    while (ei < ev.length && ev[ei].t <= T + 1e-9) applyOp(eng, ev[ei++]);
    eng.pump();
    schedMs += performance.now() - a;
  };
  // Schedule in 50 ms chunks while rendering (OfflineAudioContext.suspend), exactly like the
  // realtime lookahead: only ~LOOKAHEAD worth of notes exist at any moment.
  const q = 128 / sr, step = Math.max(1, Math.round((spec.chunk || 0.05) / q)) * q;
  tick(0);
  const chunked = spec.upfront ? false : typeof ctx.suspend === 'function';
  if (chunked) {
    for (let k = 1; k * step < dur; k++) {
      const T = k * step;
      ctx.suspend(T).then(() => { tick(T); ctx.resume(); });
    }
  } else {
    for (let T = step; T <= dur + 1e-9; T += step) tick(T);
  }
  const r0 = performance.now();
  const buf = await ctx.startRendering();
  const renderMs = performance.now() - r0 - (chunked ? schedMs : 0);
  const S = eng.music.S;
  if (spec.noData) return { sr, dur, schedMs, renderMs, nodes: eng.I.stats.nodes - n0, peak: buf.getChannelData(0).reduce((m, v) => Math.max(m, Math.abs(v)), 0) };
  return {
    sr, dur, L: f32ToB64(buf.getChannelData(0)), R: f32ToB64(buf.getChannelData(1)),
    log: eng.music.log, schedMs, renderMs, nodes: eng.I.stats.nodes - n0,
    meta: { bpm: S.bpm, stepDur: S.stepDur, style: S.styleId, layers: S.layers, lift: S.lift, lateSkips: S.lateSkips, steps: S.steps },
  };
}

/** Realtime scheduler test with injected main-thread jank. Returns scheduling margins. */
async function idle(seconds) { await new Promise(r => setTimeout(r, seconds * 1000)); return true; }
async function realtime(spec = {}) {
  Object.assign(PERF, { noSweep: false, noVibrato: false }, spec.perf || {});
  const ctx = new AudioContext({ latencyHint: 'interactive' });
  if (spec.bare || spec.graphOnly) { // platform baseline: running context (+ my idle graph)
    try { await ctx.resume(); } catch (e) {}
    const t0 = ctx.currentTime;
    const e = spec.graphOnly ? createEngine(ctx, {}) : null;
    if (e && spec.verbOff) e.graph.verbIn.disconnect();
    await new Promise(r => setTimeout(r, (spec.seconds || 5) * 1000));
    const out = { ctxElapsed: ctx.currentTime - t0, log: [], stepDur: 0.1, lateSkips: 0, schedMs: 0, janks: [], state: ctx.state, wall: spec.seconds };
    await ctx.close();
    return out;
  }
  try { await ctx.resume(); } catch (e) {}
  const eng = createEngine(ctx, { irSeconds: spec.ir });
  eng.graph.out.gain.value = 0;
  eng.music.log = [];
  eng.music.setGame(5, 1, 0);
  eng.toRun(spec.style || 'house');
  eng.music.S.forceLayers = spec.layers ?? 5;
  for (const e of spec.events || []) applyOp(eng, e);
  const timer = setInterval(() => eng.pump(), 25);
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const tStart = ctx.currentTime, wall0 = performance.now();
  const janks = [];
  while (performance.now() - wall0 < (spec.seconds || 6) * 1000) {
    await sleep(40 + Math.random() * 80);
    if (spec.jank) { // busy-block the main thread like a GC pause / shader compile
      const ms = [15, 30, 60, 90][(Math.random() * 4) | 0];
      const b = performance.now(); while (performance.now() - b < ms) {}
      janks.push(ms);
    } else eng.pump();
  }
  clearInterval(timer);
  const log = eng.music.log.map(n => ({ t: n.t, part: n.part, margin: n.margin, bar: n.bar, step: n.step }));
  const S = eng.music.S;
  const out = { state: ctx.state, ctxElapsed: ctx.currentTime - tStart, wall: (performance.now() - wall0) / 1000,
    baseLatency: ctx.baseLatency, sampleRate: ctx.sampleRate, stepDur: S.stepDur, lateSkips: S.lateSkips,
    schedMs: S.schedMs, steps: S.steps, nodes: eng.I.stats.nodes, janks, log };
  await ctx.close();
  return out;
}

function styleInfo() {
  const o = {};
  for (const id in STYLES) o[id] = { mix: STYLES[id].mix, parts: Object.keys(STYLES[id].parts), bpm: STYLES[id].bpm };
  return o;
}
window.__createFakeSim = createFakeSim;
window.__audioLab = { render, realtime, idle, styleInfo, STYLES: Object.keys(STYLES) };

// ======================================================================= interactive page
const audio = createAudio();
window.__audio = audio;

const css = `
#alab{position:fixed;inset:0;overflow:auto;pointer-events:auto;touch-action:pan-y;-webkit-overflow-scrolling:touch;
  font:14px/1.35 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#e8eef8;background:
  radial-gradient(120% 80% at 50% 0%,#1b2a55 0%,#0b1020 60%,#05070a 100%);padding:16px 16px 60px;box-sizing:border-box}
#alab h1{font-size:20px;margin:4px 0 2px;letter-spacing:.5px}
#alab h1 b{color:#4fd8ff}
#alab .sub{color:#8fa3c7;font-size:12px;margin-bottom:12px}
#alab section{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:12px;margin:0 0 12px}
#alab h2{font-size:13px;text-transform:uppercase;letter-spacing:1.2px;color:#9fb7e6;margin:0 0 8px}
#alab .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(104px,1fr));gap:8px}
#alab button{appearance:none;border:0;border-radius:10px;padding:10px 8px;font:600 13px system-ui,sans-serif;color:#fff;
  background:linear-gradient(180deg,#2d4b8f,#20366a);box-shadow:0 2px 0 #0e1a38,inset 0 1px 0 rgba(255,255,255,.15);cursor:pointer;min-height:40px}
#alab button:active{transform:translateY(1px);box-shadow:0 1px 0 #0e1a38}
#alab button.on{background:linear-gradient(180deg,#1fa37a,#157a5b)}
#alab button.hot{background:linear-gradient(180deg,#d9822b,#a95d14)}
#alab button.big{font-size:16px;padding:14px;width:100%;margin-bottom:12px;background:linear-gradient(180deg,#4fd8ff,#1d8fc0);color:#062033}
#alab .row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
#alab .row label{font-size:12px;color:#9fb7e6}
#alab select,#alab input[type=range]{accent-color:#4fd8ff}
#alab select{background:#15213f;color:#fff;border:1px solid #2d4b8f;border-radius:8px;padding:8px}
#alab .stat{font:12px ui-monospace,Menlo,Consolas,monospace;color:#b9c9e8;white-space:pre-wrap;background:rgba(0,0,0,.25);border-radius:8px;padding:8px}
`;
const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
const root = document.createElement('div'); root.id = 'alab'; document.body.appendChild(root);
const h = (tag, attrs = {}, kids = []) => {
  const e = document.createElement(tag);
  for (const k in attrs) { if (k === 'on') for (const ev in attrs.on) e.addEventListener(ev, attrs.on[ev]); else if (k === 'text') e.textContent = attrs.text; else e.setAttribute(k, attrs[k]); }
  for (const c of [].concat(kids)) if (c) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  return e;
};
const btn = (label, fn, cls) => h('button', { class: cls || '', on: { click: () => { audio.unlock(); audio.click(); fn(); } } }, label);

root.appendChild(h('h1', {}, ['C³ FOX RUN · ', h('b', { text: 'audio lab' })]));
root.appendChild(h('div', { class: 'sub', text: '100% procedural WebAudio — tap anything to start sound. Headphones recommended.' }));
root.appendChild(btn('▶ START AUDIO', () => {}, 'big'));

// fake sim state passed to update() so the real API path (power ticks, beds, sparkle) runs
const fake = { mode: 'play', level: 1, lap: 1, levelProgress: 0, themeIdx: 0, speed: 18, combo: 1,
  power: { magnet: 0, x2: 0, boost: 0 }, player: { x: 0 } };

// ---------------- music
const eng = () => audio.engine;
const secM = h('section', {}, [h('h2', { text: 'Music' })]);
const scenes = h('div', { class: 'grid' }, [
  btn('Title', () => { fake.mode = 'ready'; audio.toTitle(); }),
  btn('Run L1', () => { fake.mode = 'play'; fake.level = 1; fake.themeIdx = 0; audio.toRun(); }),
  btn('Game over', () => { audio.toRun(); fake.mode = 'play'; setTimeout(() => audio.toGameOver(), 400); }),
  btn('Death (hit)', () => { audio.onEvent({ type: 'hit' }, fake); setTimeout(() => audio.onEvent({ type: 'death' }, fake), 1000); }),
  btn('Level-up →', () => { fake.level++; fake.themeIdx = (fake.themeIdx + 1) % 12; audio.onEvent({ type: 'levelUp', level: fake.level, themeIdx: fake.themeIdx }, fake); }),
]);
secM.appendChild(scenes);

const lvlSel = h('select', {}, THEMES.map((t, i) => h('option', { value: i, text: `L${i + 1} · ${t.name} (${styleForTheme(i)})` })));
const layerSel = h('select', {}, [h('option', { value: '', text: 'layers: auto' })].concat([1, 2, 3, 4, 5].map(n => h('option', { value: n, text: `layers: ${n}` }))));
const liftBtn = btn('key lift', () => { liftBtn.classList.toggle('on'); const e = eng(); if (e) e.music.S.forceLift = liftBtn.classList.contains('on') ? 2 : 0; });
secM.appendChild(h('div', { class: 'row', style: 'margin-top:10px' }, [lvlSel, layerSel, btn('Play level', () => {
  const i = +lvlSel.value; fake.mode = 'play'; fake.themeIdx = i; fake.level = i + 1;
  audio.update(fake, null); audio.toRun();
  const e = eng(); if (e) { e.music.S.forceLayers = layerSel.value ? +layerSel.value : null; }
}), liftBtn]));
const styleRow = h('div', { class: 'grid', style: 'margin-top:10px' }, STYLE_ORDER.map(id => btn(STYLES[id].name, () => {
  const i = THEMES.findIndex((t, k) => styleForTheme(k) === id); fake.mode = 'play'; fake.themeIdx = i; fake.level = 5;
  audio.update(fake, null); audio.toRun(); const e = eng(); if (e) e.music.S.forceLayers = 5;
})));
secM.appendChild(styleRow);
const powRow = h('div', { class: 'grid', style: 'margin-top:10px' });
const powBtn = (k, label, dur) => {
  const b = btn(label, () => {
    fake.power[k] = dur; b.classList.add('hot');
    audio.onEvent({ type: 'powerup', kind: k }, fake);
    if (k === 'boost') audio.onEvent({ type: 'boostStart' }, fake);
  });
  return b;
};
const pb = { magnet: powBtn('magnet', 'MAGNET 10s', 10), x2: powBtn('x2', '2X CASH 12s', 12), boost: powBtn('boost', 'GIG BOOST 5s', 5) };
powRow.appendChild(pb.magnet); powRow.appendChild(pb.x2); powRow.appendChild(pb.boost);
powRow.appendChild(btn('combo x6+', () => { fake.combo = fake.combo >= 6 ? 1 : 7; }));
secM.appendChild(powRow);
root.appendChild(secM);

// ---------------- sfx
const SFX = [
  ['coin XM', () => ({ type: 'coin', kind: 'xm', combo: fake.combo = Math.min(9, fake.combo + 1) })],
  ['coin TAB', () => ({ type: 'coin', kind: 'tab', combo: fake.combo = Math.min(9, fake.combo + 1) })],
  ['coin WATCH', () => ({ type: 'coin', kind: 'watch', combo: fake.combo = Math.min(9, fake.combo + 1) })],
  ['T-sheet', () => ({ type: 'tsheet', count: 3, shield: 2 })],
  ['+$100 bonus', () => ({ type: 'bonus', amount: 100 })],
  ['combo 3', () => ({ type: 'combo', combo: 3 })], ['combo 6', () => ({ type: 'combo', combo: 6 })], ['combo 9', () => ({ type: 'combo', combo: 9 })],
  ['combo lost', () => { fake.combo = 1; return { type: 'comboLost' }; }],
  ['jump', () => ({ type: 'jump' })], ['land', () => ({ type: 'land', impact: 6 })], ['land roof', () => ({ type: 'land', impact: 7, onRoof: true })],
  ['lane ←', () => ({ type: 'lane', dir: -1 })], ['lane →', () => ({ type: 'lane', dir: 1 })],
  ['bump', () => ({ type: 'bump', dir: 1 })], ['ramp', () => ({ type: 'ramp' })], ['roof', () => ({ type: 'roof' })], ['drop', () => ({ type: 'drop' })],
  ['near miss L', () => ({ type: 'nearMiss', side: -1 })], ['near miss R', () => ({ type: 'nearMiss', side: 1 })], ['hop', () => ({ type: 'hop' })],
  ['shield break', () => ({ type: 'shieldBreak' })], ['smash', () => ({ type: 'smash' })],
  ['power: magnet', () => ({ type: 'powerup', kind: 'magnet' })], ['power: 2x', () => ({ type: 'powerup', kind: 'x2' })], ['power: boost', () => ({ type: 'powerup', kind: 'boost' })],
  ['power warn', () => ({ type: 'powerWarn', kind: 'x2' })], ['power end', () => ({ type: 'powerEnd', kind: 'magnet' })],
  ['boost start', () => ({ type: 'boostStart' })], ['boost end', () => ({ type: 'boostEnd' })],
  ['truck pass L', () => ({ type: 'trainPass', side: -1 })], ['truck pass R', () => ({ type: 'trainPass', side: 1 })],
  ['level up', () => ({ type: 'levelUp', level: fake.level + 1, themeIdx: fake.themeIdx })],
  ['hit', () => ({ type: 'hit' })],
];
const secS = h('section', {}, [h('h2', { text: 'Sound effects (starts a run if needed)' })]);
secS.appendChild(h('div', { class: 'grid' }, SFX.map(([label, mk]) => btn(label, () => {
  if (audio.scene !== 'run') { fake.mode = 'play'; audio.toRun(); }
  setTimeout(() => audio.onEvent(mk(), fake), audio.scene === 'run' ? 0 : 120);
}))));
secS.appendChild(h('div', { class: 'grid', style: 'margin-top:8px' }, [btn('UI click', () => {})]));
root.appendChild(secS);

// ---------------- simulated run through the real API
const secR = h('section', {}, [h('h2', { text: 'Simulated run (fake sim → onEvent/update)' })]);
let sim = null, simOn = false;
const simBtn = btn('Start simulated run', () => {
  simOn = !simOn; simBtn.classList.toggle('on', simOn); simBtn.textContent = simOn ? 'Stop simulated run' : 'Start simulated run';
  if (simOn) { sim = createFakeSim({ themeIdx: 0, speed: 17, levelLen: 420 }); audio.toRun(); }
});
secR.appendChild(h('div', { class: 'row' }, [simBtn,
  btn('Mute', () => { audio.setMuted(!audio.muted); }),
  btn('Pause', () => { paused = !paused; audio.setPaused(paused); })]));
let paused = false;
const stat = h('div', { class: 'stat', style: 'margin-top:10px' });
secR.appendChild(stat);
root.appendChild(secR);

// ---------------- frame loop
let lastT = performance.now();
function frame() {
  const now = performance.now(), dt = Math.min(0.1, (now - lastT) / 1000); lastT = now;
  if (window.__labPause) { requestAnimationFrame(frame); return; } // automated tests drive audio themselves
  if (simOn && sim && !paused) {
    sim.step(dt);
    for (const ev of sim.events) audio.onEvent(ev, sim);
    audio.update(sim, { dt, tier: 'high' });
    sim.events.length = 0;
  } else if (!paused) {
    for (const k in fake.power) if (fake.power[k] > 0) {
      fake.power[k] = Math.max(0, fake.power[k] - dt);
      if (fake.power[k] === 0) {
        pb[k].classList.remove('hot');
        audio.onEvent({ type: 'powerEnd', kind: k }, fake);
        if (k === 'boost') audio.onEvent({ type: 'boostEnd' }, fake);
      }
    }
    audio.update(fake, { dt, tier: 'high' });
  }
  const e = eng();
  if (e) {
    const S = e.music.S, c = audio.context;
    stat.textContent = `ctx ${c.state}  sr ${c.sampleRate}  t ${c.currentTime.toFixed(2)}  muted ${audio.muted}\n` +
      `scene ${audio.scene}/${e.scene}  style ${S.styleId}  ${S.bpm} bpm  bar ${S.bar}  layers ${S.layers}  lift ${S.lift}\n` +
      `boost ${S.boost}  sparkle ${S.sparkle}  comboHot ${S.comboHot}  pending ${S.pending ? S.pending.styleId + '@' + S.pending.bar : '-'}\n` +
      `nodes created ${e.I.stats.nodes}  late-skips ${S.lateSkips}` + (sim && simOn ? `\nsim L${sim.level} ${sim.theme.name}  combo ${sim.combo}  speed ${sim.speed}` : '');
  }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
