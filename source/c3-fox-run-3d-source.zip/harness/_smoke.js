// Scaffold smoke test + EXAMPLE of how a harness wires the core pieces.
// Draws every fake-sim entity as a plain box so the contract can be eyeballed.
import * as THREE from 'three';
import { createApp, basicChaseCamera } from '../src/core/app.js';
import { applyBend } from '../src/core/bend.js';
import { zOf, LANE_X } from '../src/core/constants.js';
import { getTexture, preload } from '../src/core/assets.js';
import { createFakeSim } from '../src/dev/fakeSim.js';

const app = createApp();
const { scene, camera } = app;
const sim = createFakeSim({ themeIdx: 1 });

scene.add(new THREE.HemisphereLight('#ffe7c4', '#2a3a2a', 1.6));
const sun = new THREE.DirectionalLight('#fff2d8', 2.0); sun.position.set(5, 10, 4); scene.add(sun);
scene.fog = new THREE.Fog('#e9b98e', 40, 160);
scene.background = new THREE.Color('#e9b98e');

// road: a long plane that scrolls its texture offset with distance
const roadMat = applyBend(new THREE.MeshStandardMaterial({ color: '#555a66', roughness: 0.9 }));
const road = new THREE.Mesh(new THREE.PlaneGeometry(8.6, 180, 1, 90), roadMat);
road.rotation.x = -Math.PI / 2; road.position.z = -75; scene.add(road);
const grass = new THREE.Mesh(new THREE.PlaneGeometry(200, 180, 1, 90), applyBend(new THREE.MeshStandardMaterial({ color: '#4f7a3e' })));
grass.rotation.x = -Math.PI / 2; grass.position.set(0, -0.02, -75); scene.add(grass);
for (const x of [-1.3, 1.3]) {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 180, 1, 90), applyBend(new THREE.MeshBasicMaterial({ color: '#ffffff' })));
  m.rotation.x = -Math.PI / 2; m.position.set(x, 0.01, -75); scene.add(m);
}

const pool = new Map();
const mats = {
  monster: applyBend(new THREE.MeshStandardMaterial({ color: '#c0392b' })),
  barrier: applyBend(new THREE.MeshStandardMaterial({ color: '#f1c40f' })),
  train: applyBend(new THREE.MeshStandardMaterial({ color: '#dfe6ee', metalness: 0.3, roughness: 0.5 })),
  orb: applyBend(new THREE.MeshStandardMaterial({ color: '#ffce4d', emissive: '#8a5a00' })),
  power: applyBend(new THREE.MeshStandardMaterial({ color: '#4fd8ff', emissive: '#0a4a66' })),
};
const box = new THREE.BoxGeometry(1, 1, 1);
function sync(list, kind, sizeFn) {
  const seen = new Set();
  for (const e of list) {
    seen.add(e.id);
    let m = pool.get(e.id);
    if (!m) { m = new THREE.Mesh(box, mats[kind]); pool.set(e.id, m); scene.add(m); }
    const [w, h, l, y] = sizeFn(e);
    m.scale.set(w, h, l);
    m.position.set(e.x, y + h / 2, zOf(e.s + l / 2, sim.dist));
  }
  return seen;
}
const fox = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.75), applyBend(new THREE.MeshBasicMaterial({ transparent: true, alphaTest: 0.1 })));
const tex = getTexture('sprites/player_run');
if (tex) { tex.repeat.set(1 / 6, 1); fox.material.map = tex; fox.material.needsUpdate = true; }
scene.add(fox);
preload(['sprites/player_run']);

app.addTick((dt, t) => {
  sim.step(dt);
  const all = new Set([
    ...sync(sim.obstacles, 'monster', e => [e.w, e.h, e.len, 0]),
    ...sync(sim.trains, 'train', e => [e.w, e.h, e.len, 0]),
    ...sync(sim.orbs, 'orb', e => [0.6, 0.6, 0.12, e.y - 0.3]),
    ...sync(sim.powerups, 'power', e => [0.8, 0.8, 0.8, e.y - 0.4]),
  ]);
  for (const [id, m] of pool) if (!all.has(id)) { scene.remove(m); pool.delete(id); }
  if (tex) tex.offset.x = Math.floor(t * 12) % 6 / 6;
  fox.position.set(sim.player.x, sim.player.y + 0.875, 0);
  basicChaseCamera(camera, sim);
  sim.events.length = 0;
});
app.start();
