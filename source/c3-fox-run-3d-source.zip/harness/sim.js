// SIM harness — renders the REAL simulation (src/sim/sim.js) with plain boxes, played by the
// built-in bot, to eyeball spacing / readability in 3D at phone portrait.
//   python3 tools/shot.py --entry harness/sim.js --name sim --wait 5 --advance 2 --shots 3
//   --eval "__sim.devSetLevel(9)"   "__sim.devPower('boost')"   "__simGo(12)" (level 12 + 3 s)
// Colours: monster red, barrier yellow, parked truck grey (ramp orange), oncoming truck blue,
// coins by kind (xm gold, tab blue, watch green, tsheet purple), power-ups magenta.
import * as THREE from 'three';
import { createApp, basicChaseCamera } from '../src/core/app.js';
import { applyBend } from '../src/core/bend.js';
import { zOf, LANE_X, ROAD_HALF } from '../src/core/constants.js';
import { getTexture, preload } from '../src/core/assets.js';
import { THEMES, KINDS } from '../src/data/themes.js';
import { createSim } from '../src/sim/sim.js';

const app = createApp();
const { scene, camera } = app;
const params = new URLSearchParams(location.search);
const sim = createSim({ seed: +(params.get('seed') || 7), attract: params.has('attract') });
if (!params.has('attract')) { sim.autopilot = true; sim.start(); }
window.__sim = sim;
window.__simGo = (L) => { sim.devSetLevel(L); for (let i = 0; i < 180; i++) { sim.step(1 / 60, []); sim.events.length = 0; } };

scene.add(new THREE.HemisphereLight('#ffffff', '#445544', 1.7));
const sun = new THREE.DirectionalLight('#fff2d8', 1.8); sun.position.set(4, 10, 6); scene.add(sun);
scene.fog = new THREE.Fog('#9fc3e0', 60, 165);
scene.background = new THREE.Color('#9fc3e0');

const M = (c, e) => applyBend(new THREE.MeshStandardMaterial({ color: c, emissive: e || '#000000', roughness: 0.8 }));
const road = new THREE.Mesh(new THREE.PlaneGeometry(ROAD_HALF * 2, 200, 1, 100), M('#4a4f5a'));
road.rotation.x = -Math.PI / 2; road.position.z = -90; scene.add(road);
const grass = new THREE.Mesh(new THREE.PlaneGeometry(300, 200, 1, 100), M('#5a8a45'));
grass.rotation.x = -Math.PI / 2; grass.position.set(0, -0.03, -90); scene.add(grass);
const dashMat = M('#ffffff', '#555555'), dashGeo = new THREE.BoxGeometry(0.12, 0.02, 2.2);
const dashes = [];
for (const x of [-1.3, 1.3]) for (let i = 0; i < 40; i++) { const d = new THREE.Mesh(dashGeo, dashMat); d.position.set(x, 0.01, 0); scene.add(d); dashes.push(d); }

const mats = {
  monster: M('#d8342c', '#400000'), barrier: M('#f5c400', '#403000'), truck: M('#c9d0d8'), oncoming: M('#3d6fd6', '#0a1a40'),
  ramp: M('#f08a24'), power: M('#ff3fc8', '#601050'),
  xm: M(KINDS.xm.c, '#6a4a00'), tab: M(KINDS.tab.c, '#0a3a5a'), watch: M(KINDS.watch.c, '#0a4a2a'), tsheet: M(KINDS.tsheet.c, '#3a1a6a'),
};
const box = new THREE.BoxGeometry(1, 1, 1), coin = new THREE.CylinderGeometry(0.32, 0.32, 0.08, 16);
coin.rotateX(Math.PI / 2);
const pool = new Map(), live = new Set();
function mesh(id, geo, mat) {
  let m = pool.get(id);
  if (!m) { m = new THREE.Mesh(geo, mat); pool.set(id, m); scene.add(m); }
  m.material = mat; live.add(id); return m;
}
const fox = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 1.75), applyBend(new THREE.MeshBasicMaterial({ transparent: true, alphaTest: 0.1, color: '#ffffff' })));
const tex = getTexture('sprites/player_run');
if (tex) { tex.repeat.set(1 / 6, 1); fox.material.map = tex; fox.material.needsUpdate = true; } else fox.material.color.set('#2a6cff');
scene.add(fox);
preload(['sprites/player_run']);

const hud = document.createElement('div');
hud.style.cssText = 'position:fixed;left:8px;top:8px;font:13px/1.35 system-ui,sans-serif;color:#fff;text-shadow:0 1px 2px #000;z-index:9;white-space:pre';
document.body.appendChild(hud);
const evLog = [];

app.addTick((dt, t) => {
  sim.step(dt, []);
  for (const e of sim.events) if (e.type !== 'coin' && e.type !== 'combo') { evLog.push(e.type); if (evLog.length > 6) evLog.shift(); }
  sim.events.length = 0;
  live.clear();
  const d = sim.dist;
  for (const o of sim.obstacles) {
    const m = mesh(o.id, box, o.smashed ? mats.truck : mats[o.type]);
    m.scale.set(o.w, o.h, o.len); m.position.set(o.x, o.h / 2, zOf(o.s + o.len / 2, d)); m.rotation.set(0, 0, 0);
  }
  for (const tr of sim.trains) {
    const m = mesh(tr.id, box, tr.v < 0 ? mats.oncoming : mats.truck);
    m.scale.set(tr.w, tr.h, tr.len); m.position.set(tr.x, tr.h / 2, zOf(tr.s + tr.len / 2, d)); m.rotation.set(0, 0, 0);
    if (tr.ramp) {
      const r = mesh('r' + tr.id, box, mats.ramp), L = Math.hypot(tr.rampLen, tr.h);
      r.scale.set(tr.w, 0.18, L); r.rotation.set(Math.atan2(tr.h, tr.rampLen), 0, 0);
      r.position.set(tr.x, tr.h / 2, zOf(tr.s - tr.rampLen / 2, d));
    }
  }
  for (const o of sim.orbs) {
    const m = mesh(o.id, coin, mats[o.kind]);
    m.position.set(o.x, o.y, zOf(o.s, d)); m.rotation.set(0, t * 3 + o.id, 0);
  }
  for (const u of sim.powerups) {
    const m = mesh(u.id, box, mats.power);
    m.scale.set(0.8, 0.8, 0.8); m.position.set(u.x, u.y, zOf(u.s, d)); m.rotation.set(t, t * 1.3, 0);
  }
  for (const [id, m] of pool) if (!live.has(id)) { scene.remove(m); pool.delete(id); }
  for (let i = 0; i < dashes.length; i++) { const k = i % 40; dashes[i].position.z = -((k * 5 - (d % 5)) - 3); }
  if (tex) tex.offset.x = Math.floor(t * 12) % 6 / 6;
  fox.position.set(sim.player.x, sim.player.y + 0.875, 0);
  fox.rotation.z = -sim.player.lean * 0.15;
  const th = THEMES[sim.themeIdx];
  scene.background.set(th.skyB); scene.fog.color.set(th.skyB);
  basicChaseCamera(camera, sim);
  hud.textContent = `L${sim.level} ${th.name}  ${sim.baseSpeed.toFixed(1)} m/s  ${sim.mode}\n$${Math.round(sim.score)}  x${sim.combo}  shield ${sim.shield}  next lvl ${Math.round(sim.nextLevelAt - d)} m\n` +
    `power ${Object.entries(sim.power).filter(([, v]) => v > 0).map(([k, v]) => k + ' ' + v.toFixed(1)).join(' ')}\n${evLog.join(' ')}`;
});
app.start();
