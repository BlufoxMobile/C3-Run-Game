# ART.md — C³ FOX RUN 3D art log (ART agent)

All art generated with Higgsfield (MCP) and post-processed with Python/Pillow. Scripts: `scratch/art/prompts.py`, `scratch/art/art_sky_post.py`, `scratch/art/art_sprite_post.py`. Raw 2k downloads: `scratch/art/raw/`.

## Budget

| | credits |
|---|---|
| Balance before | 1750.43 |
| Balance after | 1717.18 |
| **Spent** | **33.25** (budget 55) |

| Item | Model / settings | Jobs | Credits |
|---|---|---|---|
| Sky test (02, medium vs high) | gpt_image_2_5, 21:9, 2k, quality medium (1.0) + high (2.75) | 2 | 3.75 |
| Skies 01,03–12 | gpt_image_2_5, 21:9, 2k, quality medium | 11 | 11.00 |
| Fox back-view poses, round 1 (2 jump + 2 boost) | seedream_v5_pro, 2k, remove_bg true, ref image | 4 | 10.00 |
| Fox boost, round 2 | seedream_v5_pro 2k remove_bg (2.5) + gpt_image_2_5 1k high transparent (1.5) | 2 | 4.00 |
| Power-up icons | gpt_image_2_5, 1:1, 1k, quality high, background transparent, orb ref image | 3 | 4.50 |
| **Total** | | 22 | **33.25** |

Quality note: at 2k, gpt_image_2_5 `medium` was visually indistinguishable from `high` for these painted skies (see `scratch/art/raw/t02_medium_view.jpg` vs `t02_high_view.jpg`), so the set was generated at medium (1 credit each). 02 uses the already-paid `high` render.

## 1. Sky panoramas — `assets/sky/*.webp`

2048×878 (21:9) WebP, RGB. Post: Lanczos resize from 2688×1152; the bottom of each image (from max(horizon+8%, 74%) down) is blended toward a 28-px Gaussian-blurred copy of itself (up to 85%) so everything under the horizon melts into soft haze for the fog; WebP q88 (12_the_loop q84) to stay under 200 KB. Designed to be sampled with mirrored-repeat horizontally (no big feature at the edges).

`assets/sky/sky.json` (not shipped by build.mjs — documentation for WORLD) lists per image: `horizon` (fraction from top where distant land meets sky, measured by eye), and colours sampled from the final file: `top` (top 8%), `horizon_sky` (4% band just above the horizon — a good fog/clear colour), `bottom_haze` (bottom 10%).

| File | Horizon | top | horizon_sky | bottom_haze | Bytes |
|---|---|---|---|---|---|
| `sky/01_smoky_dawn.webp` | 0.62 | `#092357` | `#91a2c4` | `#1d3e6d` | 45,692 |
| `sky/02_tennessee_sunrise.webp` | 0.57 | `#3f53a1` | `#ddaa86` | `#fbaa6e` | 59,006 |
| `sky/03_cumberland_plateau.webp` | 0.64 | `#1c84e0` | `#a7d8f1` | `#86bbe8` | 77,288 |
| `sky/04_kentucky_bluegrass.webp` | 0.60 | `#2693ed` | `#b0defa` | `#dbf2fc` | 60,076 |
| `sky/05_louisville_haze.webp` | 0.67 | `#4d88be` | `#c8b898` | `#bca88e` | 53,776 |
| `sky/06_ohio_river.webp` | 0.67 | `#1f8ae5` | `#c9eafa` | `#5cb2ec` | 96,152 |
| `sky/07_indiana_corn.webp` | 0.70 | `#478fd0` | `#f7d388` | `#b2a374` | 66,730 |
| `sky/08_hoosier_dusk.webp` | 0.65 | `#273177` | `#ec836c` | `#574380` | 55,650 |
| `sky/09_gary_steel.webp` | 0.68 | `#0d183b` | `#a23e37` | `#5a2f42` | 78,860 |
| `sky/10_lakeshore.webp` | 0.63 | `#00164b` | `#5d73bd` | `#04256b` | 59,358 |
| `sky/11_chicago_skyline.webp` | 0.65 | `#010b31` | `#745473` | `#1c255f` | 128,670 |
| `sky/12_the_loop.webp` | 0.88 | `#02092d` | `#c2826b` | `#d58f75` | 172,688 |

Notes: 02's ridge line sits a little high (~0.57). 12_the_loop is a wall of lit skyscraper tops whose bases sit at ~0.88 — at the usual 0.63 horizon mapping the towers' upper halves rise above the ground line, which is the intended "downtown" look. 06 shows the river running toward the camera below the horizon (softened by the haze blend).

Contact sheets: `scratch/art/art_sky_contact.jpg` (2×6 grid, red ticks = horizon) and `scratch/art/art_sky_strip.jpg` (all 12 in route order, reads as one continuous dawn→night drive).

### Shared style prefix (all 12)

Test render (02) used this prefix with "about 63% of the way down"; the batch of 11 used:

```
Ultra-wide 21:9 panoramic painted sky backdrop for a stylised 3D mobile endless-runner game. Polished mobile-game key-art matte painting, Pixar / Subway Surfers environment-art style: smooth painterly gradients, clean simplified stylised shapes, vibrant saturated colour, soft volumetric light, gentle atmospheric perspective, fluffy stylised clouds. COMPOSITION: the horizon line sits about 64% of the way down from the top of the image (sky fills the upper two-thirds); the upper 60% is open sky; distant landforms form only a low soft silhouette band sitting on the horizon; below the horizon there is only far-distant land dissolving into a flat soft haze of the horizon colour with almost no detail. Keep the far left and far right edges calm and similar (no big landmark, no sun at the edges) so the image can be mirrored and tiled. Absolutely no road, no highway, no foreground objects, no trees in front, no vehicles, no people, no animals, no text, no letters, no logos, no signs, no watermark, no border. Scene: <scene>
```

### Per-stage scene text

- **01_smoky_dawn** (job a2002c32): the Great Smoky Mountains of east Tennessee before sunrise. Pre-dawn sky graded from deep indigo navy (#101a42) at the top through slate blue (#31456f) to pale misty blue-grey (#93a6bd) at the horizon, a few faint stars still visible at the very top, thin wispy blue-grey clouds (#a8bccf). Many layered overlapping blue mountain ridges receding into the distance (#3b5375 far, #2b3f58 nearer), thick white mist pooled in the valleys between the ridges, cool calm quiet mood, the first faint pale glow near the horizon in the centre.
- **02_tennessee_sunrise** (job fd3fcedc (high) — medium test 4edbbee3 discarded): sunrise over the Tennessee foothills. Sky graded from periwinkle indigo (#39498a) at the top through warm orange (#d4794a) to glowing peach-gold (#ffd7a2) at the horizon; a bright pale-yellow sun (#fff0c8) just rising above the hills, slightly right of centre, soft god-rays fanning upward; peach and apricot lit clouds (#ffd9b4). Soft layered lavender ridges (#6b6a9c) behind gentle mauve rolling foothills (#8c6b78) with golden morning mist in the hollows. Warm, hopeful, start-of-a-road-trip mood.
- **03_cumberland_plateau** (job c57e35f8): bright mid-morning over the Cumberland Plateau of Tennessee. Clear saturated sky graded from strong blue (#1273c8) at the top through sky blue (#57a8e2) to pale hazy blue (#c8e2f0) at the horizon; big fluffy white cumulus clouds; the high sun out of frame above. Long flat-topped plateau escarpments and mesas with forested edges on the horizon in soft blue-grey-green (#93a8ae far, #7b9077 nearer), slight heat shimmer. Crisp, open, high-country feeling.
- **04_kentucky_bluegrass** (job 10347f23): a perfect sunny day in Kentucky horse country. Sky graded from vivid blue (#2a92e0) through light sky blue (#6cc3ef) to almost-white blue (#ddf1ff) at the horizon, puffy white cumulus clouds. Soft rolling emerald-green bluegrass hills on the horizon (#5f9e78, far hills bluish #7fb0cc), tiny distant white horse-farm fences tracing the hills and a couple of tiny far-away barns and trees, all very small and soft. Cheerful, lush, pastoral.
- **05_louisville_haze** (job 7f981324): a warm hazy late-morning over the Ohio Valley at Louisville, Kentucky. Sky graded from soft blue (#3f7fb8) through grey-blue (#8fb2c8) to warm creamy tan haze (#e3cfa8) at the horizon, soft cream clouds (#e8dcc4). Far away in the centre, a small hazy blue-grey (#8a94a0) river-city skyline of modest towers on the far bank of the Ohio River, half dissolved in warm haze, with soft green hills (#6f8574) either side. Warm, humid, sleepy atmosphere.
- **06_ohio_river** (job 2093a423): a bright clear day over the wide Ohio River valley. Sky graded from rich blue (#1f86d6) through sky blue (#63b8ea) to pale blue (#d2e8f4) at the horizon, white fluffy clouds. A broad calm river glittering with sunlight winds through the distance between soft wooded bluffs and ridges (#87b6cf far, #6f9fbe nearer, green #3d7f55), a tiny far-away steel truss bridge silhouette spanning the river near the centre. Fresh, breezy, crossing-the-river feeling.
- **07_indiana_corn** (job df03e91c): golden late-afternoon light over flat Indiana farmland. Sky graded from clear blue (#3f8fd0) through pale blue (#a3c8e2) to warm golden cream (#ffe6b8) at the horizon, a low warm sun (#fff0c0) left of centre with soft light rays, golden-lit clouds (#ffe8c8). Perfectly flat endless farmland on the horizon, far rows of corn fading into golden haze (#c3bb90, #a8a862), a few tiny distant grain silos, red barns and a tree line. Big-sky Midwest feeling.
- **08_hoosier_dusk** (job 2c6c98b7): dusk over the flat plains of northern Indiana. Sky graded from deep indigo (#2a2f68) at the top through dusty violet (#7a5a8e) to warm orange (#f0a172) at the horizon, first stars appearing at the top, pink-magenta lit clouds (#c8869a), the sun a soft glowing disc (#ffd7a0) just touching the flat horizon near the centre. A long row of tall slender white wind turbines far away on the flat horizon, silhouetted in purple (#4a4272), soft purple haze below. Calm, magical, end-of-day mood.
- **09_gary_steel** (job 9b46321f): a dramatic red sunset over the steel mills of Gary, Indiana on the lake plain. Sky graded from dark navy (#151a3c) at the top through dusky plum (#3b3050) to rusty red-orange (#8a5a52) glowing at the horizon, a few stars at the top, smoky clouds lit red from below. Along the horizon, far-away silhouettes of steel mills, blast furnaces, gantries and tall smokestacks (#2f2a48) with billowing smoke plumes lit orange, a few warm sodium-orange lights twinkling on the industrial structures. Gritty but beautiful industrial mood.
- **10_lakeshore** (job a676b67b): blue hour over Lake Michigan. Sky graded from deep navy (#0d1638) through twilight blue (#263c70) to soft periwinkle (#7386ac) at the horizon, stars and a bright crescent moon high in the sky, soft blue-grey clouds (#5a6f96). A vast calm lake stretches to the horizon, and far across the water, small and centred, the Chicago city skyline in dark blue silhouette (#1d2c52) with tiny twinkling warm window lights reflected as long shimmering streaks on the still water. Serene, cool, anticipation of arriving in the city.
- **11_chicago_skyline** (job fc3d0f9e): night over the Chicago skyline. Sky graded from near-black navy (#060c22) through deep blue (#141d44) to dusky violet-blue (#333a66) at the horizon glow, many stars and a bright moon, faint thin clouds lit by the city. The full Chicago skyline spreads across the centre of the horizon: tall dark-blue skyscrapers (#101836) with thousands of warm yellow and cool white lit windows, one very tall black tower with twin antennas, red aircraft warning lights, a warm city glow rising behind the towers; the skyline gets lower toward both edges. Exciting, glittering, big-city night.
- **12_the_loop** (job 1d2fb913): deep night in downtown Chicago looking up between skyscrapers. Sky graded from almost-black navy (#04081c) through deep blue (#0e1432) to glowing indigo (#20264c) near the horizon, a few stars, a warm amber city-light glow rising from the streets below. Tall stylised skyscraper tops and art-deco towers rise up from the horizon across the whole width, covered in glowing warm and cool windows, lit crowns and spires, blinking red aircraft lights, faint searchlight beams; the lower part dissolves into warm glowing haze. Electric, energetic, the finish line of the road trip.

## 2. Fox back-view poses — `assets/sprites/fox_jump_back.webp`, `fox_boost_back.webp`

Reference image uploaded to Higgsfield (media 41e5ec6f…): `scratch/art/ref_fox.png` = player_run frame 3 (back view, largest connected component only) beside the existing front-view player_jump, on light grey.

**fox_jump_back** — seedream_v5_pro, 2k, 3:4, remove_bg true, job 1eeae1e8 (variant a; variant b a54f183c was also good, kept in raw/ as `jump_b.png`). Prompt:

> Use the exact character from the reference image: the same blue anthropomorphic fox with fluffy royal-blue fur and tall pointed ears, a royal-blue hoodie with thin gold piping, black jogger pants with a gold side stripe, white-and-gold sneakers, and a big fluffy blue tail with a white tip. Same glossy Pixar-style 3D animated-movie render, same fur, fabric and lighting. NEW POSE, seen directly FROM BEHIND like the back view on the left of the reference (we see his back, the hood, the back of his head and ears; no face visible): he is in the middle of a big joyful jump high in the air, knees tucked up, both arms thrown up and out to the sides, fists clenched, the fluffy tail swinging up and flowing behind him. Full body in frame, centred, one single character only, plain light grey studio background, no ground, no shadow, no text.

Variant b prompt: *The same blue fox character from the reference image (…), identical glossy Pixar-style 3D render. Back view: camera directly behind him, we only see his back and the back of his head. He is airborne in a dynamic leap, knees pulled up toward his chest, arms raised high in a V with fists up, tail flicking upward. Full body, single character, centred, plain light grey background, no floor, no text.*

**fox_boost_back** — gpt_image_2_5, 1k, 3:4, quality high, background transparent, same reference, job c74a1d91. Rejected: seedream boost a/b (3364df42, fe559768 — flying diagonally sideways, not away from camera) and seedream d (d14dbc26 — right pose but remove_bg ate the cyan jets, leaving dark smudges). Chosen prompt:

> Render the exact same character as the reference image (blue anthropomorphic fox with fluffy royal-blue fur and tall pointed ears, royal-blue hoodie with thin gold piping, black jogger pants with a gold side stripe, white-and-gold sneakers, big fluffy blue tail with a white tip) in the same glossy Pixar-style 3D animated-film render with fluffy fur detail. New pose, seen from DIRECTLY BEHIND and slightly above, like a chase camera following him: he is flying straight away from the camera into the distance, superhero style, centred and nearly symmetrical, with strong perspective foreshortening. Both arms stretched straight forward past his head (fists farthest away, at the top), the back of his head and ears above his shoulders, his back and hood in the middle, legs stretched straight back toward the camera so the soles of both sneakers are nearest to us at the bottom, bright glowing cyan energy jets and sparks blasting from both sneaker soles toward the camera, fluffy tail streaming back. Full body, single character, fully transparent background, no ground, no shadow, no text.

Round-1 boost prompts (rejected) are in the job history; they asked for "flying forward away from the camera like a superhero, body stretched out almost horizontal … cyan energy jets from the soles" from behind-and-above / three-quarter rear.

Post: alpha < 8 zeroed, trimmed, resized to 512 px tall, WebP q88 alpha_quality 100. The boost jets were cut by the frame bottom, so alpha is smooth-stepped to 0 over the bottom 9.5% (jets now dissipate). **unitsHigh** was set so the fox matches player_run's pixel-per-metre scale (player_run: 512 px = 2.4 m), measured from hoodie width / head / torso length: jump raw ≈ 4.05× run px → 2.10 m; boost ≈ 2.03× (hoodie width; head is foreshortened) → 2.55 m. Scale check: `scratch/art/art_fox_scale_check.jpg` (run, jump_back, boost_back, old player_jump side by side, anchors on the red ground line).

Manifest entries ADDED (existing entries untouched):

```json
{
 "fox_jump_back": {
  "src": "fox_jump_back.webp",
  "w": 407,
  "h": 512,
  "ax": 0.49,
  "ay": 1.0,
  "frames": 1,
  "fps": 0,
  "unitsHigh": 2.1,
  "anchor": "feet",
  "aspect": 0.7949,
  "trimmedW": 1442,
  "trimmedH": 1814,
  "bytes": {
   "webp": 44834
  }
 },
 "fox_boost_back": {
  "src": "fox_boost_back.webp",
  "w": 306,
  "h": 512,
  "ax": 0.52,
  "ay": 0.8,
  "frames": 1,
  "fps": 0,
  "unitsHigh": 2.55,
  "anchor": "feet",
  "aspect": 0.5977,
  "trimmedW": 661,
  "trimmedH": 1106,
  "bytes": {
   "webp": 49668
  },
  "note": "ay=0.80 is the sneaker soles; the cyan jets hang below the anchor"
 }
}
```

`fox_boost_back.ay = 0.80` is the sneaker soles (the anchor); the cyan jets hang below it (use ay 1.0 if you want the jet tips at the fox's y instead). Consider additive/bloom on the jets — they are the brightest pixels.

## 3. Power-up icons — `assets/ui/pow_*.webp`

gpt_image_2_5, 1:1, 1k, quality high, background transparent, reference = `scratch/art/orbs_view.png` (the four existing orb_*.webp on slate, media 774dd58d…) for the glossy gem-glass style. Post: alpha < 8 zeroed, trimmed, centred on a 320×320 transparent canvas (object fills 92%), WebP q90. Check on dark + light: `scratch/art/art_icons_check.jpg`.

- **pow_magnet** (job 5aabd109): A single glossy 3D power-up icon for a mobile endless-runner game: a classic horseshoe (U-shaped) magnet with a glossy candy-apple-red body and shiny polished silver tips, tilted in a dynamic three-quarter view, a few small white star-sparkle glints and two subtle curved glowing attraction arcs near the tips. Render it in exactly the same polished style as the reference coins: glossy gem-like glass and lacquer highlights, rich saturated colour, bright rim light, soft inner glow, crisp clean edges. One isolated object, centred, filling most of the frame, fully transparent background, no text, no letters, no ground shadow, no coin behind it.
- **pow_x2** (job df5a7e86): A single glossy 3D power-up icon for a mobile endless-runner game: a thick shiny gold coin badge in exactly the same faceted gem-glass gold style as the gold coin in the reference image, tilted slightly in a three-quarter view, with big bold chunky raised embossed characters "2X" on its face (the digit 2 followed by the letter X), glossy bright gold with a darker gold bevel and a white specular highlight, a few radiating white star-sparkle glints around the rim. The only text is exactly 2X. One isolated object, centred, filling most of the frame, fully transparent background, no ground shadow. — *Rendered cleanly as "2x" (lower-case x); reads correctly.*
- **pow_boost** (job 1389051d): A single glossy 3D power-up icon for a mobile endless-runner game: a white-and-cyan high-top sneaker seen from the side in a dynamic three-quarter angle, a bold glowing cyan lightning-bolt emblem on its side, a jet of bright cyan rocket energy flame and sparks blasting out of the heel as if it is launching forward, small swept-back wings of cyan light. Render it in exactly the same polished style and saturation as the reference coins: glossy gem-like highlights, bright rim light, soft cyan inner glow, crisp clean edges. One isolated object, centred, filling most of the frame, fully transparent background, no text, no letters, no ground shadow.

## Final file list

| File | Size (bytes) | Dimensions |
|---|---|---|
| `assets/sky/01_smoky_dawn.webp` | 45,692 | 2048×878 RGB |
| `assets/sky/02_tennessee_sunrise.webp` | 59,006 | 2048×878 RGB |
| `assets/sky/03_cumberland_plateau.webp` | 77,288 | 2048×878 RGB |
| `assets/sky/04_kentucky_bluegrass.webp` | 60,076 | 2048×878 RGB |
| `assets/sky/05_louisville_haze.webp` | 53,776 | 2048×878 RGB |
| `assets/sky/06_ohio_river.webp` | 96,152 | 2048×878 RGB |
| `assets/sky/07_indiana_corn.webp` | 66,730 | 2048×878 RGB |
| `assets/sky/08_hoosier_dusk.webp` | 55,650 | 2048×878 RGB |
| `assets/sky/09_gary_steel.webp` | 78,860 | 2048×878 RGB |
| `assets/sky/10_lakeshore.webp` | 59,358 | 2048×878 RGB |
| `assets/sky/11_chicago_skyline.webp` | 128,670 | 2048×878 RGB |
| `assets/sky/12_the_loop.webp` | 172,688 | 2048×878 RGB |
| `assets/sky/sky.json` | 2,541 | — |
| `assets/sprites/fox_boost_back.webp` | 49,668 | 306×512 RGBA |
| `assets/sprites/fox_jump_back.webp` | 44,834 | 407×512 RGBA |
| `assets/ui/pow_boost.webp` | 31,264 | 320×320 RGBA |
| `assets/ui/pow_magnet.webp` | 31,098 | 320×320 RGBA |
| `assets/ui/pow_x2.webp` | 34,580 | 320×320 RGBA |

(`assets/sprites/manifest.json` — two entries added: `fox_jump_back`, `fox_boost_back`.)

## Observations for other agents

- `player_run.webp` frames are not cleanly separated: cropping at the manifest's 321-px frame width leaves thin slivers of the neighbouring frame (e.g. a small white tail-tip triangle at the left edge of frame 3). ACTORS may want to inset the UVs by a few px or drop tiny alpha islands.

- The hero's outfit accents are **gold** (hoodie piping, jogger side stripe, sneaker trim), not white; the new sprites match that.
