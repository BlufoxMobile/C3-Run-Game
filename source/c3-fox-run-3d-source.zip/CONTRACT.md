# C³ FOX RUN 3D — build contract

This is the single source of truth every agent builds against. Read ALL of it before
writing code. If something you need is not here, make the smallest sensible assumption,
document it at the top of your module, and list it in your final report.

## 0. The product

C³ FOX RUN is Jeff Bilbrey's (Regional Sales Director, **Blufox Mobile** — always spelled
*Blufox*, never "Bluefox") break-room arcade game for his retail sales reps. It is being
rebuilt from a 2D canvas pseudo-3D runner into a **true 3D, AAA-feeling, Subway-Surfers-style
endless runner** on three.js, played mostly on **phones in portrait**, also on desktop.

His brief, verbatim where it matters:
* "AAA style subway surfers type game that is fun, entertaining, and still difficult to keep people coming back."
* "hypermotion graphics and animations" — "I would love for the graphics to get souped up."
* "I think it's difficult enough" — keep the difficulty, add fun.
* The level name used to take over the main portion of the screen and got players killed.
  **Nothing may ever cover the running corridor.** Level changes are announced in-world
  (an overhead highway gantry sign you run under) plus a slim toast at the top edge.
* On death: "I just want the option to enter your name on the scoreboard (which should show the top 5 people) or retry."
* Moves stay **left / right / jump only** (no slide). New: **power-ups** (Magnet, 2X Cash, Gig Boost)
  and **running on top of trucks/trains** via ramps.

The story (keep it): the run is a ROAD TRIP north from the east-Tennessee Smokies to downtown
Chicago through the three states his stores are in (TN, IN, IL) — 12 stages, dawn to night
(`src/data/themes.js`). The enemies are "commission killers" — monsters named EXCEPTION,
FALL-OFF, CHARGE BACK, NON-USAGE, RETAIL 360. Score is **COMMISSION** in dollars. Pickups are
devices (XM phone = gold, TABLET = blue, WATCH = green) and **T-SHEETS** (purple: +1 shield,
every 5 = +$100). The hero is a blue fox in a blue hoodie (sprites in `assets/sprites/`).

Visual target: a polished mobile runner — bright, saturated, readable, bloom-kissed, with
constant motion: camera that leans and punches, speed streaks, sparkles, trails, squash and
stretch, sky and light that change as you drive north. Painted sprite characters (the fox
and monsters are pre-rendered Pixar-style art) living in a real 3D world ("HD-2D" feel).

## 1. Repository layout and ownership

```
build.mjs            (orchestrator)  node build.mjs <entry> <out.html> [--dev]
tools/shot.py        (orchestrator)  build + headless screenshot (see §8)
src/shell.html       (UI agent may edit; keep <!--CSS--> and <!--JS--> markers, #gl and #ui)
src/main.js          (orchestrator)  final wiring — written at integration
src/core/*           (orchestrator, READ-ONLY for agents) constants, bend, assets, app
src/data/themes.js   (orchestrator, READ-ONLY) THEMES, TIERS, MONSTERS, KINDS, POWERUPS
src/dev/fakeSim.js   (orchestrator, READ-ONLY) scripted sim with the real state shape
src/vendor/lb*.js    (READ-ONLY) the live leaderboard client
src/sim/**           SIM agent
src/render/world*    WORLD agent   (world.js entry; world-*.js helpers)
src/render/actors*   ACTORS agent  (actors.js entry; actors-*.js helpers)
src/render/fx*, camera.js, post.js, feel.js, quality.js    FX agent
src/ui/**            UI agent (ui.js, input.js, style.css, ...)
src/audio/**         AUDIO agent
assets/sprites/*     existing art (manifest.json has frames/anchors); ART agent may ADD files
assets/sky/*, assets/ui/*, assets/fx/*    ART agent
harness/<you>*.js    your test entries      scratch/<you>*/  your scratch output
```
**Only write files you own.** Never edit another agent's files or the orchestrator's files —
if you need a change there, work around it locally and describe the change in your report.
Other agents are working in this same directory at the same time. Name every scratch file
and harness with your agent prefix. Never write to `dist/`.

Imports: `import * as THREE from 'three'` (three r186, bundled by esbuild — tree-shaken, so
import only what you use from addons, e.g. `three/examples/jsm/...` is available but think
about size). No other npm packages. No network requests except the leaderboard (UI agent).
No external fonts/CDNs — the page must work offline once loaded (system font stacks only).

## 2. World conventions (src/core/constants.js, src/core/bend.js)

* Metres. +Y up, ground y = 0. The fox runs toward **-Z** and its feet are always at **z = 0**
  in render space. Track distance `s` → render `z = -(s - sim.dist)` (`zOf(s, dist)`).
  Everything is positioned relative to the player every frame; never use absolute world z.
* Lanes: `LANE_X = [-2.6, 0, 2.6]`, asphalt half width `ROAD_HALF = 4.3`, then a 1.4 m shoulder.
* Draw distance: `VIEW_AHEAD = 150` m. Fog must hide the far edge.
* **Curved world.** Every material in the 3D scene goes through `applyBend(material)` (or
  includes `BEND_GLSL_PARS` / `BEND_GLSL_APPLY` in a custom shader — operates on `mvPosition`).
  The road falls away over the horizon and sweeps left/right. `BEND.uniforms` are shared;
  `BEND.update()` is called by the core loop. `projectBent(worldPos, camera, w, h)` is the CPU
  mirror (for pinning DOM text to 3D points). The sky dome is the only unbent thing.
* **No shadow maps** (they would bend differently). Use blob shadows / baked darkening.
* Colour: renderer outputs sRGB, ACES tone mapping by default. Textures from `getTexture()`
  are already sRGB. Keep HDR emissive values sane (bloom threshold is in §6.4).

## 3. The simulation state (SIM agent produces it; everyone else reads it, never writes)

`src/dev/fakeSim.js` produces this exact shape with scripted content — build against it.

```js
sim.mode        'ready' | 'play' | 'dying' | 'over'
sim.time        sim seconds since reset;   sim.runTime  seconds in 'play'
sim.dist        metres travelled = the player's track position s
sim.speed       current forward speed m/s (includes boost);  sim.baseSpeed
sim.level (1..)  sim.lap (1..)  sim.themeIdx (0..11)  sim.theme (THEMES[themeIdx])
sim.levelStart  s where this level began;  sim.nextLevelAt  s where the next level begins
sim.levelProgress 0..1;  sim.nextThemeIdx
sim.score       COMMISSION $ (float);  sim.combo 1..9;  sim.comboTimer;  sim.bestCombo
sim.tsheets     count collected;  sim.shield 0..3
sim.power       { magnet, x2, boost }  seconds left (0 = off);  sim.powerMax {magnet:10,x2:12,boost:5}
sim.invuln      seconds of post-hit / post-boost invulnerability
sim.player = {
  lane 0|1|2 (target), fromLane, laneT 0..1 (lane tween progress, 1 = settled),
  x  current lateral metres (includes the ease-out-back overshoot),
  y  feet height above ground (0 on the road; ~3.1 on a truck roof; ~4.8 in boost flight),
  vy, grounded (on road OR roof), onRoof (train id | null), surfaceY (height under the player),
  anim 'idle'|'run'|'jump'|'fall'|'land'|'stumble'|'hit'|'boost',  animT seconds in anim,
  lean -1..1 (eased lane-change lean),  stumbleT seconds left of a stumble
}
sim.obstacles[] { id, type:'monster'|'barrier', kind (monster name | 'barrier'), lane, x, s,
                  w, h, len (metres), drift:null|{from,to,t,dur}, hit, smashed, near, gateRow? }
sim.trains[]    { id, kind:'semi'|'box'|'bus', lane, x, s (NEAR end, the end facing the fox), len,
                  h (roof height), w, v (own speed m/s along +s; <0 = oncoming), ramp (bool),
                  rampLen (ramp occupies s-rampLen .. s, rising 0 -> h), livery (int), lights (bool) }
sim.orbs[]      { id, kind:'xm'|'tab'|'watch'|'tsheet', lane, x, s, y (centre height), got, magnet }
sim.powerups[]  { id, kind:'magnet'|'x2'|'boost', lane, x, s, y, got }
sim.events[]    appended during step(); main loop dispatches then clears (sim.events.length = 0)
sim.killer      { type:'monster'|'barrier'|'train', kind } once dead
sim.stats       { orbs, nearMisses, hops, smashed, distance, maxCombo }
```
Entities are removed from their arrays once collected or `VIEW_BEHIND` metres behind the fox.
Every entity keeps its `id` for life — renderers sync pooled meshes by id.

**Events** (`sim.events`, each `{type, ...}`):
`start` · `lane {dir, lane}` · `bump {dir, x, s}` (side-hit a truck, bounced back) · `jump {x,y}` ·
`land {x, y, onRoof, impact}` · `ramp {trainId}` · `roof {trainId}` · `drop` ·
`coin {kind, value, combo, x, y, s}` · `tsheet {count, shield, x, y, s}` · `bonus {amount, x, y, s}` ·
`combo {combo}` (milestones 3/6/9) · `comboLost` · `nearMiss {bonus, x, side, s}` · `hop {x, s}` ·
`shieldBreak {x, y, s, id}` · `smash {id, kind, x, y, s}` · `powerup {kind, x, y, s}` ·
`powerWarn {kind}` (2 s left) · `powerEnd {kind}` · `boostStart` · `boostEnd` ·
`levelUp {level, themeIdx, lap, name, region, tier}` · `trainPass {id, side}` (oncoming truck
whooshes past in an adjacent lane) · `hit {kind, x, y, s}` (fatal) · `death` (mode -> 'over').

## 4. Game rules (SIM agent implements; others need to know)

* Input actions per step: array of `'left' | 'right' | 'jump'`. Lane change is a fixed 110 ms
  ease-out-back tween with a 160 ms input buffer; jump has 100 ms coyote time and a 180 ms buffer.
* Jump apex ≈ 1.5 m, airtime ≈ 0.55–0.62 s; clears a 1.0 m barrier.
* **Monsters** are tall: dodge by changing lane. **Barriers** are low: jump them (`hop`).
* **Trucks** (kind semi 16–24 m, box 9–12 m, bus 12–14 m in city stages): roof ≈ 3.1 m.
  Parked trucks may have a **ramp** at the near end — run up it onto the roof. Roofs are
  coin highways; lane-change across to adjacent roofs; run off the end and drop.
  Hitting a truck's front face below roof height is fatal. Side-swiping into a truck's lane
  bounces you back (`bump`, combo lost, 0.6 s stumble); a second bump while stumbling is fatal.
  **Oncoming** trucks (v < 0, headlights on, never with ramps) appear from level 3.
* **Shield** (T-sheets, max 3) absorbs one fatal hit (`shieldBreak`, the obstacle is `smash`ed,
  0.9 s invuln). 5 T-sheets = +$100 `bonus`.
* **Power-ups**: MAGNET 10 s (all orbs within ~30 m fly to the fox), 2X CASH 12 s (all commission
  x2), GIG BOOST 5 s (the fox rockets up to ~4.8 m and flies at ~1.55x speed over everything
  along a dense coin river, lane changes still work; then descends with 1 s invuln).
* Score: passive commission per second, orbs `KINDS.val × combo × (1 + (level-1)×0.15)` (x2 when
  active), combo up to x9 with a 1.6 s window, NEAR MISS bonus, +$100 per 5 T-sheets. The
  economy should stay close to the 2D build so the shared leaderboard stays comparable.
* Levels: 12 themes, each level ≈ 24–30 s; level N+1 is `THEMES[(N) % 12]`; after 12 → lap 2.
  `sim.nextLevelAt` is known ahead of time so the world can place the gantry sign there.
* Difficulty: keep it hard. Speed ~15 m/s at L1 rising to a cap near 30 m/s; obstacle rows get
  denser; from ~L10 complexity (drifting monsters, double gates, truck mazes) keeps escalating.
  Every row must be solvable (the SIM agent proves it with a bot).
* `mode 'ready'` = attract mode behind the title screen: an AI plays forever (never dies).

## 5. Module APIs (exact). `ctx` is passed to every create function:

```js
ctx = { THREE, app, scene, camera, renderer,           // from createApp()
        BEND, applyBend, projectBent,                    // src/core/bend.js
        C,                                               // src/core/constants.js namespace
        THEMES, KINDS, POWERUPS, MONSTERS, MONSTER_LABEL,// src/data/themes.js
        assets: { getTexture, getImage, preload, hasAsset, SPRITE_META },   // src/core/assets.js
        tier: 'high' | 'med' | 'low' }
frame = { time, dt, realDt, camera, width, height, tier }
```
* **SIM** `src/sim/sim.js`: `export function createSim({seed, attract}) → sim` with
  `sim.reset(seed)`, `sim.start()`, `sim.step(dt, actions)`, `sim.setAttract(bool)`,
  `sim.devGod` (bool), `sim.devSetLevel(n)`; `export const TUNE`. Pure JS, no three.js, no DOM.
* **WORLD** `src/render/world.js`: `export function createWorld(ctx) → { update(sim, frame), onEvent(ev, sim), setQuality(tier), setTheme(idx, instant) }`
  Owns: sky, fog, lights, road/ground/shoulders, roadside props & buildings, gantries
  (incl. the level-sign gantry at `sim.nextLevelAt`), theme crossfades, ambient life
  (birds, traffic on side roads, L-train overhead in Chicago...). Exposes `world.sunDir`
  (THREE.Vector3) and `world.fogColor` (THREE.Color) for others.
* **ACTORS** `src/render/actors.js`: `export function createActors(ctx) → { update(sim, frame), onEvent(ev, sim), setQuality(tier) }`
  Owns: the fox (all anims, lean, squash/stretch, blob shadow, afterimage trail, shield
  bubble, boost look), monsters, barriers, trucks (+ramps, liveries, headlights), orbs
  (spinning 3D collectibles), power-up pickups. Syncs pooled meshes by entity id.
* **FX** `src/render/fx.js`: `export function createFX(ctx) → { update(sim, frame), onEvent(ev, sim), setQuality(tier) }`
  particles (pickup bursts, rings, sparkles, dust, confetti, smash debris, speed streaks, boost warp).
  `src/render/camera.js`: `export function createCameraDirector(ctx) → { update(sim, frame), onEvent(ev, sim) }`
  `src/render/feel.js`: `export function createFeel() → { onEvent(ev, sim), timeScale(realDt) → simDt }` (hit-stop, slow-mo).
  `src/render/post.js`: `export function createPost(ctx) → { render(frame), setSize(w, h, dpr), setQuality(tier), pulse(name, amount) }`
  `src/render/quality.js`: `export function createQuality(ctx) → { tier, dprCap, sample(frameMs), onChange(fn) }`
* **UI** `src/ui/ui.js`: `export function createUI(ctx & { root, LB, camera }) →`
  `{ setLoading(p, label), showTitle(), showHUD(), updateHUD(sim, frame), onEvent(ev, sim),`
  `  floatAt(text, worldPos: THREE.Vector3, style), showPause(b), showGameOver(summary), hideAll(),`
  `  on(name, fn) }` — emitted names: `'play'`, `'retry'`, `'pause'`, `'resume'`, `'mute'(bool)`.
  `summary = { score, level, themeName, tier, killer, bestCombo, orbs, distance, runSeconds }`
  `src/ui/input.js`: `export function createInput(el) → { poll() → actions[], enabled, onAny(fn) }`
* **AUDIO** `src/audio/audio.js`: `export function createAudio() →`
  `{ unlock(), onEvent(ev, sim), update(sim, frame), setMuted(b), muted, setPaused(b), toTitle(), toRun(), toGameOver() }`

### Main loop order (src/main.js, orchestrator)
```
realDt → simDt = feel.timeScale(realDt)
actions = input.poll();  sim.step(simDt, actions)   (also in 'ready' attract mode)
for ev of sim.events: world, actors, fx, camera, feel, audio, ui  .onEvent(ev, sim)
world.update · actors.update · fx.update · camera.update · ui.updateHUD · audio.update
sim.events.length = 0
post.render(frame)          quality.sample(ms) → setQuality(tier) on everyone + app.setDprCap
```
Flow: boot → loading bar (critical sprites) → TITLE (attract mode running behind it, top-5 board,
PLAY) → run → death (slow-mo, ~1 s) → GAME OVER (score, name + POST, top 5, RETRY) → run.
Pause on the pause button and on `visibilitychange`.

## 6. Quality bar and budgets

1. Portrait phone first (390×844 CSS px, DPR 2–3) and it must also look right at 844×390
   landscape and 1440×900 desktop.
2. Frame budget: 60 fps on a mid-range phone. Draw calls ≤ 150 (high) / ≤ 90 (low). Pool and
   instance; zero per-frame allocations in hot paths (no `new Vector3()` per frame per entity).
3. Tiers: `high` (DPR ≤ 2, full post), `med` (DPR ≤ 1.5, cheaper post), `low` (DPR ≤ 1.25, no post
   passes, fewer particles/props). Every module honours `setQuality`.
4. Bloom threshold is high: only emissive highlights (coins, headlights, neon, power-ups,
   sparkles) should bloom — keep diffuse albedo ≤ 1.0 so daylight scenes don't wash out.
5. Readability beats spectacle: obstacles must be instantly readable against every theme,
   at a distance, in portrait. The running corridor (the 3 lanes from the fox to ~60 m ahead)
   is never covered by UI or opaque effects.
6. `prefers-reduced-motion`: camera roll/shake/FOV kicks off, particles reduced.

## 7. Assets (src/core/assets.js)

`getTexture(key)` returns a THREE.Texture immediately (image fills in async; returns null if
the key does not exist — always handle null with a fallback). Keys are paths under `assets/`
without extension. Existing: `sprites/player_run` (6-frame strip, fox from BEHIND),
`sprites/player_jump` (1 frame, FRONT view arms up — the ART agent is making a back-view
replacement `sprites/fox_jump_back`), `sprites/player_hit` (4 frames), `sprites/mon_<kind>` (4 frames
each: chargeback exception falloff nonusage retail360), `sprites/orb_<xm|tab|watch|tsheet>`,
`sprites/barrier_low`, `sprites/bg_smokies`, `sprites/bg_chicago`, `sprites/scen_<barn|flag|ltrain|pine|sign|tree|turbine|walkup>`.
`SPRITE_META[name]` = {w, h, frames, ax, ay, aspect, unitsHigh, anchor}. Strips are horizontal.
Coming from the ART agent (may or may not exist when you test — always fall back gracefully):
`sky/01_smoky_dawn` … `sky/12_the_loop` (21:9 painted panoramas, horizon ~62–65% down),
`sprites/fox_jump_back`, `sprites/fox_boost_back`, `ui/pow_magnet`, `ui/pow_x2`, `ui/pow_boost`.

## 8. Testing — you MUST look at your own output

```
python3 tools/shot.py --entry harness/<you>.js --name <you> --w 390 --h 844 --wait 5 --advance 2 --shots 3
```
builds `scratch/<you>/<you>.html` and writes `scratch/<you>/shot-N.png`; prints console errors.
Headless Chromium uses SwiftShader: real-time rAF runs at only a few fps, so drive time with
`window.__app.advance(seconds)` (the `--advance` flag does this before each shot). Use `--eval`
to set up states (e.g. `"__sim.forceTheme(10)"` if your harness exposes `window.__sim`).
**Read the PNGs with the Read tool and iterate until it looks genuinely good** — agents that only
ran assertions shipped bugs they could not see. Also check 844×390 and 1440×900. Zero console
errors is required. Keep a couple of your best screenshots in `scratch/<you>/` and cite them.

## 9. Final report (≤ 500 words)
Files you own + one line each · the exact public API as implemented · anything main.js must do
(call order, required setup) · deviations from this contract · known issues · best screenshot paths.
