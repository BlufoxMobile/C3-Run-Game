// BUILD — bundles an entry (default src/main.js) into ONE html file with inline JS+CSS.
// Images are NOT inlined: they stay as files under assets/ and load at runtime through
// src/core/assets.js. The build writes the asset manifest into the bundle
// (import MANIFEST from 'virtual:asset-manifest').
//
//   node build.mjs                                   -> dist/index.html + dist/assets/ (copied)
//   node build.mjs harness/world.js scratch/world/world.html --dev
//                                                    -> that html + a symlink scratch/world/assets -> ../../assets
// Flags: --dev (no minify, __DEV__=true)   --shell <file> (default src/shell.html)
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';

const argv = process.argv.slice(2);
const flags = new Set(argv.filter(a => a.startsWith('--')));
const pos = argv.filter((a, i) => !a.startsWith('--') && !(argv[i - 1] === '--shell'));
const shellIdx = argv.indexOf('--shell');
const entry = pos[0] || 'src/main.js';
const out = pos[1] || 'dist/index.html';
const dev = flags.has('--dev');
const shellPath = shellIdx >= 0 ? argv[shellIdx + 1] : 'src/shell.html';
const ROOT = path.dirname(new URL(import.meta.url).pathname);

function walk(dir) {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap(d =>
    d.isDirectory() ? walk(path.join(dir, d.name)) : [path.join(dir, d.name)]);
}
const assetDir = path.join(ROOT, 'assets');
const files = walk(assetDir).filter(f => /\.(webp|png|jpe?g)$/i.test(f)).sort();
const assets = files.map(f => {
  const rel = path.relative(assetDir, f).split(path.sep).join('/');
  return { key: rel.replace(/\.(webp|png|jpe?g)$/i, ''), url: 'assets/' + rel, bytes: fs.statSync(f).size };
});
let sprites = {};
try { sprites = JSON.parse(fs.readFileSync(path.join(assetDir, 'sprites/manifest.json'), 'utf8')).sprites; } catch (e) {}

const manifestPlugin = {
  name: 'asset-manifest',
  setup(b) {
    b.onResolve({ filter: /^virtual:asset-manifest$/ }, a => ({ path: a.path, namespace: 'am' }));
    b.onLoad({ filter: /.*/, namespace: 'am' }, () => ({
      contents: 'export default ' + JSON.stringify({ assets, sprites }), loader: 'js',
    }));
  },
};

const res = await esbuild.build({
  entryPoints: [path.join(ROOT, entry)],
  bundle: true, write: false, format: 'iife', outdir: path.join(ROOT, '.esb'),
  minify: !dev, sourcemap: false, target: ['es2020', 'safari15', 'chrome90', 'firefox90'],
  loader: { '.css': 'css', '.glsl': 'text', '.vert': 'text', '.frag': 'text' },
  define: { __DEV__: dev ? 'true' : 'false' },
  legalComments: 'none', logLevel: 'warning',
  plugins: [manifestPlugin],
});
let js = '', css = '';
for (const f of res.outputFiles) {
  if (f.path.endsWith('.js')) js += f.text;
  else if (f.path.endsWith('.css')) css += f.text;
}
let shell = fs.readFileSync(path.join(ROOT, shellPath), 'utf8');
js = js.replace(/<\/script/gi, '<\\/script');
if (!shell.includes('<!--JS-->')) throw new Error('shell is missing <!--JS--> marker');
shell = shell.replace('<!--CSS-->', () => css ? `<style>${css}</style>` : '');
shell = shell.replace('<!--JS-->', () => `<script>${js}</script>`);

const outAbs = path.join(ROOT, out);
fs.mkdirSync(path.dirname(outAbs), { recursive: true });
fs.writeFileSync(outAbs, shell);

// make assets/ reachable next to the html
const outAssets = path.join(path.dirname(outAbs), 'assets');
const isDist = path.relative(ROOT, path.dirname(outAbs)) === 'dist';
if (isDist) {
  fs.rmSync(outAssets, { recursive: true, force: true });
  for (const a of assets) {
    const dst = path.join(path.dirname(outAbs), a.url);
    fs.mkdirSync(path.dirname(dst), { recursive: true });
    fs.copyFileSync(path.join(assetDir, a.url.slice('assets/'.length)), dst);
  }
} else if (path.resolve(outAssets) !== path.resolve(assetDir)) {
  try { fs.lstatSync(outAssets); } catch (e) { fs.symlinkSync(path.relative(path.dirname(outAbs), assetDir), outAssets); }
}
const kb = n => (n / 1024).toFixed(0) + ' KB';
const assetBytes = assets.reduce((s, a) => s + a.bytes, 0);
console.log(`built ${out}  html ${kb(shell.length)} (js ${kb(js.length)}, css ${kb(css.length)})  assets ${assets.length} files ${kb(assetBytes)}${dev ? '  [dev]' : ''}`);
